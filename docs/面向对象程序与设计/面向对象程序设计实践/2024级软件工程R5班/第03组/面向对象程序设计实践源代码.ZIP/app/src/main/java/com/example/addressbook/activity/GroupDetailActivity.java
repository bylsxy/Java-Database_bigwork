package com.example.addressbook.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.addressbook.R;
import com.example.addressbook.adapter.ContactAdapter;
import com.example.addressbook.model.Contact;
import com.example.addressbook.model.Group;
import com.example.addressbook.service.ContactService;
import com.example.addressbook.service.GroupService;
import com.google.android.material.appbar.MaterialToolbar;

import java.util.List;

public class GroupDetailActivity extends AppCompatActivity {

    public static final String EXTRA_GROUP_ID = "group_id";

    private ContactService contactService;
    private GroupService groupService;
    private ContactAdapter contactAdapter;
    private int groupId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_detail);

        groupId = getIntent().getIntExtra(EXTRA_GROUP_ID, -1);
        contactService = new ContactService(this);
        groupService = new GroupService(this);

        Group group = groupService.getGroupById(groupId);
        if (group == null) {
            Toast.makeText(this, R.string.no_groups, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setupToolbar(group);
        setupContacts();
        renderGroup(group);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Group group = groupService.getGroupById(groupId);
        if (group == null) {
            finish();
            return;
        }
        renderGroup(group);
    }

    private void setupToolbar(Group group) {
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.group_detail_title);
        toolbar.setSubtitle(group.getName());
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void setupContacts() {
        RecyclerView recyclerView = findViewById(R.id.recyclerViewContacts);
        contactAdapter = new ContactAdapter();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(contactAdapter);

        contactAdapter.setOnItemClickListener(contact -> {
            Intent intent = new Intent(this, ContactDetailActivity.class);
            intent.putExtra(ContactDetailActivity.EXTRA_CONTACT_ID, contact.getId());
            startActivity(intent);
        });

        contactAdapter.setOnCallClickListener(contact -> {
            String phone = contact.getPrimaryPhone();
            if (!phone.isEmpty()) {
                startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone)));
            } else {
                Toast.makeText(this, R.string.no_phone, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void renderGroup(Group group) {
        List<Contact> contacts = contactService.getContactsByGroup(group.getId());
        TextView tvGroupName = findViewById(R.id.tvGroupName);
        TextView tvGroupSummary = findViewById(R.id.tvGroupSummary);
        RecyclerView recyclerView = findViewById(R.id.recyclerViewContacts);
        View emptyView = findViewById(R.id.emptyView);

        tvGroupName.setText(group.getName());
        tvGroupSummary.setText(getString(R.string.group_detail_summary, contacts.size()));
        contactAdapter.setContacts(contacts);

        boolean empty = contacts.isEmpty();
        recyclerView.setVisibility(empty ? View.GONE : View.VISIBLE);
        emptyView.setVisibility(empty ? View.VISIBLE : View.GONE);
    }
}
