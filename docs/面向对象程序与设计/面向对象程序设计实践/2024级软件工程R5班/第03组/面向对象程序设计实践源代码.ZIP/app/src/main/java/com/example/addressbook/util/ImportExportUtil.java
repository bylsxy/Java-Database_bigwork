package com.example.addressbook.util;
//ImportExportUtil 是导入导出工具类，负责 CSV 和 vCard 的解析与生成。它把文件内容转换成 Contact 对象，也能把联系人列表导出成文件格式。这个类让导入导出逻辑不混在 Activity 里
import com.example.addressbook.model.Contact;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;
import org.apache.commons.csv.CSVRecord;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ImportExportUtil {

    private static final String[] CSV_HEADERS = {
            "id", "name", "phone", "mobile", "email", "homepage",
            "birthday", "company", "address", "postcode", "groupId", "remark",
            "photoPath", "private", "relationshipTag", "followUpDate",
            "imTool", "imAccount"
    };

    public static void exportToCSV(List<Contact> contacts, OutputStream out) throws Exception {
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8));
        writer.write('\uFEFF');
        try (CSVPrinter printer = new CSVPrinter(writer, CSVFormat.DEFAULT.builder()
                .setHeader(CSV_HEADERS)
                .build())) {
            for (Contact contact : contacts) {
                printer.printRecord(
                        contact.getId(),
                        contact.getName(),
                        contact.getPhone(),
                        contact.getMobile(),
                        contact.getEmail(),
                        contact.getHomepage(),
                        contact.getBirthday(),
                        contact.getCompany(),
                        contact.getAddress(),
                        contact.getPostcode(),
                        contact.getGroupId(),
                        contact.getRemark(),
                        contact.getPhotoPath(),
                        contact.isPrivateContact() ? "1" : "0",
                        contact.getRelationshipTag(),
                        contact.getFollowUpDate(),
                        contact.getImTool(),
                        contact.getImAccount()
                );
            }
            printer.flush();
        }
    }

    public static List<Contact> importFromCSV(InputStream in) throws Exception {
        List<Contact> contacts = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));

        try (CSVParser parser = new CSVParser(reader, CSVFormat.DEFAULT.builder()
                .setHeader(CSV_HEADERS)
                .setSkipHeaderRecord(true)
                .build())) {

            for (CSVRecord record : parser) {
                Contact contact = new Contact();

                String idStr = getRecordValue(record, "id");
                if (idStr != null && !idStr.isEmpty()) {
                    try {
                        contact.setId(Integer.parseInt(idStr));
                    } catch (NumberFormatException ignored) {
                    }
                }

                contact.setName(getRecordValue(record, "name"));
                contact.setPhone(getRecordValue(record, "phone"));
                contact.setMobile(getRecordValue(record, "mobile"));
                contact.setImTool(getRecordValue(record, "imTool"));
                contact.setImAccount(getRecordValue(record, "imAccount"));
                contact.setEmail(getRecordValue(record, "email"));
                contact.setHomepage(getRecordValue(record, "homepage"));
                contact.setBirthday(normalizeBirthday(getRecordValue(record, "birthday")));
                contact.setCompany(getRecordValue(record, "company"));
                contact.setAddress(getRecordValue(record, "address"));
                contact.setPostcode(getRecordValue(record, "postcode"));
                contact.setRemark(getRecordValue(record, "remark"));
                contact.setPhotoPath(getRecordValue(record, "photoPath"));
                contact.setPrivateContact(parseBoolean(getRecordValue(record, "private")));
                contact.setRelationshipTag(getRecordValue(record, "relationshipTag"));
                contact.setFollowUpDate(normalizeBirthday(getRecordValue(record, "followUpDate")));

                String groupIdStr = getRecordValue(record, "groupId");
                if (groupIdStr != null && !groupIdStr.isEmpty()) {
                    try {
                        contact.setGroupId(Integer.parseInt(groupIdStr));
                    } catch (NumberFormatException ignored) {
                    }
                }

                if (contact.getName() != null && !contact.getName().trim().isEmpty()) {
                    contacts.add(contact);
                }
            }
        }

        return contacts;
    }

    public static void exportToVCard(List<Contact> contacts, OutputStream out) throws Exception {
        try (BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(out, StandardCharsets.UTF_8))) {
            for (Contact contact : contacts) {
                writer.write("BEGIN:VCARD");
                writer.newLine();
                writer.write("VERSION:3.0");
                writer.newLine();

                String name = contact.getName() != null ? contact.getName() : "";
                String lastName = "";
                String firstName = name;
                if (name.length() > 1) {
                    lastName = name.substring(0, 1);
                    firstName = name.substring(1);
                } else if (name.length() == 1) {
                    lastName = name;
                    firstName = "";
                }

                writer.write("N:" + escapeVCard(lastName) + ";" + escapeVCard(firstName) + ";;;");
                writer.newLine();
                writer.write("FN:" + escapeVCard(name));
                writer.newLine();

                if (contact.getPhone() != null && !contact.getPhone().isEmpty()) {
                    writer.write("TEL:" + escapeVCard(contact.getPhone()));
                    writer.newLine();
                }

                if (contact.getMobile() != null && !contact.getMobile().isEmpty()) {
                    writer.write("TEL;TYPE=CELL:" + escapeVCard(contact.getMobile()));
                    writer.newLine();
                }

                if (contact.getImTool() != null && !contact.getImTool().isEmpty()) {
                    writer.write("X-ADDRESSBOOK-IM-TOOL:" + escapeVCard(contact.getImTool()));
                    writer.newLine();
                }

                if (contact.getImAccount() != null && !contact.getImAccount().isEmpty()) {
                    writer.write("X-ADDRESSBOOK-IM-ACCOUNT:" + escapeVCard(contact.getImAccount()));
                    writer.newLine();
                }

                if (contact.getEmail() != null && !contact.getEmail().isEmpty()) {
                    writer.write("EMAIL:" + escapeVCard(contact.getEmail()));
                    writer.newLine();
                }

                if (contact.getHomepage() != null && !contact.getHomepage().isEmpty()) {
                    writer.write("URL:" + escapeVCard(contact.getHomepage()));
                    writer.newLine();
                }

                if (contact.getAddress() != null && !contact.getAddress().isEmpty()) {
                    writer.write("ADR:;;" + escapeVCard(contact.getAddress()) + ";;;;");
                    writer.newLine();
                }

                if (contact.getRemark() != null && !contact.getRemark().isEmpty()) {
                    writer.write("NOTE:" + escapeVCard(contact.getRemark()));
                    writer.newLine();
                }

                if (contact.getBirthday() != null && !contact.getBirthday().isEmpty()) {
                    writer.write("BDAY:" + escapeVCard(contact.getBirthday()));
                    writer.newLine();
                }

                if (contact.getCompany() != null && !contact.getCompany().isEmpty()) {
                    writer.write("ORG:" + escapeVCard(contact.getCompany()));
                    writer.newLine();
                }

                if (contact.getPhotoPath() != null && !contact.getPhotoPath().isEmpty()) {
                    writer.write("PHOTO;VALUE=URI:" + escapeVCard(contact.getPhotoPath()));
                    writer.newLine();
                }

                if (contact.getGroupId() > 0) {
                    writer.write("X-ADDRESSBOOK-GROUP-ID:" + contact.getGroupId());
                    writer.newLine();
                }

                writer.write("X-ADDRESSBOOK-PRIVATE:" + (contact.isPrivateContact() ? "1" : "0"));
                writer.newLine();

                if (contact.getRelationshipTag() != null && !contact.getRelationshipTag().isEmpty()) {
                    writer.write("X-ADDRESSBOOK-RELATIONSHIP:" + escapeVCard(contact.getRelationshipTag()));
                    writer.newLine();
                }

                if (contact.getFollowUpDate() != null && !contact.getFollowUpDate().isEmpty()) {
                    writer.write("X-ADDRESSBOOK-FOLLOW-UP:" + escapeVCard(contact.getFollowUpDate()));
                    writer.newLine();
                }

                writer.write("END:VCARD");
                writer.newLine();
            }
            writer.flush();
        }
    }

    public static List<Contact> importFromVCard(InputStream in) throws Exception {
        List<Contact> contacts = new ArrayList<>();
        BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));

        String line;
        Contact currentContact = null;

        while ((line = reader.readLine()) != null) {
            line = line.trim();

            if (line.equalsIgnoreCase("BEGIN:VCARD")) {
                currentContact = new Contact();
                continue;
            }

            if (line.equalsIgnoreCase("END:VCARD")) {
                if (currentContact != null
                        && currentContact.getName() != null
                        && !currentContact.getName().trim().isEmpty()) {
                    contacts.add(currentContact);
                }
                currentContact = null;
                continue;
            }

            if (currentContact == null) {
                continue;
            }

            String upperLine = line.toUpperCase(Locale.ROOT);

            if (upperLine.startsWith("N:")) {
                String value = line.substring(2);
                String[] parts = value.split(";", -1);
                if (parts.length >= 2) {
                    String lastName = unescapeVCard(parts[0]).trim();
                    String firstName = unescapeVCard(parts[1]).trim();
                    if (!lastName.isEmpty() && !firstName.isEmpty()) {
                        currentContact.setName(lastName + firstName);
                    } else if (!lastName.isEmpty()) {
                        currentContact.setName(lastName);
                    } else {
                        currentContact.setName(firstName);
                    }
                } else if (parts.length == 1) {
                    currentContact.setName(unescapeVCard(parts[0]).trim());
                }
            } else if (upperLine.startsWith("FN:")) {
                String fullName = unescapeVCard(line.substring(3)).trim();
                if (currentContact.getName() == null || currentContact.getName().isEmpty()) {
                    currentContact.setName(fullName);
                }
            } else if (upperLine.startsWith("TEL;") && upperLine.contains("CELL")) {
                currentContact.setMobile(unescapeVCard(valueAfterColon(line)).trim());
            } else if (upperLine.startsWith("TEL;")) {
                String phone = unescapeVCard(valueAfterColon(line)).trim();
                if (currentContact.getPhone() == null || currentContact.getPhone().isEmpty()) {
                    currentContact.setPhone(phone);
                }
            } else if (upperLine.startsWith("TEL:")) {
                currentContact.setPhone(unescapeVCard(line.substring(4)).trim());
            } else if (upperLine.startsWith("X-ADDRESSBOOK-IM-TOOL:")) {
                currentContact.setImTool(unescapeVCard(valueAfterColon(line)).trim());
            } else if (upperLine.startsWith("X-ADDRESSBOOK-IM-ACCOUNT:")) {
                currentContact.setImAccount(unescapeVCard(valueAfterColon(line)).trim());
            } else if (upperLine.startsWith("EMAIL:")) {
                currentContact.setEmail(unescapeVCard(line.substring(6)).trim());
            } else if (upperLine.startsWith("URL:")) {
                currentContact.setHomepage(unescapeVCard(line.substring(4)).trim());
            } else if (upperLine.startsWith("ADR:")) {
                String value = line.substring(4).trim();
                String[] parts = value.split(";", -1);
                if (parts.length >= 3) {
                    currentContact.setAddress(unescapeVCard(parts[2]).trim());
                } else if (parts.length >= 1) {
                    currentContact.setAddress(unescapeVCard(parts[0]).trim());
                }
            } else if (upperLine.startsWith("NOTE:")) {
                currentContact.setRemark(unescapeVCard(line.substring(5)).trim());
            } else if (upperLine.startsWith("BDAY:")) {
                currentContact.setBirthday(normalizeBirthday(unescapeVCard(line.substring(5)).trim()));
            } else if (upperLine.startsWith("ORG:")) {
                currentContact.setCompany(unescapeVCard(line.substring(4)).trim());
            } else if (upperLine.startsWith("PHOTO")) {
                currentContact.setPhotoPath(unescapeVCard(valueAfterColon(line)).trim());
            } else if (upperLine.startsWith("X-ADDRESSBOOK-GROUP-ID:")) {
                try {
                    currentContact.setGroupId(Integer.parseInt(valueAfterColon(line).trim()));
                } catch (NumberFormatException ignored) {
                }
            } else if (upperLine.startsWith("X-ADDRESSBOOK-PRIVATE:")) {
                currentContact.setPrivateContact(parseBoolean(valueAfterColon(line)));
            } else if (upperLine.startsWith("X-ADDRESSBOOK-RELATIONSHIP:")) {
                currentContact.setRelationshipTag(unescapeVCard(valueAfterColon(line)).trim());
            } else if (upperLine.startsWith("X-ADDRESSBOOK-FOLLOW-UP:")) {
                currentContact.setFollowUpDate(normalizeBirthday(unescapeVCard(valueAfterColon(line)).trim()));
            }
        }

        return contacts;
    }

    private static String getRecordValue(CSVRecord record, String key) {
        try {
            String value = record.get(key);
            return (value != null && !value.trim().isEmpty()) ? value.trim() : null;
        } catch (RuntimeException e) {
            return null;
        }
    }

    private static boolean parseBoolean(String value) {
        if (value == null) {
            return false;
        }
        String normalized = value.trim().toLowerCase(Locale.ROOT);
        return "1".equals(normalized)
                || "true".equals(normalized)
                || "yes".equals(normalized)
                || "y".equals(normalized);
    }

    private static String valueAfterColon(String line) {
        int index = line.indexOf(':');
        return index >= 0 && index + 1 < line.length() ? line.substring(index + 1) : "";
    }

    private static String escapeVCard(String value) {
        if (value == null) {
            return "";
        }
        return value.replace("\\", "\\\\")
                .replace("\n", "\\n")
                .replace("\r", "")
                .replace(";", "\\;")
                .replace(",", "\\,");
    }

    private static String unescapeVCard(String value) {
        if (value == null) {
            return null;
        }

        StringBuilder builder = new StringBuilder();
        boolean escaping = false;
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (escaping) {
                if (c == 'n' || c == 'N') {
                    builder.append('\n');
                } else {
                    builder.append(c);
                }
                escaping = false;
            } else if (c == '\\') {
                escaping = true;
            } else {
                builder.append(c);
            }
        }
        if (escaping) {
            builder.append('\\');
        }
        return builder.toString();
    }

    private static String normalizeBirthday(String birthday) {
        if (birthday == null) {
            return null;
        }

        String normalized = birthday.trim();
        if (normalized.isEmpty()) {
            return null;
        }

        if (normalized.matches("^\\d{8}$")) {
            normalized = normalized.substring(0, 4) + "-"
                    + normalized.substring(4, 6) + "-"
                    + normalized.substring(6, 8);
        } else if (normalized.matches("^\\d{4}[/.]\\d{2}[/.]\\d{2}$")) {
            normalized = normalized.replace('/', '-').replace('.', '-');
        }

        return normalized.matches("^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])$") ? normalized : null;
    }
}
