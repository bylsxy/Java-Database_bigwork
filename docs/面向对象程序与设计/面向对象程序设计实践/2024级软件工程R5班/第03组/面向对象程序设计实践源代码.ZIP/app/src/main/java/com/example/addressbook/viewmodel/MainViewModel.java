package com.example.addressbook.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.addressbook.model.Contact;
import com.example.addressbook.model.Group;
import com.example.addressbook.service.ContactService;
import com.example.addressbook.service.GroupService;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 主界面 ViewModel
 * 管理联系人列表和分组数据的加载、搜索、筛选
 */
public class MainViewModel extends AndroidViewModel {

    private final ContactService contactService;
    private final GroupService groupService;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private final MutableLiveData<List<Contact>> contactsLiveData = new MutableLiveData<>();
    private final MutableLiveData<List<Group>> groupsLiveData = new MutableLiveData<>();

    public MainViewModel(@NonNull Application application) {
        super(application);
        contactService = new ContactService(application);
        groupService = new GroupService(application);
    }

    public LiveData<List<Contact>> getContacts() {
        return contactsLiveData;
    }

    public LiveData<List<Group>> getGroups() {
        return groupsLiveData;
    }

    public void refreshContacts() {
        executor.execute(() -> {
            List<Contact> contacts = contactService.getAllContacts();
            contactsLiveData.postValue(contacts);
        });
    }

    public void refreshGroups() {
        executor.execute(() -> {
            List<Group> groups = groupService.getAllGroups();
            groupsLiveData.postValue(groups);
        });
    }

    public void search(String keyword) {
        executor.execute(() -> {
            List<Contact> contacts = contactService.searchContacts(keyword);
            contactsLiveData.postValue(contacts);
        });
    }

    public void clearSearch() {
        executor.execute(() -> {
            List<Contact> contacts = contactService.getAllContacts();
            contactsLiveData.postValue(contacts);
        });
    }

    public void filterByGroup(int groupId) {
        executor.execute(() -> {
            List<Contact> contacts = contactService.getContactsByGroup(groupId);
            contactsLiveData.postValue(contacts);
        });
    }

    public void filterByUngrouped() {
        executor.execute(() -> {
            List<Contact> contacts = contactService.getUngroupedContacts();
            contactsLiveData.postValue(contacts);
        });
    }

    public void sortByRecent() {
        executor.execute(() -> {
            List<Contact> contacts = contactService.getContactsSortedByRecent();
            contactsLiveData.postValue(contacts);
        });
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        executor.shutdown();
    }
}
