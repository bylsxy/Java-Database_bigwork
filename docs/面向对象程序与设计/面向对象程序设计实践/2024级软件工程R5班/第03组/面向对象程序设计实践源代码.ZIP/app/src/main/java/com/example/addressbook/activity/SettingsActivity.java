package com.example.addressbook.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import com.example.addressbook.R;
import com.example.addressbook.util.AppPreferences;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textfield.TextInputEditText;

import java.util.concurrent.Executor;

public class SettingsActivity extends AppCompatActivity {

    private static final int SYSTEM_AUTHENTICATORS =
            BiometricManager.Authenticators.BIOMETRIC_WEAK
                    | BiometricManager.Authenticators.DEVICE_CREDENTIAL;

    private Switch switchBirthdayReminder;
    private Switch switchExtendedFields;
    private Switch switchCompactMode;
    private Switch switchFollowUpAlerts;
    private TextView tvPrivacyModeDesc;
    private TextView tvPrivacyPinDesc;
    private TextView tvThemeStyleDesc;
    private TextView tvListSecondaryFieldDesc;
    private TextView tvLockPrivateTitle;
    private TextView tvLockPrivateDesc;
    private MaterialToolbar toolbar;
    private View rootSettings;
    private View settingsScroll;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        initViews();
        setupToolbar();
        bindValues();
        setupActions();
    }

    private void initViews() {
        switchBirthdayReminder = findViewById(R.id.switchBirthdayReminder);
        switchExtendedFields = findViewById(R.id.switchExtendedFields);
        switchCompactMode = findViewById(R.id.switchCompactMode);
        switchFollowUpAlerts = findViewById(R.id.switchFollowUpAlerts);
        tvPrivacyModeDesc = findViewById(R.id.tvPrivacyModeDesc);
        tvPrivacyPinDesc = findViewById(R.id.tvPrivacyPinDesc);
        tvThemeStyleDesc = findViewById(R.id.tvThemeStyleDesc);
        tvListSecondaryFieldDesc = findViewById(R.id.tvListSecondaryFieldDesc);
        tvLockPrivateTitle = findViewById(R.id.tvLockPrivateTitle);
        tvLockPrivateDesc = findViewById(R.id.tvLockPrivateDesc);
        rootSettings = findViewById(R.id.rootSettings);
        settingsScroll = findViewById(R.id.settingsScroll);
    }

    private void setupToolbar() {
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.settings_title);
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void bindValues() {
        switchBirthdayReminder.setChecked(AppPreferences.isBirthdayReminderEnabled(this));
        switchExtendedFields.setChecked(AppPreferences.showExtendedFields(this));
        switchCompactMode.setChecked(AppPreferences.isCompactModeEnabled(this));
        switchFollowUpAlerts.setChecked(AppPreferences.isFollowUpAlertsEnabled(this));
        tvPrivacyModeDesc.setText(getPrivacyModeLabel(AppPreferences.getPrivacyMode(this)));
        tvPrivacyPinDesc.setText(getPrivacyCredentialSummary());
        tvThemeStyleDesc.setText(getThemeStyleLabel(AppPreferences.getThemeStyle(this)));
        tvListSecondaryFieldDesc.setText(getListSecondaryFieldLabel(AppPreferences.getListSecondaryField(this)));
        bindLockPrivateState();
        applyThemeStyle();
    }

    private void setupActions() {
        switchBirthdayReminder.setOnCheckedChangeListener((buttonView, isChecked) ->
                AppPreferences.setBirthdayReminderEnabled(this, isChecked));

        switchExtendedFields.setOnCheckedChangeListener((buttonView, isChecked) ->
                AppPreferences.setShowExtendedFields(this, isChecked));

        switchCompactMode.setOnCheckedChangeListener((buttonView, isChecked) ->
                AppPreferences.setCompactModeEnabled(this, isChecked));

        switchFollowUpAlerts.setOnCheckedChangeListener((buttonView, isChecked) ->
                AppPreferences.setFollowUpAlertsEnabled(this, isChecked));

        findViewById(R.id.cardPrivacyMode).setOnClickListener(v -> showPrivacyModeDialog());
        findViewById(R.id.cardCredentialEditor).setOnClickListener(v -> verifyBeforeCredentialChange());
        findViewById(R.id.cardLockPrivate).setOnClickListener(v -> togglePrivateLock());
        findViewById(R.id.cardThemeStyle).setOnClickListener(v -> showThemeStyleDialog());
        findViewById(R.id.cardListSecondaryField).setOnClickListener(v -> showListSecondaryFieldDialog());
        findViewById(R.id.cardReplayGuide).setOnClickListener(v ->
                startActivity(new Intent(this, OnboardingActivity.class)));
    }

    private void bindLockPrivateState() {
        String mode = AppPreferences.getPrivacyMode(this);
        if (AppPreferences.PRIVACY_MODE_NONE.equals(mode)) {
            AppPreferences.unlockPrivateContacts(this);
            tvLockPrivateTitle.setText(R.string.settings_lock_not_needed);
            tvLockPrivateDesc.setText(R.string.settings_lock_not_needed_desc);
            return;
        }

        boolean canLock = AppPreferences.hasUsablePrivacyCredential(this);
        boolean unlocked = AppPreferences.isPrivacyUnlocked(this);
        if (!canLock || unlocked) {
            tvLockPrivateTitle.setText(R.string.settings_lock_private);
            tvLockPrivateDesc.setText(canLock
                    ? R.string.settings_lock_private_desc
                    : R.string.settings_lock_requires_credential);
        } else {
            tvLockPrivateTitle.setText(R.string.settings_unlock_private);
            tvLockPrivateDesc.setText(R.string.settings_unlock_private_desc);
        }
    }

    private void togglePrivateLock() {
        if (AppPreferences.PRIVACY_MODE_NONE.equals(AppPreferences.getPrivacyMode(this))) {
            AppPreferences.unlockPrivateContacts(this);
            bindValues();
            return;
        }

        if (!AppPreferences.hasUsablePrivacyCredential(this)) {
            AppPreferences.unlockPrivateContacts(this);
            bindValues();
            Toast.makeText(this, R.string.settings_lock_requires_credential, Toast.LENGTH_SHORT).show();
            return;
        }

        verifyCurrentPrivacyMode(() -> {
            if (AppPreferences.isPrivacyUnlocked(this)) {
                AppPreferences.lockPrivateContacts(this);
                Toast.makeText(this, R.string.settings_locked, Toast.LENGTH_SHORT).show();
            } else {
                AppPreferences.unlockPrivateContacts(this);
                Toast.makeText(this, R.string.settings_unlocked, Toast.LENGTH_SHORT).show();
            }
            bindValues();
        });
    }

    private void showPrivacyModeDialog() {
        String[] labels = {
                getString(R.string.settings_privacy_mode_system),
                getString(R.string.settings_privacy_mode_pin),
                getString(R.string.settings_privacy_mode_none)
        };
        String[] values = {
                AppPreferences.PRIVACY_MODE_SYSTEM,
                AppPreferences.PRIVACY_MODE_PIN,
                AppPreferences.PRIVACY_MODE_NONE
        };

        new AlertDialog.Builder(this)
                .setTitle(R.string.settings_privacy_mode)
                .setItems(labels, (dialog, which) -> {
                    AppPreferences.setPrivacyMode(this, values[which]);
                    bindValues();
                })
                .show();
    }

    private void verifyBeforeCredentialChange() {
        String mode = AppPreferences.getPrivacyMode(this);
        boolean hasExistingPin = AppPreferences.PRIVACY_MODE_PIN.equals(mode)
                && AppPreferences.hasPrivacyPin(this);
        if (hasExistingPin) {
            showExistingCredentialVerifyDialog(mode);
        } else {
            showCredentialEditor(mode);
        }
    }

    private void showExistingCredentialVerifyDialog(String mode) {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_single_input, null);
        TextView tvHint = dialogView.findViewById(R.id.tvDialogHint);
        TextInputEditText editText = dialogView.findViewById(R.id.etDialogInput);
        tvHint.setVisibility(View.VISIBLE);
        tvHint.setText(R.string.settings_identity_verify_desc);
        editText.setHint(R.string.settings_privacy_pin_hint);
        editText.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);

        new AlertDialog.Builder(this)
                .setTitle(R.string.settings_identity_verify)
                .setView(dialogView)
                .setPositiveButton(R.string.confirm, (dialog, which) -> {
                    String input = editText.getText() != null ? editText.getText().toString().trim() : "";
                    boolean verified = AppPreferences.matchesPrivacyPin(this, input);
                    if (verified) {
                        Toast.makeText(this, R.string.settings_privacy_auth_success, Toast.LENGTH_SHORT).show();
                        showCredentialEditor(mode);
                    } else {
                        Toast.makeText(this, R.string.settings_privacy_auth_failed, Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showCredentialEditor(String mode) {
        if (AppPreferences.PRIVACY_MODE_NONE.equals(mode)) {
            AppPreferences.clearPrivacyCredentials(this);
            bindValues();
            return;
        }

        if (AppPreferences.PRIVACY_MODE_SYSTEM.equals(mode)) {
            showSystemAuthPrompt(() -> {
                Toast.makeText(this, R.string.settings_privacy_auth_success, Toast.LENGTH_SHORT).show();
                bindValues();
            });
            return;
        }

        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_single_input, null);
        TextView tvHint = dialogView.findViewById(R.id.tvDialogHint);
        TextInputEditText editText = dialogView.findViewById(R.id.etDialogInput);
        tvHint.setVisibility(View.GONE);
        editText.setHint(R.string.settings_privacy_pin_hint);
        editText.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);

        new AlertDialog.Builder(this)
                .setTitle(R.string.settings_privacy_config_title)
                .setView(dialogView)
                .setPositiveButton(R.string.save, (dialog, which) -> {
                    String value = editText.getText() != null ? editText.getText().toString().trim() : "";
                    if (value.isEmpty()) {
                        AppPreferences.clearPrivacyCredentials(this);
                        Toast.makeText(this, R.string.settings_privacy_pin_cleared, Toast.LENGTH_SHORT).show();
                        bindValues();
                        return;
                    }

                    boolean success = AppPreferences.savePrivacyPin(this, value);
                    if (success) {
                        Toast.makeText(this, R.string.settings_privacy_pin_saved, Toast.LENGTH_SHORT).show();
                        bindValues();
                    } else {
                        Toast.makeText(this, R.string.settings_privacy_pin_invalid, Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showThemeStyleDialog() {
        String[] labels = {
                getString(R.string.settings_theme_light),
                getString(R.string.settings_theme_soft),
                getString(R.string.settings_theme_clear)
        };
        String[] values = {
                AppPreferences.THEME_STYLE_LIGHT,
                AppPreferences.THEME_STYLE_SOFT,
                AppPreferences.THEME_STYLE_CLEAR
        };
        new AlertDialog.Builder(this)
                .setTitle(R.string.settings_theme_style)
                .setItems(labels, (dialog, which) -> {
                    AppPreferences.setThemeStyle(this, values[which]);
                    tvThemeStyleDesc.setText(labels[which]);
                    applyThemeStyle();
                })
                .show();
    }

    private void showListSecondaryFieldDialog() {
        String[] labels = {
                getString(R.string.settings_list_field_phone),
                getString(R.string.settings_list_field_email),
                getString(R.string.settings_list_field_im),
                getString(R.string.settings_list_field_company),
                getString(R.string.settings_list_field_group)
        };
        String[] values = {
                AppPreferences.LIST_FIELD_PHONE,
                AppPreferences.LIST_FIELD_EMAIL,
                AppPreferences.LIST_FIELD_IM,
                AppPreferences.LIST_FIELD_COMPANY,
                AppPreferences.LIST_FIELD_GROUP
        };
        new AlertDialog.Builder(this)
                .setTitle(R.string.settings_list_secondary_field)
                .setItems(labels, (dialog, which) -> {
                    AppPreferences.setListSecondaryField(this, values[which]);
                    tvListSecondaryFieldDesc.setText(labels[which]);
                })
                .show();
    }

    private void showSystemAuthPrompt(Runnable onSuccess) {
        BiometricManager biometricManager = BiometricManager.from(this);
        int canAuthenticate = biometricManager.canAuthenticate(SYSTEM_AUTHENTICATORS);
        if (canAuthenticate != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, R.string.settings_system_auth_unavailable, Toast.LENGTH_SHORT).show();
            return;
        }

        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt biometricPrompt = new BiometricPrompt(this, executor,
                new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                        super.onAuthenticationSucceeded(result);
                        onSuccess.run();
                    }

                    @Override
                    public void onAuthenticationError(int errorCode, CharSequence errString) {
                        super.onAuthenticationError(errorCode, errString);
                        if (errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON
                                && errorCode != BiometricPrompt.ERROR_USER_CANCELED
                                && errorCode != BiometricPrompt.ERROR_CANCELED) {
                            Toast.makeText(SettingsActivity.this, errString, Toast.LENGTH_SHORT).show();
                        }
                    }
                });

        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle(getString(R.string.private_contact_verify))
                .setSubtitle(getString(R.string.private_contact_system_auth))
                .setAllowedAuthenticators(SYSTEM_AUTHENTICATORS)
                .build();
        biometricPrompt.authenticate(promptInfo);
    }

    private void verifyCurrentPrivacyMode(Runnable onSuccess) {
        String mode = AppPreferences.getPrivacyMode(this);
        if (AppPreferences.PRIVACY_MODE_SYSTEM.equals(mode)) {
            showSystemAuthPrompt(onSuccess);
            return;
        }
        if (AppPreferences.PRIVACY_MODE_PIN.equals(mode)) {
            View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_single_input, null);
            TextView tvHint = dialogView.findViewById(R.id.tvDialogHint);
            TextInputEditText editText = dialogView.findViewById(R.id.etDialogInput);
            tvHint.setVisibility(View.VISIBLE);
            tvHint.setText(R.string.settings_identity_verify_desc);
            editText.setHint(R.string.settings_privacy_pin_hint);
            editText.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);

            new AlertDialog.Builder(this)
                    .setTitle(R.string.settings_identity_verify)
                    .setView(dialogView)
                    .setPositiveButton(R.string.confirm, (dialog, which) -> {
                        String input = editText.getText() != null ? editText.getText().toString().trim() : "";
                        if (AppPreferences.matchesPrivacyPin(this, input)) {
                            onSuccess.run();
                        } else {
                            Toast.makeText(this, R.string.settings_privacy_auth_failed, Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton(R.string.cancel, null)
                    .show();
            return;
        }
        onSuccess.run();
    }

    private void applyThemeStyle() {
        String style = AppPreferences.getThemeStyle(this);
        int background;
        int toolbarColor;
        if (AppPreferences.THEME_STYLE_SOFT.equals(style)) {
            background = Color.rgb(255, 248, 240);
            toolbarColor = Color.rgb(255, 251, 246);
        } else if (AppPreferences.THEME_STYLE_CLEAR.equals(style)) {
            background = Color.rgb(239, 246, 255);
            toolbarColor = Color.rgb(248, 251, 255);
        } else {
            background = getResources().getColor(R.color.colorBackground, null);
            toolbarColor = getResources().getColor(R.color.colorToolbarSurface, null);
        }
        getWindow().getDecorView().setBackgroundColor(background);
        rootSettings.setBackgroundColor(background);
        settingsScroll.setBackgroundColor(background);
        toolbar.setBackgroundColor(toolbarColor);
    }

    private int getThemeStyleLabel(String style) {
        if (AppPreferences.THEME_STYLE_SOFT.equals(style)) {
            return R.string.settings_theme_soft;
        }
        if (AppPreferences.THEME_STYLE_CLEAR.equals(style)) {
            return R.string.settings_theme_clear;
        }
        return R.string.settings_theme_light;
    }

    private int getListSecondaryFieldLabel(String field) {
        if (AppPreferences.LIST_FIELD_EMAIL.equals(field)) {
            return R.string.settings_list_field_email;
        }
        if (AppPreferences.LIST_FIELD_IM.equals(field)) {
            return R.string.settings_list_field_im;
        }
        if (AppPreferences.LIST_FIELD_COMPANY.equals(field)) {
            return R.string.settings_list_field_company;
        }
        if (AppPreferences.LIST_FIELD_GROUP.equals(field)) {
            return R.string.settings_list_field_group;
        }
        return R.string.settings_list_field_phone;
    }

    private int getPrivacyModeLabel(String mode) {
        if (AppPreferences.PRIVACY_MODE_SYSTEM.equals(mode)) {
            return R.string.settings_privacy_mode_system;
        }
        if (AppPreferences.PRIVACY_MODE_PIN.equals(mode)) {
            return R.string.settings_privacy_mode_pin;
        }
        return R.string.settings_privacy_mode_none;
    }

    private int getPrivacyCredentialSummary() {
        String mode = AppPreferences.getPrivacyMode(this);
        if (AppPreferences.PRIVACY_MODE_PIN.equals(mode) && AppPreferences.hasPrivacyPin(this)) {
            return R.string.settings_privacy_pin_enabled;
        }
        if (AppPreferences.PRIVACY_MODE_SYSTEM.equals(mode)) {
            return R.string.settings_privacy_mode_system;
        }
        return R.string.settings_privacy_pin_disabled;
    }
}
