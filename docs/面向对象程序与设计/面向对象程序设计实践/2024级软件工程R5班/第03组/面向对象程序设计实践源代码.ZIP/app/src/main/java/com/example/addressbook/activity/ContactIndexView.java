package com.example.addressbook.activity;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.annotation.Nullable;

import com.example.addressbook.R;

import java.util.HashSet;
import java.util.Set;

public class ContactIndexView extends View {

    public interface OnLetterSelectedListener {
        void onLetterSelected(String letter);
    }

    private static final String INDEX_SYMBOLS = "#ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Set<String> availableLetters = new HashSet<>();
    private OnLetterSelectedListener listener;

    public ContactIndexView(Context context) {
        super(context);
        init();
    }

    public ContactIndexView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ContactIndexView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setClickable(true);
        paint.setTextAlign(Paint.Align.CENTER);
    }

    public void setAvailableLetters(Set<String> letters) {
        availableLetters.clear();
        if (letters != null) {
            availableLetters.addAll(letters);
        }
        invalidate();
    }

    public void setOnLetterSelectedListener(OnLetterSelectedListener listener) {
        this.listener = listener;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int count = INDEX_SYMBOLS.length();
        if (count == 0 || getHeight() == 0) {
            return;
        }

        float rawSlotHeight = (getHeight() - getPaddingTop() - getPaddingBottom()) / (float) count;
        if (rawSlotHeight <= 0) {
            return;
        }
        float textSize = Math.max(8f, Math.min(13f * getResources().getDisplayMetrics().scaledDensity,
                rawSlotHeight * 0.68f));
        paint.setTextSize(textSize);
        Paint.FontMetrics metrics = paint.getFontMetrics();
        float baselineOffset = (metrics.bottom + metrics.top) / 2f;
        float centerX = getWidth() / 2f;
        float topCenter = getPaddingTop() + textSize;
        float bottomCenter = getHeight() - getPaddingBottom() - textSize * 0.7f;
        float slotHeight = count > 1 ? (bottomCenter - topCenter) / (float) (count - 1) : 0f;

        for (int i = 0; i < count; i++) {
            String letter = String.valueOf(INDEX_SYMBOLS.charAt(i));
            paint.setColor(getResources().getColor(
                    availableLetters.contains(letter)
                            ? R.color.colorPrimaryDark
                            : R.color.colorTextSecondary,
                    null));
            float centerY = topCenter + slotHeight * i;
            canvas.drawText(letter, centerX, centerY - baselineOffset, paint);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() != MotionEvent.ACTION_DOWN
                && event.getAction() != MotionEvent.ACTION_MOVE) {
            return true;
        }
        float textSize = Math.max(8f, Math.min(13f * getResources().getDisplayMetrics().scaledDensity,
                (getHeight() - getPaddingTop() - getPaddingBottom()) / (float) INDEX_SYMBOLS.length() * 0.68f));
        float topCenter = getPaddingTop() + textSize;
        float bottomCenter = getHeight() - getPaddingBottom() - textSize * 0.7f;
        float y = event.getY();
        int index = Math.max(0, Math.min(INDEX_SYMBOLS.length() - 1,
                Math.round((y - topCenter) / Math.max(1f, bottomCenter - topCenter)
                        * (INDEX_SYMBOLS.length() - 1))));
        if (listener != null) {
            listener.onLetterSelected(String.valueOf(INDEX_SYMBOLS.charAt(index)));
        }
        return true;
    }
}
