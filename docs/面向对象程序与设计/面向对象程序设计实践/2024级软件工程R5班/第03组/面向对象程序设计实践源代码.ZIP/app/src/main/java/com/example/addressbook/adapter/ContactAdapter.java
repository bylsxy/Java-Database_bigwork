package com.example.addressbook.adapter;
//ContactAdapter 是联系人列表适配器，用于把 Contact 对象显示到 RecyclerView 中
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.addressbook.R;
import com.example.addressbook.model.Contact;
import com.example.addressbook.util.AppPreferences;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ContactAdapter extends RecyclerView.Adapter<ContactAdapter.ViewHolder> {

    private List<Contact> contactList = new ArrayList<>();
    private final Set<Integer> selectedIds = new HashSet<>();
    private boolean selectionMode = false;
    private boolean compactMode = false;
    private String secondaryField = AppPreferences.LIST_FIELD_PHONE;
    private OnItemClickListener listener;
    private OnItemLongClickListener longClickListener;
    private OnCallClickListener callListener;
    private OnSelectionChangedListener selectionChangedListener;

    public interface OnItemClickListener {
        void onItemClick(Contact contact);
    }

    public interface OnCallClickListener {
        void onCallClick(Contact contact);
    }

    public interface OnItemLongClickListener {
        void onItemLongClick(Contact contact);
    }

    public interface OnSelectionChangedListener {
        void onSelectionChanged(int selectedCount);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public void setOnItemLongClickListener(OnItemLongClickListener listener) {
        this.longClickListener = listener;
    }

    public void setOnCallClickListener(OnCallClickListener listener) {
        this.callListener = listener;
    }

    public void setOnSelectionChangedListener(OnSelectionChangedListener listener) {
        this.selectionChangedListener = listener;
    }

    public void setContacts(List<Contact> contacts) {
        this.contactList = contacts != null ? contacts : new ArrayList<>();
        pruneSelection();
        notifyDataSetChanged();
    }

    public void setSelectionMode(boolean selectionMode) {
        this.selectionMode = selectionMode;
        if (!selectionMode) {
            selectedIds.clear();
        }
        notifySelectionChanged();
        notifyDataSetChanged();
    }

    public void setCompactMode(boolean compactMode) {
        if (this.compactMode != compactMode) {
            this.compactMode = compactMode;
            notifyDataSetChanged();
        }
    }

    public void setSecondaryField(String secondaryField) {
        String safeField = secondaryField != null ? secondaryField : AppPreferences.LIST_FIELD_PHONE;
        if (!this.secondaryField.equals(safeField)) {
            this.secondaryField = safeField;
            notifyDataSetChanged();
        }
    }

    public boolean isSelectionMode() {
        return selectionMode;
    }

    public void toggleSelection(Contact contact) {
        int id = contact.getId();
        if (selectedIds.contains(id)) {
            selectedIds.remove(id);
        } else {
            selectedIds.add(id);
        }
        notifySelectionChanged();
        notifyDataSetChanged();
    }

    public void selectAllVisible() {
        for (Contact contact : contactList) {
            selectedIds.add(contact.getId());
        }
        notifySelectionChanged();
        notifyDataSetChanged();
    }

    public void clearSelection() {
        selectedIds.clear();
        notifySelectionChanged();
        notifyDataSetChanged();
    }

    public int getSelectedCount() {
        return selectedIds.size();
    }

    public List<Integer> getSelectedIds() {
        return new ArrayList<>(selectedIds);
    }

    public List<Contact> getSelectedContacts() {
        List<Contact> contacts = new ArrayList<>();
        for (Contact contact : contactList) {
            if (selectedIds.contains(contact.getId())) {
                contacts.add(contact);
            }
        }
        return contacts;
    }

    private void pruneSelection() {
        Set<Integer> visibleIds = new HashSet<>();
        for (Contact contact : contactList) {
            visibleIds.add(contact.getId());
        }
        selectedIds.retainAll(visibleIds);
        notifySelectionChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_contact, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Contact contact = contactList.get(position);
        RecyclerView.LayoutParams params = (RecyclerView.LayoutParams) holder.itemView.getLayoutParams();
        int margin = dp(holder.itemView, compactMode ? 3 : 6);
        params.setMargins(margin, margin, margin, margin);
        holder.itemView.setLayoutParams(params);
        holder.contentLayout.setPadding(dp(holder.itemView, 14), dp(holder.itemView, compactMode ? 10 : 14),
                dp(holder.itemView, 14), dp(holder.itemView, compactMode ? 10 : 14));

        if (contact.getPhotoPath() != null && !contact.getPhotoPath().isEmpty()) {
            try {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = 8;
                android.graphics.Bitmap bitmap = BitmapFactory.decodeFile(contact.getPhotoPath(), options);
                if (bitmap != null) {
                    holder.ivPhoto.setVisibility(View.VISIBLE);
                    holder.ivPhoto.setImageBitmap(bitmap);
                    holder.ivPhoto.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    holder.tvInitial.setVisibility(View.GONE);
                } else {
                    showInitialAvatar(holder, contact);
                }
            } catch (Exception e) {
                showInitialAvatar(holder, contact);
            }
        } else {
            showInitialAvatar(holder, contact);
        }

        holder.tvName.setText(contact.getName());
        boolean maskPrivateInfo = contact.isPrivateContact()
                && !AppPreferences.isPrivacyUnlocked(holder.itemView.getContext());
        if (maskPrivateInfo) {
            holder.tvPhone.setText(R.string.private_contact_mask);
        } else {
            holder.tvPhone.setText(getSecondaryText(holder.itemView, contact));
        }

        String groupName = contact.getGroupName();
        if (groupName != null && !"未分组".equals(groupName)) {
            holder.tvGroupTag.setText(groupName);
            holder.tvGroupTag.setVisibility(View.VISIBLE);
        } else {
            holder.tvGroupTag.setVisibility(View.GONE);
        }

        holder.tvPrivateTag.setVisibility(contact.isPrivateContact() ? View.VISIBLE : View.GONE);
        boolean selected = selectedIds.contains(contact.getId());
        holder.cbSelect.setVisibility(selectionMode ? View.VISIBLE : View.GONE);
        holder.cbSelect.setChecked(selected);
        holder.btnCall.setVisibility(selectionMode ? View.GONE : View.VISIBLE);

        holder.itemView.setOnClickListener(v -> {
            if (selectionMode) {
                toggleSelection(contact);
            } else if (listener != null) {
                listener.onItemClick(contact);
            }
        });

        holder.itemView.setOnLongClickListener(v -> {
            if (longClickListener != null) {
                longClickListener.onItemLongClick(contact);
            }
            return true;
        });

        holder.cbSelect.setOnClickListener(v -> toggleSelection(contact));

        holder.btnCall.setOnClickListener(v -> {
            if (callListener != null) {
                callListener.onCallClick(contact);
            }
        });
    }

    private void showInitialAvatar(ViewHolder holder, Contact contact) {
        holder.ivPhoto.setImageBitmap(null);
        holder.ivPhoto.setScaleType(ImageView.ScaleType.CENTER);
        holder.ivPhoto.setVisibility(View.GONE);
        holder.tvInitial.setText(getInitial(contact.getName()));
        holder.tvInitial.setVisibility(View.VISIBLE);
    }

    private String getSecondaryText(View view, Contact contact) {
        if (AppPreferences.LIST_FIELD_EMAIL.equals(secondaryField)) {
            return nonEmptyOrFallback(contact.getEmail(), view.getContext().getString(R.string.no_email));
        }
        if (AppPreferences.LIST_FIELD_IM.equals(secondaryField)) {
            String tool = contact.getImTool();
            String account = contact.getImAccount();
            if (tool != null && !tool.trim().isEmpty() && account != null && !account.trim().isEmpty()) {
                return tool.trim() + ": " + account.trim();
            }
            if (account != null && !account.trim().isEmpty()) {
                return account.trim();
            }
            return view.getContext().getString(R.string.no_im);
        }
        if (AppPreferences.LIST_FIELD_COMPANY.equals(secondaryField)) {
            return nonEmptyOrFallback(contact.getCompany(), view.getContext().getString(R.string.no_company));
        }
        if (AppPreferences.LIST_FIELD_GROUP.equals(secondaryField)) {
            return nonEmptyOrFallback(contact.getGroupName(), view.getContext().getString(R.string.no_group));
        }

        String phone = contact.getPrimaryPhone();
        return phone.isEmpty() ? view.getContext().getString(R.string.no_phone) : phone;
    }

    private String nonEmptyOrFallback(String value, String fallback) {
        return value != null && !value.trim().isEmpty() ? value : fallback;
    }

    @Override
    public int getItemCount() {
        return contactList.size();
    }

    private String getInitial(String name) {
        if (name == null || name.isEmpty()) {
            return "?";
        }
        char firstChar = name.charAt(0);
        if (firstChar >= 'A' && firstChar <= 'Z') {
            return String.valueOf(firstChar);
        }
        if (firstChar >= 'a' && firstChar <= 'z') {
            return String.valueOf(Character.toUpperCase(firstChar));
        }
        if (firstChar >= 0x4E00 && firstChar <= 0x9FA5) {
            return String.valueOf(firstChar);
        }
        return "#";
    }

    private void notifySelectionChanged() {
        if (selectionChangedListener != null) {
            selectionChangedListener.onSelectionChanged(selectedIds.size());
        }
    }

    private int dp(View view, int value) {
        return (int) (value * view.getResources().getDisplayMetrics().density + 0.5f);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        View contentLayout;
        CheckBox cbSelect;
        ImageView ivPhoto;
        TextView tvInitial;
        TextView tvName;
        TextView tvPhone;
        TextView tvGroupTag;
        TextView tvPrivateTag;
        View btnCall;

        ViewHolder(View itemView) {
            super(itemView);
            contentLayout = itemView.findViewById(R.id.layoutContactContent);
            cbSelect = itemView.findViewById(R.id.cbSelect);
            ivPhoto = itemView.findViewById(R.id.ivPhoto);
            tvInitial = itemView.findViewById(R.id.tvInitial);
            tvName = itemView.findViewById(R.id.tvName);
            tvPhone = itemView.findViewById(R.id.tvPhone);
            tvGroupTag = itemView.findViewById(R.id.tvGroupTag);
            tvPrivateTag = itemView.findViewById(R.id.tvPrivateTag);
            btnCall = itemView.findViewById(R.id.btnCall);
        }
    }
}
