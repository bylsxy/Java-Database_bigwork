package com.example.addressbook.service;

//联系人业务服务类(界面层不直接写 SQL，而是通过这个类完成联系人增删改查、搜索、排序、分组、重复检测、生日提醒等功能)
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.addressbook.model.Contact;
import com.example.addressbook.util.DatabaseHelper;
import com.example.addressbook.util.PinyinUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ContactService {

    private static final String BASE_QUERY =
            "SELECT c.id, c.name, c.phone, c.mobile, c.im_tool, c.im_account, c.email, c.homepage, " +
            "c.birthday, c.photo_path, c.company, c.address, c.postcode, " +
            "c.group_id, c.remark, c.last_viewed_time, c.is_private, " +
            "c.relationship_tag, c.follow_up_date, " +
            "g.name as group_name " +
            "FROM contacts c LEFT JOIN groups g ON c.group_id = g.id ";

    private final DatabaseHelper dbHelper;

    public ContactService(Context context) {
        this.dbHelper = DatabaseHelper.getInstance(context);
    }

    public List<Contact> getAllContacts() {
        return queryContacts(BASE_QUERY + "ORDER BY c.name COLLATE NOCASE", null);
    }

    public List<Contact> getContactsByGroup(int groupId) {
        return queryContacts(BASE_QUERY + "WHERE c.group_id = ? ORDER BY c.name COLLATE NOCASE",
                new String[]{String.valueOf(groupId)});
    }

    public List<Contact> getUngroupedContacts() {
        return queryContacts(BASE_QUERY + "WHERE c.group_id IS NULL OR c.group_id = 0 ORDER BY c.name COLLATE NOCASE", null);
    }

    public List<Contact> getContactsSortedByRecent() {
        return queryContacts(BASE_QUERY + "ORDER BY c.last_viewed_time DESC, c.name COLLATE NOCASE", null);
    }

    public Contact getContactById(int id) {
        List<Contact> list = queryContacts(BASE_QUERY + "WHERE c.id = ?",
                new String[]{String.valueOf(id)});
        return list.isEmpty() ? null : list.get(0);
    }

    public List<Contact> searchContacts(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllContacts();
        }

        String normalizedKeyword = keyword.trim().toUpperCase(Locale.ROOT);
        List<Contact> matchedContacts = new ArrayList<>();
        for (Contact contact : getAllContacts()) {
            if (matchesKeyword(contact, normalizedKeyword)) {
                matchedContacts.add(contact);
            }
        }
        return matchedContacts;
    }

    public long addContact(Contact contact) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        try {
            db.beginTransaction(); //事务,操作要么全部成功，要么失败时回滚，避免批量操作只完成一半
            long newId = db.insert("contacts", null, contactToValues(contact));
            db.setTransactionSuccessful();
            return newId;
        } finally {
            db.endTransaction();
        }
    }

    public int updateContact(Contact contact) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        Contact oldContact = getContactById(contact.getId());
        if (oldContact != null) {
            contact.setLastViewedTime(oldContact.getLastViewedTime());
        }
        return db.update("contacts", contactToValues(contact), "id = ?",
                new String[]{String.valueOf(contact.getId())});
    }

    public int deleteContact(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete("recent_contacts", "contact_id = ?", new String[]{String.valueOf(id)});
        return db.delete("contacts", "id = ?", new String[]{String.valueOf(id)});
    }

    public int deleteContacts(List<Integer> ids) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        try {
            db.beginTransaction();
            for (int id : ids) {
                db.delete("recent_contacts", "contact_id = ?", new String[]{String.valueOf(id)});
                db.delete("contacts", "id = ?", new String[]{String.valueOf(id)});
            }
            db.setTransactionSuccessful();
            return ids.size();
        } finally {
            db.endTransaction();
        }
    }

    public int assignContactsToGroup(List<Integer> contactIds, int groupId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        boolean targetGroupExists = groupId > 0 && groupExists(groupId);
        try {
            db.beginTransaction();
            int count = 0;
            for (int contactId : contactIds) {
                ContentValues values = new ContentValues();
                if (!targetGroupExists) {
                    values.putNull("group_id");
                } else {
                    values.put("group_id", groupId);
                }
                count += db.update("contacts", values, "id = ?",
                        new String[]{String.valueOf(contactId)});
            }
            db.setTransactionSuccessful();
            return count;
        } finally {
            db.endTransaction();
        }
    }

    public List<Contact> findDuplicates(Contact contact) {
        List<Contact> duplicates = new ArrayList<>();

        String name = contact.getName();
        String phone = contact.getPhone();
        String mobile = contact.getMobile();

        if (name == null || name.isEmpty()) {
            return duplicates;
        }

        if (phone != null && !phone.isEmpty()) {
            duplicates.addAll(queryContacts(BASE_QUERY +
                    "WHERE c.name = ? AND c.phone = ? AND c.id != ?",
                    new String[]{name, phone, String.valueOf(contact.getId())}));
        }

        if (mobile != null && !mobile.isEmpty()) {
            List<Contact> list = queryContacts(BASE_QUERY +
                    "WHERE c.name = ? AND c.mobile = ? AND c.id != ?",
                    new String[]{name, mobile, String.valueOf(contact.getId())});
            for (Contact item : list) {
                if (!duplicates.contains(item)) {
                    duplicates.add(item);
                }
            }
        }

        if (duplicates.isEmpty()) {
            duplicates.addAll(queryContacts(BASE_QUERY +
                    "WHERE c.name = ? AND c.id != ?",
                    new String[]{name, String.valueOf(contact.getId())}));
        }

        return duplicates;
    }

    public boolean isDuplicate(String name, String phone, String mobile) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        if (name == null || name.isEmpty()) {
            return false;
        }

        String sql = "SELECT COUNT(*) FROM contacts WHERE name = ?";
        String[] args;

        if (phone != null && !phone.isEmpty()) {
            sql += " AND phone = ?";
            args = new String[]{name, phone};
        } else if (mobile != null && !mobile.isEmpty()) {
            sql += " AND mobile = ?";
            args = new String[]{name, mobile};
        } else {
            args = new String[]{name};
        }

        Cursor cursor = db.rawQuery(sql, args);
        try {
            return cursor.moveToFirst() && cursor.getInt(0) > 0;
        } finally {
            cursor.close();
        }
    }

    public void recordViewed(int contactId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long now = System.currentTimeMillis();

        ContentValues values = new ContentValues();
        values.put("last_viewed_time", now);
        db.update("contacts", values, "id = ?", new String[]{String.valueOf(contactId)});

        db.execSQL("INSERT INTO recent_contacts (contact_id, viewed_time) VALUES (?, ?) " +
                "ON CONFLICT(contact_id) DO UPDATE SET viewed_time = ?",
                new Object[]{contactId, now, now});
    }

    public List<Contact> getRecentContacts(int limit) {
        String sql = BASE_QUERY +
                "INNER JOIN recent_contacts r ON c.id = r.contact_id " +
                "ORDER BY r.viewed_time DESC LIMIT ?";
        return queryContacts(sql, new String[]{String.valueOf(limit)});
    }

    public List<Contact> getUpcomingBirthdays(int days) {
        List<Contact> result = new ArrayList<>();
        java.util.Calendar today = java.util.Calendar.getInstance();
        int todayMonth = today.get(java.util.Calendar.MONTH) + 1;
        int todayDay = today.get(java.util.Calendar.DAY_OF_MONTH);

        for (Contact contact : getAllContacts()) {
            if (contact.getBirthday() == null || contact.getBirthday().isEmpty()) {
                continue;
            }
            try {
                int[] monthDay = parseBirthdayMonthDay(contact.getBirthday());
                if (monthDay == null) {
                    continue;
                }

                int daysDiff = daysUntilBirthday(todayMonth, todayDay, monthDay[0], monthDay[1]);
                if (daysDiff >= 0 && daysDiff <= days) {
                    result.add(contact);
                }
            } catch (NumberFormatException ignored) {
            }
        }
        return result;
    }

    public int getContactCount() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM contacts", null);
        try {
            return cursor.moveToFirst() ? cursor.getInt(0) : 0;
        } finally {
            cursor.close();
        }
    }

    private ContentValues contactToValues(Contact contact) {
        ContentValues values = new ContentValues();
        values.put("name", contact.getName());
        values.put("phone", contact.getPhone());
        values.put("mobile", contact.getMobile());
        values.put("im_tool", contact.getImTool());
        values.put("im_account", contact.getImAccount());
        values.put("email", contact.getEmail());
        values.put("homepage", contact.getHomepage());
        values.put("birthday", contact.getBirthday());
        values.put("photo_path", contact.getPhotoPath());
        values.put("company", contact.getCompany());
        values.put("address", contact.getAddress());
        values.put("postcode", contact.getPostcode());
        values.put("remark", contact.getRemark());
        values.put("last_viewed_time", contact.getLastViewedTime());
        values.put("is_private", contact.isPrivateContact() ? 1 : 0);
        values.put("relationship_tag", contact.getRelationshipTag());
        values.put("follow_up_date", contact.getFollowUpDate());

        if (contact.getGroupId() == 0 || !groupExists(contact.getGroupId())) {
            values.putNull("group_id");
        } else {
            values.put("group_id", contact.getGroupId());
        }
        return values;
    }

    private boolean matchesKeyword(Contact contact, String keyword) {
        return containsIgnoreCase(contact.getName(), keyword)
                || containsIgnoreCase(contact.getPhone(), keyword)
                || containsIgnoreCase(contact.getMobile(), keyword)
                || containsIgnoreCase(contact.getImTool(), keyword)
                || containsIgnoreCase(contact.getImAccount(), keyword)
                || containsIgnoreCase(contact.getEmail(), keyword)
                || PinyinUtil.matchesPinyin(contact.getName(), keyword);
    }

    private boolean containsIgnoreCase(String value, String keyword) {
        return value != null && value.toUpperCase(Locale.ROOT).contains(keyword);
    }

    private int[] parseBirthdayMonthDay(String birthday) {
        String[] parts = birthday.split("-");
        if (parts.length < 3) {
            return null;
        }

        int month = Integer.parseInt(parts[1]);
        int day = Integer.parseInt(parts[2]);
        if (month < 1 || month > 12 || day < 1 || day > 31) {
            return null;
        }
        return new int[]{month, day};
    }

    private int daysUntilBirthday(int todayMonth, int todayDay, int birthdayMonth, int birthdayDay) {
        java.util.Calendar today = java.util.Calendar.getInstance();
        today.set(java.util.Calendar.MONTH, todayMonth - 1);
        today.set(java.util.Calendar.DAY_OF_MONTH, todayDay);
        today.set(java.util.Calendar.HOUR_OF_DAY, 0);
        today.set(java.util.Calendar.MINUTE, 0);
        today.set(java.util.Calendar.SECOND, 0);
        today.set(java.util.Calendar.MILLISECOND, 0);

        java.util.Calendar birthday = java.util.Calendar.getInstance();
        birthday.set(java.util.Calendar.MONTH, birthdayMonth - 1);
        birthday.set(java.util.Calendar.DAY_OF_MONTH, birthdayDay);
        birthday.set(java.util.Calendar.HOUR_OF_DAY, 0);
        birthday.set(java.util.Calendar.MINUTE, 0);
        birthday.set(java.util.Calendar.SECOND, 0);
        birthday.set(java.util.Calendar.MILLISECOND, 0);

        if (birthday.before(today)) {
            birthday.add(java.util.Calendar.YEAR, 1);
        }

        long diff = birthday.getTimeInMillis() - today.getTimeInMillis();
        return (int) (diff / (1000L * 60 * 60 * 24));
    }

    private boolean groupExists(int groupId) {
        if (groupId <= 0) {
            return false;
        }

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT 1 FROM groups WHERE id = ? LIMIT 1",
                new String[]{String.valueOf(groupId)});
        try {
            return cursor.moveToFirst();
        } finally {
            cursor.close();
        }
    }

    private List<Contact> queryContacts(String sql, String[] args) {
        List<Contact> contacts = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(sql, args);
        try {
            while (cursor.moveToNext()) {
                contacts.add(mapRowToContact(cursor));
            }
        } finally {
            cursor.close();
        }
        return contacts;
    }

    private Contact mapRowToContact(Cursor cursor) {
        Contact contact = new Contact();
        contact.setId(cursor.getInt(cursor.getColumnIndexOrThrow("id")));
        contact.setName(cursor.getString(cursor.getColumnIndexOrThrow("name")));
        contact.setPhone(getCol(cursor, "phone"));
        contact.setMobile(getCol(cursor, "mobile"));
        contact.setImTool(getCol(cursor, "im_tool"));
        contact.setImAccount(getCol(cursor, "im_account"));
        contact.setEmail(getCol(cursor, "email"));
        contact.setHomepage(getCol(cursor, "homepage"));
        contact.setBirthday(getCol(cursor, "birthday"));
        contact.setPhotoPath(getCol(cursor, "photo_path"));
        contact.setCompany(getCol(cursor, "company"));
        contact.setAddress(getCol(cursor, "address"));
        contact.setPostcode(getCol(cursor, "postcode"));
        contact.setRemark(getCol(cursor, "remark"));
        contact.setRelationshipTag(getCol(cursor, "relationship_tag"));
        contact.setFollowUpDate(getCol(cursor, "follow_up_date"));

        int groupIndex = cursor.getColumnIndex("group_id");
        contact.setGroupId((groupIndex >= 0 && !cursor.isNull(groupIndex)) ? cursor.getInt(groupIndex) : 0);

        String groupName = getCol(cursor, "group_name");
        contact.setGroupName(groupName != null ? groupName : "未分组");

        int lastViewedIndex = cursor.getColumnIndex("last_viewed_time");
        contact.setLastViewedTime((lastViewedIndex >= 0 && !cursor.isNull(lastViewedIndex))
                ? cursor.getLong(lastViewedIndex) : 0);

        int privateIndex = cursor.getColumnIndex("is_private");
        contact.setPrivateContact(privateIndex >= 0 && !cursor.isNull(privateIndex)
                && cursor.getInt(privateIndex) == 1);

        return contact;
    }

    private String getCol(Cursor cursor, String col) {
        int index = cursor.getColumnIndex(col);
        return (index >= 0 && !cursor.isNull(index)) ? cursor.getString(index) : null;
    }
}
