package com.example.addressbook.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.CompositePageTransformer;
import androidx.viewpager2.widget.MarginPageTransformer;
import androidx.viewpager2.widget.ViewPager2;

import com.example.addressbook.R;
import com.example.addressbook.adapter.OnboardingPagerAdapter;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.List;

public class OnboardingActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private LinearLayout layoutDots;
    private TextView tvSkip;
    private MaterialButton btnPrimaryAction;
    private List<OnboardingPagerAdapter.OnboardingPage> pages;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding);

        viewPager = findViewById(R.id.viewPagerOnboarding);
        layoutDots = findViewById(R.id.layoutDots);
        tvSkip = findViewById(R.id.tvSkip);
        btnPrimaryAction = findViewById(R.id.btnPrimaryAction);

        pages = buildPages();
        setupPager();
        setupActions();
        updateDots(0);
        updateActionState(0);
    }

    private List<OnboardingPagerAdapter.OnboardingPage> buildPages() {
        List<OnboardingPagerAdapter.OnboardingPage> result = new ArrayList<>();
        result.add(new OnboardingPagerAdapter.OnboardingPage(
                R.string.onboarding_badge_welcome,
                R.string.onboarding_title_welcome,
                R.string.onboarding_desc_welcome,
                android.R.drawable.ic_dialog_info,
                R.color.colorPrimary));
        result.add(new OnboardingPagerAdapter.OnboardingPage(
                R.string.onboarding_badge_dashboard,
                R.string.onboarding_title_dashboard,
                R.string.onboarding_desc_dashboard,
                android.R.drawable.ic_menu_view,
                R.color.colorAccent));
        result.add(new OnboardingPagerAdapter.OnboardingPage(
                R.string.onboarding_badge_groups,
                R.string.onboarding_title_groups,
                R.string.onboarding_desc_groups,
                android.R.drawable.ic_menu_agenda,
                R.color.colorSuccess));
        return result;
    }

    private void setupPager() {
        viewPager.setAdapter(new OnboardingPagerAdapter(pages));
        viewPager.setOffscreenPageLimit(3);

        CompositePageTransformer transformer = new CompositePageTransformer();
        transformer.addTransformer(new MarginPageTransformer(18));
        transformer.addTransformer((page, position) -> {
            float scale = 0.9f + (1f - Math.abs(position)) * 0.1f;
            page.setScaleX(scale);
            page.setScaleY(scale);
            page.setAlpha(0.6f + (1f - Math.abs(position)) * 0.4f);
        });
        viewPager.setPageTransformer(transformer);

        buildDots();
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                updateDots(position);
                updateActionState(position);
            }
        });
    }

    private void setupActions() {
        tvSkip.setOnClickListener(v -> finish());
        btnPrimaryAction.setOnClickListener(v -> {
            int current = viewPager.getCurrentItem();
            if (current == pages.size() - 1) {
                finish();
            } else {
                viewPager.setCurrentItem(current + 1, true);
            }
        });
    }

    private void buildDots() {
        layoutDots.removeAllViews();
        for (int i = 0; i < pages.size(); i++) {
            ImageView dot = new ImageView(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            params.setMargins(8, 0, 8, 0);
            dot.setLayoutParams(params);
            layoutDots.addView(dot);
        }
    }

    private void updateDots(int selectedIndex) {
        for (int i = 0; i < layoutDots.getChildCount(); i++) {
            View dot = layoutDots.getChildAt(i);
            dot.setBackgroundResource(i == selectedIndex
                    ? R.drawable.bg_dot_active
                    : R.drawable.bg_dot_inactive);
        }
    }

    private void updateActionState(int index) {
        boolean isLastPage = index == pages.size() - 1;
        btnPrimaryAction.setText(isLastPage ? R.string.onboarding_start : R.string.onboarding_next);
        tvSkip.setVisibility(isLastPage ? View.INVISIBLE : View.VISIBLE);
    }
}
