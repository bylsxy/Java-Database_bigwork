package com.example.addressbook.service;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.addressbook.model.Group;
import com.example.addressbook.util.DatabaseHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * 分组管理服务类（Android 版本）
 * 使用 Android SQLiteDatabase API 替代 JDBC
 */
public class GroupService {

    private final DatabaseHelper dbHelper;

    public GroupService(Context context) {
        this.dbHelper = DatabaseHelper.getInstance(context);
    }

    /**
     * 获取所有分组
     */
    public List<Group> getAllGroups() {
        List<Group> groups = new ArrayList<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query("groups", new String[]{"id", "name"},
                null, null, null, null, "id ASC");

        try {
            while (cursor.moveToNext()) {
                groups.add(mapRowToGroup(cursor));
            }
        } finally {
            cursor.close();
        }
        return groups;
    }

    /**
     * 根据 ID 获取分组
     */
    public Group getGroupById(int id) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query("groups", new String[]{"id", "name"},
                "id = ?", new String[]{String.valueOf(id)},
                null, null, null);

        try {
            if (cursor.moveToNext()) {
                return mapRowToGroup(cursor);
            }
        } finally {
            cursor.close();
        }
        return null;
    }

    /**
     * 根据名称获取分组
     */
    public Group getGroupByName(String name) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.query("groups", new String[]{"id", "name"},
                "name = ?", new String[]{name},
                null, null, null);

        try {
            if (cursor.moveToNext()) {
                return mapRowToGroup(cursor);
            }
        } finally {
            cursor.close();
        }
        return null;
    }

    /**
     * 添加分组
     */
    public long addGroup(Group group) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        android.content.ContentValues values = new android.content.ContentValues();
        values.put("name", group.getName());

        return db.insert("groups", null, values);
    }

    /**
     * 更新分组名称
     */
    public int updateGroup(Group group) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        android.content.ContentValues values = new android.content.ContentValues();
        values.put("name", group.getName());

        return db.update("groups", values, "id = ?", new String[]{String.valueOf(group.getId())});
    }

    /**
     * 删除分组（同时将该分组下的联系人置为未分组）
     */
    public int deleteGroup(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        try {
            db.beginTransaction();

            // 先将该分组下的联系人的 group_id 置为 NULL
            db.execSQL("UPDATE contacts SET group_id = NULL WHERE group_id = " + id);

            // 再删除分组
            int rowsDeleted = db.delete("groups", "id = ?", new String[]{String.valueOf(id)});

            db.setTransactionSuccessful();
            return rowsDeleted;
        } finally {
            db.endTransaction();
        }
    }

    /**
     * 获取分组下的联系人数量
     */
    public int getGroupContactCount(int groupId) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM contacts WHERE group_id = ?",
                new String[]{String.valueOf(groupId)});

        try {
            if (cursor.moveToNext()) {
                return cursor.getInt(0);
            }
        } finally {
            cursor.close();
        }
        return 0;
    }

    /**
     * 获取分组总数
     */
    public int getGroupCount() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM groups", null);
        try {
            if (cursor.moveToNext()) {
                return cursor.getInt(0);
            }
        } finally {
            cursor.close();
        }
        return 0;
    }

    /**
     * 将 Cursor 行映射为 Group 对象
     */
    private Group mapRowToGroup(Cursor cursor) {
        Group group = new Group();
        group.setId(cursor.getInt(cursor.getColumnIndexOrThrow("id")));
        group.setName(cursor.getString(cursor.getColumnIndexOrThrow("name")));
        return group;
    }
}
