package com.example.addressbook.activity;
//ContactEditActivity 是联系人新增/编辑页面，负责让用户填写联系人信息、选择头像、选择分组，并保存到数据库
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.example.addressbook.R;
import com.example.addressbook.model.Contact;
import com.example.addressbook.model.Group;
import com.example.addressbook.service.ContactService;
import com.example.addressbook.service.GroupService;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

public class ContactEditActivity extends AppCompatActivity {

    public static final String EXTRA_MODE = "mode";
    public static final String EXTRA_CONTACT_ID = "contact_id";
    public static final String EXTRA_FORCE_PRIVATE = "force_private";
    public static final int MODE_ADD = 0;
    public static final int MODE_EDIT = 1;

    private static final int REQUEST_CAMERA = 100;
    private static final int REQUEST_GALLERY = 101;
    private static final int REQUEST_PERMISSION_CAMERA = 200;

    private ImageView ivPhoto;
    private TextInputEditText etName;
    private TextInputEditText etPhone;
    private TextInputEditText etMobile;
    private TextInputEditText etImTool;
    private TextInputEditText etImAccount;
    private TextInputEditText etEmail;
    private TextInputEditText etHomepage;
    private TextInputEditText etBirthday;
    private TextInputEditText etCompany;
    private TextInputEditText etAddress;
    private TextInputEditText etPostcode;
    private TextInputEditText etRemark;
    private TextInputEditText etRelationshipTag;
    private TextInputEditText etFollowUpDate;
    private Spinner spinnerGroup;
    private TextView tvManageGroups;
    private CheckBox cbPrivateContact;

    private ContactService contactService;
    private GroupService groupService;

    private int mode = MODE_ADD;
    private int editingContactId = -1;
    private final Map<String, Integer> groupNameToIdMap = new HashMap<>();
    private final Handler autoSaveHandler = new Handler(Looper.getMainLooper());
    private String currentPhotoPath;
    private String initialFormState;
    private boolean suppressChangeTracking = true;
    private boolean hasUnsavedChanges = false;
    private AutoSaveRunnable autoSaveRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_edit);

        contactService = new ContactService(this);
        groupService = new GroupService(this);

        mode = getIntent().getIntExtra(EXTRA_MODE, MODE_ADD);
        editingContactId = getIntent().getIntExtra(EXTRA_CONTACT_ID, -1);

        initViews();
        setupToolbar();
        setupBackNavigation();
        loadGroups();
        setupPhotoPicker();

        if (mode == MODE_EDIT && editingContactId > 0) {
            loadContactForEdit();
        } else if (getIntent().getBooleanExtra(EXTRA_FORCE_PRIVATE, false)) {
            cbPrivateContact.setChecked(true);
        }

        suppressChangeTracking = false;
        syncInitialFormState();
    }

    private void initViews() {
        ivPhoto = findViewById(R.id.ivPhoto);
        etName = findViewById(R.id.etName);
        etPhone = findViewById(R.id.etPhone);
        etMobile = findViewById(R.id.etMobile);
        etImTool = findViewById(R.id.etImTool);
        etImAccount = findViewById(R.id.etImAccount);
        etEmail = findViewById(R.id.etEmail);
        etHomepage = findViewById(R.id.etHomepage);
        etBirthday = findViewById(R.id.etBirthday);
        etCompany = findViewById(R.id.etCompany);
        etAddress = findViewById(R.id.etAddress);
        etPostcode = findViewById(R.id.etPostcode);
        etRemark = findViewById(R.id.etRemark);
        etRelationshipTag = findViewById(R.id.etRelationshipTag);
        etFollowUpDate = findViewById(R.id.etFollowUpDate);
        spinnerGroup = findViewById(R.id.spinnerGroup);
        tvManageGroups = findViewById(R.id.tvManageGroups);
        cbPrivateContact = findViewById(R.id.cbPrivateContact);
        MaterialButton btnSave = findViewById(R.id.btnSave);

        btnSave.setOnClickListener(v -> onSave());
        tvManageGroups.setOnClickListener(v ->
                startActivity(new Intent(ContactEditActivity.this, GroupManageActivity.class)));
        cbPrivateContact.setOnCheckedChangeListener((buttonView, isChecked) -> markChanged());
        setupAutoSaveListener();
        spinnerGroup.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                markChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void setupToolbar() {
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(mode == MODE_ADD ? R.string.add_contact : R.string.edit_contact);
        toolbar.setNavigationOnClickListener(v -> handleCloseRequest());
    }

    private void setupBackNavigation() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                handleCloseRequest();
            }
        });
    }

    private void handleCloseRequest() {
        if (!hasFormChanges()) {
            finish();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("未保存的更改")
                .setMessage("有未保存的更改，是否保存？")
                .setPositiveButton(R.string.save, (dialog, which) -> onSave())
                .setNegativeButton("不保存", (dialog, which) -> finish())
                .setNeutralButton(R.string.cancel, null)
                .show();
    }

    private void setupAutoSaveListener() {
        autoSaveRunnable = new AutoSaveRunnable();
        android.text.TextWatcher watcher = new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                markChanged();
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {
            }
        };

        TextInputEditText[] trackedFields = new TextInputEditText[]{
                etName, etPhone, etMobile, etImTool, etImAccount, etEmail, etHomepage,
                etBirthday, etCompany, etAddress, etPostcode, etRemark,
                etRelationshipTag, etFollowUpDate
        };
        for (TextInputEditText field : trackedFields) {
            field.addTextChangedListener(watcher);
        }
    }

    private class AutoSaveRunnable implements Runnable {
        @Override
        public void run() {
            if (hasUnsavedChanges && canAutoSaveSilently()) {
                doSave(true);
            }
        }
    }

    private void markChanged() {
        if (suppressChangeTracking) {
            return;
        }

        hasUnsavedChanges = hasFormChanges();
        autoSaveHandler.removeCallbacks(autoSaveRunnable);
        if (hasUnsavedChanges && (mode == MODE_EDIT || hasMinimumAutoSaveFields())) {
            autoSaveHandler.postDelayed(autoSaveRunnable, 2000);
        }
    }

    private void loadGroups() {
        boolean previousSuppressState = suppressChangeTracking;
        String selectedGroupName = getSelectedGroupName();
        suppressChangeTracking = true;

        List<Group> groups = groupService.getAllGroups();
        List<String> groupNames = new ArrayList<>();
        groupNames.add("未分组");
        groupNameToIdMap.clear();

        for (Group group : groups) {
            groupNames.add(group.getName());
            groupNameToIdMap.put(group.getName(), group.getId());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, groupNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerGroup.setAdapter(adapter);
        restoreGroupSelection(selectedGroupName);

        suppressChangeTracking = previousSuppressState;
    }

    private void loadContactForEdit() {
        suppressChangeTracking = true;
        Contact contact = contactService.getContactById(editingContactId);
        if (contact == null) {
            suppressChangeTracking = false;
            finish();
            return;
        }

        etName.setText(contact.getName());
        etPhone.setText(contact.getPhone());
        etMobile.setText(contact.getMobile());
        etImTool.setText(contact.getImTool());
        etImAccount.setText(contact.getImAccount());
        etEmail.setText(contact.getEmail());
        etHomepage.setText(contact.getHomepage());
        etBirthday.setText(contact.getBirthday());
        etCompany.setText(contact.getCompany());
        etAddress.setText(contact.getAddress());
        etPostcode.setText(contact.getPostcode());
        etRemark.setText(contact.getRemark());
        etRelationshipTag.setText(contact.getRelationshipTag());
        etFollowUpDate.setText(contact.getFollowUpDate());
        cbPrivateContact.setChecked(contact.isPrivateContact());
        currentPhotoPath = contact.getPhotoPath();

        String groupName = contact.getGroupName();
        if (groupName != null && !"未分组".equals(groupName)) {
            for (int i = 0; i < spinnerGroup.getCount(); i++) {
                if (groupName.equals(spinnerGroup.getItemAtPosition(i))) {
                    spinnerGroup.setSelection(i);
                    break;
                }
            }
        }

        loadPhoto(contact.getPhotoPath());
        hasUnsavedChanges = false;
        suppressChangeTracking = false;
    }

    private void syncInitialFormState() {
        initialFormState = captureFormState();
        hasUnsavedChanges = false;
        autoSaveHandler.removeCallbacks(autoSaveRunnable);
    }

    private boolean hasFormChanges() {
        return initialFormState != null && !initialFormState.equals(captureFormState());
    }

    private String captureFormState() {
        String selectedGroup = null;
        Object selectedItem = spinnerGroup != null ? spinnerGroup.getSelectedItem() : null;
        if (selectedItem instanceof String) {
            selectedGroup = (String) selectedItem;
        }

        return String.join("\u0001",
                nullToEmpty(getText(etName)),
                nullToEmpty(getText(etPhone)),
                nullToEmpty(getText(etMobile)),
                nullToEmpty(getText(etImTool)),
                nullToEmpty(getText(etImAccount)),
                nullToEmpty(getText(etEmail)),
                nullToEmpty(getText(etHomepage)),
                nullToEmpty(getText(etBirthday)),
                nullToEmpty(getText(etCompany)),
                nullToEmpty(getText(etAddress)),
                nullToEmpty(getText(etPostcode)),
                nullToEmpty(getText(etRemark)),
                nullToEmpty(getText(etRelationshipTag)),
                nullToEmpty(getText(etFollowUpDate)),
                nullToEmpty(selectedGroup),
                nullToEmpty(currentPhotoPath),
                String.valueOf(cbPrivateContact != null && cbPrivateContact.isChecked()));
    }

    private String nullToEmpty(String value) {
        return value == null ? "" : value;
    }

    private String getSelectedGroupName() {
        Object selectedItem = spinnerGroup.getSelectedItem();
        return selectedItem instanceof String ? (String) selectedItem : null;
    }

    private void restoreGroupSelection(String groupName) {
        if (groupName == null || spinnerGroup.getAdapter() == null) {
            return;
        }

        for (int i = 0; i < spinnerGroup.getCount(); i++) {
            if (groupName.equals(spinnerGroup.getItemAtPosition(i))) {
                spinnerGroup.setSelection(i);
                return;
            }
        }
    }

    private void setupPhotoPicker() {
        ivPhoto.setOnClickListener(v -> {
            String[] options = {getString(R.string.take_photo), getString(R.string.pick_from_gallery)};
            new AlertDialog.Builder(this)
                    .setTitle(R.string.select_photo)
                    .setItems(options, (dialog, which) -> {
                        if (which == 0) {
                            openCamera();
                        } else {
                            openGallery();
                        }
                    })
                    .show();
        });
    }

    private void openCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA}, REQUEST_PERMISSION_CAMERA);
            return;
        }

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) != null) {
            File photoFile = createImageFile();
            if (photoFile != null) {
                Uri photoUri = FileProvider.getUriForFile(this,
                        getPackageName() + ".fileprovider", photoFile);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                startActivityForResult(intent, REQUEST_CAMERA);
            }
        }
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        startActivityForResult(Intent.createChooser(intent, getString(R.string.pick_from_gallery)),
                REQUEST_GALLERY);
    }

    private File createImageFile() {
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        try {
            File image = File.createTempFile("contact_photo_", ".jpg", storageDir);
            currentPhotoPath = image.getAbsolutePath();
            return image;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK) {
            return;
        }

        if (requestCode == REQUEST_CAMERA) {
            loadPhoto(currentPhotoPath);
            markChanged();
            return;
        }

        if (requestCode == REQUEST_GALLERY && data != null) {
            try {
                Uri uri = data.getData();
                if (uri == null) {
                    return;
                }

                Bitmap bitmap;
                try (InputStream inputStream = getContentResolver().openInputStream(uri)) {
                    bitmap = BitmapFactory.decodeStream(inputStream);
                }

                if (bitmap == null) {
                    Toast.makeText(this, "图片处理失败", Toast.LENGTH_SHORT).show();
                    return;
                }

                File photoFile = createImageFile();
                if (photoFile != null) {
                    try (FileOutputStream outputStream = new FileOutputStream(photoFile)) {
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream);
                    }
                    currentPhotoPath = photoFile.getAbsolutePath();
                    loadPhoto(currentPhotoPath);
                    markChanged();
                }
            } catch (Exception e) {
                Toast.makeText(this, "图片处理失败", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void loadPhoto(String path) {
        if (path != null && !path.isEmpty()) {
            try {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = 4;
                Bitmap bitmap = BitmapFactory.decodeFile(path, options);
                if (bitmap != null) {
                    ivPhoto.setImageBitmap(bitmap);
                    ivPhoto.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    return;
                }
            } catch (Exception ignored) {
            }
        }
        ivPhoto.setImageResource(R.drawable.avatar_placeholder);
        ivPhoto.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
    }

    private void onSave() {
        if (!validateInput()) {
            return;
        }

        Contact contact = buildContact();
        if (mode == MODE_ADD) {
            List<Contact> duplicates = contactService.findDuplicates(contact);
            if (!duplicates.isEmpty()) {
                new AlertDialog.Builder(this)
                        .setTitle(R.string.duplicate_warning)
                        .setMessage(getString(R.string.duplicate_warning_msg))
                        .setPositiveButton(R.string.save_anyway, (dialog, which) -> doSave(false))
                        .setNegativeButton(R.string.cancel, null)
                        .show();
                return;
            }
        }

        doSave(false);
    }

    private void doSave(boolean silent) {
        Contact contact = buildContact();
        autoSaveHandler.removeCallbacks(autoSaveRunnable);
        try {
            if (mode == MODE_EDIT) {
                contact.setId(editingContactId);
                contactService.updateContact(contact);
            } else {
                long newId = contactService.addContact(contact);
                if (newId <= 0) {
                    throw new IllegalStateException("add contact failed");
                }
                if (silent && newId > 0) {
                    editingContactId = (int) newId;
                    mode = MODE_EDIT;
                    MaterialToolbar toolbar = findViewById(R.id.toolbar);
                    toolbar.setTitle(R.string.edit_contact);
                }
            }
            syncInitialFormState();
            if (!silent) {
                Toast.makeText(this, mode == MODE_EDIT ? R.string.update_success : R.string.add_success,
                        Toast.LENGTH_SHORT).show();
                finish();
            }
        } catch (Exception e) {
            if (!silent) {
                Toast.makeText(this, getString(R.string.operation_failed) + ": " + e.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean canAutoSaveSilently() {
        if (!hasMinimumAutoSaveFields() || !hasValidOptionalFieldsSilently()) {
            return false;
        }

        if (mode != MODE_ADD) {
            return true;
        }

        Contact contact = buildContact();
        return contactService.findDuplicates(contact).isEmpty();
    }

    private boolean hasMinimumAutoSaveFields() {
        return !TextUtils.isEmpty(getText(etName))
                && (!TextUtils.isEmpty(getText(etPhone)) || !TextUtils.isEmpty(getText(etMobile)));
    }

    private boolean hasValidOptionalFieldsSilently() {
        String email = getText(etEmail);
        if (!TextUtils.isEmpty(email) && !isValidEmail(email)) {
            return false;
        }

        String birthday = getText(etBirthday);
        if (!TextUtils.isEmpty(birthday) && !isValidBirthday(birthday)) {
            return false;
        }

        String homepage = getText(etHomepage);
        return TextUtils.isEmpty(homepage) || homepage.startsWith("http");
    }

    private Contact buildContact() {
        Contact contact = new Contact();
        contact.setName(getText(etName));
        contact.setPhone(getText(etPhone));
        contact.setMobile(getText(etMobile));
        contact.setImTool(getText(etImTool));
        contact.setImAccount(getText(etImAccount));
        contact.setEmail(getText(etEmail));
        contact.setHomepage(getText(etHomepage));
        contact.setBirthday(getText(etBirthday));
        contact.setCompany(getText(etCompany));
        contact.setAddress(getText(etAddress));
        contact.setPostcode(getText(etPostcode));
        contact.setRemark(getText(etRemark));
        contact.setRelationshipTag(getText(etRelationshipTag));
        contact.setFollowUpDate(getText(etFollowUpDate));
        contact.setPhotoPath(currentPhotoPath);
        contact.setPrivateContact(cbPrivateContact.isChecked());

        String selectedGroup = (String) spinnerGroup.getSelectedItem();
        if (selectedGroup != null && groupNameToIdMap.containsKey(selectedGroup)) {
            contact.setGroupId(groupNameToIdMap.get(selectedGroup));
        } else {
            contact.setGroupId(0);
        }
        return contact;
    }

    private boolean validateInput() {
        etName.setError(null);
        etPhone.setError(null);
        etMobile.setError(null);
        etEmail.setError(null);
        etBirthday.setError(null);
        etHomepage.setError(null);

        String name = getText(etName);
        if (TextUtils.isEmpty(name)) {
            etName.setError(getString(R.string.name_required));
            etName.requestFocus();
            return false;
        }

        String phone = getText(etPhone);
        String mobile = getText(etMobile);
        if (TextUtils.isEmpty(phone) && TextUtils.isEmpty(mobile)) {
            String error = getString(R.string.phone_or_mobile_required);
            etPhone.setError(error);
            etMobile.setError(error);
            etPhone.requestFocus();
            return false;
        }

        String email = getText(etEmail);
        if (!TextUtils.isEmpty(email) && !isValidEmail(email)) {
            etEmail.setError(getString(R.string.email_invalid));
            etEmail.requestFocus();
            return false;
        }

        String birthday = getText(etBirthday);
        if (!TextUtils.isEmpty(birthday) && !isValidBirthday(birthday)) {
            etBirthday.setError(getString(R.string.birthday_invalid));
            etBirthday.requestFocus();
            return false;
        }

        String homepage = getText(etHomepage);
        if (!TextUtils.isEmpty(homepage) && !homepage.startsWith("http")) {
            etHomepage.setError("请输入完整的网址（以 http 开头）");
            etHomepage.requestFocus();
            return false;
        }

        return true;
    }

    private String getText(TextInputEditText editText) {
        return editText.getText() != null ? editText.getText().toString().trim() : "";
    }

    private boolean isValidEmail(String email) {
        return Pattern.matches("^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$", email);
    }

    private boolean isValidBirthday(String birthday) {
        return Pattern.matches("^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])$", birthday);
    }

    @Override
    protected void onDestroy() {
        autoSaveHandler.removeCallbacks(autoSaveRunnable);
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (spinnerGroup != null) {
            loadGroups();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSION_CAMERA
                && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            openCamera();
        }
    }
}
