package com.example.addressbook.util;
//数据库类
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "addressbook.db";
    private static final int DATABASE_VERSION = 5;

    public static final String TABLE_GROUPS = "groups";
    public static final String TABLE_CONTACTS = "contacts";
    public static final String TABLE_RECENT = "recent_contacts";

    public static final String GROUP_ID = "id";
    public static final String GROUP_NAME = "name";

    public static final String CONTACT_ID = "id";
    public static final String CONTACT_NAME = "name";
    public static final String CONTACT_PHONE = "phone";
    public static final String CONTACT_MOBILE = "mobile";
    public static final String CONTACT_IM_TOOL = "im_tool";
    public static final String CONTACT_IM_ACCOUNT = "im_account";
    public static final String CONTACT_EMAIL = "email";
    public static final String CONTACT_HOMEPAGE = "homepage";
    public static final String CONTACT_BIRTHDAY = "birthday";
    public static final String CONTACT_PHOTO = "photo_path";
    public static final String CONTACT_COMPANY = "company";
    public static final String CONTACT_ADDRESS = "address";
    public static final String CONTACT_POSTCODE = "postcode";
    public static final String CONTACT_GROUP_ID = "group_id";
    public static final String CONTACT_REMARK = "remark";
    public static final String CONTACT_LAST_VIEWED = "last_viewed_time";
    public static final String CONTACT_PRIVATE = "is_private";
    public static final String CONTACT_RELATIONSHIP = "relationship_tag";
    public static final String CONTACT_FOLLOW_UP = "follow_up_date";

    public static final String RECENT_ID = "id";
    public static final String RECENT_CONTACT_ID = "contact_id";
    public static final String RECENT_VIEWED_TIME = "viewed_time";

    private static DatabaseHelper instance;

    public static synchronized DatabaseHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseHelper(context.getApplicationContext());
        }
        return instance;
    }

    private DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createGroupsTable(db);
        createContactsTable(db);
        createRecentTable(db);
        createIndexes(db); //FOREIGN KEY (group_id) REFERENCES groups(id) ON DELETE SET NULL  FOREIGN KEY (group_id) REFERENCES groups(id) ON DELETE SET NULL
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE contacts ADD COLUMN mobile TEXT");
            db.execSQL("ALTER TABLE contacts ADD COLUMN homepage TEXT");
            db.execSQL("ALTER TABLE contacts ADD COLUMN photo_path TEXT");
            db.execSQL("ALTER TABLE contacts ADD COLUMN company TEXT");
            db.execSQL("ALTER TABLE contacts ADD COLUMN postcode TEXT");
            db.execSQL("ALTER TABLE contacts ADD COLUMN remark TEXT");
            db.execSQL("ALTER TABLE contacts ADD COLUMN last_viewed_time INTEGER DEFAULT 0");
            createRecentTable(db);
            createIndexes(db);
        }
        if (oldVersion < 3) {
            db.execSQL("ALTER TABLE contacts ADD COLUMN is_private INTEGER DEFAULT 0");
        }
        if (oldVersion < 4) {
            db.execSQL("ALTER TABLE contacts ADD COLUMN relationship_tag TEXT");
            db.execSQL("ALTER TABLE contacts ADD COLUMN follow_up_date TEXT");
        }
        if (oldVersion < 5) {
            db.execSQL("ALTER TABLE contacts ADD COLUMN im_tool TEXT");
            db.execSQL("ALTER TABLE contacts ADD COLUMN im_account TEXT");
        }
    }

    private void createGroupsTable(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_GROUPS + " (" +
                GROUP_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                GROUP_NAME + " TEXT NOT NULL UNIQUE" +
                ")");
    }

    private void createContactsTable(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_CONTACTS + " (" +
                CONTACT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                CONTACT_NAME + " TEXT NOT NULL, " +
                CONTACT_PHONE + " TEXT, " +
                CONTACT_MOBILE + " TEXT, " +
                CONTACT_IM_TOOL + " TEXT, " +
                CONTACT_IM_ACCOUNT + " TEXT, " +
                CONTACT_EMAIL + " TEXT, " +
                CONTACT_HOMEPAGE + " TEXT, " +
                CONTACT_BIRTHDAY + " TEXT, " +
                CONTACT_PHOTO + " TEXT, " +
                CONTACT_COMPANY + " TEXT, " +
                CONTACT_ADDRESS + " TEXT, " +
                CONTACT_POSTCODE + " TEXT, " +
                CONTACT_GROUP_ID + " INTEGER, " +
                CONTACT_REMARK + " TEXT, " +
                CONTACT_LAST_VIEWED + " INTEGER DEFAULT 0, " +
                CONTACT_PRIVATE + " INTEGER DEFAULT 0, " +
                CONTACT_RELATIONSHIP + " TEXT, " +
                CONTACT_FOLLOW_UP + " TEXT, " +
                "FOREIGN KEY (" + CONTACT_GROUP_ID + ") REFERENCES " +
                TABLE_GROUPS + "(" + GROUP_ID + ") ON DELETE SET NULL" +
                ")");
    }

    private void createRecentTable(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_RECENT + " (" +
                RECENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                RECENT_CONTACT_ID + " INTEGER NOT NULL, " +
                RECENT_VIEWED_TIME + " INTEGER NOT NULL, " +
                "UNIQUE(" + RECENT_CONTACT_ID + ")" +
                ")");
    }

    private void createIndexes(SQLiteDatabase db) {
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_contacts_name ON " +
                TABLE_CONTACTS + "(" + CONTACT_NAME + ")");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_contacts_phone ON " +
                TABLE_CONTACTS + "(" + CONTACT_PHONE + ")");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_contacts_mobile ON " +
                TABLE_CONTACTS + "(" + CONTACT_MOBILE + ")");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_contacts_last_viewed ON " +
                TABLE_CONTACTS + "(" + CONTACT_LAST_VIEWED + ")");
    }
}
