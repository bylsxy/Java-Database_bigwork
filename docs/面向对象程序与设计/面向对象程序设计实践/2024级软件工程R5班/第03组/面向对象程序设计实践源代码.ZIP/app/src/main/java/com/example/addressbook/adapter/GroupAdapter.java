package com.example.addressbook.adapter;
//GroupAdapter 是分组列表适配器，用于显示分组名称和该分组下联系人数量。它提供点击分组进入详情、点击删除按钮删除分组两个事件接口
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.addressbook.R;
import com.example.addressbook.model.Group;

import java.util.ArrayList;
import java.util.List;

public class GroupAdapter extends RecyclerView.Adapter<GroupAdapter.ViewHolder> {

    private List<Group> groupList = new ArrayList<>();
    private List<Integer> groupContactCounts = new ArrayList<>();
    private OnDeleteClickListener deleteListener;
    private OnItemClickListener itemClickListener;

    public interface OnDeleteClickListener {
        void onDeleteClick(Group group);
    }

    public interface OnItemClickListener {
        void onItemClick(Group group);
    }

    public void setOnDeleteClickListener(OnDeleteClickListener listener) {
        this.deleteListener = listener;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.itemClickListener = listener;
    }

    public void setGroups(List<Group> groups, List<Integer> counts) {
        this.groupList = groups != null ? groups : new ArrayList<>();
        this.groupContactCounts = counts != null ? counts : new ArrayList<>();
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_group, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Group group = groupList.get(position);
        holder.tvGroupName.setText(group.getName());

        int count = position < groupContactCounts.size() ? groupContactCounts.get(position) : 0;
        holder.tvGroupCount.setText(holder.itemView.getContext()
                .getString(R.string.group_member_count, count));

        holder.itemView.setOnClickListener(v -> {
            if (itemClickListener != null) {
                itemClickListener.onItemClick(group);
            }
        });

        holder.btnDelete.setOnClickListener(v -> {
            if (deleteListener != null) {
                deleteListener.onDeleteClick(group);
            }
        });
    }

    @Override
    public int getItemCount() {
        return groupList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvGroupName;
        TextView tvGroupCount;
        View btnDelete;

        ViewHolder(View itemView) {
            super(itemView);
            tvGroupName = itemView.findViewById(R.id.tvGroupName);
            tvGroupCount = itemView.findViewById(R.id.tvGroupCount);
            btnDelete = itemView.findViewById(R.id.btnDeleteGroup);
        }
    }
}
