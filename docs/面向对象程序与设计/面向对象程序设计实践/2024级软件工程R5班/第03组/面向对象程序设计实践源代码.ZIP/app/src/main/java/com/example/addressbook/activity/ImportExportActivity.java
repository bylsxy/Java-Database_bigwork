package com.example.addressbook.activity;

import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.example.addressbook.R;
import com.example.addressbook.model.Contact;
import com.example.addressbook.service.ContactService;
import com.example.addressbook.util.ImportExportUtil;
import com.google.android.material.appbar.MaterialToolbar;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class ImportExportActivity extends AppCompatActivity {

    private MaterialToolbar toolbar;
    private ContactService contactService;
    private CheckBox cbExportIncludePrivate;

    private final ActivityResultLauncher<Intent> exportCsvLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    if (uri != null) {
                        try {
                            List<Contact> contacts = filterExportContacts(contactService.getAllContacts());
                            OutputStream out = getContentResolver().openOutputStream(uri);
                            if (out != null) {
                                ImportExportUtil.exportToCSV(contacts, out);
                                out.close();
                            }
                            Toast.makeText(this,
                                    getString(R.string.export_success_count, contacts.size()),
                                    Toast.LENGTH_SHORT).show();
                        } catch (Exception e) {
                            Toast.makeText(this, R.string.operation_failed, Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });

    private final ActivityResultLauncher<Intent> importCsvLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    if (uri != null) {
                        importContacts(uri, false);
                    }
                }
            });

    private final ActivityResultLauncher<Intent> exportVCardLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    if (uri != null) {
                        try {
                            List<Contact> contacts = filterExportContacts(contactService.getAllContacts());
                            OutputStream out = getContentResolver().openOutputStream(uri);
                            if (out != null) {
                                ImportExportUtil.exportToVCard(contacts, out);
                                out.close();
                            }
                            Toast.makeText(this,
                                    getString(R.string.export_success_count, contacts.size()),
                                    Toast.LENGTH_SHORT).show();
                        } catch (Exception e) {
                            Toast.makeText(this, R.string.operation_failed, Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            });

    private final ActivityResultLauncher<Intent> importVCardLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    if (uri != null) {
                        importContacts(uri, true);
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_import_export);

        contactService = new ContactService(this);
        cbExportIncludePrivate = findViewById(R.id.cbExportIncludePrivate);

        initToolbar();
        initButtons();
    }

    private void initToolbar() {
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.data_management);
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void initButtons() {
        findViewById(R.id.cardExportCsv).setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("text/csv");
            intent.putExtra(Intent.EXTRA_TITLE, "contacts_export.csv");
            exportCsvLauncher.launch(intent);
        });

        findViewById(R.id.cardImportCsv).setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            String[] mimeTypes = {"text/csv", "text/comma-separated-values", "application/csv"};
            intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
            importCsvLauncher.launch(intent);
        });

        findViewById(R.id.cardExportVcard).setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("text/vcard");
            intent.putExtra(Intent.EXTRA_TITLE, "contacts.vcf");
            exportVCardLauncher.launch(intent);
        });

        findViewById(R.id.cardImportVcard).setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            String[] mimeTypes = {"text/vcard", "text/x-vcard", "text/directory"};
            intent.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
            importVCardLauncher.launch(intent);
        });
    }

    private void importContacts(Uri uri, boolean isVCard) {
        try {
            InputStream in = getContentResolver().openInputStream(uri);
            if (in == null) {
                Toast.makeText(this, R.string.operation_failed, Toast.LENGTH_SHORT).show();
                return;
            }

            List<Contact> importedContacts = isVCard
                    ? ImportExportUtil.importFromVCard(in)
                    : ImportExportUtil.importFromCSV(in);
            in.close();

            if (importedContacts.isEmpty()) {
                new AlertDialog.Builder(this)
                        .setTitle(R.string.import_result)
                        .setMessage("未找到可导入的联系人数据")
                        .setPositiveButton(android.R.string.ok, null)
                        .show();
                return;
            }

            int successCount = 0;
            int skipCount = 0;
            int invalidCount = 0;

            for (Contact contact : importedContacts) {
                if (!hasRequiredPhone(contact)) {
                    invalidCount++;
                    continue;
                }

                boolean duplicate = contactService.isDuplicate(
                        contact.getName(),
                        contact.getPhone(),
                        contact.getMobile()
                );

                if (duplicate) {
                    skipCount++;
                } else {
                    contactService.addContact(contact);
                    successCount++;
                }
            }

            StringBuilder message = new StringBuilder();
            message.append(getString(R.string.import_success_count, successCount));
            if (skipCount > 0) {
                message.append("\n").append(getString(R.string.import_skip_count, skipCount));
            }
            if (invalidCount > 0) {
                message.append("\n").append(getString(R.string.import_invalid_phone_count, invalidCount));
            }

            new AlertDialog.Builder(this)
                    .setTitle(R.string.import_result)
                    .setMessage(message.toString())
                    .setPositiveButton(android.R.string.ok, null)
                    .show();

        } catch (Exception e) {
            Toast.makeText(this, R.string.operation_failed, Toast.LENGTH_SHORT).show();
        }
    }

    private boolean hasRequiredPhone(Contact contact) {
        return hasText(contact.getPhone()) || hasText(contact.getMobile());
    }

    private boolean hasText(String value) {
        return value != null && !value.trim().isEmpty();
    }

    private List<Contact> filterExportContacts(List<Contact> contacts) {
        if (cbExportIncludePrivate != null && cbExportIncludePrivate.isChecked()) {
            return contacts;
        }

        List<Contact> filtered = new ArrayList<>();
        for (Contact contact : contacts) {
            if (!contact.isPrivateContact()) {
                filtered.add(contact);
            }
        }
        return filtered;
    }
}
