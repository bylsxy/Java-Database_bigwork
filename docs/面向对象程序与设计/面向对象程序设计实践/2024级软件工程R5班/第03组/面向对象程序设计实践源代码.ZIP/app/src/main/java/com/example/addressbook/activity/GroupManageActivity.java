package com.example.addressbook.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.addressbook.R;
import com.example.addressbook.adapter.GroupAdapter;
import com.example.addressbook.model.Group;
import com.example.addressbook.service.GroupService;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;
import java.util.List;

/**
 * 分组管理 Activity
 * 对应原 JavaFX 版本的 GroupDialogController + 分组管理功能
 */
public class GroupManageActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private GroupAdapter groupAdapter;
    private View emptyView;
    private GroupService groupService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_manage);

        groupService = new GroupService(this);

        initViews();
        setupToolbar();
        setupRecyclerView();
        setupAddButton();
        loadGroups();
    }

    private void initViews() {
        recyclerView = findViewById(R.id.recyclerViewGroups);
        emptyView = findViewById(R.id.emptyView);
    }

    private void setupToolbar() {
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.manage_groups);
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void setupRecyclerView() {
        groupAdapter = new GroupAdapter();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(groupAdapter);

        groupAdapter.setOnDeleteClickListener(group -> {
            showDeleteConfirmDialog(group);
        });
    }

    private void setupAddButton() {
        MaterialButton fabAddGroup = findViewById(R.id.fabAddGroup);
        fabAddGroup.setOnClickListener(v -> showAddGroupDialog());
    }

    private void loadGroups() {
        List<Group> groups = groupService.getAllGroups();
        List<Integer> counts = new ArrayList<>();
        for (Group group : groups) {
            counts.add(groupService.getGroupContactCount(group.getId()));
        }

        groupAdapter.setGroups(groups, counts);

        if (groups.isEmpty()) {
            emptyView.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.GONE);
        } else {
            emptyView.setVisibility(View.GONE);
            recyclerView.setVisibility(View.VISIBLE);
        }
    }

    private void showAddGroupDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_single_input, null);
        TextView tvHint = dialogView.findViewById(R.id.tvDialogHint);
        TextInputEditText editText = dialogView.findViewById(R.id.etDialogInput);
        tvHint.setVisibility(View.GONE);
        editText.setHint(R.string.group_name_hint);

        new AlertDialog.Builder(this)
                .setTitle(R.string.add_group)
                .setView(dialogView)
                .setPositiveButton(R.string.save, (dialog, which) -> {
                    String name = editText.getText() != null ? editText.getText().toString().trim() : "";
                    if (TextUtils.isEmpty(name)) {
                        Toast.makeText(this, R.string.group_name_required, Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (name.length() > 50) {
                        Toast.makeText(this, R.string.group_name_too_long, Toast.LENGTH_SHORT).show();
                        return;
                    }

                    try {
                        Group group = new Group(name);
                        groupService.addGroup(group);
                        Toast.makeText(this, R.string.add_success, Toast.LENGTH_SHORT).show();
                        loadGroups();
                    } catch (Exception e) {
                        Toast.makeText(this, R.string.operation_failed, Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showDeleteConfirmDialog(Group group) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_confirm_title)
                .setMessage(getString(R.string.delete_group_confirm, group.getName()))
                .setPositiveButton(R.string.delete, (dialog, which) -> {
                    try {
                        groupService.deleteGroup(group.getId());
                        Toast.makeText(this, R.string.delete_success, Toast.LENGTH_SHORT).show();
                        loadGroups();
                    } catch (Exception e) {
                        Toast.makeText(this, R.string.operation_failed, Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadGroups();
    }
}
