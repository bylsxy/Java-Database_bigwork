package com.example.addressbook.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.addressbook.R;
import com.example.addressbook.adapter.ContactAdapter;
import com.example.addressbook.adapter.GroupAdapter;
import com.example.addressbook.model.Contact;
import com.example.addressbook.model.Group;
import com.example.addressbook.service.ContactService;
import com.example.addressbook.service.GroupService;
import com.example.addressbook.util.AppPreferences;
import com.example.addressbook.util.ImportExportUtil;
import com.example.addressbook.util.PinyinUtil;
import com.example.addressbook.viewmodel.MainViewModel;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private static final String PREFS_ONBOARDING = "addressbook_prefs";
    private static final String KEY_ONBOARDING_SHOWN = "onboarding_shown";
    private static final String CONTACT_INDEX_SYMBOLS = "#ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final int FILTER_ALL = -1;
    private static final int FILTER_UNGROUPED = -2;

    private MaterialToolbar toolbar;
    private BottomNavigationView bottomNavigation;
    private View rootMain;
    private View sectionDashboard;
    private View sectionContacts;
    private View sectionGroups;
    private View dashboardBanner;

    private TextView tvDashboardSummary;
    private TextView tvStatContacts;
    private TextView tvStatGroups;
    private TextView tvStatGrouped;
    private TextView tvStatBirthdays;
    private TextView tvBirthdayDigest;
    //通讯录页中间那块联系人列表
    private RecyclerView recyclerViewContacts;
    private RecyclerView recyclerViewGroups;
    private ContactAdapter contactAdapter;
    private GroupAdapter groupAdapter;
    private LinearLayoutManager contactsLayoutManager;
    private EditText etSearch;
    private View btnClearSearch;
    private LinearLayout groupFilterLayout;
    private ContactIndexView contactIndexBar;
    private View emptyViewContacts;
    private View emptyViewGroups;
    private FloatingActionButton fabAddContact;
    private View batchActionBar;
    private TextView tvBatchSelectedCount;
    private MaterialButton btnBatchSelectAll;
    private MaterialButton btnBatchDelete;
    private MaterialButton btnBatchExport;
    private MaterialButton btnBatchAssignGroup;
    private MaterialButton btnBatchCancel;

    private MainViewModel viewModel;
    private ContactService contactService;
    private GroupService groupService;

    private final List<View> chipViews = new ArrayList<>();
    private final List<Contact> currentContacts = new ArrayList<>();
    private final List<Group> currentGroups = new ArrayList<>();
    private final Map<String, Integer> contactIndexPositions = new HashMap<>();

    private boolean sortByRecent = false;
    private int currentTabId = R.id.nav_home;
    private int currentGroupFilter = FILTER_ALL;
    private boolean pendingExportVCard = false;
    private boolean birthdayReminderShownThisLaunch = false;
    private List<Contact> pendingExportContacts = new ArrayList<>();

    private final ActivityResultLauncher<Intent> selectedExportLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri uri = result.getData().getData();
                    if (uri != null) {
                        exportSelectedContacts(uri);
                    }
                }
            });
    //页面创建时执行。它会初始化界面、工具栏、列表、搜索框、按钮事件、数据观察，并加载设置
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewModel = new ViewModelProvider(this).get(MainViewModel.class);
        contactService = new ContactService(this);
        groupService = new GroupService(this);

        initViews();
        setupToolbar();
        setupRecyclerViews();
        setupSearch();
        setupActions();
        observeData();
        applySettings();
        bottomNavigation.setSelectedItemId(R.id.nav_home);
        launchOnboardingIfNeeded();
        checkBirthdayReminderOnce();
    }

    private void applySettings() {
        boolean previousSortByRecent = sortByRecent;
        sortByRecent = AppPreferences.DEFAULT_SORT_RECENT.equals(AppPreferences.getDefaultSort(this));
        if (contactAdapter != null) {
            contactAdapter.setCompactMode(AppPreferences.isCompactModeEnabled(this));
            contactAdapter.setSecondaryField(AppPreferences.getListSecondaryField(this));
        }
        applyThemeStyle();
        if (previousSortByRecent != sortByRecent && currentTabId == R.id.nav_contacts) {
            applyCurrentContactFeed();
        }
    }

    //把 XML 布局里的控件通过 findViewById() 找出来，比如工具栏、底部导航栏、联系人列表、搜索框、批量操作按钮等
    private void initViews() {
        toolbar = findViewById(R.id.toolbar);
        bottomNavigation = findViewById(R.id.bottomNavigation);
        rootMain = findViewById(R.id.rootMain);
        sectionDashboard = findViewById(R.id.sectionDashboard);
        sectionContacts = findViewById(R.id.sectionContacts);
        sectionGroups = findViewById(R.id.sectionGroups);
        dashboardBanner = findViewById(R.id.dashboardBanner);

        tvDashboardSummary = findViewById(R.id.tvDashboardSummary);
        tvStatContacts = findViewById(R.id.tvStatContacts);
        tvStatGroups = findViewById(R.id.tvStatGroups);
        tvStatGrouped = findViewById(R.id.tvStatGrouped);
        tvStatBirthdays = findViewById(R.id.tvStatBirthdays);
        tvBirthdayDigest = findViewById(R.id.tvBirthdayDigest);

        recyclerViewContacts = findViewById(R.id.recyclerViewContacts);
        recyclerViewGroups = findViewById(R.id.recyclerViewGroups);
        etSearch = findViewById(R.id.etSearch);
        btnClearSearch = findViewById(R.id.btnClearSearch);
        groupFilterLayout = findViewById(R.id.groupFilterLayout);
        contactIndexBar = findViewById(R.id.contactIndexBar);
        emptyViewContacts = findViewById(R.id.emptyView);
        emptyViewGroups = findViewById(R.id.emptyViewGroups);
        fabAddContact = findViewById(R.id.fabAddContact);
        batchActionBar = findViewById(R.id.batchActionBar);
        tvBatchSelectedCount = findViewById(R.id.tvBatchSelectedCount);
        btnBatchSelectAll = findViewById(R.id.btnBatchSelectAll);
        btnBatchDelete = findViewById(R.id.btnBatchDelete);
        btnBatchExport = findViewById(R.id.btnBatchExport);
        btnBatchAssignGroup = findViewById(R.id.btnBatchAssignGroup);
        btnBatchCancel = findViewById(R.id.btnBatchCancel);
    }

    private void setupToolbar() {
        setSupportActionBar(toolbar);
        toolbar.setTitle(R.string.main_tab_home);
    }

    private void applyThemeStyle() {
        String style = AppPreferences.getThemeStyle(this);
        int background;
        int toolbarColor;
        int bottomColor;
        if (AppPreferences.THEME_STYLE_SOFT.equals(style)) {
            background = Color.rgb(255, 248, 240);
            toolbarColor = Color.rgb(255, 251, 246);
            bottomColor = Color.rgb(255, 251, 246);
            dashboardBanner.setBackgroundResource(R.drawable.bg_dashboard_banner_soft);
        } else if (AppPreferences.THEME_STYLE_CLEAR.equals(style)) {
            background = Color.rgb(239, 246, 255);
            toolbarColor = Color.rgb(248, 251, 255);
            bottomColor = Color.rgb(248, 251, 255);
            dashboardBanner.setBackgroundResource(R.drawable.bg_dashboard_banner_clear);
        } else {
            background = getResources().getColor(R.color.colorBackground, null);
            toolbarColor = getResources().getColor(R.color.colorToolbarSurface, null);
            bottomColor = getResources().getColor(R.color.colorWhite, null);
            dashboardBanner.setBackgroundResource(R.drawable.bg_dashboard_banner);
        }
        getWindow().getDecorView().setBackgroundColor(background);
        rootMain.setBackgroundColor(background);
        sectionDashboard.setBackgroundColor(background);
        sectionContacts.setBackgroundColor(background);
        sectionGroups.setBackgroundColor(background);
        toolbar.setBackgroundColor(toolbarColor);
        bottomNavigation.setBackgroundColor(bottomColor);
    }
    //初始化联系人列表和分组列表。联系人列表用 ContactAdapter，分组列表用 GroupAdapter。这里还设置了点击联系人进入详情、点击电话按钮拨号、长按联系人进入批量模式、点击分组进入分组详情等事件
    private void setupRecyclerViews() {
        contactAdapter = new ContactAdapter();
        contactsLayoutManager = new LinearLayoutManager(this);
        recyclerViewContacts.setLayoutManager(contactsLayoutManager);
        recyclerViewContacts.setAdapter(contactAdapter);

        contactAdapter.setOnItemClickListener(contact -> {
            Intent intent = new Intent(MainActivity.this, ContactDetailActivity.class);
            intent.putExtra(ContactDetailActivity.EXTRA_CONTACT_ID, contact.getId());
            startActivity(intent);
        });

        contactAdapter.setOnCallClickListener(contact -> {
            String phone = contact.getPrimaryPhone();
            if (!phone.isEmpty()) {
                startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone)));
            } else {
                Toast.makeText(this, "该联系人没有电话号码", Toast.LENGTH_SHORT).show();
            }
        });

        contactAdapter.setOnItemLongClickListener(this::enterBatchMode);
        contactAdapter.setOnSelectionChangedListener(count -> updateBatchActionBar());

        groupAdapter = new GroupAdapter();
        recyclerViewGroups.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewGroups.setAdapter(groupAdapter);
        groupAdapter.setOnDeleteClickListener(this::showDeleteConfirmDialog);
        groupAdapter.setOnItemClickListener(group -> {
            Intent intent = new Intent(MainActivity.this, GroupDetailActivity.class);
            intent.putExtra(GroupDetailActivity.EXTRA_GROUP_ID, group.getId());
            startActivity(intent);
        });
    }
    //搜索框添加监听器
    private void setupSearch() {
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                btnClearSearch.setVisibility(s.length() > 0 ? View.VISIBLE : View.GONE);
                applyCurrentContactFeed();//调用 applyCurrentContactFeed() 重新加载联系人列表，实现实时搜索
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        etSearch.setOnEditorActionListener((v, actionId, event) ->
                actionId == EditorInfo.IME_ACTION_SEARCH
                        || (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER));

        btnClearSearch.setOnClickListener(v -> etSearch.setText(""));
    }
    //设置各种按钮点击事件
    private void setupActions() {
        bottomNavigation.setOnItemSelectedListener(item -> {
            switchTab(item.getItemId());
            return true;
        });

        fabAddContact.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, ContactEditActivity.class)));

        MaterialButton btnDashboardAddContact = findViewById(R.id.btnDashboardAddContact);
        MaterialButton btnDashboardAddPrivateContact = findViewById(R.id.btnDashboardAddPrivateContact);
        MaterialButton btnDashboardImportExport = findViewById(R.id.btnDashboardImportExport);
        MaterialButton btnDashboardOpenGroups = findViewById(R.id.btnDashboardOpenGroups);
        MaterialButton btnAddGroup = findViewById(R.id.btnAddGroup);

        btnDashboardAddContact.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, ContactEditActivity.class)));
        btnDashboardAddPrivateContact.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ContactEditActivity.class);
            intent.putExtra(ContactEditActivity.EXTRA_FORCE_PRIVATE, true);
            startActivity(intent);
        });
        btnDashboardImportExport.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, ImportExportActivity.class)));
        btnDashboardOpenGroups.setOnClickListener(v ->
                bottomNavigation.setSelectedItemId(R.id.nav_groups));
        btnAddGroup.setOnClickListener(v -> showAddGroupDialog());

        btnBatchSelectAll.setOnClickListener(v -> {
            contactAdapter.selectAllVisible();
            updateBatchActionBar();
        });
        btnBatchDelete.setOnClickListener(v -> showBatchDeleteDialog());
        btnBatchExport.setOnClickListener(v -> showBatchExportDialog());
        btnBatchAssignGroup.setOnClickListener(v -> {
            List<Integer> selectedIds = contactAdapter.getSelectedIds();
            if (selectedIds.isEmpty()) {
                Toast.makeText(this, R.string.batch_assign_select_none, Toast.LENGTH_SHORT).show();
                return;
            }
            showGroupPickerForBatchAssign(selectedIds);
        });
        btnBatchCancel.setOnClickListener(v -> exitBatchMode());
    }
    //观察 MainViewModel 里的联系人和分组数据
    private void observeData() {
        viewModel.getContacts().observe(this, contacts -> {
            currentContacts.clear();
            if (contacts != null) {
                currentContacts.addAll(contacts);
                if (sortByRecent) {
                    currentContacts.sort((left, right) -> {
                        int result = Long.compare(right.getLastViewedTime(), left.getLastViewedTime());
                        if (result != 0) {
                            return result;
                        }
                        String leftName = left.getName() == null ? "" : left.getName();
                        String rightName = right.getName() == null ? "" : right.getName();
                        return leftName.compareToIgnoreCase(rightName);
                    });
                } else {
                    sortContactsByIndexName(currentContacts);
                }
            }
            contactAdapter.setContacts(currentContacts);
            emptyViewContacts.setVisibility(currentContacts.isEmpty() ? View.VISIBLE : View.GONE);
            recyclerViewContacts.setVisibility(currentContacts.isEmpty() ? View.GONE : View.VISIBLE);
            buildContactIndexBar();
            renderGroups();
            updateDashboard();
        });

        viewModel.getGroups().observe(this, groups -> {
            currentGroups.clear();
            if (groups != null) {
                currentGroups.addAll(groups);
            }
            buildGroupFilterChips(currentGroups);
            renderGroups();
            updateDashboard();
        });
    }

    private void launchOnboardingIfNeeded() {
        SharedPreferences preferences = getSharedPreferences(PREFS_ONBOARDING, MODE_PRIVATE);
        if (!preferences.getBoolean(KEY_ONBOARDING_SHOWN, false)) {
            preferences.edit().putBoolean(KEY_ONBOARDING_SHOWN, true).apply();
            startActivity(new Intent(this, OnboardingActivity.class));
        }
    }
    //控制底部导航切换
    private void switchTab(int tabId) {
        if (contactAdapter != null && contactAdapter.isSelectionMode()) {
            exitBatchMode();
        }
        currentTabId = tabId;
        sectionDashboard.setVisibility(tabId == R.id.nav_home ? View.VISIBLE : View.GONE);
        sectionContacts.setVisibility(tabId == R.id.nav_contacts ? View.VISIBLE : View.GONE);
        sectionGroups.setVisibility(tabId == R.id.nav_groups ? View.VISIBLE : View.GONE);

        if (tabId == R.id.nav_home) {
            toolbar.setTitle(R.string.main_tab_home);
        } else if (tabId == R.id.nav_contacts) {
            toolbar.setTitle(R.string.main_tab_contacts);
        } else {
            toolbar.setTitle(R.string.main_tab_groups);
        }
    }

    private void enterBatchMode(Contact contact) {
        if (contactAdapter.isSelectionMode()) {
            return;
        }
        contactAdapter.setSelectionMode(true);
        contactAdapter.toggleSelection(contact);
        updateBatchActionBar();
    }

    private void exitBatchMode() {
        contactAdapter.setSelectionMode(false);
        updateBatchActionBar();
    }

    private void updateBatchActionBar() {
        if (batchActionBar == null || contactAdapter == null) {
            return;
        }

        boolean active = contactAdapter.isSelectionMode();
        int selectedCount = contactAdapter.getSelectedCount();
        batchActionBar.setVisibility(active ? View.VISIBLE : View.GONE);
        fabAddContact.setVisibility(active ? View.GONE : View.VISIBLE);
        tvBatchSelectedCount.setText(getString(R.string.batch_selection_count, selectedCount));

        boolean hasSelection = selectedCount > 0;
        btnBatchDelete.setEnabled(hasSelection);
        btnBatchExport.setEnabled(hasSelection);
        btnBatchAssignGroup.setEnabled(hasSelection);
    }

    //生成右侧 A-Z 首字母索引。它会统计当前联系人列表中有哪些首字母，并记录每个字母第一次出现的位置
    private void buildContactIndexBar() {
        contactIndexPositions.clear();
        if (contactIndexBar == null) {
            return;
        }

        if (currentContacts.isEmpty()) {
            contactIndexBar.setVisibility(View.GONE);
            return;
        }

        Set<String> availableLetters = new HashSet<>();
        for (int i = 0; i < currentContacts.size(); i++) {
            String letter = PinyinUtil.getFirstLetter(currentContacts.get(i).getName());
            if (letter.length() == 0 || CONTACT_INDEX_SYMBOLS.indexOf(letter) < 0) {
                letter = "#";
            }
            availableLetters.add(letter);
            if (!contactIndexPositions.containsKey(letter)) {
                contactIndexPositions.put(letter, i);
            }
        }

        contactIndexBar.setAvailableLetters(availableLetters);
        contactIndexBar.setOnLetterSelectedListener(this::scrollToContactIndex);
        contactIndexBar.setVisibility(View.VISIBLE);
    }

    private void sortContactsByIndexName(List<Contact> contacts) {
        contacts.sort((left, right) -> {
            String leftName = left.getName() == null ? "" : left.getName();
            String rightName = right.getName() == null ? "" : right.getName();
            String leftLetter = PinyinUtil.getFirstLetter(leftName);
            String rightLetter = PinyinUtil.getFirstLetter(rightName);
            int leftOrder = CONTACT_INDEX_SYMBOLS.indexOf(leftLetter);
            int rightOrder = CONTACT_INDEX_SYMBOLS.indexOf(rightLetter);
            int result = Integer.compare(
                    leftOrder >= 0 ? leftOrder : 0,
                    rightOrder >= 0 ? rightOrder : 0);
            if (result != 0) {
                return result;
            }
            result = PinyinUtil.toPinyinInitial(leftName).compareToIgnoreCase(
                    PinyinUtil.toPinyinInitial(rightName));
            if (result != 0) {
                return result;
            }
            return leftName.compareToIgnoreCase(rightName);
        });
    }
    //点击右侧索引字母时，让联系人列表滚动到对应首字母的位置
    private void scrollToContactIndex(String letter) {
        Integer position = findNearestContactIndexPosition(letter);
        if (position != null && contactsLayoutManager != null) {
            contactsLayoutManager.scrollToPositionWithOffset(position, 0);
        }
    }

    private Integer findNearestContactIndexPosition(String letter) {
        Integer position = contactIndexPositions.get(letter);
        if (position != null) {
            return position;
        }
        int start = CONTACT_INDEX_SYMBOLS.indexOf(letter);
        if (start < 0) {
            return null;
        }
        for (int i = start + 1; i < CONTACT_INDEX_SYMBOLS.length(); i++) {
            position = contactIndexPositions.get(String.valueOf(CONTACT_INDEX_SYMBOLS.charAt(i)));
            if (position != null) {
                return position;
            }
        }
        for (int i = start - 1; i >= 0; i--) {
            position = contactIndexPositions.get(String.valueOf(CONTACT_INDEX_SYMBOLS.charAt(i)));
            if (position != null) {
                return position;
            }
        }
        return null;
    }
    //联系人列表刷新的核心方法。它会根据当前状态决定加载哪种联系人：如果有搜索关键字，就搜索；如果选择了某个分组，就按分组筛选；如果选择未分组，就查未分组；如果选择最近排序，就按最近查看排序；否则显示全部联系人
    private void applyCurrentContactFeed() {
        String keyword = etSearch.getText() != null ? etSearch.getText().toString().trim() : "";
        if (!keyword.isEmpty()) {
            viewModel.search(keyword);
            return;
        }

        if (currentGroupFilter == FILTER_UNGROUPED) {
            viewModel.filterByUngrouped();
            return;
        }
        if (currentGroupFilter > 0) {
            viewModel.filterByGroup(currentGroupFilter);
            return;
        }

        if (sortByRecent) {
            viewModel.sortByRecent();
        } else {
            viewModel.clearSearch();
        }
    }
    //用分组筛选联系人列表
    private void buildGroupFilterChips(List<Group> groups) {
        int selectedFilter = currentGroupFilter;
        groupFilterLayout.removeAllViews();
        chipViews.clear();

        addChip(getString(R.string.all_groups), FILTER_ALL);
        addChip(getString(R.string.ungrouped), FILTER_UNGROUPED);
        for (Group group : groups) {
            addChip(group.getName(), group.getId());
        }

        boolean selectedExists = selectedFilter == FILTER_ALL || selectedFilter == FILTER_UNGROUPED;
        if (!selectedExists) {
            for (Group group : groups) {
                if (group.getId() == selectedFilter) {
                    selectedExists = true;
                    break;
                }
            }
        }
        currentGroupFilter = selectedExists ? selectedFilter : FILTER_ALL;
        selectChipByFilter(currentGroupFilter);
    }

    private void addChip(String name, int filterId) {
        TextView chip = (TextView) LayoutInflater.from(this)
                .inflate(R.layout.item_filter_chip, groupFilterLayout, false);
        chip.setText(name);
        chip.setTag(filterId);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMarginEnd(8);
        chip.setLayoutParams(params);

        chip.setOnClickListener(v -> {
            currentGroupFilter = filterId;
            selectChipByFilter(filterId);
            applyCurrentContactFeed();
        });

        chipViews.add(chip);
        groupFilterLayout.addView(chip);
    }

    private void selectChipByFilter(int filterId) {
        for (View chipView : chipViews) {
            int tag = (int) chipView.getTag();
            boolean selected = tag == filterId;
            chipView.setBackgroundResource(selected
                    ? R.drawable.bg_chip_selected
                    : R.drawable.bg_chip_normal);
            ((TextView) chipView).setTextColor(getResources().getColor(
                    selected ? R.color.colorPrimary : R.color.colorTextSecondary, null));
        }
    }

    private void renderGroups() {
        List<Contact> allContacts = contactService.getAllContacts();
        Map<Integer, Integer> countsByGroup = new HashMap<>();
        for (Contact contact : allContacts) {
            if (contact.getGroupId() > 0) {
                int count = countsByGroup.containsKey(contact.getGroupId())
                        ? countsByGroup.get(contact.getGroupId()) : 0;
                countsByGroup.put(contact.getGroupId(), count + 1);
            }
        }

        List<Integer> counts = new ArrayList<>();
        for (Group group : currentGroups) {
            counts.add(countsByGroup.containsKey(group.getId()) ? countsByGroup.get(group.getId()) : 0);
        }
        groupAdapter.setGroups(currentGroups, counts);

        boolean hasGroups = !currentGroups.isEmpty();
        recyclerViewGroups.setVisibility(hasGroups ? View.VISIBLE : View.GONE);
        emptyViewGroups.setVisibility(hasGroups ? View.GONE : View.VISIBLE);
    }
    //刷新首页统计数据，包括联系人总数、分组数、已分组人数、近期生日人数等。
    private void updateDashboard() {
        List<Contact> allContacts = contactService.getAllContacts();
        int totalContacts = allContacts.size();
        int totalGroups = currentGroups.size();
        int groupedContacts = 0;
        for (Contact contact : allContacts) {
            if (contact.getGroupId() > 0) {
                groupedContacts++;
            }
        }

        int upcomingBirthdays = countUpcomingBirthdays(allContacts, 7);
        int ungroupedContacts = totalContacts - groupedContacts;

        tvStatContacts.setText(String.valueOf(totalContacts));
        tvStatGroups.setText(String.valueOf(totalGroups));
        tvStatGrouped.setText(String.valueOf(groupedContacts));
        tvStatBirthdays.setText(String.valueOf(upcomingBirthdays));
        tvDashboardSummary.setText(getString(
                R.string.dashboard_summary, totalContacts, totalGroups, groupedContacts));
        boolean showFollowUps = AppPreferences.isFollowUpAlertsEnabled(this);
        if (showFollowUps) {
            tvBirthdayDigest.setText(getString(
                    upcomingBirthdays == 0 ? R.string.dashboard_digest_none : R.string.dashboard_digest_birthdays,
                    upcomingBirthdays == 0 ? ungroupedContacts : upcomingBirthdays,
                    ungroupedContacts));
        } else {
            tvBirthdayDigest.setText(getString(
                    upcomingBirthdays == 0
                            ? R.string.dashboard_digest_none_no_followup
                            : R.string.dashboard_digest_birthdays_no_followup,
                    upcomingBirthdays));
        }
    }

    private int countUpcomingBirthdays(List<Contact> contacts, int days) {
        Calendar today = Calendar.getInstance();
        clearTime(today);
        int count = 0;

        for (Contact contact : contacts) {
            if (contact.getBirthday() == null || contact.getBirthday().trim().isEmpty()) {
                continue;
            }
            String[] parts = contact.getBirthday().split("-");
            if (parts.length < 3) {
                continue;
            }

            try {
                int month = Integer.parseInt(parts[1]);
                int day = Integer.parseInt(parts[2]);
                Calendar birthday = Calendar.getInstance();
                clearTime(birthday);
                birthday.set(Calendar.MONTH, month - 1);
                birthday.set(Calendar.DAY_OF_MONTH, day);
                if (birthday.before(today)) {
                    birthday.add(Calendar.YEAR, 1);
                }

                long diff = birthday.getTimeInMillis() - today.getTimeInMillis();
                int diffDays = (int) (diff / (1000L * 60 * 60 * 24));
                if (diffDays >= 0 && diffDays <= days) {
                    count++;
                }
            } catch (NumberFormatException ignored) {
            }
        }

        return count;
    }

    private void clearTime(Calendar calendar) {
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
    }
    //弹出新建分组对话框
    private void showAddGroupDialog() {
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_single_input, null);
        TextView tvHint = dialogView.findViewById(R.id.tvDialogHint);
        TextInputEditText editText = dialogView.findViewById(R.id.etDialogInput);
        tvHint.setVisibility(View.GONE);
        editText.setHint(R.string.group_name_hint);

        new AlertDialog.Builder(this)
                .setTitle(R.string.add_group)
                .setView(dialogView)
                .setPositiveButton(R.string.save, (dialog, which) -> {
                    String name = editText.getText() != null ? editText.getText().toString().trim() : "";
                    if (name.isEmpty()) {
                        Toast.makeText(this, R.string.group_name_required, Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (name.length() > 50) {
                        Toast.makeText(this, R.string.group_name_too_long, Toast.LENGTH_SHORT).show();
                        return;
                    }

                    try {
                        groupService.addGroup(new Group(name));
                        Toast.makeText(this, R.string.add_success, Toast.LENGTH_SHORT).show();
                        viewModel.refreshGroups();
                    } catch (Exception e) {
                        Toast.makeText(this, R.string.operation_failed, Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showDeleteConfirmDialog(Group group) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_confirm_title)
                .setMessage(getString(R.string.delete_group_confirm, group.getName()))
                .setPositiveButton(R.string.delete, (dialog, which) -> {
                    try {
                        groupService.deleteGroup(group.getId());
                        Toast.makeText(this, R.string.delete_success, Toast.LENGTH_SHORT).show();
                        viewModel.refreshGroups();
                        viewModel.refreshContacts();
                    } catch (Exception e) {
                        Toast.makeText(this, R.string.operation_failed, Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showBatchDeleteDialog() {
        List<Integer> selectedIds = contactAdapter.getSelectedIds();
        if (selectedIds.isEmpty()) {
            Toast.makeText(this, R.string.batch_assign_select_none, Toast.LENGTH_SHORT).show();
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle(R.string.delete_confirm_title)
                .setMessage(getString(R.string.batch_delete_confirm, selectedIds.size()))
                .setPositiveButton(R.string.delete, (dialog, which) -> {
                    contactService.deleteContacts(selectedIds);
                    Toast.makeText(this, R.string.delete_success, Toast.LENGTH_SHORT).show();
                    exitBatchMode();
                    viewModel.refreshContacts();
                    viewModel.refreshGroups();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void showBatchExportDialog() {
        pendingExportContacts = contactAdapter.getSelectedContacts();
        if (pendingExportContacts.isEmpty()) {
            Toast.makeText(this, R.string.batch_assign_select_none, Toast.LENGTH_SHORT).show();
            return;
        }

        String[] formats = {"CSV", "vCard"};
        new AlertDialog.Builder(this)
                .setTitle(R.string.batch_export_selected)
                .setItems(formats, (dialog, which) -> {
                    pendingExportVCard = which == 1;
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType(pendingExportVCard ? "text/vcard" : "text/csv");
                    intent.putExtra(Intent.EXTRA_TITLE,
                            pendingExportVCard ? "selected_contacts.vcf" : "selected_contacts.csv");
                    selectedExportLauncher.launch(intent);
                })
                .show();
    }

    private void exportSelectedContacts(Uri uri) {
        try {
            OutputStream out = getContentResolver().openOutputStream(uri);
            if (out != null) {
                if (pendingExportVCard) {
                    ImportExportUtil.exportToVCard(pendingExportContacts, out);
                } else {
                    ImportExportUtil.exportToCSV(pendingExportContacts, out);
                }
                out.close();
            }
            Toast.makeText(this,
                    getString(R.string.export_success_count, pendingExportContacts.size()),
                    Toast.LENGTH_SHORT).show();
            exitBatchMode();
        } catch (Exception e) {
            Toast.makeText(this, R.string.operation_failed, Toast.LENGTH_SHORT).show();
        }
    }

    private void showGroupPickerForBatchAssign(List<Integer> contactIds) {
        List<String> names = new ArrayList<>();
        List<Integer> ids = new ArrayList<>();
        names.add(getString(R.string.ungrouped));
        ids.add(0);
        for (Group group : currentGroups) {
            names.add(group.getName());
            ids.add(group.getId());
        }

        new AlertDialog.Builder(this)
                .setTitle(R.string.batch_assign_pick_target)
                .setItems(names.toArray(new String[0]), (dialog, which) -> {
                    int count = contactService.assignContactsToGroup(contactIds, ids.get(which));
                    Toast.makeText(this, getString(R.string.batch_assign_success, count), Toast.LENGTH_SHORT).show();
                    exitBatchMode();
                    viewModel.refreshContacts();
                    viewModel.refreshGroups();
                })
                .show();
    }

    private void checkBirthdayReminderOnce() {
        if (birthdayReminderShownThisLaunch || !AppPreferences.isBirthdayReminderEnabled(this)) {
            return;
        }
        birthdayReminderShownThisLaunch = true;
        new Thread(() -> {
            List<Contact> upcoming = contactService.getUpcomingBirthdays(7);
            if (!upcoming.isEmpty()) {
                runOnUiThread(() -> showBirthdayReminder(upcoming));
            }
        }).start();
    }

    private void showBirthdayReminder(List<Contact> contacts) {
        StringBuilder message = new StringBuilder();
        for (Contact contact : contacts) {
            message.append("- ").append(contact.getName());
            if (contact.getBirthday() != null && contact.getBirthday().length() >= 10) {
                message.append(" (")
                        .append(contact.getBirthday().substring(5, 7))
                        .append("/")
                        .append(contact.getBirthday().substring(8, 10))
                        .append(")");
            }
            message.append("\n");
        }

        new AlertDialog.Builder(this)
                .setTitle(R.string.birthday_reminder)
                .setMessage(getString(R.string.birthday_reminder_msg, message.toString()))
                .setPositiveButton(R.string.confirm, null)
                .show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        MenuItem sortItem = menu.findItem(R.id.action_sort_recent);
        if (sortItem != null) {
            sortItem.setVisible(currentTabId == R.id.nav_contacts);
            sortItem.setTitle(sortByRecent ? R.string.sort_by_name : R.string.sort_by_recent);
        }
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_sort_recent) {
            sortByRecent = !sortByRecent;
            AppPreferences.setDefaultSort(this,
                    sortByRecent ? AppPreferences.DEFAULT_SORT_RECENT : AppPreferences.DEFAULT_SORT_NAME);
            applyCurrentContactFeed();
            invalidateOptionsMenu();
            return true;
        }
        if (id == R.id.action_import_export) {
            startActivity(new Intent(this, ImportExportActivity.class));
            return true;
        }
        if (id == R.id.action_settings) {
            startActivity(new Intent(this, SettingsActivity.class));
            return true;
        }
        if (id == R.id.action_about) {
            new AlertDialog.Builder(this)
                    .setTitle(R.string.about_title)
                    .setMessage(R.string.about_message)
                    .setPositiveButton(R.string.confirm, null)
                    .show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        applySettings();
        applyCurrentContactFeed();
        viewModel.refreshGroups();
    }

}
