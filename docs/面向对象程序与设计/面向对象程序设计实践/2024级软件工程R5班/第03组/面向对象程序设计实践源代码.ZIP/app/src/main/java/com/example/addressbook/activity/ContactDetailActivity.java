package com.example.addressbook.activity;
//展示联系人完整资料，并提供拨号、发邮件、打开主页、编辑、删除等操作。亲密联系人在详情页打开时会根据设置进行验证
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import com.example.addressbook.R;
import com.example.addressbook.model.Contact;
import com.example.addressbook.service.ContactService;
import com.example.addressbook.util.AppPreferences;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.concurrent.Executor;

public class ContactDetailActivity extends AppCompatActivity {

    public static final String EXTRA_CONTACT_ID = "contact_id";
    private static final int SYSTEM_AUTHENTICATORS =
            BiometricManager.Authenticators.BIOMETRIC_WEAK
                    | BiometricManager.Authenticators.DEVICE_CREDENTIAL;

    private ContactService contactService;
    private Contact currentContact;
    private boolean privateContentVisible = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_detail);

        contactService = new ContactService(this);

        int contactId = getIntent().getIntExtra(EXTRA_CONTACT_ID, -1);
        if (contactId <= 0) {
            finish();
            return;
        }

        currentContact = contactService.getContactById(contactId);
        if (currentContact == null) {
            Toast.makeText(this, "联系人不存在", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        setupToolbar();
        if (shouldRequestPrivateUnlock()) {
            requestPrivateUnlock();
        } else {
            showUnlockedContent();
        }
        setupButtons();
    }

    private void setupToolbar() {
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(currentContact.getName());
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void requestPrivateUnlock() {
        String mode = AppPreferences.getPrivacyMode(this);
        if (!AppPreferences.hasUsablePrivacyCredential(this)) {
            Toast.makeText(this, R.string.settings_lock_requires_credential, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        if (AppPreferences.PRIVACY_MODE_SYSTEM.equals(mode)) {
            showSystemAuthPrompt();
            return;
        }

        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_single_input, null);
        TextView tvHint = dialogView.findViewById(R.id.tvDialogHint);
        TextInputEditText editText = dialogView.findViewById(R.id.etDialogInput);
        tvHint.setVisibility(View.GONE);
        editText.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        editText.setHint(R.string.settings_privacy_pin_hint);

        new AlertDialog.Builder(this)
                .setTitle(R.string.private_contact_verify)
                .setView(dialogView)
                .setCancelable(false)
                .setPositiveButton(R.string.confirm, (dialog, which) -> {
                    String pin = editText.getText() != null ? editText.getText().toString().trim() : "";
                    boolean verified = AppPreferences.matchesPrivacyPin(this, pin);
                    if (verified) {
                        showUnlockedContent();
                    } else {
                        Toast.makeText(this, R.string.private_contact_pin_error, Toast.LENGTH_SHORT).show();
                        finish();
                    }
                })
                .setNegativeButton(R.string.cancel, (dialog, which) -> finish())
                .show();
    }

    private void showSystemAuthPrompt() {
        BiometricManager biometricManager = BiometricManager.from(this);
        int canAuthenticate = biometricManager.canAuthenticate(SYSTEM_AUTHENTICATORS);
        if (canAuthenticate != BiometricManager.BIOMETRIC_SUCCESS) {
            Toast.makeText(this, R.string.settings_system_auth_unavailable, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt biometricPrompt = new BiometricPrompt(this, executor,
                new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                        super.onAuthenticationSucceeded(result);
                        showUnlockedContent();
                    }

                    @Override
                    public void onAuthenticationError(int errorCode, CharSequence errString) {
                        super.onAuthenticationError(errorCode, errString);
                        if (errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON
                                && errorCode != BiometricPrompt.ERROR_USER_CANCELED
                                && errorCode != BiometricPrompt.ERROR_CANCELED) {
                            Toast.makeText(ContactDetailActivity.this, errString, Toast.LENGTH_SHORT).show();
                        }
                        finish();
                    }
                });

        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle(getString(R.string.private_contact_verify))
                .setSubtitle(getString(R.string.private_contact_system_auth))
                .setAllowedAuthenticators(SYSTEM_AUTHENTICATORS)
                .build();
        biometricPrompt.authenticate(promptInfo);
    }

    private void showUnlockedContent() {
        privateContentVisible = true;
        contactService.recordViewed(currentContact.getId());
        setupViews();
    }

    private void setupViews() {
        privateContentVisible = true;
        ImageView ivPhoto = findViewById(R.id.ivPhoto);
        loadPhoto(ivPhoto, currentContact.getPhotoPath());

        TextView tvName = findViewById(R.id.tvName);
        tvName.setText(currentContact.getName());

        setTextOrHide(R.id.tvPhone, currentContact.getPhone(), "无");
        setupClickRow(R.id.rowPhone, currentContact.getPhone(), () -> dial(currentContact.getPhone()));

        setTextOrHide(R.id.tvMobile, currentContact.getMobile(), "无");
        setupClickRow(R.id.rowMobile, currentContact.getMobile(), () -> dial(currentContact.getMobile()));

        setTextOrHide(R.id.tvImTool, currentContact.getImTool(), "无");
        setTextOrHide(R.id.tvImAccount, currentContact.getImAccount(), "无");

        setTextOrHide(R.id.tvEmail, currentContact.getEmail(), "无");
        setupClickRow(R.id.rowEmail, currentContact.getEmail(), () -> sendEmail(currentContact.getEmail()));

        setTextOrHide(R.id.tvHomepage, currentContact.getHomepage(), "无");
        setupClickRow(R.id.rowHomepage, currentContact.getHomepage(), () -> openUrl(currentContact.getHomepage()));

        setTextOrHide(R.id.tvCompany, currentContact.getCompany(), "无");
        setTextOrHide(R.id.tvAddress, currentContact.getAddress(), "无");
        setTextOrHide(R.id.tvPostcode, currentContact.getPostcode(), "无");
        setTextOrHide(R.id.tvBirthday, currentContact.getBirthday(), "无");

        TextView tvGroup = findViewById(R.id.tvGroup);
        tvGroup.setText(currentContact.getGroupName() != null ? currentContact.getGroupName() : "未分组");

        View privateBadge = findViewById(R.id.tvPrivateBadge);
        privateBadge.setVisibility(currentContact.isPrivateContact() ? View.VISIBLE : View.GONE);
        toggleExtendedRows(AppPreferences.showExtendedFields(this));

        String remark = currentContact.getRemark();
        LinearLayout rowRemark = findViewById(R.id.rowRemark);
        if (remark != null && !remark.isEmpty()) {
            rowRemark.setVisibility(View.VISIBLE);
            TextView tvRemark = findViewById(R.id.tvRemark);
            tvRemark.setText(remark);
        } else {
            rowRemark.setVisibility(View.GONE);
        }
    }

    private void toggleExtendedRows(boolean visible) {
        int visibility = visible ? View.VISIBLE : View.GONE;
        findViewById(R.id.rowHomepage).setVisibility(visibility);
        findViewById(R.id.rowCompany).setVisibility(visibility);
        findViewById(R.id.rowAddress).setVisibility(visibility);
        findViewById(R.id.rowPostcode).setVisibility(visibility);
        findViewById(R.id.rowBirthday).setVisibility(visibility);
        findViewById(R.id.rowGroup).setVisibility(visibility);
    }

    private void setTextOrHide(int textViewId, String value, String fallback) {
        TextView tv = findViewById(textViewId);
        tv.setText(value != null && !value.isEmpty() ? value : fallback);
    }

    private void setupClickRow(int rowId, String value, Runnable action) {
        View row = findViewById(rowId);
        if (value != null && !value.isEmpty()) {
            row.setOnClickListener(v -> action.run());
        } else {
            row.setClickable(false);
        }
    }
    //设置底部按钮
    private void setupButtons() {
        MaterialButton btnEdit = findViewById(R.id.btnEdit);
        MaterialButton btnDelete = findViewById(R.id.btnDelete);
        //跳转到 ContactEditActivity，并传入编辑模式和联系人 id
        btnEdit.setOnClickListener(v -> {
            Intent intent = new Intent(ContactDetailActivity.this, ContactEditActivity.class);
            intent.putExtra(ContactEditActivity.EXTRA_MODE, ContactEditActivity.MODE_EDIT);
            intent.putExtra(ContactEditActivity.EXTRA_CONTACT_ID, currentContact.getId());
            startActivity(intent);
        });

        btnDelete.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle(R.string.delete_confirm_title)
                .setMessage(getString(R.string.delete_contact_confirm, currentContact.getName()))
                .setPositiveButton(R.string.delete, (dialog, which) -> {
                    contactService.deleteContact(currentContact.getId());
                    Toast.makeText(this, R.string.delete_success, Toast.LENGTH_SHORT).show();
                    finish();
                })
                .setNegativeButton(R.string.cancel, null)
                .show());
    }

    private void loadPhoto(ImageView iv, String path) {
        if (path != null && !path.isEmpty()) {
            try {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inSampleSize = 4;
                android.graphics.Bitmap bitmap = BitmapFactory.decodeFile(path, options);
                if (bitmap != null) {
                    iv.setImageBitmap(bitmap);
                    iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                    return;
                }
            } catch (Exception ignored) {
            }
        }
        iv.setImageResource(R.drawable.avatar_placeholder);
        iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
    }

    private void dial(String phone) {
        if (phone != null && !phone.isEmpty()) {
            startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone)));
        }
    }

    private void sendEmail(String email) {
        if (email != null && !email.isEmpty()) {
            startActivity(Intent.createChooser(
                    new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + email)), "发送邮件"));
        }
    }

    private void openUrl(String url) {
        if (url != null && !url.isEmpty()) {
            startActivity(Intent.createChooser(
                    new Intent(Intent.ACTION_VIEW, Uri.parse(url)), getString(R.string.open_browser)));
        }
    }
    //从编辑页面返回详情页时，它会重新查询数据库中的联系人数据
    @Override
    protected void onResume() {
        super.onResume();
        if (currentContact != null) {
            currentContact = contactService.getContactById(currentContact.getId());
            if (currentContact != null) {
                if (privateContentVisible) {
                    setupViews();
                }
                MaterialToolbar toolbar = findViewById(R.id.toolbar);
                toolbar.setTitle(currentContact.getName());
            }
        }
    }

    private boolean shouldRequestPrivateUnlock() {
        return currentContact != null
                && currentContact.isPrivateContact()
                && !AppPreferences.PRIVACY_MODE_NONE.equals(AppPreferences.getPrivacyMode(this))
                && AppPreferences.hasUsablePrivacyCredential(this)
                && !AppPreferences.isPrivacyUnlocked(this);
    }
}
