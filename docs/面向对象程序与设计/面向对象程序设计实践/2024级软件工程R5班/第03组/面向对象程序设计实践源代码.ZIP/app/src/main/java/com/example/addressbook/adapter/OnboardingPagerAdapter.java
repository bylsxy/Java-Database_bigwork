package com.example.addressbook.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.ColorRes;
import androidx.annotation.DrawableRes;
import androidx.annotation.NonNull;
import androidx.annotation.StringRes;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.addressbook.R;
import com.google.android.material.card.MaterialCardView;

import java.util.List;

public class OnboardingPagerAdapter extends RecyclerView.Adapter<OnboardingPagerAdapter.ViewHolder> {

    public static class OnboardingPage {
        @StringRes public final int badgeRes;
        @StringRes public final int titleRes;
        @StringRes public final int descriptionRes;
        @DrawableRes public final int iconRes;
        @ColorRes public final int accentColorRes;

        public OnboardingPage(int badgeRes, int titleRes, int descriptionRes,
                              int iconRes, int accentColorRes) {
            this.badgeRes = badgeRes;
            this.titleRes = titleRes;
            this.descriptionRes = descriptionRes;
            this.iconRes = iconRes;
            this.accentColorRes = accentColorRes;
        }
    }

    private final List<OnboardingPage> pages;

    public OnboardingPagerAdapter(List<OnboardingPage> pages) {
        this.pages = pages;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_onboarding_page, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        OnboardingPage page = pages.get(position);
        holder.tvBadge.setText(page.badgeRes);
        holder.tvTitle.setText(page.titleRes);
        holder.tvDescription.setText(page.descriptionRes);
        holder.ivIcon.setImageResource(page.iconRes);
        holder.cardIllustration.setCardBackgroundColor(
                ContextCompat.getColor(holder.itemView.getContext(), page.accentColorRes));
    }

    @Override
    public int getItemCount() {
        return pages.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvBadge;
        TextView tvTitle;
        TextView tvDescription;
        ImageView ivIcon;
        MaterialCardView cardIllustration;

        ViewHolder(View itemView) {
            super(itemView);
            tvBadge = itemView.findViewById(R.id.tvPageBadge);
            tvTitle = itemView.findViewById(R.id.tvPageTitle);
            tvDescription = itemView.findViewById(R.id.tvPageDescription);
            ivIcon = itemView.findViewById(R.id.ivPageIcon);
            cardIllustration = itemView.findViewById(R.id.cardIllustration);
        }
    }
}
