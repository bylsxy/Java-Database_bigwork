package com.example.addressbook.model;
//联系人实体类
public class Contact {

    private int id;
    private String name;
    private String phone;
    private String mobile;
    private String imTool;
    private String imAccount;
    private String email;
    private String homepage;
    private String birthday;
    private String photoPath;
    private String company;
    private String address;
    private String postcode;
    private int groupId;
    private String groupName;
    private String remark;
    private long lastViewedTime; //最近查看时间，保存时间戳，用于“最近联系人”排序
    private boolean privateContact;
    private String relationshipTag;
    private String followUpDate; //	联系提醒日期，用于记录后续需要联系该联系人的时间

    public Contact() {
    }

    public Contact(int id, String name, String phone, String email,
                   String address, String birthday, int groupId) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.address = address;
        this.birthday = birthday;
        this.groupId = groupId;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getMobile() { return mobile; }
    public void setMobile(String mobile) { this.mobile = mobile; }

    public String getImTool() { return imTool; }
    public void setImTool(String imTool) { this.imTool = imTool; }

    public String getImAccount() { return imAccount; }
    public void setImAccount(String imAccount) { this.imAccount = imAccount; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getHomepage() { return homepage; }
    public void setHomepage(String homepage) { this.homepage = homepage; }

    public String getBirthday() { return birthday; }
    public void setBirthday(String birthday) { this.birthday = birthday; }

    public String getPhotoPath() { return photoPath; }
    public void setPhotoPath(String photoPath) { this.photoPath = photoPath; }

    public String getCompany() { return company; }
    public void setCompany(String company) { this.company = company; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getPostcode() { return postcode; }
    public void setPostcode(String postcode) { this.postcode = postcode; }

    public int getGroupId() { return groupId; }
    public void setGroupId(int groupId) { this.groupId = groupId; }

    public String getGroupName() { return groupName; }
    public void setGroupName(String groupName) { this.groupName = groupName; }

    public String getRemark() { return remark; }
    public void setRemark(String remark) { this.remark = remark; }

    public long getLastViewedTime() { return lastViewedTime; }
    public void setLastViewedTime(long lastViewedTime) { this.lastViewedTime = lastViewedTime; }

    public boolean isPrivateContact() { return privateContact; }
    public void setPrivateContact(boolean privateContact) { this.privateContact = privateContact; }

    public String getRelationshipTag() { return relationshipTag; }
    public void setRelationshipTag(String relationshipTag) { this.relationshipTag = relationshipTag; }

    public String getFollowUpDate() { return followUpDate; }
    public void setFollowUpDate(String followUpDate) { this.followUpDate = followUpDate; }

    public String getPrimaryPhone() {
        if (mobile != null && !mobile.isEmpty()) return mobile;
        if (phone != null && !phone.isEmpty()) return phone;
        return "";
    }

    @Override
    public String toString() {
        return "Contact{id=" + id + ", name='" + name + "', phone='" + phone + "'}";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Contact contact = (Contact) o;
        return id == contact.id;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }
}
