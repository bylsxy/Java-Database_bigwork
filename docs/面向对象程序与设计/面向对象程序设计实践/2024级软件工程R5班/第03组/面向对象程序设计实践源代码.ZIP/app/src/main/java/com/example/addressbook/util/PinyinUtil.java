package com.example.addressbook.util;
//PinyinUtil 是拼音首字母工具类，用来把中文姓名转换成首字母。搜索时可以用它实现拼音首字母匹配，排序和右侧 A-Z 索引也依赖它判断联系人属于哪个首字母
import java.text.Collator;
import java.util.Locale;

/**
 * 拼音工具类
 * 提供简单的汉字到拼音首字母的转换功能
 * 使用 Unicode 编码范围估算，适用于常见汉字
 */
public class PinyinUtil {

    // 拼音首字母对照表
    private static final String[] PINYIN_ARRAY = {
            "A", "B", "C", "D", "E", "F", "G",
            "H", "J", "K", "L", "M", "N",
            "O", "P", "Q", "R", "S", "T",
            "W", "X", "Y", "Z"
    };
    private static final String[] PINYIN_BOUNDARIES = {
            "\u963F", "\u82AD", "\u64E6", "\u642D", "\u86FE", "\u53D1", "\u5676",
            "\u54C8", "\u51FB", "\u5580", "\u5783", "\u5988", "\u62FF",
            "\u54E6", "\u556A", "\u671F", "\u7136", "\u6492", "\u584C",
            "\u6316", "\u6614", "\u538B", "\u531D"
    };
    private static final Collator CHINA_COLLATOR = Collator.getInstance(Locale.CHINA);

    /**
     * 获取字符串的拼音首字母字符串
     * 例如："张三" -> "ZS", "abc" -> "ABC", "张三丰" -> "ZSF"
     */
    public static String toPinyinInitial(String str) {
        if (str == null || str.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (c >= 'A' && c <= 'Z') {
                sb.append(c);
            } else if (c >= 'a' && c <= 'z') {
                sb.append(Character.toUpperCase(c));
            } else if (c >= 0x4E00 && c <= 0x9FA5) {
                sb.append(getPinyinByUnicode(c));
            }
            // 其他字符跳过
        }
        return sb.toString();
    }

    /**
     * 将输入字符串转为拼音形式（用于搜索匹配）
     * 中文转首字母，英文直接大写
     */
    public static String toPinyin(String str) {
        return toPinyinInitial(str);
    }

    public static String getFirstLetter(String str) {
        if (str == null) return "#";
        String text = str.trim();
        if (text.isEmpty()) return "#";

        char c = text.charAt(0);
        if (c >= 'A' && c <= 'Z') {
            return String.valueOf(c);
        } else if (c >= 'a' && c <= 'z') {
            return String.valueOf(Character.toUpperCase(c));
        } else if (c >= 0x4E00 && c <= 0x9FA5) {
            return getPinyinByUnicode(c);
        }
        return "#";
    }

    /**
     * 判断字符串是否匹配拼音搜索
     * 例如：keyword="zs" 可以匹配 "张三"
     */
    public static boolean matchesPinyin(String name, String keyword) {
        if (name == null || keyword == null) return false;
        String pinyin = toPinyinInitial(name);
        return pinyin.toUpperCase().contains(keyword.toUpperCase());
    }

    private static String getPinyinByUnicode(char c) {
        String text = String.valueOf(c);
        for (int i = PINYIN_BOUNDARIES.length - 1; i >= 0; i--) {
            if (CHINA_COLLATOR.compare(text, PINYIN_BOUNDARIES[i]) >= 0) {
                return PINYIN_ARRAY[i];
            }
        }
        return "#";
    }
}
