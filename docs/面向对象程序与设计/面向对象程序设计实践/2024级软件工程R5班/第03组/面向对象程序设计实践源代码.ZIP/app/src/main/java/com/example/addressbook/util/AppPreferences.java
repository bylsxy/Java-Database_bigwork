package com.example.addressbook.util;
//AppPreferences 是设置管理类，使用 SharedPreferences 保存应用设置。比如生日提醒开关、亲密联系人验证方式、PIN 哈希值、主题风格、紧凑列表模式、列表副标题显示字段等都由它统一读写
import android.content.Context;
import android.content.SharedPreferences;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public final class AppPreferences {

    public static final String PRIVACY_MODE_NONE = "none";
    public static final String PRIVACY_MODE_SYSTEM = "system";
    public static final String PRIVACY_MODE_PIN = "pin";
    public static final String THEME_STYLE_LIGHT = "light";
    public static final String THEME_STYLE_SOFT = "soft";
    public static final String THEME_STYLE_CLEAR = "clear";
    public static final String DEFAULT_SORT_NAME = "name";
    public static final String DEFAULT_SORT_RECENT = "recent";
    public static final String LIST_FIELD_PHONE = "phone";
    public static final String LIST_FIELD_EMAIL = "email";
    public static final String LIST_FIELD_IM = "im";
    public static final String LIST_FIELD_COMPANY = "company";
    public static final String LIST_FIELD_GROUP = "group";

    private static final String PREFS_NAME = "addressbook_app_settings";
    private static final String KEY_BIRTHDAY_REMINDER = "birthday_reminder";
    private static final String KEY_PRIVACY_PIN_HASH = "privacy_pin_hash";
    private static final String KEY_PRIVACY_MODE = "privacy_mode";
    private static final String KEY_PRIVACY_UNLOCKED = "privacy_unlocked";
    private static final String KEY_SHOW_EXTENDED_FIELDS = "show_extended_fields";
    private static final String KEY_COMPACT_MODE = "compact_mode";
    private static final String KEY_FOLLOW_UP_ALERTS = "follow_up_alerts";
    private static final String KEY_THEME_STYLE = "theme_style";
    private static final String KEY_DEFAULT_SORT = "default_sort";
    private static final String KEY_LIST_SECONDARY_FIELD = "list_secondary_field";

    private AppPreferences() {
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public static boolean isBirthdayReminderEnabled(Context context) {
        return prefs(context).getBoolean(KEY_BIRTHDAY_REMINDER, true);
    }

    public static void setBirthdayReminderEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(KEY_BIRTHDAY_REMINDER, enabled).apply();
    }

    public static String getPrivacyMode(Context context) {
        SharedPreferences preferences = prefs(context);
        if (preferences.contains(KEY_PRIVACY_MODE)) {
            String mode = preferences.getString(KEY_PRIVACY_MODE, PRIVACY_MODE_NONE);
            if (PRIVACY_MODE_SYSTEM.equals(mode)
                    || PRIVACY_MODE_PIN.equals(mode)
                    || PRIVACY_MODE_NONE.equals(mode)) {
                return mode;
            }
            return preferences.contains(KEY_PRIVACY_PIN_HASH) ? PRIVACY_MODE_PIN : PRIVACY_MODE_NONE;
        }
        if (preferences.contains(KEY_PRIVACY_PIN_HASH)) {
            return PRIVACY_MODE_PIN;
        }
        return PRIVACY_MODE_NONE;
    }

    public static void setPrivacyMode(Context context, String mode) {
        SharedPreferences.Editor editor = prefs(context).edit()
                .putString(KEY_PRIVACY_MODE, mode)
                .putBoolean(KEY_PRIVACY_UNLOCKED, false);
        editor.apply();
    }

    public static boolean hasPrivacyPin(Context context) {
        return prefs(context).contains(KEY_PRIVACY_PIN_HASH);
    }

    public static boolean savePrivacyPin(Context context, String pin) {
        if (pin == null || !pin.matches("^\\d{4,8}$")) {
            return false;
        }
        prefs(context).edit()
                .putString(KEY_PRIVACY_PIN_HASH, sha256(pin))
                .putString(KEY_PRIVACY_MODE, PRIVACY_MODE_PIN)
                .putBoolean(KEY_PRIVACY_UNLOCKED, true)
                .apply();
        return true;
    }

    public static boolean verifyPrivacyPin(Context context, String pin) {
        boolean matched = matchesPrivacyPin(context, pin);
        if (matched) {
            unlockPrivateContacts(context);
        }
        return matched;
    }

    public static boolean matchesPrivacyPin(Context context, String pin) {
        String storedHash = prefs(context).getString(KEY_PRIVACY_PIN_HASH, null);
        if (storedHash == null || pin == null) {
            return false;
        }
        return storedHash.equals(sha256(pin));
    }

    public static void clearPrivacyCredentials(Context context) {
        prefs(context).edit()
                .remove(KEY_PRIVACY_PIN_HASH)
                .putString(KEY_PRIVACY_MODE, PRIVACY_MODE_NONE)
                .remove(KEY_PRIVACY_UNLOCKED)
                .apply();
    }

    public static boolean isPrivacyUnlocked(Context context) {
        if (!hasUsablePrivacyCredential(context)) {
            unlockPrivateContacts(context);
            return true;
        }
        String mode = getPrivacyMode(context);
        return PRIVACY_MODE_NONE.equals(mode) || prefs(context).getBoolean(KEY_PRIVACY_UNLOCKED, false);
    }

    public static boolean hasUsablePrivacyCredential(Context context) {
        String mode = getPrivacyMode(context);
        return PRIVACY_MODE_SYSTEM.equals(mode)
                || (PRIVACY_MODE_PIN.equals(mode) && hasPrivacyPin(context));
    }

    public static void unlockPrivateContacts(Context context) {
        prefs(context).edit().putBoolean(KEY_PRIVACY_UNLOCKED, true).apply();
    }

    public static void lockPrivateContacts(Context context) {
        if (!hasUsablePrivacyCredential(context)) {
            unlockPrivateContacts(context);
            return;
        }
        prefs(context).edit().putBoolean(KEY_PRIVACY_UNLOCKED, false).apply();
    }

    public static boolean showExtendedFields(Context context) {
        return prefs(context).getBoolean(KEY_SHOW_EXTENDED_FIELDS, true);
    }

    public static void setShowExtendedFields(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(KEY_SHOW_EXTENDED_FIELDS, enabled).apply();
    }

    public static boolean isCompactModeEnabled(Context context) {
        return prefs(context).getBoolean(KEY_COMPACT_MODE, false);
    }

    public static void setCompactModeEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(KEY_COMPACT_MODE, enabled).apply();
    }

    public static boolean isFollowUpAlertsEnabled(Context context) {
        return prefs(context).getBoolean(KEY_FOLLOW_UP_ALERTS, true);
    }

    public static void setFollowUpAlertsEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(KEY_FOLLOW_UP_ALERTS, enabled).apply();
    }

    public static String getThemeStyle(Context context) {
        return prefs(context).getString(KEY_THEME_STYLE, THEME_STYLE_LIGHT);
    }

    public static void setThemeStyle(Context context, String style) {
        prefs(context).edit().putString(KEY_THEME_STYLE, style).apply();
    }

    public static String getDefaultSort(Context context) {
        return prefs(context).getString(KEY_DEFAULT_SORT, DEFAULT_SORT_NAME);
    }

    public static void setDefaultSort(Context context, String sort) {
        prefs(context).edit().putString(KEY_DEFAULT_SORT, sort).apply();
    }

    public static String getListSecondaryField(Context context) {
        String field = prefs(context).getString(KEY_LIST_SECONDARY_FIELD, LIST_FIELD_PHONE);
        if (LIST_FIELD_EMAIL.equals(field)
                || LIST_FIELD_IM.equals(field)
                || LIST_FIELD_COMPANY.equals(field)
                || LIST_FIELD_GROUP.equals(field)
                || LIST_FIELD_PHONE.equals(field)) {
            return field;
        }
        return LIST_FIELD_PHONE;
    }

    public static void setListSecondaryField(Context context, String field) {
        prefs(context).edit().putString(KEY_LIST_SECONDARY_FIELD, field).apply();
    }

    private static String sha256(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder builder = new StringBuilder();
            for (byte b : bytes) {
                builder.append(String.format("%02x", b));
            }
            return builder.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
