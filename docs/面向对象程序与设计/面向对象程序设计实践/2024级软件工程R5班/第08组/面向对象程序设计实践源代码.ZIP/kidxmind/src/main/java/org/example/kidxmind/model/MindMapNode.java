package org.example.kidxmind.model;

import java.util.ArrayList;
import java.util.List;

/**
 * <h1>思维导图节点</h1>
 *
 * <p>这是整个思维导图的核心数据结构。每个节点是树中的一个结点，包含：</p>
 * <ul>
 *   <li><b>文本内容</b> —— 节点显示的文字</li>
 *   <li><b>树形关系</b> —— 指向父节点和子节点的引用</li>
 *   <li><b>布局坐标</b> —— 在画布上的位置（x, y）和尺寸（width, height）</li>
 *   <li><b>方向标记</b> —— 标记自己在父节点的左侧还是右侧</li>
 * </ul>
 *
 * <p><b>坐标系统说明：</b>所有坐标都是"逻辑坐标"，即相对于中心节点(0,0)的偏移量。
 * 实际屏幕位置由 DrawingPane 中的变换（平移 + 缩放 + 画布居中）决定。</p>
 *
 * <p><b>x, y 含义：</b>节点的中心点坐标，不是左上角。</p>
 *
 * @see MindMapModel 数据模型（管理整棵树、选中状态、剪贴板）
 */
public class MindMapNode {

    // ========== 基本属性 ==========

    /** 唯一标识符，通过 UUID 生成，用于命中测试时匹配节点 */
    private final String id;

    /** 节点显示的文本内容，默认为空字符串（不是 null） */
    private String text;

    /** 父节点引用；如果是根节点（中心节点），parent 为 null */
    private MindMapNode parent;

    /** 子节点列表，按添加顺序排列。此顺序决定了布局中的展示顺序 */
    private final List<MindMapNode> children;

    // ========== 布局属性（由 DrawingPane 的布局算法计算）==========

    /** 节点中心点在逻辑坐标系中的 X 坐标 */
    private double x;

    /** 节点中心点在逻辑坐标系中的 Y 坐标 */
    private double y;

    /** 节点矩形的宽度（由布局计算得出）。 */
    private double width;

    /** 用户自定义宽度。0 表示使用默认宽度 NODE_WIDTH，>0 表示用户拖拽调整后的宽度 */
    private double userWidth = 0;

    /** 节点矩形的高度。由文本内容自动计算，最小 MIN_NODE_HEIGHT */
    private double height;

    /**
     * 标记此节点位于父节点的左侧还是右侧。
     * - true  = 左侧（节点向左侧展开）
     * - false = 右侧（节点向右侧展开）
     * 只有中心节点的子孙节点此值才有意义，中心节点本身无方向。
     */
    private boolean leftSide;

    // ========== 构造方法 ==========

    /**
     * 创建一个新节点。
     *
     * @param text 初始文本，可以为 null（自动转为空字符串）
     */
    public MindMapNode(String text) {
        this.id = java.util.UUID.randomUUID().toString();
        this.text = text == null ? "" : text;
        this.children = new ArrayList<>();
    }

    // ========== 树结构操作 ==========

    /** 判断是否为根节点（中心节点）。根节点没有 parent。 */
    public boolean isRoot() {
        return parent == null;
    }

    /** 判断是否为叶子节点（没有子节点的节点）。*/
    public boolean isLeaf() {
        return children.isEmpty();
    }

    /**
     * 在末尾添加一个子节点。
     * 同时设置子节点的 parent 指向自己，建立双向关联。
     */
    public void addChild(MindMapNode child) {
        children.add(child);
        child.parent = this;
    }

    /**
     * 在指定位置插入子节点。
     *
     * @param index 插入位置（0 表示第一个）
     * @param child 要插入的子节点
     */
    public void addChildAt(int index, MindMapNode child) {
        children.add(index, child);
        child.parent = this;
    }

    /** 移除指定子节点，同时断开子节点的 parent 引用。 */
    public void removeChild(MindMapNode child) {
        children.remove(child);
        child.parent = null;
    }

    /**
     * 从父节点中移除自己。
     * 调用此方法即可从树中删除此节点（以及它的整棵子树，因为失去引用后会被 GC 回收）。
     */
    public void removeFromParent() {
        if (parent != null) {
            parent.children.remove(this);
            parent = null;
        }
    }

    /**
     * <h3>深拷贝整棵子树</h3>
     * <p>递归复制此节点及其所有子孙，但 <b>不复制 parent 引用</b>。</p>
     * <p>用途：复制（Ctrl+C）/ 剪切（Ctrl+X）时，将选中的子树复制到剪贴板。</p>
     *
     * @return 与原始节点完全独立的新子树副本
     */
    public MindMapNode deepCopy() {
        MindMapNode copy = new MindMapNode(this.text);
        for (MindMapNode child : children) {
            copy.addChild(child.deepCopy());
        }
        return copy;
    }

    // ========== getters / setters ==========

    public String getId() { return id; }

    public String getText() { return text; }

    /** 设置文本。传入 null 自动转为空字符串。 */
    public void setText(String text) {
        this.text = text == null ? "" : text;
    }

    public MindMapNode getParent() { return parent; }

    public List<MindMapNode> getChildren() { return children; }

    public double getX() { return x; }
    public void setX(double x) { this.x = x; }

    public double getY() { return y; }
    public void setY(double y) { this.y = y; }

    public double getWidth() { return width; }
    public void setWidth(double width) { this.width = width; }

    /** 用户自定义宽度，0 表示使用默认 */
    public double getUserWidth() { return userWidth; }
    public void setUserWidth(double w) { this.userWidth = w; }

    public double getHeight() { return height; }
    public void setHeight(double height) { this.height = height; }

    public boolean isLeftSide() { return leftSide; }
    public void setLeftSide(boolean leftSide) { this.leftSide = leftSide; }

    /**
     * 获取节点连接线的"出口"X 坐标。
     * - 左侧子节点：连线从节点左边缘出发（x - width/2）
     * - 右侧子节点：连线从节点右边缘出发（x + width/2）
     */
    public double getConnectionRightX() {
        return leftSide ? x - width / 2 : x + width / 2;
    }

    /** 获取节点连接线的"入口"X 坐标（与出口相反）。*/
    public double getConnectionLeftX() {
        return leftSide ? x + width / 2 : x - width / 2;
    }

    @Override
    public String toString() {
        return text.isEmpty() ? "(空)" : text;
    }
}
