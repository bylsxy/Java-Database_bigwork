package org.example.kidxmind.command;

import org.example.kidxmind.model.MindMapModel;
import org.example.kidxmind.model.MindMapNode;

/**
 * <h1>粘贴节点命令</h1>
 *
 * <h2>这个命令做了什么</h2>
 * <p>将剪贴板中的节点深拷贝后粘贴到目标节点的子节点列表中。
 * 根据剪贴板的模式不同，行为也不同：</p>
 * <ul>
 *   <li><b>复制模式</b>（clipboardCut == false）：纯粹的复制粘贴，源节点不受影响</li>
 *   <li><b>剪切模式</b>（clipboardCut == true）：粘贴的同时删除源节点，实现"移动"效果</li>
 * </ul>
 *
 * <h2>execute() 做什么</h2>
 * <ol>
 *   <li>记录当前的剪贴板模式（wasCutMode）</li>
 *   <li>调用 {@link MindMapModel#pasteTo(MindMapNode)} 执行粘贴：
 *       <ul>
 *         <li>深拷贝剪贴板内容</li>
 *         <li>将拷贝添加到 target 的子节点列表</li>
 *         <li>如果是剪切模式，删除源节点</li>
 *       </ul>
 *   </li>
 * </ol>
 *
 * <h2>undo() 做什么</h2>
 * <ol>
 *   <li>移除粘贴产生的新节点</li>
 *   <li>如果是剪切模式，将源节点放回原来的位置（恢复"移动"操作）</li>
 *   <li>恢复剪贴板到粘贴前的状态</li>
 *   <li>选中回 target 节点</li>
 * </ol>
 *
 * <h2>为什么要区分复制模式和剪切模式？</h2>
 * <p>两种模式下 undo 的复杂度不同：</p>
 * <ul>
 *   <li>复制模式：undo 只需移除粘贴出来的副本</li>
 *   <li>剪切模式：undo 需要做两件事——移除副本 + 把源节点放回原位。
 *       因为剪切本质上是一个"移动"操作，undo 就是"移回去"。</li>
 * </ul>
 *
 * <h2>用到的 Java 概念</h2>
 * <ul>
 *   <li><b>条件分支</b> —— {@code if (model.isClipboardCut())} 根据状态选择不同的
 *       处理逻辑。这是状态驱动的设计模式。</li>
 *   <li><b>深拷贝（Deep Copy）</b> —— 粘贴时不是直接使用剪贴板中的引用，
 *       而是创建一个全新的副本。这样粘贴出来的节点和剪贴板中的节点互不影响。</li>
 *   <li><b>构造器中预捕获</b> —— 类似于 DeleteNodeCommand，在 execute() 之前
 *       就把剪切源节点的 parent 和 index 记录下来。因为 execute() 中
 *       PasteCommand 会删除源节点，届时再想获取位置信息就晚了。</li>
 * </ul>
 */
public class PasteCommand implements Command {

    /** 数据模型 */
    private final MindMapModel model;

    /**
     * 粘贴的目标节点——剪贴板内容将作为 target 的子节点添加。
     */
    private final MindMapNode target;

    // ========== 粘贴前的剪贴板状态（undo 时恢复） ==========

    /** 粘贴前剪贴板中保存的节点副本 */
    private final MindMapNode oldClipboard;

    /** 粘贴前剪贴板的模式标记（true = 剪切模式，false = 复制模式） */
    private final boolean oldClipboardCut;

    /** 粘贴前剪贴板的剪切源节点引用 */
    private final MindMapNode oldCutSourceNode;

    // ========== 剪切模式下预捕获的位置信息 ==========

    /**
     * 剪切源节点的父节点。
     * 只在剪切模式下有效（复制模式下为 null）。
     * undo() 时需要把源节点重新挂回到这个父节点下。
     */
    private MindMapNode cutSourceParent;

    /**
     * 剪切源节点在父节点 children 列表中的位置索引。
     * 只在剪切模式下有效。undo() 时需要把源节点精确恢复到原位置。
     */
    private int cutSourceIndex;

    // ========== execute() 产生的信息 ==========

    /**
     * execute() 中粘贴产生的新节点引用。
     * undo() 时需要把它从树中移除。
     */
    private MindMapNode pastedNode;

    /**
     * execute() 执行时剪贴板是否为剪切模式。
     * 需要单独保存这个值，因为 execute() 中 model.pasteTo() 可能会
     * 修改 model 的剪贴板状态，所以不能等到 undo() 时再查。
     */
    private boolean wasCutMode;

    /**
     * 构造粘贴命令。
     *
     * <h3>构造器中的"预捕获"逻辑</h3>
     * <p>构造器做两件事：</p>
     * <ol>
     *   <li>保存粘贴前的剪贴板状态（oldClipboard、oldClipboardCut、oldCutSourceNode）。
     *       这些值在 undo() 时用于恢复剪贴板。</li>
     *   <li>如果是剪切模式，捕获剪切源节点的位置信息（cutSourceParent、cutSourceIndex）。
     *       因为 execute() 中的 pasteTo() 会删除源节点，必须提前记录位置。</li>
     * </ol>
     *
     * <p>这体现了命令模式的核心思想：<b>在执行操作之前，先把恢复所需的所有信息
     * 都记录下来</b>。就像一个拆弹专家，动手之前先拍照、做笔记，
     * 万一失误还能原样装回去。</p>
     *
     * @param model  数据模型
     * @param target 粘贴的目标父节点
     */
    public PasteCommand(MindMapModel model, MindMapNode target) {
        this.model = model;
        this.target = target;

        // 保存粘贴前的剪贴板快照
        this.oldClipboard = model.getClipboard();
        this.oldClipboardCut = model.isClipboardCut();
        this.oldCutSourceNode = model.getCutSourceNode();

        // 如果是剪切模式，提前捕获 cutSourceNode 的位置（在 execute 删除之前）
        if (model.isClipboardCut() && model.getCutSourceNode() != null) {
            MindMapNode src = model.getCutSourceNode();
            this.cutSourceParent = src.getParent();
            this.cutSourceIndex = cutSourceParent.getChildren().indexOf(src);
        }
    }

    /**
     * 执行粘贴操作。
     *
     * <p>执行流程：</p>
     * <ol>
     *   <li>记录当前是否为剪切模式（{@code wasCutMode}），供 undo() 判断</li>
     *   <li>调用 {@code model.pasteTo(target)} 执行粘贴：
     *       <ul>
     *         <li><b>深拷贝</b>：将剪贴板中的节点（含整棵子树）完全复制一份</li>
     *         <li><b>添加子节点</b>：把复制出来的节点添加到 target 的子节点列表中</li>
     *         <li><b>剪切模式额外操作</b>：调用 {@code cutSourceNode.removeFromParent()}
     *             将源节点从原来的位置删除，实现"移动"效果</li>
     *       </ul>
     *   </li>
     *   <li>将返回的新节点引用保存到 {@code pastedNode}，供 undo() 移除</li>
     * </ol>
     */
    @Override
    public void execute() {
        wasCutMode = model.isClipboardCut();
        pastedNode = model.pasteTo(target);
    }

    /**
     * 撤销粘贴操作，恢复到粘贴前的状态。
     *
     * <p>撤销分三步，顺序不能乱：</p>
     * <ol>
     *   <li><b>移除粘贴的节点</b>：{@code pastedNode.removeFromParent()}
     *       将粘贴时新增的节点从 target 的子节点列表中移除。
     *       这个 step 在复制模式和剪切模式下都需要。</li>
     *
     *   <li><b>恢复剪切源节点（仅剪切模式）</b>：
     *       {@code cutSourceParent.addChildAt(cutSourceIndex, oldCutSourceNode)}
     *       将被剪切走的源节点放回原来的父节点和原来的位置。
     *       这样"剪切+粘贴=移动"的效果就被完全撤销了。</li>
     *
     *   <li><b>恢复剪贴板状态</b>：
     *       {@code model.restoreClipboard(oldClipboard, oldClipboardCut, oldCutSourceNode)}
     *       把剪贴板的内容、模式和源节点引用都恢复到粘贴前的值。</li>
     *
     *   <li><b>恢复选中</b>：{@code model.selectNode(target)} 选中回粘贴的目标节点</li>
     * </ol>
     */
    @Override
    public void undo() {
        // 1. 移除粘贴的节点
        if (pastedNode != null) {
            pastedNode.removeFromParent();
        }

        // 2. 如果是剪切模式，将原剪切节点放回原位
        if (wasCutMode && oldCutSourceNode != null) {
            cutSourceParent.addChildAt(cutSourceIndex, oldCutSourceNode);
        }

        // 3. 恢复剪贴板到粘贴前的状态
        model.restoreClipboard(oldClipboard, oldClipboardCut, oldCutSourceNode);

        // 4. 恢复选中
        model.selectNode(target);
    }

    /**
     * 返回操作的中文描述。
     * @return "粘贴节点"
     */
    @Override
    public String getDescription() { return "粘贴节点"; }
}
