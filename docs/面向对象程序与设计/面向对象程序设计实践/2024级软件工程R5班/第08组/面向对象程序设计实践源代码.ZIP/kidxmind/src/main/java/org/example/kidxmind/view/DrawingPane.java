package org.example.kidxmind.view;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import org.example.kidxmind.controller.MindMapController;
import org.example.kidxmind.model.MindMapModel;
import org.example.kidxmind.model.MindMapNode;

import java.util.*;

/**
 * <h1>思维导图绘图区组件</h1>
 *
 * <p>这是整个应用中最复杂的组件，集成了<b>布局计算、Canvas 绘制、用户交互、
 * 文本编辑</b>四大职责。它是 Model（数据）和用户（眼睛+鼠标）之间的桥梁：
 * 把 Model 中的节点树变成屏幕上可见的图形，同时把用户的鼠标操作转发给 Controller。</p>
 *
 * <h2>四大职责</h2>
 * <ol>
 *   <li><b>布局计算</b> —— 递归计算每个节点在逻辑坐标系中的 (x, y) 位置</li>
 *   <li><b>Canvas 绘制</b> —— 在画布上绘制节点矩形、贝塞尔连线、多行文字</li>
 *   <li><b>用户交互</b> —— 单击选中、双击编辑、Ctrl+滚轮缩放、拖拽平移、
 *       拖拽调整节点宽度、拖拽交换节点</li>
 *   <li><b>文本编辑</b> —— 在 Canvas 上方叠加 TextArea 实现原地编辑</li>
 * </ol>
 *
 * <h2>核心数据流</h2>
 * <pre>
 * 用户操作（鼠标/键盘）
 *     │
 *     ▼
 * 事件处理器（本类中的 handleMouse / handleScroll 等）
 *     │
 *     ▼
 * Controller.xxx()  ← 转发给控制器执行业务逻辑
 *     │
 *     ▼
 * Model 更新（节点树状态变化）
 *     │
 *     ▼
 * Controller.refreshAll()  ← 控制器通知所有视图刷新
 *     │
 *     ▼
 * DrawingPane.redraw()
 *   ├── layoutAllNodes()  ← 重新计算所有节点的逻辑坐标
 *   └── drawAll()         ← 清空 Canvas 并重新绘制所有内容
 * </pre>
 *
 * <h2>使用的 JavaFX 关键概念（面向初学者）</h2>
 *
 * <h3>1. Canvas（画布）—— "像素画板"</h3>
 * <p>{@link Canvas} 是 JavaFX 提供的<b>位图画布</b>。你可以把它想象成一张白纸，
 * 通过 {@link GraphicsContext}（画笔）在上面画线、画矩形、写文字。
 * 一旦画上去，就变成了纸上的像素——你不能再"选中"或"移动"某个已经画好的图形，
 * 只能擦掉重画。</p>
 *
 * <p><b>Canvas vs Shape（为什么选 Canvas？）</b></p>
 * <ul>
 *   <li><b>Shape</b>（如 Rectangle、Circle）：每个图形是一个独立的 JavaFX
 *       Node，有自己的事件系统、CSS 样式、布局属性。如果思维导图有 100 个节点，
 *       就需要 100 个 Node 对象 → 内存开销大、渲染慢。</li>
 *   <li><b>Canvas</b>：所有图形画在同一张位图上，只需要一个 Canvas 节点。
 *       批量绘制几百个节点非常高效。代价是需要自己实现命中测试（判断点击了哪个节点）
 *       和交互逻辑（因为没有独立的事件系统）。</li>
 * </ul>
 * <p>对于可能有几十到几百个节点的思维导图，Canvas 是更合适的选择。</p>
 *
 * <h3>2. GraphicsContext（绘图上下文）—— "画笔"</h3>
 * <p>{@link GraphicsContext} 是操作 Canvas 的唯一途径，类似于 HTML5 Canvas 的
 * {@code getContext('2d')}。通过它可以：</p>
 * <ul>
 *   <li><b>设置样式</b>：setFill（填充色）、setStroke（边框色）、
 *       setLineWidth（线宽）、setFont（字体）</li>
 *   <li><b>绘制图形</b>：fillRoundRect（圆角矩形填充）、strokeRoundRect（圆角矩形边框）、
 *       fillText（文字）、quadraticCurveTo（贝塞尔曲线）</li>
 *   <li><b>变换坐标</b>：translate（平移）、scale（缩放）</li>
 *   <li><b>save() / restore()</b>：保存/恢复状态。save 把当前的变换矩阵、颜色、
 *       字体等设置压入栈；restore 弹出栈顶恢复。这保证了我们的变换不会影响其他绘制代码。</li>
 * </ul>
 *
 * <h3>3. 坐标变换（Transform）—— "三层叠加"</h3>
 * <p>Canvas 有自己独立的坐标系。通过 GraphicsContext 的变换方法，可以实现
 * 缩放和平移。在 drawAll() 中应用了三层变换：</p>
 * <pre>
 * gc.translate(cx, cy);      // 第 1 步：原点移到画布中心
 * gc.scale(scale, scale);     // 第 2 步：缩放（以原点为中心）
 * gc.translate(tx, ty);       // 第 3 步：平移
 * </pre>
 * <p><b>变换是累积的，顺序至关重要！</b></p>
 * <ul>
 *   <li>先 translate 再 scale：translate 偏移量会被 scale 放大。
 *       例如 translate(10,0) 再 scale(2) → 实际偏移 20px</li>
 *   <li>先 scale 再 translate：translate 偏移量不变。
 *       例如 scale(2) 再 translate(10,0) → 实际偏移 10px</li>
 * </ul>
 * <p>我们使用 gc.translate(tx,ty) 后 gc.scale(scale,scale) 的顺序，
 * 使得 (tx, ty) 在缩放后的坐标系中生效——也就是说 tx/ty 是"屏幕像素"单位。</p>
 * <p>变换后的效果：逻辑坐标 (0,0) 处的内容显示在屏幕中心，缩放和平移围绕中心进行。</p>
 *
 * <h3>4. StackPane（堆叠面板）—— "图层叠加"</h3>
 * <p>{@link StackPane} 是一个<b>堆叠式布局容器</b>：所有子节点叠放在一起，
 * 后添加的在上面。本类继承 StackPane，形成两层结构：</p>
 * <ul>
 *   <li><b>底层：Canvas</b> —— 绘制思维导图的所有图形</li>
 *   <li><b>上层：TextArea</b> —— 编辑浮层，覆盖在节点上方用于输入文字</li>
 * </ul>
 * <p>TextArea 设置了 {@code setManaged(false)}（见下文），使它脱离 StackPane
 * 的自动布局管理，位置由代码手动控制。</p>
 *
 * <h3>5. setManaged(false) —— "脱离布局管理"</h3>
 * <p>JavaFX 中，每个 Node 都有一个 {@code managed} 属性（默认 true）。
 * 当 managed 为 true 时，父布局容器会自动计算和设置该 Node 的位置和大小。
 * 当设为 false 时：</p>
 * <ul>
 *   <li>父容器<b>忽略</b>这个 Node，不为它保留空间</li>
 *   <li>Node 的位置和大小<b>完全由代码手动控制</b></li>
 *   <li>必须使用 {@code resizeRelocate(x, y, w, h)} 来设置位置和大小，
 *       不能用 setLayoutX/setPrefWidth（它们只对 managed 的 Node 有效）</li>
 * </ul>
 * <p>在本类中，TextArea 设为 unmanaged，因为它的位置需要精确跟随被编辑的节点，
 * 而不是由 StackPane 自动居中。这是实现"原地编辑"效果的关键。</p>
 *
 * <h3>6. 属性绑定（bind）—— "自动同步"</h3>
 * <p>JavaFX 的<b>属性绑定</b>机制可以让一个属性自动跟随另一个属性的值变化：</p>
 * <pre>
 * canvas.widthProperty().bind(this.widthProperty());
 * </pre>
 * <p>这行代码的意思是：Canvas 的宽度<b>始终等于</b> DrawingPane（this）的宽度。
 * 当 DrawingPane 的宽度改变时（如窗口缩放），Canvas 的宽度自动同步更新。
 * 无需手动写监听器，是一种声明式的编程方式。</p>
 * <p>{@code widthProperty()} 返回一个 {@code DoubleProperty} 对象，
 * 它实现了"属性"模式，带有事件通知机制。</p>
 *
 * <h3>7. 事件处理（Event Handling）—— "监听用户操作"</h3>
 * <p>JavaFX 使用<b>事件驱动</b>模型。当用户操作鼠标、键盘、滚轮时，
 * 系统生成一个 Event 对象，然后调用注册好的事件处理器（Event Handler）。</p>
 * <ul>
 *   <li>{@code addEventHandler(MouseEvent.ANY, handler)} —— 监听<b>所有类型</b>
 *       的鼠标事件（按下、拖拽、释放、点击、移动），在处理器内部根据
 *       event.getEventType() 分辨具体类型后分发到不同方法。</li>
 *   <li>{@code setOnScroll(handler)} —— 专门监听滚轮事件（ScrollEvent）。
 *       注意 ScrollEvent 不是 MouseEvent 的子类型，所以不能用 addEventHandler 捕获。</li>
 *   <li>{@code addEventFilter(KeyEvent.KEY_PRESSED, handler)} —— 拦截键盘事件。
 *       与 addEventHandler 的区别：filter 在<b>事件冒泡前</b>执行，
 *       可以调用 {@code e.consume()} 阻止事件继续传播（如拦截 Enter 键防止 TextArea 换行）。</li>
 * </ul>
 *
 * <h3>8. Platform.runLater —— "延迟到下一帧执行"</h3>
 * <p>{@link javafx.application.Platform#runLater(Runnable)} 将一段代码
 * 放入 JavaFX 主线程的事件队列末尾，在当前帧的所有 UI 操作完成后才执行。</p>
 * <p>常见用途：</p>
 * <ul>
 *   <li><b>防抖</b>：同一帧内多次触发的事件（如 resize）只需要一次重绘，
 *       用 runLater 合并为一次</li>
 *   <li><b>等待布局完成</b>：设置组件属性后，布局系统可能在下一帧才完成计算，
 *       用 runLater 确保拿到最终尺寸</li>
 *   <li><b>避免事件冲突</b>：在事件处理器中直接修改 UI 可能导致嵌套事件，
 *       用 runLater 延迟到事件处理完成后再执行</li>
 * </ul>
 *
 * <h2>关键设计决策（为什么这样做）</h2>
 *
 * <h3>命中测试用 nodeScreenBounds Map 缓存</h3>
 * <p>因为 Canvas 上的图形是无状态的像素，无法像 Shape 节点那样直接通过
 * Node.contains() 判断点击位置。每次绘制时，我们把每个节点的屏幕坐标存到
 * nodeScreenBounds 这个 Map 中。点击时遍历这个 Map 做矩形碰撞检测。</p>
 *
 * <h3>防抖机制（redrawPending 标记）</h3>
 * <p>JavaFX 在初始布局阶段可能多次微调组件尺寸（可能达到 4-5 次）。
 * 不用防抖的话，每次微调都触发一次完整的布局计算+重绘，造成闪烁和性能浪费。
 * 用 redrawPending 标记 + Platform.runLater，同一帧内的多次 resize
 * 只触发一次真正的 redraw。</p>
 *
 * <h3>缩放以鼠标为中心的计算公式</h3>
 * <p>默认缩放是以画布中心为原点的。如果直接改 scale 而不调整 translate，
 * 鼠标下的内容会"跑掉"（因为缩放前后鼠标对应的逻辑坐标变了）。
 * 我们需要在缩放后调整 translate，使得缩放前后鼠标下的逻辑坐标保持不变。
 * 具体推导见 handleScroll 方法。</p>
 *
 * <h3>文本手动换行（Canvas 不支持自动换行）</h3>
 * <p>JavaFX Canvas 的 fillText 方法不支持自动换行（不像 HTML Canvas 那样
 * 有 maxWidth 参数）。必须手动逐字符测量宽度，在适当位置断行。
 * 详见 drawWrappedText 和 wrapLine 方法。</p>
 *
 * <h3>resize 监听从 Canvas 移到 Scene + 最近 Canvas 自身尺寸 &gt;2px 监听</h3>
 * <p>最初只监听 Canvas 自身的宽高变化。但发现：</p>
 * <ul>
 *   <li>监听 Scene 的尺寸变化可以覆盖更多场景（如窗口最大化）</li>
 *   <li>SplitPane 拖拽时 Canvas 的尺寸变化可能只有 1px（CSS 微调），
 *       设置 2px 阈值可以过滤掉这些无意义的微小变化</li>
 * </ul>
 *
 * <h2>绘制相关的关键概念</h2>
 *
 * <h3>drawAll() 的三阶段变换</h3>
 * <p>见上文"坐标变换"一节。三层变换使得逻辑坐标 (0,0) 永远是根节点的位置，
 * 方便布局计算；而屏幕中心、缩放、平移都由变换矩阵处理。</p>
 *
 * <h3>贝塞尔曲线连线（quadraticCurveTo）</h3>
 * <p>使用两段二次贝塞尔曲线绘制"L 形"弯折连线，比直线更美观。
 * 第一段从父节点边缘水平出发到中间点，第二段从中间点垂直到达子节点边缘。</p>
 *
 * <h3>drawNode() 中的 fillRoundRect + strokeRoundRect</h3>
 * <p>先填充矩形再描边，形成"白底灰边"的卡片效果。选中的节点有不同的配色。
 * 选中节点边框更粗（2.5/drawScale），确保在缩放时视觉上保持一致。</p>
 */
public class DrawingPane extends StackPane {

    // ========================================================================
    // 布局常量
    //   - 这些值决定了思维导图的视觉效果
    //   - 单位全部是"逻辑坐标"（模型空间），不受缩放影响
    // ========================================================================

    /**
     * 节点内部水平内边距（文字左右留白）。
     * 单位：逻辑坐标。在固定节点宽度内，文字区域 = nodeWidth - 2 * NODE_PADDING_X
     */
    private static final double NODE_PADDING_X = 10;

    /**
     * 节点内部垂直内边距（文字上下留白）。
     * 单位：逻辑坐标。在动态节点高度内，文字区域 = nodeHeight - 2 * NODE_PADDING_Y
     */
    private static final double NODE_PADDING_Y = 10;

    /**
     * 节点圆角矩形的圆角半径。
     * 值越大边角越圆润。参照 XMind 的圆角卡片风格。
     */
    private static final double NODE_ARC = 10;

    /**
     * 父子节点之间的水平间距（父节点边缘到子节点边缘的距离）。
     * 配合节点固定宽度，控制导图的横向"松紧度"。
     */
    private static final double H_GAP = 50;

    /**
     * 兄弟节点之间的垂直间距（上一个节点底部到下一个节点顶部的距离）。
     * 配合节点动态高度，控制导图的纵向"松紧度"。
     */
    private static final double V_GAP = 15;

    /**
     * 节点固定宽度（所有节点统一，参照 XMind 的设计）。
     * XMind 中节点宽度不随文字长度变化——文字超出宽度时自动换行增加高度。
     */
    private static final double NODE_WIDTH = 120;

    /**
     * 最小节点高度，确保即使只有一行文字也有足够的视觉高度。
     */
    private static final double MIN_NODE_HEIGHT = 30;

    // ========================================================================
    // 颜色常量
    //   - 使用 Color.web() 从十六进制字符串创建颜色（支持 #RRGGBB 格式）
    //   - 不同状态使用不同配色，提供清晰的视觉反馈
    // ========================================================================

    /** 普通节点填充色（浅灰底） */
    private static final Color NODE_FILL = Color.web("#EAEEF1");

    /** 普通节点边框色（银灰边框） */
    private static final Color NODE_STROKE = Color.web("#C0C0C0");

    /** 选中节点边框色（IDEA 风格蓝色） */
    private static final Color NODE_SELECTED_STROKE = Color.web("#7FA6C5");

    /** 选中节点填充色（浅蓝背景，与蓝色边框配套） */
    private static final Color NODE_SELECTED_FILL = Color.web("#E8F0FE");

    /** 根节点填充色（浅黄背景，区分于普通节点） */
    private static final Color NODE_ROOT_FILL = Color.web("#FFF8E1");

    /** 根节点边框色（金黄色边框） */
    private static final Color NODE_ROOT_STROKE = Color.web("#E6A817");

    /** 连线颜色（中灰，不抢眼但清晰可见） */
    private static final Color LINE_COLOR = Color.web("#999999");

    /** 文字颜色（深灰，保证在浅色背景上的可读性） */
    private static final Color TEXT_COLOR = Color.web("#333333");

    // ========================================================================
    // 字体常量
    // ========================================================================

    /**
     * 节点字体。
     * 使用 "等线Light"（等线体）作为首选字体，确保中英文混排美观。
     * 字号 16px，所有节点统一大小。
     */
    private static final Font NODE_FONT = Font.font("DengXian Light", 16);

    // ========================================================================
    // JavaFX 核心组件
    //   - Canvas：底层画布，用于绘制思维导图的所有图形
    //   - GraphicsContext：Canvas 的"画笔"，所有绘制操作通过它执行
    //   - controller：MVC 中的控制器引用，用户交互通过它转发
    // ========================================================================

    /**
     * 画布组件，用于绘制思维导图的所有图形（节点矩形、连线、文字）。
     * Canvas 是 JavaFX 的位图画布：绘制后图形变成像素，不能单独选中/移动。
     * 适合需要频繁全量重绘的场景（如游戏、图表），性能优于大量 Shape 节点。
     */
    private final Canvas canvas;

    /**
     * 画布的绘图上下文，相当于"画笔"。
     * 通过 Canvas.getGraphicsContext2D() 获取。
     * 所有绘制操作（setFill、fillRoundRect、fillText 等）都通过它执行。
     * 同时负责坐标变换（translate、scale）和状态管理（save/restore）。
     */
    private final GraphicsContext gc;

    /**
     * 控制器引用（MVC 架构中的 Controller）。
     * 本类不直接修改 Model——所有业务操作都通过 Controller 转发，
     * Controller 负责走命令模式（支持撤销/重做）并协调 Model 和 View 的同步。
     */
    private final MindMapController controller;

    // ========================================================================
    // 编辑浮层
    //   - TextArea：多行文本输入控件，覆盖在 Canvas 上方
    //   - 仅在双击节点编辑时可见，编辑完成后隐藏
    //   - setManaged(false) 使其脱离 StackPane 的自动布局，位置由我们手动控制
    // ========================================================================

    /**
     * 文本编辑区域，用于双击编辑节点文本。
     *
     * <p>这是一个叠加在 Canvas 上方的标准 JavaFX TextArea 控件。
     * 为什么不在 Canvas 上直接画"正在编辑的文字"？</p>
     * <ul>
     *   <li>Canvas 不提供光标、选区、复制粘贴等编辑功能</li>
     *   <li>TextArea 自带所有文本编辑基础设施（光标闪烁、拖拽选区、快捷键）</li>
     *   <li>利用 JavaFX 的标准控件比在 Canvas 上自建编辑系统简单得多</li>
     * </ul>
     *
     * <p>编辑完成后内容写回 Model，重新在 Canvas 上绘制（用 Canvas 的文字渲染），
     * TextArea 隐藏。这样即利用了标准控件的编辑便利性，又不影响 Canvas 的渲染效率。</p>
     */
    private final TextArea editTextArea;

    /**
     * 当前正在编辑的节点引用。
     * 非 null 时表示处于编辑状态，TextArea 可见并定位在该节点上方。
     * null 表示不在编辑状态。
     */
    private MindMapNode editingNode;

    /**
     * 编辑开始时的节点原始文本。
     * 用于创建 TextEditCommand（撤销时需要知道旧文本）。
     * 在 startEditing 时记录，在 commitEdit 时使用。
     */
    private String editingOldText;

    // ========================================================================
    // 视图变换参数
    //   - 控制思维导图在屏幕上的显示位置和大小
    //   - translateX/Y 是逻辑坐标下的平移量
    //   - scale 是统一缩放比例（X 和 Y 方向等比例，保持图形不变形）
    //   - 这些参数由用户交互修改（平移拖拽、Ctrl+滚轮缩放）
    // ========================================================================

    /**
     * 水平平移量（逻辑坐标）。
     * 正值 = 思维导图整体向右移动，负值 = 向左移动。
     * 初始值为 0（根节点在画布中心）。
     * 用户按住空白区域拖拽时修改此值。
     */
    private double translateX = 0;

    /**
     * 垂直平移量（逻辑坐标）。
     * 正值 = 思维导图整体向下移动，负值 = 向上移动。
     */
    private double translateY = 0;

    /**
     * 缩放比例。
     * 1.0 = 原始大小（100%），大于 1 = 放大，小于 1 = 缩小。
     * 通过 Ctrl+滚轮修改，每次缩放 1.12 倍。
     * 范围限制在 [0.15（15%）, 5.0（500%）]，防止过小看不清或过大超出计算范围。
     */
    private double scale = 1.0;

    // ========================================================================
    // 画布尺寸防抖
    //   - 问题：JavaFX 在初始布局阶段会多次微调组件尺寸
    //   - 解决：redrawPending 标记 + Platform.runLater
    //   - 效果：同一帧内的多次 resize 只触发一次真正的重绘
    // ========================================================================

    /**
     * 防抖标记。
     *
     * <p>当为 {@code true} 时表示已经安排了一次延迟重绘（通过 Platform.runLater），
     * 后续的 resize 事件不再重复安排。等延迟重绘实际执行后（在 runLater 回调中）
     * 才重置为 {@code false}。</p>
     *
     * <p>用途：消除 JavaFX 初始布局阶段的多次 resize "风暴"。
     * 不用此机制的话，每次微调都触发一次完整的布局计算 + Canvas 重绘，
     * 造成可见的闪烁和性能浪费。</p>
     */
    private boolean redrawPending = false;

    // ========================================================================
    // 拖拽画布状态（平移）
    //   - 用户按住空白区域拖拽时平移思维导图
    //   - 分为两个阶段：按下时记录起始位置，拖拽超过阈值后启动平移
    //   - 6px 阈值防止纯点击被误判为拖拽
    // ========================================================================

    /** 是否正在拖拽平移画布（已超过阈值并进入平移模式） */
    private boolean panning = false;

    /**
     * 鼠标按下时是否落在某个节点上。
     * 如果按下在节点上则不会启动拖拽平移（节点上的拖拽用于交换等其他操作）。
     */
    private boolean pressOnNode = false;

    /** 鼠标按下时的屏幕 X 坐标（用于计算移动距离） */
    private double pressX;

    /** 鼠标按下时的屏幕 Y 坐标 */
    private double pressY;

    /** 鼠标按下时的 translateX 备份（未真正拖拽释放时恢复此值） */
    private double savedTX;

    /** 鼠标按下时的 translateY 备份（未真正拖拽释放时恢复此值） */
    private double savedTY;

    /** 进入平移模式时的屏幕 X 坐标 */
    private double panStartX;

    /** 进入平移模式时的屏幕 Y 坐标 */
    private double panStartY;

    /** 进入平移模式时的 translateX（作为平移基准） */
    private double panStartTX;

    /** 进入平移模式时的 translateY（作为平移基准） */
    private double panStartTY;

    // ========================================================================
    // 节点宽度调整状态
    //   - 鼠标悬停在选中节点的左/右边框时，光标变为水平调整箭头
    //   - 拖拽边框可调整节点宽度，视觉上用虚线框预览
    //   - 释放时通过 Controller 走命令模式（支持撤销）
    // ========================================================================

    /** 是否正在拖拽调整节点宽度 */
    private boolean resizing = false;

    /** 正在被调整宽度的目标节点 */
    private MindMapNode resizeTarget;

    /**
     * 调整的是左边缘还是右边缘。
     * true = 左边缘（拖拽左边缘，右侧固定不动），
     * false = 右边缘（拖拽右边缘，左侧固定不动）。
     */
    private boolean resizeLeft;

    /** 拖拽起始时的鼠标 X 坐标（屏幕坐标，用于计算拖拽距离） */
    private double resizeStartScreenX;

    /** 拖拽起始时的节点宽度（逻辑坐标，currentWidth 或 userWidth） */
    private double resizeOriginalW;

    /**
     * 拖拽起始时的 userWidth（用于创建 ResizeNodeCommand）。
     * userWidth 存储在节点对象中，0 表示使用默认 NODE_WIDTH。
     * 命令模式需要旧值来支持撤销。
     */
    private double resizeOldUserWidth;

    /** 拖拽过程中实时更新的预览宽度（逻辑坐标） */
    private double resizePreviewW;

    // ========================================================================
    // 节点交换状态
    //   - 按住一个节点拖拽到另一个节点上 → 交换两个节点在树中的位置
    //   - swapSource：被拖拽的节点（交换源）
    //   - swapHoverTarget：鼠标当前悬停的节点（交换目标），视觉上用绿色虚线高亮
    // ========================================================================

    /** 是否正在拖拽交换节点（已超过移动阈值） */
    private boolean swapping = false;

    /** 交换源节点，即被用户按住拖拽的那个节点 */
    private MindMapNode swapSource;

    /** 交换目标节点，即鼠标当前悬停的节点（绿色高亮显示） */
    private MindMapNode swapHoverTarget;

    // ========================================================================
    // 命中测试缓存
    //   - 因为 Canvas 是无状态的像素，无法直接判断"点击了哪个节点"
    //   - 解决：每次绘制时记录每个节点的屏幕坐标，点击时遍历做碰撞检测
    //   - 选择面积最小的命中节点（当节点重叠时选最上层/最小的）
    // ========================================================================

    /**
     * 节点 ID → 屏幕坐标的映射表。
     *
     * <p>这是实现"Canvas 上的命中测试"的关键数据结构。
     * 每次调用 drawAll() 绘制时，drawNode() 会把每个节点的屏幕坐标存入此 Map。
     * 当用户点击时，hitTest() 遍历此 Map 找到被点击的节点。</p>
     *
     * <p><b>键（Key）：</b>节点的 UUID 字符串（MindMapNode.getId()）</p>
     * <p><b>值（Value）：</b>{@code double[4] {screenX, screenY, screenWidth, screenHeight}}</p>
     * <ul>
     *   <li>screenX：节点矩形的<b>左上角</b> X 屏幕坐标</li>
     *   <li>screenY：节点矩形的左上角 Y 屏幕坐标</li>
     *   <li>screenWidth：节点在屏幕上的宽度（逻辑宽度 × 缩放比例）</li>
     *   <li>screenHeight：节点在屏幕上的高度（逻辑高度 × 缩放比例）</li>
     * </ul>
     *
     * <p><b>坐标转换公式：</b></p>
     * <pre>
     * screenX = canvasCenterX + (nodeLogicalX + translateX) * scale
     * screenY = canvasCenterY + (nodeLogicalY + translateY) * scale
     * </pre>
     * <p>这个 Map 在每次 redraw() → layoutAllNodes() 开始时清空，绘制时重新填充。</p>
     */
    private final Map<String, double[]> nodeScreenBounds = new HashMap<>();

    // ========================================================================
    // 构造方法
    // ========================================================================

    /**
     * 构造绘图区组件。
     *
     * <p>初始化步骤：</p>
     * <ol>
     *   <li>创建 Canvas 并绑定尺寸到 DrawingPane</li>
     *   <li>监听 Canvas 和 Scene 尺寸变化（触发防抖重绘）</li>
     *   <li>创建编辑浮层 TextArea（设为 unmanaged，手动控制位置）</li>
     *   <li>注册鼠标事件处理器（单击/双击/拖拽/滚轮）</li>
     *   <li>注册编辑监听器（文本变化 → 实时更新、失焦 → 提交）</li>
     *   <li>触发初次重绘</li>
     * </ol>
     *
     * @param controller 控制器引用，所有用户操作通过它转发
     */
    public DrawingPane(MindMapController controller) {
        this.controller = controller;

        // ================================================================
        // 创建 Canvas（画布）
        // ================================================================
        // new Canvas() 创建一个初始尺寸为 0x0 的画布。
        // 真正的尺寸由下方的 bind() 动态决定。
        this.canvas = new Canvas();

        // GraphicsContext 是操作 Canvas 的唯一途径，相当于"画笔"。
        // 在 Canvas 的整个生命周期中只获取一次，重复使用。
        this.gc = canvas.getGraphicsContext2D();

        // ================================================================
        // Canvas 尺寸绑定
        // ================================================================
        // 将 Canvas 的宽高绑定到 DrawingPane（this）的宽高。
        // 这是 JavaFX 的属性绑定机制：当 DrawingPane 尺寸改变时，
        // Canvas 尺寸自动同步，无需手动监听。
        // 注意：bind() 是单向绑定，Canvas 跟随 this 变化。
        canvas.widthProperty().bind(this.widthProperty());
        canvas.heightProperty().bind(this.heightProperty());

        // ---- Canvas 自身尺寸变化监听 ----
        // 监听 Canvas 的宽高属性变化，但只处理变化量 > 2px 的情况。
        // 2px 阈值的作用：过滤掉 CSS 渲染微调引起的 1px 级变化
        // （例如 SplitPane 拖拽时可能产生 1px 的抖动），避免无意义的重绘。
        // 注意：此监听覆盖窗口缩放 + SplitPane 拖拽等场景。
        canvas.widthProperty().addListener((obs, old, w) -> {
            if (Math.abs(w.doubleValue() - old.doubleValue()) > 2) checkResize();
        });
        canvas.heightProperty().addListener((obs, old, h) -> {
            if (Math.abs(h.doubleValue() - old.doubleValue()) > 2) checkResize();
        });

        // ---- Scene 尺寸变化监听（兜底） ----
        // 有些场景下 Canvas 尺寸可能不变但 Scene 变了（如窗口最大化时
        // Canvas 跟随 StackPane 已经调整了），加上这个监听作为兜底。
        // 使用 sceneProperty() 而不是 getScene()，因为在构造时 Scene 可能
        // 还未设置（Node 尚未添加到 Scene Graph 中）。
        sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                newScene.widthProperty().addListener(e -> checkResize());
                newScene.heightProperty().addListener(e -> checkResize());
            }
        });

        // Canvas 必须先添加到 StackPane 中才能显示。
        // 它是第一个子节点，所以在最底层（后续添加的节点会覆盖在它上面）。
        getChildren().add(canvas);

        // ================================================================
        // 创建编辑浮层（TextArea）
        // ================================================================
        // TextArea 是 JavaFX 的标准多行文本输入控件。
        // 它在 Canvas 上方，双击节点时显示，用于原地编辑节点文本。
        editTextArea = new TextArea();

        // setWrapText(true)：启用自动换行。当文字超出 TextArea 宽度时自动折行。
        editTextArea.setWrapText(true);

        // 初始状态隐藏，只在双击编辑时通过 setVisible(true) 显示。
        editTextArea.setVisible(false);

        // CSS 样式类名，对应 CSS 文件中的 .edit-area 规则。
        // 外部 CSS 可定义编辑框的外观（白底蓝边框圆角等）。
        editTextArea.getStyleClass().add("edit-area");

        // 设置 TextArea 的首选行数和列数（但不是硬限制，内容超出会滚动）。
        editTextArea.setPrefRowCount(2);
        editTextArea.setPrefColumnCount(15);

        /*
         * ☆ 关键设计：setManaged(false)
         *
         * StackPane 作为布局容器，默认会"管理"所有子节点（managed = true）：
         *   - 自动计算子节点的位置（默认居中）
         *   - 自动计算子节点的尺寸（根据 prefWidth/prefHeight）
         *   - 子节点的 setLayoutX/setLayoutY 被忽略
         *
         * 将 TextArea 设为 unmanaged (setManaged(false)) 后：
         *   - StackPane 不再干预 TextArea 的位置和尺寸
         *   - 我们可以通过 resizeRelocate(x, y, w, h) 精确控制它的位置
         *   - 这使我们能够把 TextArea 精确定位在编辑节点的正上方
         *
         * 这是实现"Canvas 上方原地编辑"效果的关键技术点。
         */
        editTextArea.setManaged(false);

        // TextArea 后添加，所以在 Canvas 上层（后添加的在上）。
        getChildren().add(editTextArea);

        // ================================================================
        // 初始化事件处理
        // ================================================================
        setupMouseHandlers();

        // 初始化编辑监听器（文本变化实时更新、失焦自动提交）
        setupEditHandler();

        // ================================================================
        // 初次绘制
        // ================================================================
        // 此时 Canvas 尺寸可能还是 0x0（尚未完成初始布局），
        // drawAll() 内部会检查尺寸，小于等于 0 时直接返回不做绘制。
        // 后续当 DrawingPane 获得实际尺寸时，resize 监听器会触发重绘。
        redraw();
    }

    // ========================================================================
    // 鼠标事件注册与分发
    // ========================================================================

    /**
     * 注册鼠标事件处理器到 Canvas。
     *
     * <p>两个注册方式的不同：</p>
     * <ul>
     *   <li>{@code addEventHandler(MouseEvent.ANY, ...)}：
     *       <b>监听所有类型的鼠标事件</b>（按下、拖拽、释放、点击、移动、进入、离开）。
     *       使用 {@code MouseEvent.ANY} 作为事件类型参数，相当于注册了一个"万能"处理器。
     *       在处理器内部通过 {@code event.getEventType()} 分辨具体类型并分派。
     *       这种方式比分别注册 7 个处理器更简洁。</li>
     *   <li>{@code setOnScroll(...)}：
     *       <b>监听滚轮事件（ScrollEvent）</b>。
     *       ScrollEvent 不是 MouseEvent 的子类型，因此不能用 addEventHandler(MouseEvent.ANY)
     *       捕获。必须独立注册。</li>
     * </ul>
     */
    private void setupMouseHandlers() {
        canvas.addEventHandler(MouseEvent.ANY, this::handleMouse);
        canvas.setOnScroll(this::handleScroll);
    }

    /**
     * 鼠标事件分发器。
     *
     * <p>接收所有类型的鼠标事件，根据事件类型路由到对应的处理方法。
     * 这是一个典型的"事件分发"模式——用一个入口接收所有事件，内部做 if-else 路由。</p>
     *
     * <p><b>JavaFX 鼠标事件类型详解：</b></p>
     * <ul>
     *   <li><b>MOUSE_PRESSED</b> —— 鼠标按键按下（但尚未释放）。
     *       我们用它记录按下位置、判断是否按下在节点上。</li>
     *   <li><b>MOUSE_DRAGGED</b> —— 鼠标按键保持按下并移动。
     *       我们用它实现拖拽平移、节点宽度调整、节点交换。</li>
     *   <li><b>MOUSE_RELEASED</b> —— 鼠标按键释放。
     *       我们用它提交各种拖拽操作的结果。</li>
     *   <li><b>MOUSE_CLICKED</b> —— 完整的"点击"（按下+释放，期间移动很小）。
     *       通过 clickCount 区分单击（=1）和双击（=2）。
     *       注意：JavaFX 的 clickCount 是系统自动计数的，我们不需要自己维护。</li>
     *   <li><b>MOUSE_MOVED</b> —— 鼠标移动（没有按键按下）。
     *       我们用它检测鼠标是否悬停在节点边框上，切换光标样式。</li>
     * </ul>
     *
     * <p><b>为什么不用 MouseEvent.MOUSE_PRESSED 等分别注册？</b>
     * 集中分发可以让状态管理更清晰——所有鼠标相关的状态（pressX, pressY 等）
     * 都在同一个类中，不需要跨处理器共享。</p>
     *
     * @param e 鼠标事件对象，包含事件类型、坐标、按键信息等
     */
    private void handleMouse(MouseEvent e) {
        if (e.getEventType() == MouseEvent.MOUSE_PRESSED) {
            handleMousePressed(e);
        } else if (e.getEventType() == MouseEvent.MOUSE_DRAGGED) {
            handleMouseDragged(e);
        } else if (e.getEventType() == MouseEvent.MOUSE_RELEASED) {
            handleMouseReleased(e);
        } else if (e.getEventType() == MouseEvent.MOUSE_CLICKED) {
            handleMouseClicked(e);
        } else if (e.getEventType() == MouseEvent.MOUSE_MOVED) {
            handleMouseMoved(e);
        }
    }

    /**
     * 鼠标按下处理。
     *
     * <p><b>处理逻辑（按优先级）：</b></p>
     * <ol>
     *   <li><b>忽略非左键</b>：只处理 PRIMARY（左键），右键/中键忽略</li>
     *   <li><b>记录按下状态</b>：保存按下的屏幕坐标和当前的平移值，
     *       用于后续判断是"点击"还是"拖拽"</li>
     *   <li><b>检查节点边框</b>：如果按下位置在选中节点的左/右边缘 6px 范围内，
     *       进入"节点宽度调整"模式（这是最高优先级，覆盖其他判断）</li>
     *   <li><b>命中测试</b>：判断按下位置是否在某个节点上</li>
     *   <li><b>提交编辑</b>：如果按下在其他节点或空白区域，且当前有编辑中的节点，
     *       自动提交当前编辑（防止编辑内容丢失）</li>
     * </ol>
     *
     * <p><b>为什么这里不启动平移？</b>
     * 平移在 MOUSE_DRAGGED 中检测到足够移动距离（>6px）后才启动。
     * 这是为了防止纯点击（按下-释放，没有移动）被误判为拖拽。
     * 如果在此处就启动平移，纯点击也会导致微小的画面移动。</p>
     *
     * @param e 鼠标按下事件
     */
    private void handleMousePressed(MouseEvent e) {
        if (e.getButton() != MouseButton.PRIMARY) return;

        // 记录按下时的鼠标位置（屏幕坐标）
        pressX = e.getX();
        pressY = e.getY();

        // 备份当前的平移值（用于释放时恢复）
        savedTX = translateX;
        savedTY = translateY;

        // 初始化状态
        panning = false;
        resizing = false;

        // ---- 优先检测：选中节点边框 → 进入宽度调整模式 ----
        // 这是最高优先级的判断：即使按下在节点上，如果是边框位置，
        // 就进入宽度调整而不是其他模式。
        MindMapNode sel = controller.getSelectedNode();
        int edge = (sel != null) ? detectResizeEdge(sel, pressX, pressY) : 0;
        if (edge != 0) {
            resizing = true;
            resizeTarget = sel;
            resizeLeft = (edge == -1);  // -1 = 左边缘，1 = 右边缘
            resizeStartScreenX = pressX;
            resizeOriginalW = sel.getUserWidth() > 0 ? sel.getUserWidth() : NODE_WIDTH;
            resizePreviewW = resizeOriginalW;
            resizeOldUserWidth = sel.getUserWidth(); // 记录旧值，用于命令模式的撤销
            return;
        }

        // ---- 常规处理：节点或空白区域 ----
        MindMapNode hit = hitTest(pressX, pressY);
        pressOnNode = hit != null;

        // 初始化交换相关状态
        swapping = false;
        swapSource = hit;  // 记录潜在交换源（拖拽超过阈值后启动交换）
        swapHoverTarget = null;

        if (pressOnNode) {
            // 按下在节点上：如果当前正在编辑另一个节点，先提交那个编辑
            if (editingNode != null && editingNode != hit) {
                commitEdit();
            }
        } else {
            // 按下在空白区域：如果有编辑中的节点，提交编辑
            commitEdit();
        }
    }

    /**
     * 鼠标拖拽处理。
     *
     * <p>鼠标拖拽（MOUSE_DRAGGED）是指鼠标按键保持按下并移动。它与 MOUSE_MOVED
     * 的区别是：MOUSE_MOVED 不需要按键按下，而 MOUSE_DRAGGED 需要。</p>
     *
     * <p><b>处理三种拖拽场景（按优先级）：</b></p>
     * <ol>
     *   <li><b>节点宽度调整</b>：如果 resizing 为 true，更新预览宽度</li>
     *   <li><b>节点交换</b>：如果按下在节点上且移动超过 6px 阈值，启动交换模式</li>
     *   <li><b>画布平移</b>：如果按下在空白区域，移动超过 6px 阈值后启动平移</li>
     * </ol>
     *
     * <p><b>平移量计算公式：</b>鼠标在屏幕上移动了 (dx, dy) 像素。
     * 要让逻辑坐标产生等量的位移，需要除以当前缩放比例：</p>
     * <pre>
     * translateX = panStartTX + (当前屏幕X - 起始屏幕X) / scale
     * </pre>
     * <p>这是必要的——缩放 2x 时，逻辑坐标 1 个单位 = 屏幕 2 像素。
     * 所以鼠标移动 10px 对应逻辑坐标移动 5px。</p>
     *
     * @param e 鼠标拖拽事件
     */
    private void handleMouseDragged(MouseEvent e) {
        // ---- 场景 1：节点宽度调整拖拽 ----
        if (resizing && resizeTarget != null) {
            // 鼠标移动量除以 scale，转换为逻辑坐标下的宽度变化
            double delta = (e.getX() - resizeStartScreenX) / scale;
            // 左边缘拖拽则宽度减小（delta 正 = 鼠标右移 = 左边缘右移 = 宽度减小）
            double newW = resizeLeft ? resizeOriginalW - delta : resizeOriginalW + delta;
            // 宽度不能小于默认 NODE_WIDTH
            resizePreviewW = Math.max(NODE_WIDTH, newW);
            redraw();  // 重绘以显示预览虚线框
            return;
        }

        // ---- 场景 2：节点交换 ----
        // 如果按下在节点上且还没启动交换模式，检查是否超过阈值
        if (swapSource != null && !swapping) {
            double dx = e.getX() - pressX;
            double dy = e.getY() - pressY;
            // 欧几里得距离 > 6px 才启动交换（防止单击微动误触）
            if (dx * dx + dy * dy > 36) {  // 6² = 36
                swapping = true;
                pressOnNode = false;  // 阻止后续 click 事件触发选中
            }
        }

        if (swapping) {
            // 持续更新鼠标悬停的目标节点（用于高亮显示）
            swapHoverTarget = hitTest(e.getX(), e.getY());
            redraw();
            return;
        }

        // ---- 场景 3：画布平移 ----
        // 如果按下位置在节点上（且未作为交换启动），不进行画布平移
        if (pressOnNode) return;

        if (!panning) {
            // 欧氏距离 < 6px → 忽略（防止微动误触平移）
            double dx = e.getX() - pressX;
            double dy = e.getY() - pressY;
            if (dx * dx + dy * dy < 36) return;

            // 达到阈值，正式启动拖拽平移
            panning = true;
            panStartX = pressX;          // 平移起始屏幕坐标
            panStartY = pressY;
            panStartTX = translateX;      // 平移起始逻辑平移量
            panStartTY = translateY;
        }

        // 更新平移量：屏幕移动量 / scale = 逻辑坐标下的等效移动
        translateX = panStartTX + (e.getX() - panStartX) / scale;
        translateY = panStartTY + (e.getY() - panStartY) / scale;
        redraw();
    }

    /**
     * 鼠标释放处理。
     *
     * <p>各场景的释放行为：</p>
     * <ul>
     *   <li><b>宽度调整释放</b>：通过 Controller 提交调整（走命令模式），
     *       重置拖拽状态，恢复默认光标</li>
     *   <li><b>节点交换释放</b>：如果目标有效且不同于源，执行交换，
     *       重置交换状态</li>
     *   <li><b>平移释放</b>：无特殊操作（平移量已在拖拽中更新）</li>
     *   <li><b>未发生拖拽</b>：检查 translate 是否发生了意外变化，
     *       如果有，恢复到按下的值。这是防止单击导致画面偏移的最后一道防线</li>
     * </ul>
     *
     * @param e 鼠标释放事件
     */
    private void handleMouseReleased(MouseEvent e) {
        // ---- 完成节点宽度调整 ----
        if (resizing && resizeTarget != null) {
            // 通过 Controller 提交，走命令模式（支持撤销/重做）
            controller.resizeNode(resizeTarget, resizeOldUserWidth, resizePreviewW);
            resizing = false;
            resizeTarget = null;
            setCursor(javafx.scene.Cursor.DEFAULT);
            redraw();
            return;
        }

        // ---- 完成节点交换 ----
        if (swapping) {
            // 需要目标有效、目标不同于源、源存在
            if (swapHoverTarget != null && swapHoverTarget != swapSource && swapSource != null) {
                swapNodes(swapSource, swapHoverTarget);
            }
            swapping = false;
            swapSource = null;
            swapHoverTarget = null;
            redraw();
            return;
        }

        // ---- 无真正拖拽：恢复平移值 ----
        if (!panning) {
            // 没有进入平移模式，但 translate 发生了变化（可能是异常情况）
            // 恢复到鼠标按下时的值
            if (translateX != savedTX || translateY != savedTY) {
                translateX = savedTX;
                translateY = savedTY;
                redraw();
            }
        }
        panning = false;
    }

    /**
     * 鼠标移动处理（无按键按下时的移动）。
     *
     * <p>检测鼠标是否悬停在选中节点的边框上，如果是则切换光标为水平调整样式，
     * 否则恢复为默认光标。这为用户提供"此处可拖拽调整宽度"的视觉提示。</p>
     *
     * <p>光标样式：{@code Cursor.H_RESIZE} 是水平双箭头（↔），
     * 表示可以水平拖拽调整大小。</p>
     *
     * @param e 鼠标移动事件
     */
    private void handleMouseMoved(MouseEvent e) {
        MindMapNode sel = controller.getSelectedNode();
        // 没有选中节点、正在调整、正在平移时都不需要切换光标
        if (sel == null || resizing || panning) {
            setCursor(javafx.scene.Cursor.DEFAULT);
            return;
        }
        int edge = detectResizeEdge(sel, e.getX(), e.getY());
        if (edge != 0) {
            setCursor(javafx.scene.Cursor.H_RESIZE);  // ↔ 水平调整光标
        } else {
            setCursor(javafx.scene.Cursor.DEFAULT);
        }
    }

    /**
     * 检测鼠标是否靠近选中节点的左/右边框。
     *
     * <p>判断条件：</p>
     * <ul>
     *   <li>鼠标 Y 坐标在节点纵向范围内（上下各多 4px 容差）</li>
     *   <li>鼠标 X 坐标在节点左/右边缘 ±6px 范围内</li>
     * </ul>
     *
     * @param node    被检测的节点
     * @param screenX 鼠标屏幕 X 坐标
     * @param screenY 鼠标屏幕 Y 坐标
     * @return -1 = 左边缘，1 = 右边缘，0 = 不在边缘区域
     */
    private int detectResizeEdge(MindMapNode node, double screenX, double screenY) {
        double[] sb = nodeScreenBounds.get(node.getId());
        if (sb == null) return 0;
        double sx = sb[0], sy = sb[1], sw = sb[2], sh = sb[3];
        // 检查是否在节点纵向范围内（含 4px 容差，方便定位）
        if (screenY < sy - 4 || screenY > sy + sh + 4) return 0;
        // 左边缘 6px 范围内
        if (Math.abs(screenX - sx) <= 6) return -1;
        // 右边缘 6px 范围内
        if (Math.abs(screenX - (sx + sw)) <= 6) return 1;
        return 0;
    }

    /**
     * 鼠标点击处理。
     *
     * <p>JavaFX 的 {@code clickCount} 属性自动区分单击和双击：</p>
     * <ul>
     *   <li>快速连续两次"按下-释放" → 第一次 clickCount=1，第二次 clickCount=2</li>
     *   <li>如果两次间隔太长，clickCount 不会累加到 2</li>
     * </ul>
     *
     * <p><b>处理逻辑：</b></p>
     * <ul>
     *   <li>clickCount == 2（双击）：启动节点文本编辑</li>
     *   <li>clickCount == 1（单击）：
     *     <ul>
     *       <li>命中节点 → 通过 Controller 选中该节点</li>
     *       <li>命中空白 → 提交编辑 + 清除选中</li>
     *     </ul>
     *   </li>
     * </ul>
     *
     * @param e 鼠标点击事件
     */
    private void handleMouseClicked(MouseEvent e) {
        if (e.getButton() != MouseButton.PRIMARY) return;
        if (resizing || swapping) return; // 宽度调整/交换中不处理点击

        MindMapNode hit = hitTest(e.getX(), e.getY());

        // 双击 → 启动节点文本编辑
        if (e.getClickCount() == 2 && hit != null) {
            startEditing(hit);
            return;
        }

        // 单击
        if (e.getClickCount() == 1) {
            if (hit != null) {
                // 单击节点 → 通知 Controller 选中（单选模式）
                controller.selectNode(hit);
            } else {
                // 单击空白区域 → 提交编辑 + 清除选中
                commitEdit();
                controller.clearSelection();
            }
        }
    }

    /**
     * 鼠标滚轮处理 —— 缩放入口。
     *
     * <p><b>只有按住 Ctrl 键时才缩放。</b>如果没按 Ctrl，滚轮事件被忽略，
     * 这样不会影响 ScrollPane 等其他组件的滚动行为。</p>
     *
     * <h3>以鼠标位置为中心的缩放算法（核心难点）</h3>
     *
     * <p><b>问题：</b>默认的缩放是以画布中心（或坐标原点）为缩放中心的。
     * 如果直接修改 scale 而不调整 translate，鼠标所指位置的内容会"跑掉"——
     * 因为缩放改变了逻辑坐标和屏幕坐标的对应关系。</p>
     *
     * <p><b>目标：</b>缩放前后，鼠标所指位置的逻辑坐标保持不变。
     * 这样用户看到的效果是：画面以鼠标为中心放大/缩小。</p>
     *
     * <p><b>数学推导：</b></p>
     * <pre>
     * 已知变换公式（见 drawAll）：
     *   屏幕坐标 s = center + (逻辑坐标 m + translate) × scale
     *
     * 反解逻辑坐标：
     *   m = (s - center) / scale - translate
     *
     * 缩放前：m₁ = (s - c) / oldScale - oldTranslate
     * 缩放后：m₂ = (s - c) / newScale - newTranslate
     *
     * 要保持 m₁ == m₂：
     *   newTranslate = (s - c) / newScale - ((s - c) / oldScale - oldTranslate)
     *                = (s - c) / newScale - (s - c) / oldScale + oldTranslate
     *                = oldTranslate + (s - c) × (1/newScale - 1/oldScale)
     * </pre>
     *
     * <p><b>缩放步长：</b>每次滚轮缩放 1.12 倍（向上滚放大，向下滚缩小）。
     * 1.12 是一个经验值——足够快（10 次滚轮约 3 倍变化），又不会太激进。
     * 缩放范围限制在 [0.15, 5.0]，即 15% 到 500%。</p>
     *
     * @param e 滚轮事件，getDeltaY() > 0 表示向上滚（放大），< 0 表示向下滚（缩小）
     */
    private void handleScroll(javafx.scene.input.ScrollEvent e) {
        if (!e.isControlDown()) return;   // 没有 Ctrl → 不缩放，让事件继续传播

        double oldScale = scale;

        // getDeltaY() > 0 表示向上滚（放大），< 0 表示向下滚（缩小）
        double delta = e.getDeltaY() > 0 ? 1.12 : 1.0 / 1.12;
        scale *= delta;

        // 限制缩放范围，防止极端值
        scale = clamp(scale, 0.15, 5.0);

        // ---- 以鼠标位置为中心调整平移 ----
        double cx = getWidth() / 2;     // 画布中心 X（屏幕坐标）
        double cy = getHeight() / 2;    // 画布中心 Y（屏幕坐标）
        double mx = e.getX();           // 鼠标当前 X（屏幕坐标）
        double my = e.getY();           // 鼠标当前 Y（屏幕坐标）

        // 应用推导公式：保持鼠标下的逻辑坐标不变
        translateX = (mx - cx) / scale - ((mx - cx) / oldScale - translateX);
        translateY = (my - cy) / scale - ((my - cy) / oldScale - translateY);

        redraw();
    }

    // ========================================================================
    // 命中测试
    //   - 因为 Canvas 是无状态的像素，无法用 Node.contains() 判断点击位置
    //   - 解决：遍历 nodeScreenBounds Map，做矩形碰撞检测
    //   - 选择面积最小的命中节点（处理节点重叠的情况）
    // ========================================================================

    /**
     * 命中测试：判断屏幕坐标 (screenX, screenY) 落在哪个节点上。
     *
     * <p><b>为什么需要自己实现命中测试？</b>
     * Canvas 上的图形是像素，不是独立的 JavaFX Node 对象。没有 Node.contains()
     * 方法可用。必须手动记录每个节点的屏幕范围（nodeScreenBounds），
     * 然后做矩形碰撞检测。</p>
     *
     * <p><b>算法：矩形碰撞检测</b></p>
     * <ol>
     *   <li>遍历 nodeScreenBounds 中的所有节点</li>
     *   <li>检查点击坐标是否在节点矩形范围内</li>
     *   <li>如果多个节点重叠，选择面积最小的那个（最可能是在上层的）</li>
     * </ol>
     *
     * <p><b>选择面积最小的原因：</b>当父节点和子节点重叠时，
     * 子节点通常在父节点的视觉"内部"，面积也更小。选最小的可以提高命中精度。</p>
     *
     * @param screenX 鼠标屏幕 X 坐标
     * @param screenY 鼠标屏幕 Y 坐标
     * @return 命中的节点引用；如果没有命中任何节点则返回 null
     */
    private MindMapNode hitTest(double screenX, double screenY) {
        MindMapNode best = null;
        double bestArea = Double.MAX_VALUE;

        for (Map.Entry<String, double[]> entry : nodeScreenBounds.entrySet()) {
            double[] b = entry.getValue();
            // b = {screenX, screenY, screenWidth, screenHeight}
            // 检查点击位置是否在矩形范围内
            if (screenX >= b[0] && screenX <= b[0] + b[2] &&
                screenY >= b[1] && screenY <= b[1] + b[3]) {
                double area = b[2] * b[3];
                if (area < bestArea) {
                    bestArea = area;
                    // 通过 ID 从节点树中查找实际的 MindMapNode 引用
                    best = findNodeById(controller.getModel().getRoot(), entry.getKey());
                }
            }
        }
        return best;
    }

    /**
     * 在节点树中根据 ID 递归查找节点。
     *
     * <p>使用 DFS（深度优先搜索）从给定节点开始遍历整棵子树。</p>
     * <p>每个节点有唯一的 UUID，通过 ID 匹配找到目标节点。</p>
     *
     * @param node 搜索起始节点（通常是根节点）
     * @param id   目标节点的 UUID 字符串
     * @return 匹配的节点；如果未找到则返回 null
     */
    private MindMapNode findNodeById(MindMapNode node, String id) {
        if (node.getId().equals(id)) return node;
        for (MindMapNode child : node.getChildren()) {
            MindMapNode found = findNodeById(child, id);
            if (found != null) return found;
        }
        return null;
    }

    // ========================================================================
    // 文本编辑
    //   - 双击节点启动编辑，TextArea 覆盖在节点上方
    //   - 每输入一个字符，实时更新 Model 并重绘 Canvas
    //   - 失去焦点 / 按 Enter / 点其他地方 时提交编辑
    //   - 通过 Controller 走命令模式（支持撤销）
    // ========================================================================

    /**
     * 设置编辑相关的事件监听器。
     *
     * <p>注册三个监听器：</p>
     *
     * <h3>1. textProperty 监听器 —— "每打一个字"的实时更新</h3>
     * <p>JavaFX 中，每个 UI 控件的文本内容通过 {@code textProperty()} 暴露。
     * 这是一个 {@code StringProperty}（可观察的属性），当文本变化时会通知所有监听器。
     * 我们在监听器中：</p>
     * <ol>
     *   <li>清理混入的换行符（Enter 键被 eventFilter 拦截了，但粘贴可能带入）</li>
     *   <li>更新 Model 中的节点文本</li>
     *   <li>触发 redraw（重绘 Canvas + 重新定位编辑器）</li>
     * </ol>
     *
     * <h3>2. focusedProperty 监听器 —— 失焦自动提交</h3>
     * <p>{@code focusedProperty()} 表示控件是否拥有键盘焦点。
     * 当 TextArea 失去焦点（focused 变为 false）时自动提交编辑。</p>
     *
     * <h3>3. KeyEvent.KEY_PRESSED eventFilter —— 拦截 Enter 键</h3>
     * <p>Enter 键在 TextArea 中默认是换行，但在思维导图中 Enter 意味着"完成编辑"。
     * 通过 eventFilter（在事件到达 TextArea 之前拦截），调用
     * {@code e.consume()} 阻止事件继续传播，从而防止换行。</p>
     */
    private void setupEditHandler() {
        // ---- 1. 文本变化监听 ----
        // textProperty() 返回 StringProperty，调用 addListener 注册监听器
        editTextArea.textProperty().addListener((obs, old, newText) -> {
            if (editingNode != null) {
                // 移除可能混入的换行符
                // Enter 键虽然在 eventFilter 中被拦截，但粘贴等操作可能带入 \n
                String cleanText = newText.replace("\n", "");
                if (!cleanText.equals(newText)) {
                    // 有换行符被清理 → 回写清理后的文本，这将再次触发此监听器
                    editTextArea.setText(cleanText);
                    return;
                }
                // 更新 Model（注意：这里直接修改 Model，但最终提交走命令模式）
                editingNode.setText(cleanText);
                // 重绘 Canvas（内部会把 Model 中的文本画到 Canvas 上，并重新定位编辑器）
                redraw();
            }
        });

        // ---- 2. 焦点丢失监听 ----
        // 当用户点击 Canvas 上的其他地方、按 Tab、或切换到其他窗口时，
        // focusedProperty 会变为 false，此时自动提交编辑
        editTextArea.focusedProperty().addListener((obs, old, focused) -> {
            if (!focused && editingNode != null) {
                commitEdit();
            }
        });

        // ---- 3. Enter 键拦截 ----
        // 使用 addEventFilter（拦截阶段）而非 addEventHandler（冒泡阶段），
        // 这样可以在事件被 TextArea 处理之前就拦截它
        editTextArea.addEventFilter(javafx.scene.input.KeyEvent.KEY_PRESSED, e -> {
            if (e.getCode() == javafx.scene.input.KeyCode.ENTER && editingNode != null) {
                e.consume();    // 阻止 TextArea 默认的换行行为
                commitEdit();   // 提交编辑
            }
        });
    }

    /**
     * 公开的编辑入口（供 Controller 通过快捷键 F2 等启动编辑）。
     * Controller 层通过此方法触发编辑，不直接调用私有的 startEditing。
     *
     * @param node 要编辑的节点
     */
    public void startEdit(MindMapNode node) {
        startEditing(node);
    }

    /**
     * 开始编辑节点（内部实现）。
     *
     * <p><b>编辑启动流程：</b></p>
     * <ol>
     *   <li><b>提交之前的编辑</b>（如果有）：确保不会丢失之前的数据</li>
     *   <li><b>记录编辑节点</b>：设置 editingNode 和 editingOldText</li>
     *   <li><b>将节点文本填入 TextArea</b>：仅当文本不同时更新，避免无意义 redraw</li>
     *   <li><b>定位编辑器</b>：将 TextArea 定位到节点位置</li>
     *   <li><b>显示编辑器</b>：setVisible(true)</li>
     *   <li><b>延迟执行（Platform.runLater）</b>：
     *       重绘 Canvas → 校准编辑器位置 → 获取焦点 → 全选文本</li>
     * </ol>
     *
     * <p><b>为什么需要 Platform.runLater？</b>
     * 双击事件处理器（handleMouseClicked）还在执行中。如果在事件处理器中直接
     * 操作 UI（如 requestFocus），可能导致嵌套事件的产生。用 Platform.runLater
     * 将这些操作延迟到当前事件处理完成后的下一帧执行。</p>
     *
     * @param node 要编辑的节点
     */
    private void startEditing(MindMapNode node) {
        // 1. 先提交之前的编辑（如果有）
        commitEdit();

        // 2. 设置当前编辑状态
        editingNode = node;
        editingOldText = node.getText();  // 记录原始文本，用于创建编辑命令（撤销用）

        // 3. 填入文本（仅当不同时更新，避免触发无意义的文本监听）
        String nodeText = node.getText();
        if (!nodeText.equals(editTextArea.getText())) {
            editTextArea.setText(nodeText);    // 触发监听器 → redraw + repositionEditor
        }

        // 4. 定位编辑器到节点位置
        repositionEditor();

        // 5. 显示编辑器
        editTextArea.setVisible(true);

        // 6. 延迟到下一帧：等 TextArea 显示触发的布局变化稳定后再做最终校准
        javafx.application.Platform.runLater(() -> {
            // 以最终稳定的 Canvas 尺寸重绘
            redraw();
            // 重新校准编辑器位置（因为重绘可能改变了 nodeScreenBounds）
            repositionEditor();
            // TextArea 获取键盘焦点（光标闪烁，准备输入）
            editTextArea.requestFocus();
            // 全选已有文本，方便用户直接输入替换
            editTextArea.selectAll();
        });
    }

    /**
     * 提交编辑：将 TextArea 中的文本正式写入节点数据。
     *
     * <p>提交流程：</p>
     * <ol>
     *   <li>获取 TextArea 中的当前文本</li>
     *   <li>记录当前编辑节点和原始文本，然后清空编辑状态</li>
     *   <li>隐藏 TextArea</li>
     *   <li>通过 Controller 走命令模式提交（内部会判断文本是否真正改变，
     *       如无变化则不创建命令）</li>
     * </ol>
     */
    private void commitEdit() {
        if (editingNode != null) {
            String newText = editTextArea.getText();
            MindMapNode node = editingNode;
            String oldText = editingOldText;

            // 清空编辑状态（在调用 Controller 之前，防止递归）
            editingNode = null;
            editingOldText = null;

            // 隐藏编辑器
            editTextArea.setVisible(false);

            // 通过 Controller 提交，走命令模式
            // Controller 内部会判断 old/new 是否相同，相同则不创建命令
            controller.commitEditText(node, oldText, newText);
        }
    }

    /**
     * 重新定位编辑浮层（TextArea）到编辑节点的位置。
     *
     * <p>从 nodeScreenBounds 中读取节点的屏幕坐标，将 TextArea 定位在
     * 节点上方并稍大于节点（提供更好的编辑体验）。</p>
     *
     * <p><b>为什么用 resizeRelocate 而不是 setLayoutX/setPrefWidth？</b>
     * TextArea 是 unmanaged 的（setManaged(false)），不受 StackPane 的
     * 布局管理。unmanaged 节点的位置和尺寸必须通过 {@code resizeRelocate(x, y, w, h)}
     * 来设置。setLayoutX/setPrefWidth 对 unmanaged 节点无效，因为布局系统
     * 跳过了它们。</p>
     *
     * <p>resizeRelocate 一次性设置节点的 bounds：
     * 左上角 (x, y) + 宽度 w + 高度 h。</p>
     */
    private void repositionEditor() {
        if (editingNode == null) return;
        double[] sb = nodeScreenBounds.get(editingNode.getId());
        if (sb == null) return;

        // 编辑器比节点稍大：水平多 20px，垂直多 10px
        // 最小值保证即使节点很小也有足够的编辑空间
        double editorW = Math.max(sb[2] + 20, 150);
        double editorH = Math.max(sb[3] + 10, 40);

        // 居中于节点位置
        double editorX = sb[0] + sb[2] / 2 - editorW / 2;
        double editorY = sb[1] + sb[3] / 2 - editorH / 2;

        // resizeRelocate：同时设置位置和尺寸（对 unmanaged 节点的唯一有效方式）
        editTextArea.resizeRelocate(editorX, editorY, editorW, editorH);
    }

    // ========================================================================
    // 布局计算
    //   - 自底向上计算节点尺寸（calcNodeSize）
    //   - 自顶向下计算节点位置（layoutChildren / layoutAuto / layoutSubtree）
    //   - 三种布局模式：LEFT（全左）、RIGHT（全右）、AUTO（平衡分侧）
    // ========================================================================

    /**
     * 画布尺寸变化防抖处理。
     *
     * <p><b>问题背景：</b>JavaFX 在初始布局阶段会多次微调组件尺寸——
     * 场景初始化、CSS 计算完成、SplitPane 拖拽后等都可能触发 resize。
     * 如果不做防抖，每次微调都触发一次完整的布局重算+Canvas 重绘，
     * 造成明显的闪烁和性能浪费。</p>
     *
     * <p><b>解决方案：Platform.runLater 防抖</b></p>
     * <ol>
     *   <li>第一次 resize 时：设置 redrawPending = true，安排 runLater 重绘</li>
     *   <li>同一帧内后续 resize：redrawPending 为 true，跳过</li>
     *   <li>下一帧：runLater 执行 → 重置 redrawPending → 执行 redraw</li>
     * </ol>
     *
     * <p>{@link javafx.application.Platform#runLater(Runnable)} 将任务放入
     * JavaFX 主线程的事件队列末尾，保证在当前所有 pending 的 UI 事件处理完毕后
     * 再执行。因此同一帧内的多次 resize 只会触发一次重绘。</p>
     */
    private void checkResize() {
        if (!redrawPending) {
            redrawPending = true;
            javafx.application.Platform.runLater(() -> {
                redrawPending = false;
                redraw();
            });
        }
    }

    /**
     * 重绘入口。
     *
     * <p>这是外部调用的标准入口。执行顺序：</p>
     * <ol>
     *   <li>layoutAllNodes() —— 重新计算所有节点的逻辑坐标</li>
     *   <li>drawAll() —— 清空 Canvas 并重新绘制所有内容</li>
     *   <li>repositionEditor() —— 如果正在编辑，重新定位编辑器</li>
     * </ol>
     *
     * <p>外部不应直接调用 drawAll()，因为 drawAll 依赖 layoutAllNodes
     * 先计算出正确的节点位置。如果 Model 状态已变化但布局未更新，
     * 直接 drawAll 会画出错误的图形。</p>
     */
    public void redraw() {
        layoutAllNodes();       // 第 1 步：计算布局（逻辑坐标）
        drawAll();              // 第 2 步：绘制（逻辑坐标 → 屏幕坐标）
        if (editingNode != null) {
            repositionEditor(); // 第 3 步：如果正在编辑，重新定位编辑器
        }
    }

    /**
     * 计算整棵节点树的布局。
     *
     * <p><b>布局分两步走：</b></p>
     * <ol>
     *   <li><b>calcNodeSize(root)</b> —— 自底向上（后序遍历）：
     *       先递归计算每个子树的节点尺寸（width, height），
     *       因为父节点的位置取决于子节点的总高度</li>
     *   <li><b>layoutChildren / layoutAuto / layoutSubtree</b> —— 自顶向下（前序遍历）：
     *       从根节点开始，根据布局模式递归分配每个节点的 (x, y) 坐标</li>
     * </ol>
     *
     * <p><b>为什么必须"先尺寸后位置"？</b>
     * 考虑：一个父节点有 3 个子节点，每个子节点又有各自的子树。
     * 父节点的 Y 坐标需要让所有子节点围绕它垂直居中。
     * 要知道"居中"是什么，必须先知道所有子节点的总高度。
     * 所以必须先（自底向上）算出所有子树的尺寸，才能（自顶向下）确定父节点的位置。</p>
     */
    private void layoutAllNodes() {
        // 清空命中测试缓存（每次布局都会重新填充）
        nodeScreenBounds.clear();
        MindMapNode root = controller.getModel().getRoot();
        MindMapModel.LayoutMode mode = controller.getModel().getLayoutMode();

        // 第 1 步：自底向上计算每个节点的尺寸
        calcNodeSize(root);

        // 第 2 步：自顶向下计算每个节点的位置
        // LEFT  布局 → 所有子节点在根节点的左侧
        // RIGHT 布局 → 所有子节点在根节点的右侧
        // AUTO  布局 → 按"平衡左右高度"原则自动分侧
        switch (mode) {
            case LEFT -> layoutChildren(root, true);
            case RIGHT -> layoutChildren(root, false);
            case AUTO -> layoutAuto(root);
        }
    }

    /**
     * 测量指定字体下单行文字的高度（含 ascent + descent）。
     *
     * <p>JavaFX 的 Text 对象不是用来显示的，而是用作"测量工具"。
     * 创建一个 Text 对象，设置字体，读取它的 layoutBounds 来获取渲染尺寸。
     * </p>
     *
     * <p>"Ag" 是常用测量字符串：包含上伸字符（A）和下伸字符（g），
     * 能反映字体的完整高度范围。也可以用 "Xg" 等。</p>
     *
     * @param font 要测量的字体
     * @return 单行文字的高度（像素）
     */
    private double measureTextHeight(Font font) {
        Text m = new Text("Ag");
        m.setFont(font);
        return m.getLayoutBounds().getHeight();
    }

    /**
     * 计算节点尺寸（递归，自底向上）。
     *
     * <h3>尺寸计算规则（模仿 XMind 风格）</h3>
     * <ol>
     *   <li><b>宽度固定</b>：所有节点统一使用 NODE_WIDTH（或用户拖拽设定的 userWidth），
     *       不随文本长度变化</li>
     *   <li><b>高度自适应</b>：在固定宽度下，文本超出宽度时自动换行；
     *       测量换行后的文本总高度，加上内边距 NODE_PADDING_Y × 2</li>
     *   <li><b>最小高度</b>：不低于 MIN_NODE_HEIGHT（30px），确保至少能容纳一行文字</li>
     * </ol>
     *
     * <p>这个行为模拟了 XMind：输入文字时节点宽度不变，超出宽度自动换行增加高度。</p>
     *
     * <p><b>递归顺序：后序遍历（先子后父）</b>。虽然节点自身的尺寸不依赖子节点，
     * 但这样写保持了一致性。</p>
     *
     * @param node 要计算尺寸的节点（会递归处理其所有子节点）
     */
    private void calcNodeSize(MindMapNode node) {
        Font font = NODE_FONT;

        // 空文本用一个空格代替，确保至少有 1 行
        String text = node.getText().isEmpty() ? " " : node.getText();

        // 使用用户拖拽设定的宽度，0 表示使用默认 NODE_WIDTH
        double nodeW = node.getUserWidth() > 0 ? node.getUserWidth() : NODE_WIDTH;

        // 文本可用宽度 = 节点宽度 - 左右内边距
        double textAreaW = nodeW - NODE_PADDING_X * 2;

        // 用与绘制相同的 wrapLine 方法计算行数，确保高度一致
        List<String> lines = wrapLine(text, font, textAreaW);
        double textH = measureTextHeight(font);    // 单行文字高度
        double lineH = textH + 2;                   // 行高（含行间距）
        int nLines = Math.max(1, lines.size());     // 至少 1 行
        // 文本块总高度：nLines 行，但最后一行不需要行间距
        double textBlockH = nLines * lineH - (lineH - textH);
        // 节点总高度 = 文本块高度 + 上下内边距，但不低于最小高度
        double h = Math.max(textBlockH + NODE_PADDING_Y * 2, MIN_NODE_HEIGHT);

        node.setWidth(nodeW);
        node.setHeight(h);

        // 递归计算子节点尺寸
        for (MindMapNode child : node.getChildren()) {
            calcNodeSize(child);
        }
    }

    /**
     * 单侧布局（LEFT 或 RIGHT）：将所有子节点统一放在父节点的一侧。
     *
     * <p><b>算法：</b></p>
     * <ol>
     *   <li>父节点定位在逻辑坐标的 (0, 0)（根节点的情况）</li>
     *   <li>计算所有子树的垂直总高度（含兄弟间距 V_GAP）</li>
     *   <li>从父节点垂直中心线开始，向上/下排列子节点</li>
     *   <li>每个子节点递归调用 layoutSubtree 继续排版</li>
     * </ol>
     *
     * <p><b>子节点排列方向：</b>从 startY（总高度一半的负值）开始，
     * 依次向下排列。这使子节点组垂直居中于父节点。</p>
     *
     * <p><b>X 坐标计算：</b></p>
     * <ul>
     *   <li>左侧布局：子节点 X = 父节点左边缘 - 间距 - 子节点半宽</li>
     *   <li>右侧布局：子节点 X = 父节点右边缘 + 间距 + 子节点半宽</li>
     * </ul>
     *
     * @param parent 父节点（根节点）
     * @param toLeft true = 左侧布局，false = 右侧布局
     */
    private void layoutChildren(MindMapNode parent, boolean toLeft) {
        // 根节点定位在 (0, 0)
        parent.setX(0);
        parent.setY(0);
        parent.setLeftSide(false);

        List<MindMapNode> children = parent.getChildren();
        if (children.isEmpty()) return;

        // ---- 计算每个子树的垂直高度 ----
        List<Double> subtreeHeights = new ArrayList<>();
        double totalH = 0;
        for (MindMapNode child : children) {
            double sh = calcSubtreeHeight(child);
            subtreeHeights.add(sh);
            totalH += sh;
        }
        // 加上兄弟节点之间的间距
        totalH += (children.size() - 1) * V_GAP;

        // ---- 垂直排列子节点 ----
        // startY 是第一个子节点中心相对于父节点中心的 Y 偏移
        // -totalH/2 使子节点组垂直居中于父节点
        double startY = -totalH / 2;

        for (int i = 0; i < children.size(); i++) {
            MindMapNode child = children.get(i);
            double sh = subtreeHeights.get(i);
            // 子节点中心 Y = 当前偏移 + 子树高度的一半
            double childY = startY + sh / 2;

            // 子节点 X 坐标：父节点边缘 + 间距 + 子节点半宽
            double childX;
            if (toLeft) {
                // 左侧：子节点在父节点左边
                childX = parent.getX() - parent.getWidth() / 2 - H_GAP - child.getWidth() / 2;
            } else {
                // 右侧：子节点在父节点右边
                childX = parent.getX() + parent.getWidth() / 2 + H_GAP + child.getWidth() / 2;
            }

            // 递归布局该子节点的子树
            layoutSubtree(child, childX, childY, toLeft);

            // 移动到下一个子节点的起始 Y 位置
            startY += sh + V_GAP;
        }
    }

    /**
     * 自动布局（AUTO）：将子节点分配到左右两侧，使两侧总高度尽量接近。
     *
     * <h3>核心问题</h3>
     * <p>给定 n 个有顺序的子节点，每个子节点有一个"子树高度"（权重）。
     * 在保持原有顺序的前提下，把它们分成"左侧组"和"右侧组"，
     * 使两组各自的垂直总高度尽可能接近。</p>
     *
     * <h3>算法：枚举分割点</h3>
     * <ol>
     *   <li>对 children[0..n-1]，枚举所有分割点 k（k 表示前 k 个放左侧，
     *       剩余放右侧）。k 的取值范围是 [0, n]。</li>
     *   <li>对每个 k，计算左侧总高度和右侧总高度（含兄弟间距 V_GAP）</li>
     *   <li>选择使高度差最小的 k</li>
     * </ol>
     *
     * <p><b>时间复杂度：O(n)</b>，使用前缀和（prefix sum）避免重复求和。</p>
     *
     * <p><b>前缀和：</b>prefixSum[i] = weights[0] + ... + weights[i-1]，
     * 那么 leftWeight = prefixSum[k], rightWeight = totalWeight - prefixSum[k]。</p>
     *
     * <p><b>关键约束：保持原有顺序。</b>左侧子节点按原顺序从上到下，
     * 右侧也按原顺序从上到下。视觉阅读顺序为"先左侧组（上→下），
     * 再右侧组（上→下）"。</p>
     *
     * @param root 根节点
     */
    private void layoutAuto(MindMapNode root) {
        root.setX(0);
        root.setY(0);
        root.setLeftSide(false);

        List<MindMapNode> children = root.getChildren();
        if (children.isEmpty()) return;

        int n = children.size();

        // ---- 第 1 步：计算每个子树的"权重"（垂直总高度） ----
        double[] weights = new double[n];
        for (int i = 0; i < n; i++) {
            weights[i] = calcSubtreeHeight(children.get(i));
        }

        // ---- 第 2 步：计算前缀和（prefix sum） ----
        // prefixSum[i] = 前 i 个子节点的权重之和
        double[] prefixSum = new double[n + 1];
        for (int i = 0; i < n; i++) {
            prefixSum[i + 1] = prefixSum[i] + weights[i];
        }
        double totalWeight = prefixSum[n];

        // ---- 第 3 步：枚举所有分割点，找最佳 k ----
        int bestK = 1;                          // 默认至少 1 个在左侧
        double bestDiff = Double.MAX_VALUE;

        for (int k = 0; k <= n; k++) {
            // 左侧权重（前 k 个）
            double leftWeight = prefixSum[k];
            // 右侧权重（后 n-k 个）
            double rightWeight = totalWeight - prefixSum[k];
            // 总高度 = 节点高度之和 + 兄弟间的间距
            double leftTotal = leftWeight + Math.max(0, k - 1) * V_GAP;
            double rightTotal = rightWeight + Math.max(0, n - k - 1) * V_GAP;
            double diff = Math.abs(leftTotal - rightTotal);
            if (diff < bestDiff) {
                bestDiff = diff;
                bestK = k;
            }
        }

        // ---- 第 4 步：按最佳分割点排列左右两侧 ----

        // 左侧组：children[0..bestK-1]，从上到下排列
        if (bestK > 0) {
            double leftTotalH = prefixSum[bestK] + (bestK - 1) * V_GAP;
            double startY = -leftTotalH / 2;
            for (int i = 0; i < bestK; i++) {
                MindMapNode child = children.get(i);
                double sh = weights[i];
                double childY = startY + sh / 2;
                // 子节点在根节点左侧
                double childX = root.getX() - root.getWidth() / 2 - H_GAP - child.getWidth() / 2;
                layoutSubtree(child, childX, childY, true);
                startY += sh + V_GAP;
            }
        }

        // 右侧组：children[bestK..n-1]，从上到下排列
        if (bestK < n) {
            int rightCount = n - bestK;
            double rightWeight = totalWeight - prefixSum[bestK];
            double rightTotalH = rightWeight + (rightCount - 1) * V_GAP;
            double startY = -rightTotalH / 2;
            for (int i = bestK; i < n; i++) {
                MindMapNode child = children.get(i);
                double sh = weights[i];
                double childY = startY + sh / 2;
                // 子节点在根节点右侧
                double childX = root.getX() + root.getWidth() / 2 + H_GAP + child.getWidth() / 2;
                layoutSubtree(child, childX, childY, false);
                startY += sh + V_GAP;
            }
        }
    }

    /**
     * 递归布局子树。
     *
     * <p>从给定的 (x, y) 位置（节点中心）开始，将当前节点放在此位置，
     * 然后对其所有子节点重复此过程——垂直排列、居中对齐。</p>
     *
     * <p>子节点的排列逻辑与 layoutChildren 相同：</p>
     * <ol>
     *   <li>计算子节点的总高度</li>
     *   <li>从中心线向上/下排列</li>
     *   <li>每个子节点再次递归调用 layoutSubtree</li>
     * </ol>
     *
     * <p><b>X 坐标计算：</b>子节点始终放在当前节点的左侧（如果 leftSide=true）
     * 或右侧（如果 leftSide=false）。这保证了同一子树中的所有节点在同一侧。</p>
     *
     * @param node     当前要布局的节点
     * @param x        节点中心 X 坐标（逻辑坐标）
     * @param y        节点中心 Y 坐标（逻辑坐标）
     * @param leftSide 节点在父节点的左侧还是右侧
     */
    private void layoutSubtree(MindMapNode node, double x, double y, boolean leftSide) {
        // 将当前节点放置在指定位置
        node.setX(x);
        node.setY(y);
        node.setLeftSide(leftSide);

        List<MindMapNode> children = node.getChildren();
        if (children.isEmpty()) return;

        // ---- 计算子节点总高度 ----
        List<Double> subtreeHeights = new ArrayList<>();
        double totalH = 0;
        for (MindMapNode child : children) {
            double sh = calcSubtreeHeight(child);
            subtreeHeights.add(sh);
            totalH += sh;
        }
        totalH += (children.size() - 1) * V_GAP;

        // ---- 垂直排列子节点 ----
        double startY = y - totalH / 2;
        for (int i = 0; i < children.size(); i++) {
            MindMapNode child = children.get(i);
            double sh = subtreeHeights.get(i);
            double childY = startY + sh / 2;
            double childX;
            if (leftSide) {
                // 子节点在当前节点的左侧
                childX = x - node.getWidth() / 2 - H_GAP - child.getWidth() / 2;
            } else {
                // 子节点在当前节点的右侧
                childX = x + node.getWidth() / 2 + H_GAP + child.getWidth() / 2;
            }
            layoutSubtree(child, childX, childY, leftSide);
            startY += sh + V_GAP;
        }
    }

    /**
     * 计算子树的总垂直高度（递归）。
     *
     * <p>子树高度 = max(节点自身高度, 所有子节点垂直排列的总高度)。</p>
     *
     * <p>例如：一个节点高度 40px，有 3 个子节点（各有自己的子树），
     * 它们垂直排列的总高度是 200px。那么这个子树的总高度是 max(40, 200) = 200px。</p>
     *
     * <p>另一种情况：一个叶子节点（无子节点），子树高度就是节点自身高度。</p>
     *
     * <p>这个计算对布局至关重要——父节点需要知道子子树的总高度，
     * 才能正确定位子节点使其垂直居中。</p>
     *
     * @param node 子树的根节点
     * @return 子树的垂直总高度（逻辑坐标）
     */
    private double calcSubtreeHeight(MindMapNode node) {
        List<MindMapNode> children = node.getChildren();
        // 叶子节点：高度就是自身节点高度
        if (children.isEmpty()) return node.getHeight();

        // 有子节点：递归计算所有子子树高度之和 + 兄弟间距
        double childrenH = 0;
        for (MindMapNode child : children) {
            childrenH += calcSubtreeHeight(child);
        }
        childrenH += (children.size() - 1) * V_GAP;

        // 取节点自身高度和子节点总高度的较大值
        return Math.max(node.getHeight(), childrenH);
    }

    // ========================================================================
    // 绘制（Canvas 渲染）
    //   - drawAll()：绘制入口，应用三层坐标变换
    //   - drawConnection()：贝塞尔曲线连线
    //   - drawNode()：节点矩形 + 文字（含命中测试坐标记录）
    //   - drawWrappedText()：手动换行文字绘制
    // ========================================================================

    /**
     * 全部绘制（使用主 Canvas 的 GraphicsContext）。
     *
     * <p>这是内部绘制入口，委托给完整的 drawAll 方法。</p>
     */
    private void drawAll() {
        drawAll(this.gc, canvas.getWidth(), canvas.getHeight(), scale, translateX, translateY, true);
    }

    /**
     * 全部绘制（通用版本，用于正常显示和导出图像）。
     *
     * <h3>绘制流程</h3>
     * <ol>
     *   <li><b>清空画布</b>：clearRect(0, 0, width, height)</li>
     *   <li><b>保存变换状态</b>：gc.save()</li>
     *   <li><b>应用三层坐标变换</b>（顺序至关重要）：
     *     <ol>
     *       <li>translate(cx, cy) —— 原点移到画布中心</li>
     *       <li>scale(scale, scale) —— 缩放</li>
     *       <li>translate(tx, ty) —— 平移</li>
     *     </ol>
     *     结果是：逻辑坐标 (0,0) 的内容显示在画布中心附近
     *   </li>
     *   <li><b>递归绘制连线</b>：drawAllConnections（先画线）</li>
     *   <li><b>递归绘制节点</b>：drawAllNodes（后画节点，覆盖在线上方）</li>
     *   <li><b>绘制 UI 层叠效果</b>：宽度调整预览虚线框、交换高亮边框</li>
     *   <li><b>恢复变换状态</b>：gc.restore()</li>
     * </ol>
     *
     * <h3>为什么连线先画？</h3>
     * <p>节点覆盖在连线上方，连线看起来像是从节点边缘"发出"的。
     * 如果反过来（先节点后连线），连线会画在节点上方，不美观。</p>
     *
     * <h3>save() / restore() 的重要性</h3>
     * <p>gc.save() 将当前的变换矩阵、颜色、字体等设置压入内部栈。
     * gc.restore() 从栈顶弹出恢复。这保证：</p>
     * <ul>
     *   <li>本方法内的坐标变换（translate/scale）不会影响其他绘制代码</li>
     *   <li>不需要手动"反向变换"恢复——直接 restore 即可</li>
     * </ul>
     *
     * @param g         绘图上下文（主 Canvas 的 gc 或导出用的临时 gc）
     * @param cw        画布宽度（像素）
     * @param ch        画布高度（像素）
     * @param drawScale 绘制缩放比例（正常显示=this.scale，导出=自动计算）
     * @param tx        X 平移量
     * @param ty        Y 平移量
     * @param hitTest   true = 收集节点屏幕坐标用于命中测试（正常显示）；
     *                  false = 不收集（导出时不需要）
     */
    private void drawAll(GraphicsContext g, double cw, double ch,
                         double drawScale, double tx, double ty, boolean hitTest) {
        // 清空整个画布（否则旧内容会残留）
        g.clearRect(0, 0, cw, ch);
        // Canvas 尺寸无效时跳过（初始阶段可能出现 0x0）
        if (cw <= 0 || ch <= 0) return;

        // ---- 保存当前状态 ----
        g.save();

        // ---- 应用三层坐标变换 ----
        double cx = cw / 2;     // 画布中心 X
        double cy = ch / 2;     // 画布中心 Y
        g.translate(cx, cy);    // 第 1 步：原点移到画布中心
        g.scale(drawScale, drawScale);  // 第 2 步：缩放（以当前原点为中心）
        g.translate(tx, ty);    // 第 3 步：平移

        // ---- 绘制所有内容 ----
        MindMapNode root = controller.getModel().getRoot();
        drawAllConnections(g, root, drawScale);   // 先画连线
        drawAllNodes(g, root, drawScale, cx, cy, tx, ty, hitTest);  // 后画节点

        // ---- 绘制 UI 层叠效果（仅在正常显示时） ----
        if (hitTest) {
            // 节点宽度调整的虚线预览框
            if (resizing && resizeTarget != null) {
                drawResizePreview(g, resizeTarget, drawScale);
            }
            // 节点交换目标的高亮边框
            if (swapping && swapHoverTarget != null) {
                drawSwapHighlight(g, swapHoverTarget, drawScale);
            }
        }

        // ---- 恢复变换状态 ----
        g.restore();
    }

    /**
     * 递归绘制所有连线（先序遍历）。
     *
     * <p>对每个节点，绘制它到其所有子节点的连线，然后递归处理子节点。</p>
     *
     * @param g         绘图上下文
     * @param node      当前节点
     * @param drawScale 绘制缩放（用于计算线宽）
     */
    private void drawAllConnections(GraphicsContext g, MindMapNode node, double drawScale) {
        for (MindMapNode child : node.getChildren()) {
            drawConnection(g, node, child, drawScale);
            drawAllConnections(g, child, drawScale);
        }
    }

    /**
     * 绘制父子节点之间的连线（贝塞尔曲线）。
     *
     * <h3>为什么用贝塞尔曲线？</h3>
     * <p>直线连线虽然简单，但在思维导图中不够美观。XMind 使用平滑弯曲的连线，
     * 让思维导图看起来更"有机"、更流畅。我们使用<b>两段二次贝塞尔曲线</b>
     * 来模拟"L 形直角弯折"的圆角效果。</p>
     *
     * <h3>贝塞尔曲线简介</h3>
     * <p>{@code quadraticCurveTo(cpx, cpy, x, y)} 绘制一条从当前点到 (x, y)
     * 的二次贝塞尔曲线，(cpx, cpy) 是控制点。曲线从起点弯向控制点，然后弯向终点。
     * 不会实际经过控制点，而是被控制点"吸引"。</p>
     *
     * <h3>本方法的连线路径</h3>
     * <pre>
     * 起点（父节点边缘）
     *   → 第 1 段贝塞尔：水平出发，到达中间水平线
     *   → 第 2 段贝塞尔：垂直到达，到达子节点边缘
     * </pre>
     *
     * <p><b>线宽自适应：</b>使用 {@code 1.5 / drawScale}。
     * 缩放后像素变粗，除以 drawScale 可以让线宽在屏幕上保持约 1.5px 的视觉粗细。</p>
     *
     * @param g         绘图上下文
     * @param parent    父节点
     * @param child     子节点
     * @param drawScale 绘制缩放比例
     */
    private void drawConnection(GraphicsContext g, MindMapNode parent, MindMapNode child, double drawScale) {
        // 设置连线样式
        g.setStroke(LINE_COLOR);
        g.setLineWidth(1.5 / drawScale);  // 屏幕视觉粗细保持约 1.5px

        double startX, startY, endX, endY;

        // ---- 确定起点（父节点边缘） ----
        if (child.isLeftSide()) {
            startX = parent.getX() - parent.getWidth() / 2;   // 父节点左边缘
        } else {
            startX = parent.getX() + parent.getWidth() / 2;   // 父节点右边缘
        }
        startY = parent.getY();  // 父节点垂直中心

        // ---- 确定终点（子节点边缘） ----
        if (child.isLeftSide()) {
            endX = child.getX() + child.getWidth() / 2;       // 子节点右边缘（因为是左侧的孩子，朝向父节点的是右边缘）
        } else {
            endX = child.getX() - child.getWidth() / 2;       // 子节点左边缘
        }
        endY = child.getY();    // 子节点垂直中心

        // ---- 贝塞尔曲线绘制 ----
        // 控制点 X 取起点和终点的中间位置
        double ctrlX = (startX + endX) / 2;

        g.beginPath();  // 开始一条新路径
        g.moveTo(startX, startY);  // 移动到起点
        // 第 1 段：从起点水平弯向中间水平线
        g.quadraticCurveTo(ctrlX, startY, ctrlX, (startY + endY) / 2);
        // 第 2 段：从中间水平线垂直弯向终点
        g.quadraticCurveTo(ctrlX, endY, endX, endY);
        g.stroke();  // 绘制路径边框（即连线）
    }

    /**
     * 绘制节点宽度调整的预览虚线框。
     *
     * <p>在用户拖拽节点边框时，绘制一个蓝色虚线矩形来预览调整后的宽度。
     * 这个矩形不是实际节点，只是视觉预览——真正的宽度在鼠标释放后才提交。</p>
     *
     * <p><b>虚线设置：</b>{@code setLineDashes(6/drawScale)} 设置虚线模式，
     * 实线 6 像素、间隔 6 像素。设为 null 恢复为实线。</p>
     *
     * @param g         绘图上下文
     * @param node      被调整的节点
     * @param drawScale 绘制缩放（用于计算线宽和虚线间距）
     */
    private void drawResizePreview(GraphicsContext g, MindMapNode node, double drawScale) {
        double ny = node.getY() - node.getHeight() / 2;
        double nh = node.getHeight();
        double nx, nw;
        if (resizeLeft) {
            // 左边缘拖拽：右边固定，左边移动
            double rightEdge = node.getX() + resizeOriginalW / 2;
            nw = resizePreviewW;
            nx = rightEdge - nw;
        } else {
            // 右边缘拖拽：左边固定，右边移动
            nx = node.getX() - resizeOriginalW / 2;
            nw = resizePreviewW;
        }
        // 设置蓝色虚线样式
        g.setStroke(Color.web("#4A90D9"));
        g.setLineWidth(2.0 / drawScale);
        g.setLineDashes(6 / drawScale);  // 虚线：实 6 空 6
        g.strokeRoundRect(nx, ny, nw, nh, NODE_ARC, NODE_ARC);
        g.setLineDashes(null);  // 恢复为实线（避免影响后续绘制）
    }

    /**
     * 绘制节点交换目标的高亮边框。
     *
     * <p>在节点交换拖拽过程中，鼠标悬停的目标节点用绿色虚线高亮显示，
     * 给用户清晰的"这个节点将被交换"的视觉提示。</p>
     *
     * @param g         绘图上下文
     * @param node      交换目标节点
     * @param drawScale 绘制缩放
     */
    private void drawSwapHighlight(GraphicsContext g, MindMapNode node, double drawScale) {
        double nx = node.getX() - node.getWidth() / 2;
        double ny = node.getY() - node.getHeight() / 2;
        g.setStroke(Color.web("#2E7D32"));       // 深绿色
        g.setLineWidth(3.0 / drawScale);          // 比边框更粗，更醒目
        g.setLineDashes(8 / drawScale);           // 虚线
        g.strokeRoundRect(nx, ny, node.getWidth(), node.getHeight(), NODE_ARC, NODE_ARC);
        g.setLineDashes(null);                     // 恢复实线
    }

    /**
     * 递归绘制所有节点（先序遍历）。
     *
     * @param g         绘图上下文
     * @param node      当前节点
     * @param drawScale 绘制缩放
     * @param cx        画布中心 X
     * @param cy        画布中心 Y
     * @param tx        X 平移
     * @param ty        Y 平移
     * @param hitTest   是否收集屏幕坐标
     */
    private void drawAllNodes(GraphicsContext g, MindMapNode node, double drawScale,
                              double cx, double cy, double tx, double ty, boolean hitTest) {
        drawNode(g, node, drawScale, cx, cy, tx, ty, hitTest);
        for (MindMapNode child : node.getChildren()) {
            drawAllNodes(g, child, drawScale, cx, cy, tx, ty, hitTest);
        }
    }

    /**
     * 绘制单个节点。
     *
     * <p>绘制流程：</p>
     * <ol>
     *   <li><b>计算节点矩形的逻辑坐标</b>：
     *       nx = node.x - width/2, ny = node.y - height/2</li>
     *   <li><b>（可选）记录屏幕坐标</b>用于命中测试：
     *       将逻辑坐标通过反变换公式转为屏幕坐标存入 nodeScreenBounds</li>
     *   <li><b>选择颜色</b>：根据节点状态（选中/根节点/普通）选择填充色和边框色</li>
     *   <li><b>填充矩形</b>：fillRoundRect —— 绘制圆角矩形背景</li>
     *   <li><b>描边矩形</b>：strokeRoundRect —— 绘制圆角矩形边框</li>
     *   <li><b>绘制文字</b>：如果有文本内容，调用 drawWrappedText 绘制多行文本</li>
     * </ol>
     *
     * <h3>fillRoundRect vs strokeRoundRect</h3>
     * <p>这是两个独立的绘制操作：</p>
     * <ul>
     *   <li>{@code fillRoundRect(x, y, w, h, arcW, arcH)} —— 填充圆角矩形内部</li>
     *   <li>{@code strokeRoundRect(x, y, w, h, arcW, arcH)} —— 绘制圆角矩形边框</li>
     * </ul>
     * <p>我们使用相同的 arc = NODE_ARC，确保填充和边框的圆角完全一致。
     * 先填充再描边的顺序很重要——边框画在填充之上，保证边框完整可见。</p>
     *
     * <h3>屏幕坐标的转换公式</h3>
     * <p>在 drawAll() 中应用了变换：</p>
     * <pre>
     * screen = center + (logical + translate) * scale
     * </pre>
     * <p>其中 logical = (nx, ny)，即节点左上角在逻辑坐标系中的位置。</p>
     *
     * <p><b>线宽自适应：</b>选中节点使用 2.5/drawScale 的线宽。
     * 除以 drawScale 是为了在缩放时保持屏幕上的视觉粗细一致——
     * 放大时线条不变粗，缩小时线条不变细。</p>
     *
     * @param g         绘图上下文
     * @param node      要绘制的节点
     * @param drawScale 绘制缩放
     * @param cx        画布中心 X
     * @param cy        画布中心 Y
     * @param tx        X 平移
     * @param ty        Y 平移
     * @param hitTest   true = 记录屏幕坐标（正常显示），false = 跳过（导出）
     */
    private void drawNode(GraphicsContext g, MindMapNode node, double drawScale,
                          double cx, double cy, double tx, double ty, boolean hitTest) {
        // ---- 计算节点矩形的逻辑坐标 ----
        // nx, ny = 节点矩形的左上角
        double nx = node.getX() - node.getWidth() / 2;
        double ny = node.getY() - node.getHeight() / 2;
        double nw = node.getWidth();
        double nh = node.getHeight();

        // ---- 记录屏幕坐标用于命中测试 ----
        // 只有在正常显示时才记录（导出时不需要命中测试）
        if (hitTest) {
            // 应用与 drawAll 中相同的变换公式（反向）
            double sx = cx + (nx + tx) * drawScale;
            double sy = cy + (ny + ty) * drawScale;
            double sw = nw * drawScale;
            double sh = nh * drawScale;
            // 存入 nodeScreenBounds Map，后续 hitTest() 使用
            nodeScreenBounds.put(node.getId(), new double[]{sx, sy, sw, sh});
        }

        // ---- 确定节点状态 ----
        boolean selected = !hitTest ? false : (controller.getSelectedNode() == node);
        boolean isRoot = node.isRoot();

        // ---- 填充节点背景 ----
        if (selected) {
            g.setFill(NODE_SELECTED_FILL);     // 选中 = 浅蓝
        } else if (isRoot) {
            g.setFill(NODE_ROOT_FILL);          // 根节点 = 浅黄
        } else {
            g.setFill(NODE_FILL);               // 普通 = 浅灰
        }
        g.fillRoundRect(nx, ny, nw, nh, NODE_ARC, NODE_ARC);

        // ---- 绘制节点边框 ----
        if (selected) {
            g.setStroke(NODE_SELECTED_STROKE);   // 蓝色边框
            g.setLineWidth(2.5 / drawScale);      // 较粗（除以 scale 保持视觉一致）
        } else if (isRoot) {
            g.setStroke(NODE_ROOT_STROKE);        // 金黄色边框
            g.setLineWidth(2.0 / drawScale);
        } else {
            g.setStroke(NODE_STROKE);              // 灰色边框
            g.setLineWidth(1.2 / drawScale);
        }
        g.strokeRoundRect(nx, ny, nw, nh, NODE_ARC, NODE_ARC);

        // ---- 绘制文字 ----
        g.setFill(TEXT_COLOR);
        Font font = NODE_FONT;
        g.setFont(font);

        String text = node.getText();
        if (!text.isEmpty()) {
            // 文字区域：在节点矩形内部，减去内边距
            drawWrappedText(g, text,
                nx + NODE_PADDING_X,        // 文字区域左边界
                ny + NODE_PADDING_Y,        // 文字区域上边界
                nw - NODE_PADDING_X * 2,    // 文字区域宽度
                nh - NODE_PADDING_Y * 2,    // 文字区域高度
                font);
        }
    }

    /**
     * 将文本在指定宽度内自动换行后，绘制到 Canvas 上。
     *
     * <h3>为什么需要手动实现换行？</h3>
     * <p>JavaFX Canvas 的 {@code fillText(text, x, y)} 方法<b>不支持自动换行</b>
     * （不像 HTML5 Canvas 那样有可选的 maxWidth 参数）。所有文字必须手动断行后
     * 逐行绘制。</p>
     *
     * <p>本方法先按 \n（显式换行符）拆分为段落，然后对每个段落按宽度拆行，
     * 最后将所有行垂直居中绘制到指定区域内。</p>
     *
     * <h3>JavaFX 文字坐标系统（重要！）</h3>
     * <p>fillText(text, x, y) 中的 y 是文字的<b>基线（baseline）</b>位置，
     * 不是文字顶部也不是底部。</p>
     * <pre>
     *             ← ascent（上升部，如字母 h 的竖）
     * ─── 基线 ──
     *             ← descent（下降部，如字母 g 的尾巴）
     * </pre>
     * <p>layoutBounds.getMinY() 是一个负值，表示从基线到文字顶部的距离。
     * 我们用这个值来校准 y 坐标，使文字顶部对齐期望的行顶位置。</p>
     *
     * <h3>算法步骤</h3>
     * <ol>
     *   <li>按 \n 拆分原始文本为段落</li>
     *   <li>对每个段落调用 wrapLine() 按宽度拆行</li>
     *   <li>计算所有行的总高度（行高 × 行数 - 多余间距）</li>
     *   <li>在可用区域内垂直居中</li>
     *   <li>逐行绘制（每行 y = startY + i × lineHeight - minY）</li>
     * </ol>
     *
     * @param gc   绘图上下文
     * @param text 要绘制的原始文本（可含 \n）
     * @param x    文本区域左上角 X
     * @param y    文本区域左上角 Y
     * @param maxW 文本区域最大宽度（超出则换行）
     * @param maxH 文本区域最大高度
     * @param font 字体
     */
    private void drawWrappedText(GraphicsContext gc, String text,
                                  double x, double y, double maxW, double maxH, Font font) {
        // ---- 第 1 步：按宽度换行 ----
        // 先按 \n 拆行，然后对每行按宽度换行
        List<String> wrappedLines = new ArrayList<>();
        for (String line : text.split("\n", -1)) {  // -1 = 保留尾部空行
            wrappedLines.addAll(wrapLine(line, font, maxW));
        }

        if (wrappedLines.isEmpty()) return;

        // ---- 第 2 步：垂直定位 ----
        // 使用与 calcNodeSize 相同的测量方式，确保绘制高度与计算高度一致
        Text measure = new Text("Ag");
        measure.setFont(font);
        double textH = measure.getLayoutBounds().getHeight();     // 单行文字高度
        double textMinY = measure.getLayoutBounds().getMinY();    // 基线到顶部的负值
        double lineH = textH + 2;                                  // 行高 = 文字高 + 行距

        int nLines = wrappedLines.size();
        // 文本块总高度（最后一行不需要行间距）
        double blockHeight = nLines * lineH - (lineH - textH);
        // 在可用区域内垂直居中
        double startY = y + (maxH - blockHeight) / 2;
        if (startY < y) startY = y;  // 文本超出区域顶部时，对齐到区域顶部

        // ---- 第 3 步：逐行绘制 ----
        for (int i = 0; i < nLines; i++) {
            // ly 是文字的基线位置
            // startY + i * lineH = 行顶位置（理论值）
            // -textMinY = 将行顶位置转换为基线位置（因为 textMinY 是负值，减负值等于加正值）
            double ly = startY + i * lineH - textMinY;
            // 检查是否超出区域底部
            double lineTop = ly + textMinY;
            if (i > 0 && lineTop > y + maxH) break;
            gc.fillText(wrappedLines.get(i), x, ly);
        }
    }

    /**
     * 对单行文本做宽度换行。
     *
     * <p><b>算法：</b>逐字符追加，创建临时的 Text 测量对象，
     * 检查如果加上当前字符后宽度是否超出 maxW。超出则在前一个位置断行。</p>
     *
     * <p><b>边界情况：</b>如果一个字符本身就比 maxW 还宽（极少见），
     * 当 line 为空时不会断行（line.length() > 0 条件），该字符会保留在当前行。
     * 这避免了一个字符单独成行甚至无限循环的问题。</p>
     *
     * @param text 原始文本
     * @param font 字体（用于测量）
     * @param maxW 最大宽度
     * @return 换行后的行列表
     */
    private List<String> wrapLine(String text, Font font, double maxW) {
        List<String> result = new ArrayList<>();
        // 将字符串拆分为单字符数组（注意：对中文、表情符号等 Unicode 字符，
        // 这种拆分方式会将一个完整字符拆成多个片段，但本项目内容为简单中英文，影响不大）
        String[] chars = text.split("");
        StringBuilder line = new StringBuilder();

        for (String ch : chars) {
            // 创建临时 Text 对象，测量加上当前字符后的整体宽度
            Text testLine = new Text(line.toString() + ch);
            testLine.setFont(font);
            // 如果超出宽度且当前行非空（避免一个字符单独成行）
            if (testLine.getLayoutBounds().getWidth() > maxW && line.length() > 0) {
                result.add(line.toString());     // 保存当前行
                line = new StringBuilder(ch);    // 开始新行
            } else {
                line.append(ch);                 // 继续追加到当前行
            }
        }
        // 最后一行（可能为空）
        if (line.length() > 0) {
            result.add(line.toString());
        }
        return result;
    }

    // ========================================================================
    // 工具方法
    // ========================================================================

    /**
     * 交换两个节点在树中的位置。
     *
     * <p>委托给 Controller 走命令模式（支持撤销/重做）。
     * Controller 内部会处理父节点引用交换、子节点重排等逻辑。</p>
     *
     * @param a 第一个节点
     * @param b 第二个节点
     */
    private void swapNodes(MindMapNode a, MindMapNode b) {
        controller.swapNodes(a, b);
    }

    /**
     * 将数值限制在 [min, max] 范围内。
     *
     * <p>例如：clamp(7.5, 0.15, 5.0) → 5.0；clamp(0.1, 0.15, 5.0) → 0.15。</p>
     *
     * @param val 原始值
     * @param min 下限
     * @param max 上限
     * @return 限制后的值
     */
    private double clamp(double val, double min, double max) {
        return Math.max(min, Math.min(max, val));
    }

    // ========================================================================
    // 导出图像
    //   - 计算所有节点的逻辑坐标边界
    //   - 自动计算缩放和平移，使所有节点完整可见并居中
    //   - 渲染到 WritableImage 上
    // ========================================================================

    /**
     * 计算所有节点的逻辑坐标边界框。
     *
     * <p>遍历整棵节点树，收集所有节点矩形的 minX、minY、maxX、maxY。
     * 结果用于导出图像时确定内容范围和缩放比例。</p>
     *
     * @return 长度为 4 的数组：{minX, minY, maxX, maxY}（逻辑坐标）
     */
    private double[] calculateContentBounds() {
        double[] bounds = new double[]{
            Double.MAX_VALUE,       // minX（初始为最大正数值）
            Double.MAX_VALUE,       // minY
            -Double.MAX_VALUE,      // maxX（初始为最小负数值）
            -Double.MAX_VALUE       // maxY
        };
        collectBounds(controller.getModel().getRoot(), bounds);
        return bounds;
    }

    /**
     * 递归收集节点的边界坐标。
     *
     * <p>将节点的矩形范围与已知边界取并集。节点的矩形以 (nodeX - width/2,
     * nodeY - height/2) 为左上角。</p>
     *
     * @param node   当前节点
     * @param b      边界数组 {minX, minY, maxX, maxY}，方法会更新它
     */
    private void collectBounds(MindMapNode node, double[] b) {
        double nx = node.getX() - node.getWidth() / 2;
        double ny = node.getY() - node.getHeight() / 2;
        b[0] = Math.min(b[0], nx);                  // 更新 minX
        b[1] = Math.min(b[1], ny);                  // 更新 minY
        b[2] = Math.max(b[2], nx + node.getWidth()); // 更新 maxX
        b[3] = Math.max(b[3], ny + node.getHeight());// 更新 maxY
        for (MindMapNode child : node.getChildren()) {
            collectBounds(child, b);
        }
    }

    /**
     * 将思维导图渲染到指定的 WritableImage 上（导出为图片）。
     *
     * <p><b>处理流程：</b></p>
     * <ol>
     *   <li>计算所有节点的逻辑坐标边界</li>
     *   <li>计算合适的缩放比例（使内容适应图像尺寸，四周留 40px 边距）</li>
     *   <li>计算平移量（使内容中心对齐图像中心）</li>
     *   <li>创建临时 Canvas 并用这些参数绘制全部内容</li>
     *   <li>使用 snapshot() 将 Canvas 内容"快照"到 WritableImage</li>
     * </ol>
     *
     * <p><b>关于 snapshot()：</b>这是 JavaFX Node 的方法，将节点的当前视觉内容
     * 渲染到指定的 WritableImage 上。它利用 GPU 加速，比逐像素复制快得多。
     * 注意：snapshot 的第一个参数（SnapshotParameters）设为 null 表示使用默认参数。</p>
     *
     * <p><b>注意：</b>调用此方法前应确保已调用过 redraw() 完成布局计算。</p>
     *
     * @param image 目标 WritableImage（需要已创建，尺寸确定）
     */
    public void renderToImage(javafx.scene.image.WritableImage image) {
        double imgW = image.getWidth();
        double imgH = image.getHeight();
        double padding = 40;  // 图像四周留白，使导图不贴边

        // ---- 计算内容边界 ----
        double[] bounds = calculateContentBounds();
        double contentW = bounds[2] - bounds[0];  // 内容总宽度
        double contentH = bounds[3] - bounds[1];  // 内容总高度
        if (contentW <= 0 || contentH <= 0) return;

        // ---- 计算缩放比例 ----
        // 取 X 和 Y 方向的较小缩放比，确保所有内容完整可见
        double scaleX = (imgW - padding * 2) / contentW;
        double scaleY = (imgH - padding * 2) / contentH;
        double exportScale = Math.min(scaleX, scaleY);

        // ---- 计算平移量 ----
        // 使内容中心对齐图像中心
        double contentCX = (bounds[0] + bounds[2]) / 2;  // 内容中心 X
        double contentCY = (bounds[1] + bounds[3]) / 2;  // 内容中心 Y
        double exportTX = -contentCX;                      // 平移使中心到原点
        double exportTY = -contentCY;

        // ---- 创建临时 Canvas 并绘制 ----
        // 注意：hitTest=false 表示不需要收集屏幕坐标（导出不需要命中测试）
        Canvas temp = new Canvas(imgW, imgH);
        GraphicsContext tgc = temp.getGraphicsContext2D();
        drawAll(tgc, imgW, imgH, exportScale, exportTX, exportTY, false);

        // ---- 快照到目标图像 ----
        temp.snapshot(null, image);
    }
}
