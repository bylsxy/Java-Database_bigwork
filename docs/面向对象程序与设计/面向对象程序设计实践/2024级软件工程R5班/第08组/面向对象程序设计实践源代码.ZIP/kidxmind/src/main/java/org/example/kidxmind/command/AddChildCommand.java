package org.example.kidxmind.command;

import org.example.kidxmind.model.MindMapModel;
import org.example.kidxmind.model.MindMapNode;

/**
 * <h1>添加子节点命令</h1>
 *
 * <h2>这个命令做了什么</h2>
 * <p>为指定的父节点创建一个新的子节点，新节点会自动获得默认文本（如"新节点"）。
 * 执行后自动选中新创建的子节点，方便用户立即编辑。</p>
 *
 * <h2>execute() 做什么</h2>
 * <ol>
 *   <li>调用 {@link MindMapModel#addChild(MindMapNode)} 在 model 中创建子节点</li>
 *   <li>选中新创建的子节点（把选中状态从父节点切换到子节点）</li>
 * </ol>
 *
 * <h2>undo() 做什么</h2>
 * <ol>
 *   <li>把新创建的子节点从父节点的 children 列表中移除</li>
 *   <li>如果当前选中的恰好是这个子节点，则选中回父节点</li>
 * </ol>
 *
 * <h2>关键设计点</h2>
 * <ul>
 *   <li>新创建的节点引用（{@code child}）在 {@code execute()} 中才赋值，不是在构造器中。
 *       因为构造时节点还不存在，只有真正执行了 {@code model.addChild(parent)} 之后才能拿到引用。</li>
 *   <li>undo() 中先判断 {@code model.getSelectedNode() == child} 再改选中，避免在选中其他
 *       节点时错误地改变选中状态。</li>
 * </ul>
 *
 * <h2>用到的 Java 概念</h2>
 * <ul>
 *   <li><b>final 字段</b> —— {@code model} 和 {@code parent} 用 {@code final} 修饰，表示它们在
 *       构造器赋值后不可再更改。这是防御性编程的好习惯：如果一个变量不应该变，
 *       就用 final 告诉编译器帮我们检查。</li>
 *   <li><b>接口实现</b> —— {@code implements Command} 表示这个类必须提供 {@code execute()}、
 *       {@code undo()} 和 {@code getDescription()} 三个方法，否则编译器会报错。</li>
 * </ul>
 */
public class AddChildCommand implements Command {

    /**
     * 思维导图的数据模型，所有对节点树的操作都通过它来完成。
     * 用 final 修饰是因为命令对象创建后不应该换一个 model。
     */
    private final MindMapModel model;

    /**
     * 要添加子节点的目标父节点。
     * 构造时保存下来，execute 时把新节点挂到这个父节点下面。
     */
    private final MindMapNode parent;

    /**
     * 新创建的子节点引用。
     * 注意：构造时这个字段还是 null，execute() 执行后才被赋值。
     * 因为新节点在 execute() 调用 model.addChild() 时才被创建出来。
     * undo() 时需要这个引用来把它从树中移除。
     */
    private MindMapNode child;

    /**
     * 构造添加子节点命令。
     *
     * <h3>为什么不在构造器里执行操作？</h3>
     * <p>这是命令模式的核心约定：构造器只负责"记录执行操作所需的信息"，
     * 真正的操作在 execute() 中执行。这样做的好处是：</p>
     * <ul>
     *   <li>可以先创建命令对象，稍后再执行（比如批量操作）</li>
     *   <li>命令对象可以放入栈中，用于撤回/重做</li>
     * </ul>
     *
     * @param model  数据模型，所有操作都通过它完成
     * @param parent 目标父节点，新子节点将挂到这个节点下
     */
    public AddChildCommand(MindMapModel model, MindMapNode parent) {
        this.model = model;
        this.parent = parent;
    }

    /**
     * 执行添加子节点的操作。
     *
     * <p>执行流程：</p>
     * <ol>
     *   <li>{@code model.addChild(parent)} —— 让 model 创建一个新节点并挂到 parent 下。
     *       model 内部会设置新节点的文本（如"新节点"），然后调用
     *       {@code parent.addChildAt(0, newNode)} 把新节点插到 children 列表最前面。</li>
     *   <li>{@code model.selectNode(child)} —— 把 model 的选中节点改为新创建的子节点。</li>
     * </ol>
     *
     * <p>执行后，{@code child} 字段被赋值为新创建的节点，undo() 会用到它。</p>
     */
    @Override
    public void execute() {
        child = model.addChild(parent);
        model.selectNode(child);
    }

    /**
     * 撤销添加子节点的操作，恢复到 execute() 之前的状态。
     *
     * <p>撤销流程：</p>
     * <ol>
     *   <li>{@code child.removeFromParent()} —— 从父节点的 children 列表中移除该子节点。
     *       注意：节点对象本身仍然存在（在内存中），只是不再属于树的一部分。
     *       Java 的垃圾回收器（GC）会在没有引用指向它时自动回收内存。</li>
     *   <li>判断当前选中——如果用户恰好选中了这个被移除的子节点，
     *       就把选中恢复到父节点上。这个判断使用 {@code ==}（引用比较）而不是
     *       {@code .equals()}，因为我们需要确认是同一个对象。</li>
     * </ol>
     */
    @Override
    public void undo() {
        child.removeFromParent();
        if (model.getSelectedNode() == child) {
            model.selectNode(parent);
        }
    }

    /**
     * 返回操作的中文描述，用于状态栏或撤回/重做按钮的提示文本。
     * @return 操作描述字符串"添加子节点"
     */
    @Override
    public String getDescription() { return "添加子节点"; }
}
