package org.example.kidxmind.command;

import org.example.kidxmind.model.MindMapNode;

/**
 * <h1>节点宽度调整命令</h1>
 *
 * <h2>这个命令做了什么</h2>
 * <p>修改单个节点的自定义宽度（userWidth）。在 KidxMind 中，节点宽度默认由
 * 文本内容决定（宽度 = 3 x 高度），但用户可以通过拖动节点边框来设置自定义宽度。
 * 一旦设置了 userWidth，节点就会使用这个固定宽度而非自动计算。</p>
 *
 * <h2>execute() 做什么</h2>
 * <p>将节点的 userWidth 设置为新宽度值（newUserWidth）。</p>
 *
 * <h2>undo() 做什么</h2>
 * <p>将节点的 userWidth 恢复为旧宽度值（oldUserWidth）。</p>
 *
 * <h2>与 TextEditCommand 的相似性</h2>
 * <p>这两个命令结构几乎完全相同——都是"保存旧值 → 设置新值 → undo 恢复旧值"。
 * 这说明命令模式具有很好的<b>模板化</b>特性：只要掌握了"状态切换"类的命令，
 * 就可以用同样的模式处理各种属性修改。</p>
 *
 * <h2>用到的 Java 概念</h2>
 * <ul>
 *   <li><b>原始类型 double vs 包装类型 Double</b> —— 这里使用 {@code double}（基本类型）
 *       而不是 {@code Double}（包装类）。基本类型不能为 null，默认值是 0.0。
 *       如果 userWidth 可能不存在，应该用 {@code Double} 配合 null 来表示"未设置"。
 *       当前设计选择了 {@code double}，意味着未设置时可能用 0 或特定值表示。</li>
 *   <li><b>简单命令模式</b> —— 和 TextEditCommand 一样，这是命令模式最简单的形式。
 *       只需要两个状态值就能实现完整的 undo/redo。</li>
 * </ul>
 */
public class ResizeNodeCommand implements Command {

    /**
     * 宽度被调整的节点引用。
     */
    private final MindMapNode node;

    /**
     * 调整前的宽度值（undo 时恢复为此值）。
     *
     * <p>用 {@code double} 基本类型存储。如果是默认宽度（未手动设置过），
     * 这个值可能为 0 或某个表示"自动"的特殊值。</p>
     */
    private final double oldUserWidth;

    /**
     * 调整后的宽度值（execute 时设置为此值）。
     * 通常是用户拖动节点边框后的新宽度。
     */
    private final double newUserWidth;

    /**
     * 构造节点宽度调整命令。
     *
     * @param node         要调整宽度的节点
     * @param oldUserWidth 调整前的宽度值（从节点当前状态读取）
     * @param newUserWidth 调整后的宽度值（通常来自用户拖动操作的计算结果）
     */
    public ResizeNodeCommand(MindMapNode node, double oldUserWidth, double newUserWidth) {
        this.node = node;
        this.oldUserWidth = oldUserWidth;
        this.newUserWidth = newUserWidth;
    }

    /**
     * 执行宽度调整：将节点宽度设置为新值。
     *
     * <p>{@code node.setUserWidth(newUserWidth)} 修改节点的 userWidth 属性。
     * 这个操作会触发界面重新布局（如果 controller 在命令执行后调用了 refreshAll）。</p>
     */
    @Override
    public void execute() {
        node.setUserWidth(newUserWidth);
    }

    /**
     * 撤销宽度调整：将节点宽度恢复为旧值。
     */
    @Override
    public void undo() {
        node.setUserWidth(oldUserWidth);
    }

    /**
     * 返回操作的中文描述。
     * @return "调整节点宽度"
     */
    @Override
    public String getDescription() { return "调整节点宽度"; }
}
