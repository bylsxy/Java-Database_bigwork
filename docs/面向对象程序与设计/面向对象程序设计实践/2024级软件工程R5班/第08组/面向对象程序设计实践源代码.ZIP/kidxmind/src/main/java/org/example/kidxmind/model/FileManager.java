package org.example.kidxmind.model;

import com.google.gson.*;

import java.io.*;
import java.nio.charset.StandardCharsets;

/**
 * <h1>文件读写管理</h1>
 *
 * <p>负责将思维导图序列化为 .dt（JSON 格式）文件，或从 .dt 文件反序列化。
 * 扩展名 .dt 是本项目自定义的格式，本质上是 UTF-8 编码的 JSON。</p>
 *
 * <h2>用到的第三方库：Gson</h2>
 * <ul>
 *   <li><b>{@link com.google.gson.Gson}</b> —— Google 的 JSON 库。
 *       类似 Jackson，但更轻量。GsonBuilder().setPrettyPrinting() 让输出带缩进。</li>
 *   <li><b>{@link com.google.gson.JsonObject}</b> —— 表示 JSON 对象 {}，
 *       通过 addProperty(key, value) 添加键值对。</li>
 *   <li><b>{@link com.google.gson.JsonArray}</b> —— 表示 JSON 数组 []。</li>
 * </ul>
 *
 * <h2>文件格式示例</h2>
 * <pre>
 * {
 *   "version": "1.0",
 *   "layout": "auto",
 *   "nodes": {
 *     "id": "uuid",
 *     "text": "中心节点",
 *     "x": 0, "y": 0,
 *     "width": 120, "height": 50,
 *     "children": [ ... ]
 *   }
 * }
 * </pre>
 *
 * <h2>关于序列化</h2>
 * <p>不使用 Gson 的自动序列化（@Expose 注解），而是手动构建 JsonObject。
 * 好处是精确控制输出格式，容错性更好（字段缺失时给默认值）。</p>
 */
public class FileManager {

    /**
     * Gson 实例。
     * setPrettyPrinting() —— 让输出的 JSON 带缩进和换行（方便人类阅读）。
     * 如果不设置，所有 JSON 会写在一行。
     */
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    // ==================== 写（序列化）====================

    /**
     * 将整个 MindMapModel 保存为 .dt 文件。
     *
     * @param model 当前的数据模型
     * @param file  目标文件
     * @throws IOException 如果写入失败
     */
    public static void save(MindMapModel model, File file) throws IOException {
        JsonObject root = new JsonObject();
        root.addProperty("version", "1.0");
        // 枚举值转字符串：AUTO → "auto"
        root.addProperty("layout", model.getLayoutMode().name().toLowerCase());
        // 递归序列化整棵节点树
        root.add("nodes", nodeToJson(model.getRoot()));

        // try-with-resources：Writer 会在 try 块结束时自动关闭
        // OutputStreamWriter + FileOutputStream + StandardCharsets.UTF_8 确保 UTF-8 编码
        try (Writer w = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8)) {
            gson.toJson(root, w); // 将 JSON 对象写入文件
        }
    }

    /**
     * 递归将节点树转为 JsonObject。
     * 深度优先遍历：先序列化当前节点，再递归序列化所有子节点。
     */
    private static JsonObject nodeToJson(MindMapNode node) {
        JsonObject obj = new JsonObject();
        obj.addProperty("id", node.getId());
        obj.addProperty("text", node.getText());
        obj.addProperty("x", node.getX());
        obj.addProperty("y", node.getY());
        obj.addProperty("width", node.getWidth());
        obj.addProperty("height", node.getHeight());
        // 只有用户手动调整过宽度（userWidth > 0）才保存该字段
        if (node.getUserWidth() > 0) {
            obj.addProperty("userWidth", node.getUserWidth());
        }
        // 递归序列化子节点
        JsonArray children = new JsonArray();
        for (MindMapNode child : node.getChildren()) {
            children.add(nodeToJson(child));
        }
        obj.add("children", children);
        return obj;
    }

    // ==================== 读（反序列化）====================

    /**
     * 从 .dt 文件加载并构建 MindMapModel。
     *
     * @param file 源文件
     * @return 新构建的 MindMapModel（含完整节点树）
     * @throws IOException 如果文件读取失败
     */
    public static MindMapModel load(File file) throws IOException {
        String json;
        // FileInputStream.readAllBytes() 读取整个文件的字节
        // new String(bytes, StandardCharsets.UTF_8) 将字节转为 UTF-8 字符串
        try (FileInputStream fis = new FileInputStream(file)) {
            json = new String(fis.readAllBytes(), StandardCharsets.UTF_8);
        }
        return fromJson(json);
    }

    /**
     * 从 JSON 字符串反序列化为 MindMapModel。
     * 包含容错处理：缺少字段时使用默认值。
     */
    public static MindMapModel fromJson(String json) {
        // JsonParser.parseString() 把字符串解析为 JsonElement（可能是对象、数组、基本类型）
        // getAsJsonObject() 断言它是 JSON 对象（如果不是则抛异常）
        JsonObject root = JsonParser.parseString(json).getAsJsonObject();

        // ---- 读取 layout（容错：缺失时默认为 AUTO）----
        String layoutStr = "auto";
        if (root.has("layout")) layoutStr = root.get("layout").getAsString();
        MindMapModel.LayoutMode layout = MindMapModel.LayoutMode.AUTO;
        if ("left".equals(layoutStr)) layout = MindMapModel.LayoutMode.LEFT;
        else if ("right".equals(layoutStr)) layout = MindMapModel.LayoutMode.RIGHT;
        // AUTO 已经默认，不需要判断

        MindMapModel model = new MindMapModel();
        model.setLayoutMode(layout);

        // ---- 读取节点树（容错：缺失时使用默认中心节点）----
        if (root.has("nodes")) {
            JsonObject nodes = root.getAsJsonObject("nodes");
            MindMapNode loadedRoot = nodeFromJson(nodes);
            if (loadedRoot != null) {
                // 将加载的根节点数据"移植"到模型的根节点中
                // 为什么不直接替换根节点？因为模型已经创建了根节点，
                // 直接替换会导致引用丢失。用"移植子节点"的方式更安全。
                MindMapNode modelRoot = model.getRoot();
                modelRoot.setText(loadedRoot.getText());
                modelRoot.setUserWidth(loadedRoot.getUserWidth());
                for (MindMapNode child : loadedRoot.getChildren()) {
                    modelRoot.addChild(child);
                }
            }
        }
        return model;
    }

    /**
     * 递归从 JsonObject 反序列化节点树。
     * 深度优先遍历：先构建当前节点，再递归构建所有子节点。
     */
    private static MindMapNode nodeFromJson(JsonObject obj) {
        // 容错：没有 id 的节点无效
        if (obj == null || !obj.has("id")) return null;

        // 容错：text 缺失则用空字符串
        String text = obj.has("text") ? obj.get("text").getAsString() : "";
        MindMapNode node = new MindMapNode(text);

        /*
         * 用反射设置 ID。
         * 为什么需要这样？因为 MindMapNode 的 id 是 final 字段，在构造器中
         * 通过 UUID.randomUUID() 自动生成，没有 setter。但加载文件时需要
         * 保持和保存时相同的 ID（以便 undo 等操作正确匹配节点）。
         * 反射绕过 private 限制直接修改 final 字段。
         *
         * 注意：反射操作较慢且有安全隐患，但在这个场景下是合理的——
         * 我们需要精确恢复节点身份标识。
         */
        setId(node, obj.get("id").getAsString());

        // 容错：坐标/尺寸缺失时保留默认值（后续布局计算会重新赋值，所以无所谓）
        if (obj.has("x")) node.setX(obj.get("x").getAsDouble());
        if (obj.has("y")) node.setY(obj.get("y").getAsDouble());
        if (obj.has("width")) node.setWidth(obj.get("width").getAsDouble());
        if (obj.has("height")) node.setHeight(obj.get("height").getAsDouble());
        if (obj.has("userWidth")) node.setUserWidth(obj.get("userWidth").getAsDouble());

        // 递归构建子节点
        if (obj.has("children")) {
            JsonArray children = obj.getAsJsonArray("children");
            for (JsonElement e : children) {
                MindMapNode child = nodeFromJson(e.getAsJsonObject());
                if (child != null) node.addChild(child);
            }
        }
        return node;
    }

    /**
     * 用 Java 反射机制设置节点的 ID。
     *
     * <h3>Java 反射简介</h3>
     * <p>反射（Reflection）允许程序在运行时操作类的结构（字段、方法等），
     * 即使这些字段是 private 的。这是 Java 的高级特性。</p>
     *
     * <ol>
     *   <li>{@code getDeclaredField("id")} —— 获取 MindMapNode 类中名为 "id" 的字段</li>
     *   <li>{@code setAccessible(true)} —— 绕过 private 访问限制</li>
     *   <li>{@code f.set(node, id)} —— 将 node 对象的 id 字段设为指定值</li>
     * </ol>
     *
     * <p>如果反射操作失败（如字段不存在），catch 块吞掉异常，节点使用默认 UUID。</p>
     */
    private static void setId(MindMapNode node, String id) {
        try {
            java.lang.reflect.Field f = MindMapNode.class.getDeclaredField("id");
            f.setAccessible(true);
            f.set(node, id);
        } catch (Exception ignored) {
            // 反射失败时保留默认 UUID，不影响程序运行
        }
    }
}
