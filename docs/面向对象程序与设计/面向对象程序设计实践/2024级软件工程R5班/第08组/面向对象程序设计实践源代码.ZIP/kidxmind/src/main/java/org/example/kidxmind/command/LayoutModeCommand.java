package org.example.kidxmind.command;

import org.example.kidxmind.model.MindMapModel;

/**
 * <h1>布局模式切换命令</h1>
 *
 * <h2>这个命令做了什么</h2>
 * <p>切换思维导图的布局模式。KidxMind 支持三种布局模式：</p>
 * <ul>
 *   <li><b>LEFT</b> —— 所有子节点统一放在父节点左侧，从上到下排列</li>
 *   <li><b>RIGHT</b> —— 所有子节点统一放在父节点右侧，从上到下排列</li>
 *   <li><b>AUTO</b> —— 自动平衡布局：遍历所有分割点，选择使左右两侧总高度
 *       最接近的方案，前 k 个放左侧、其余放右侧</li>
 * </ul>
 *
 * <h2>execute() 做什么</h2>
 * <p>将模型（MindMapModel）的布局模式设置为 newMode。</p>
 *
 * <h2>undo() 做什么</h2>
 * <p>将模型（MindMapModel）的布局模式恢复为 oldMode。</p>
 *
 * <h2>这个命令的特殊之处</h2>
 * <p>与 TextEditCommand 和 ResizeNodeCommand 不同，LayoutModeCommand 修改的是
 * <b>全局设置</b>（model 级别），而不是单个节点的属性。切换布局模式后，
 * 所有节点的位置都需要重新计算，因此 controller 需要在命令执行后调用
 * {@code refreshAll()} 来重绘整个画布。</p>
 *
 * <h2>用到的 Java 概念</h2>
 * <ul>
 *   <li><b>枚举（Enum）</b> —— {@link MindMapModel.LayoutMode} 是一个枚举类型。
 *       枚举的好处是限定了取值范围——布局模式只能是 LEFT、RIGHT、AUTO 三者之一，
 *       不可能出现非法的值。这让代码更安全、更易读。</li>
 *   <li><b>全局状态切换</b> —— 这是命令模式处理"开关/模式切换"类操作的典型形式：
 *       记录旧模式 → 切换到新模式 → undo 恢复旧模式。</li>
 *   <li><b>不可变性</b> —— 枚举值在 Java 中天然是不可变的（单例），所以保存的
 *       oldMode 和 newMode 引用不会被子类或反射修改。</li>
 * </ul>
 */
public class LayoutModeCommand implements Command {

    /**
     * 数据模型，布局模式是 model 的一个属性。
     */
    private final MindMapModel model;

    /**
     * 切换前的布局模式（undo 时恢复）。
     *
     * <p>使用枚举类型 {@link MindMapModel.LayoutMode}，可能是 LEFT、RIGHT 或 AUTO。</p>
     */
    private final MindMapModel.LayoutMode oldMode;

    /**
     * 切换后的布局模式（execute 时设置）。
     */
    private final MindMapModel.LayoutMode newMode;

    /**
     * 构造布局模式切换命令。
     *
     * <h3>枚举类型参数</h3>
     * <p>{@code MindMapModel.LayoutMode} 是 MindMapModel 内部定义的枚举类。
     * 在 Java 中，内部枚举默认是 {@code static} 的，所以可以通过
     * {@code MindMapModel.LayoutMode.LEFT} 这样的语法来引用。</p>
     *
     * @param model   数据模型
     * @param oldMode 切换前的布局模式
     * @param newMode 切换后的布局模式
     */
    public LayoutModeCommand(MindMapModel model, MindMapModel.LayoutMode oldMode,
                              MindMapModel.LayoutMode newMode) {
        this.model = model;
        this.oldMode = oldMode;
        this.newMode = newMode;
    }

    /**
     * 执行布局模式切换：将 model 的布局模式设为 newMode。
     *
     * <p>注意：这个操作本身只改一个属性值，不会自动触发界面刷新。
     * controller 需要在命令执行后手动调用 refreshAll()。</p>
     */
    @Override
    public void execute() {
        model.setLayoutMode(newMode);
    }

    /**
     * 撤销布局模式切换：将 model 的布局模式恢复为 oldMode。
     */
    @Override
    public void undo() {
        model.setLayoutMode(oldMode);
    }

    /**
     * 返回操作的中文描述。
     * @return "切换布局"
     */
    @Override
    public String getDescription() { return "切换布局"; }
}
