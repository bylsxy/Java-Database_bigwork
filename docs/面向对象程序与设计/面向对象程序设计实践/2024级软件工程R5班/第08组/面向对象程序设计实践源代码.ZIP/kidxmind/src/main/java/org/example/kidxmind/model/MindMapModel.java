package org.example.kidxmind.model;

/**
 * <h1>思维导图数据模型</h1>
 *
 * <p>管理思维导图的<b>数据状态</b>，不涉及任何 UI 渲染。类似 MVC 中的 Model 层。</p>
 *
 * <h2>职责</h2>
 * <ul>
 *   <li><b>树结构</b> —— 持有根节点引用，树的结构由节点自身的 parent/children 维护</li>
 *   <li><b>选中状态</b> —— 维护当前选中的节点（单选，最多一个，可为 null）</li>
 *   <li><b>剪贴板</b> —— 存储复制/剪切的内容，以及剪切来源节点的引用</li>
 *   <li><b>布局模式</b> —— 记录当前的布局模式（自动/左侧/右侧）</li>
 * </ul>
 *
 * <h2>关于剪切/粘贴的特殊逻辑</h2>
 * <p>需求规定"剪切在粘贴后剪切的节点会从原位置删除"，即剪切不是立即删除，而是：</p>
 * <ol>
 *   <li>剪切时：深拷贝到剪贴板 + 记录原节点引用（cutSourceNode）</li>
 *   <li>粘贴时：将副本插入目标节点下，然后从树中移除 cutSourceNode</li>
 * </ol>
 *
 * @see MindMapNode 节点数据结构
 * @see org.example.kidxmind.controller.MindMapController 控制器（操作入口）
 */
public class MindMapModel {

    // ========== 布局模式枚举 ==========

    /**
     * 思维导图的三种布局模式。
     * 模式决定了根节点的子节点如何排列在左右两侧。
     */
    public enum LayoutMode {
        /** 自动布局：子节点尽可能均匀分布在左右两侧，两边高度相近 */
        AUTO,
        /** 左侧布局：所有子节点放在根节点左侧 */
        LEFT,
        /** 右侧布局：所有子节点放在根节点右侧 */
        RIGHT
    }

    // ========== 文件持久化 ==========

    /** 当前文件路径（新建/打开后设置，保存时使用） */
    private String currentFilePath;

    /** 脏标记：自上次保存后是否有未保存的修改 */
    private boolean dirty = false;

    // ========== 核心数据 ==========

    /** 根节点（中心节点）。这是整个思维导图树的入口，初始化时自动创建 */
    private final MindMapNode root;

    /**
     * 当前选中的节点。null 表示没有选中任何节点。
     * 需求规定最多只有一个节点被选中，所以用单个引用即可。
     */
    private MindMapNode selectedNode;

    /** 当前布局模式，默认自动布局 */
    private LayoutMode layoutMode;

    // ========== 剪贴板相关 ==========

    /** 剪贴板中存储的子树副本（深拷贝，与原树无关） */
    private MindMapNode clipboard;

    /** 标记剪贴板内容来自剪切（true）还是复制（false） */
    private boolean clipboardCut;

    /**
     * 剪切操作时保存的原始节点引用。
     * 粘贴后会从此引用在原树中删除节点。
     */
    private MindMapNode cutSourceNode;

    // ========== 构造方法 ==========

    public MindMapModel() {
        this.root = new MindMapNode("中心节点");
        this.layoutMode = LayoutMode.AUTO;
    }

    // ==================== 选中管理 ====================

    /**
     * 获取当前选中的节点，可能为 null（表示没有选中）。
     */
    public MindMapNode getSelectedNode() {
        return selectedNode;
    }

    /**
     * 单选：选中指定节点。传入 null 等同于清除选中。
     * 保证最多只有一个节点被选中。
     */
    public void selectNode(MindMapNode node) {
        selectedNode = node;
    }

    /** 清除选中状态（设为 null）。点击空白区域时调用。 */
    public void clearSelection() {
        selectedNode = null;
    }

    /** 判断指定节点是否被选中。 */
    public boolean isSelected(MindMapNode node) {
        return node != null && node == selectedNode;
    }

    // ==================== 剪贴板 ====================

    /**
     * 复制选中的节点（必须有节点被选中）。
     * 将节点的深拷贝放入剪贴板，标记为"复制"。
     */
    public void copySelected() {
        if (selectedNode == null) return;
        clipboard = selectedNode.deepCopy();
        clipboardCut = false;
    }

    /**
     * 剪切选中的节点（必须有节点被选中且非根节点）。
     * 保存深拷贝到剪贴板 + 保存原节点引用（粘贴后删除用）。
     */
    public void cutSelected() {
        if (selectedNode == null) return;
        if (selectedNode.isRoot()) return;       // 根节点不可剪切
        clipboard = selectedNode.deepCopy();
        cutSourceNode = selectedNode;            // 记录原节点，粘贴后从此位置删除
        clipboardCut = true;
    }

    public MindMapNode getClipboard() { return clipboard; }

    public boolean isClipboardCut() { return clipboardCut; }

    /** 获取剪切源节点（供命令模式 PasteCommand 捕获位置） */
    public MindMapNode getCutSourceNode() { return cutSourceNode; }

    /** 清空剪贴板（通常在粘贴后或取消操作时调用） */
    public void clearClipboard() {
        clipboard = null;
        clipboardCut = false;
        cutSourceNode = null;
    }

    /**
     * 恢复剪贴板到指定状态。供剪切/粘贴命令的 undo() 使用。
     */
    public void restoreClipboard(MindMapNode savedClipboard, boolean savedCut, MindMapNode savedSource) {
        this.clipboard = savedClipboard;
        this.clipboardCut = savedCut;
        this.cutSourceNode = savedSource;
    }

    // ==================== 编辑操作 ====================

    /**
     * 为指定父节点添加一个子节点。新节点文本为空字符串。
     *
     * @param parent 父节点
     * @return 新创建的子节点
     */
    public MindMapNode addChild(MindMapNode parent) {
        MindMapNode child = new MindMapNode("");
        parent.addChild(child);
        return child;
    }

    /**
     * 为指定节点添加一个兄弟节点（插入到该节点之后）。
     * 根节点不能添加兄弟节点（根节点没有父节点，不存在"兄弟"概念）。
     *
     * @param node 参考节点，新兄弟在其之后
     * @return 新创建的兄弟节点，如果 node 是根节点则返回 null
     */
    public MindMapNode addSibling(MindMapNode node) {
        if (node.isRoot()) return null;
        MindMapNode parent = node.getParent();
        int idx = parent.getChildren().indexOf(node);
        MindMapNode sibling = new MindMapNode("");
        parent.addChildAt(idx + 1, sibling);
        return sibling;
    }

    /**
     * 删除节点及其所有子孙节点。根节点不可删除。
     *
     * @return true 表示删除成功，false 表示操作被拒绝（根节点）
     */
    public boolean deleteNode(MindMapNode node) {
        if (node.isRoot()) return false;
        // 如果要删除的节点正好是选中的，清除选中
        if (selectedNode == node) {
            selectedNode = null;
        }
        node.removeFromParent();
        return true;
    }

    /**
     * 将剪贴板内容粘贴到目标节点下。
     *
     * <p>如果剪贴板来自剪切操作（clipboardCut == true），粘贴后会：</p>
     * <ol>
     *   <li>将剪贴板内容深拷贝并添加为 target 的子节点</li>
     *   <li>从树中删除原始的剪切源节点（cutSourceNode）</li>
     *   <li>清空剪贴板</li>
     * </ol>
     *
     * <p>这对应需求中的"剪切在粘贴后剪切的节点会从原位置删除"。</p>
     *
     * @param target 粘贴目标节点，剪贴板内容将作为其子节点
     * @return 新粘贴的节点，如果剪贴板为空则返回 null
     */
    public MindMapNode pasteTo(MindMapNode target) {
        if (clipboard == null) return null;
        // 再次深拷贝：保证多次粘贴产生独立副本
        MindMapNode copy = clipboard.deepCopy();
        target.addChild(copy);
        if (clipboardCut && cutSourceNode != null) {
            // 剪切模式：删除原始节点，如果源节点正好是选中节点则清除
            if (selectedNode == cutSourceNode) {
                selectedNode = null;
            }
            cutSourceNode.removeFromParent();
            cutSourceNode = null;
            clipboard = null;
            clipboardCut = false;
        }
        return copy;
    }

    // ==================== getters / setters ====================

    public MindMapNode getRoot() { return root; }

    public LayoutMode getLayoutMode() { return layoutMode; }

    public void setLayoutMode(LayoutMode layoutMode) { this.layoutMode = layoutMode; }

    // ==================== 文件持久化 ====================

    public String getCurrentFilePath() { return currentFilePath; }
    public void setCurrentFilePath(String path) { this.currentFilePath = path; }

    public boolean isDirty() { return dirty; }

    /** 标记有未保存修改 */
    public void markDirty() { dirty = true; }

    /** 清除脏标记（保存/新建/打开后调用） */
    public void clearDirty() { dirty = false; }

    /** 递归统计节点总数 */
    public int getTotalNodeCount() {
        return countNodes(root);
    }

    private int countNodes(MindMapNode node) {
        int count = 1;
        for (MindMapNode child : node.getChildren()) {
            count += countNodes(child);
        }
        return count;
    }
}
