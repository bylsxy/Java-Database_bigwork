package org.example.kidxmind.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

/**
 * <h1>启动欢迎页</h1>
 *
 * <h2>JavaFX 相关概念</h2>
 * <ul>
 *   <li><b>{@link VBox}</b> —— 垂直排列容器。子节点从上到下排列。
 *       setAlignment(Pos.CENTER) 使子节点在水平和垂直方向都居中。</li>
 *   <li><b>{@link Pos}</b> —— 位置枚举：CENTER(居中)、TOP_LEFT(左上) 等。</li>
 *   <li><b>{@link VBox#setMargin}</b> —— 给单个子节点设置外边距。
 *       这样可以在统一的间距基础上微调某个子节点的间距。</li>
 * </ul>
 *
 * <h2>设计</h2>
 * <p>首次启动或无法恢复上次文件时显示。简洁的 IDEA 风格：
 * 标题 + 两个大按钮（新建/打开）+ 提示文字。</p>
 * <p>按钮回调通过构造器传入（Runnable 参数）——这是"回调模式"，
 * 让 WelcomeView 本身不需要知道 Controller 的存在。</p>
 */
public class WelcomeView extends VBox {

    /**
     * @param onNew  点击"新建"时的回调
     * @param onOpen 点击"打开"时的回调
     */
    public WelcomeView(Runnable onNew, Runnable onOpen) {
        getStyleClass().add("welcome-view");
        setAlignment(Pos.CENTER);
        setSpacing(16);  // 子节点之间间距 16px

        // 标题
        Label title = new Label("KidxMind");
        title.getStyleClass().add("title");  // 使用 CSS 中 .welcome-view .title 的样式

        // 副标题
        Label subtitle = new Label("思维导图绘制工具");
        subtitle.getStyleClass().add("subtitle");

        // "新建"按钮
        Button newBtn = new Button("新建思维导图");
        newBtn.setOnAction(e -> onNew.run()); // 点击时执行传入的回调

        // "打开"按钮
        Button openBtn = new Button("打开思维导图");
        openBtn.setOnAction(e -> onOpen.run());

        // 底部提示文字
        Label hint = new Label("请新建一个思维导图或打开已有的 .dt 文件");
        hint.setStyle("-fx-text-fill: #999999;"); // 灰色提示文字

        // 添加所有子节点
        getChildren().addAll(title, subtitle, newBtn, openBtn, hint);

        // 微调各子节点的外边距（setMargin 只影响指定的子节点）
        VBox.setMargin(subtitle, new Insets(0, 0, 20, 0));  // 副标题下方 20px 间距
        VBox.setMargin(newBtn, new Insets(4, 0, 4, 0));      // 按钮上下 4px 间距
        VBox.setMargin(openBtn, new Insets(4, 0, 4, 0));
    }
}
