package org.example.kidxmind;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import org.example.kidxmind.controller.MindMapController;
import org.example.kidxmind.model.MindMapModel;
import org.example.kidxmind.model.PreferencesManager;
import org.example.kidxmind.view.*;

import java.io.File;

/**
 * <h1>KidxMind 应用入口</h1>
 *
 * <h2>JavaFX 基础概念</h2>
 * <ul>
 *   <li><b>{@link Application}</b> —— JavaFX 应用的基类。每个 JavaFX 程序必须继承它。
 *       它的 {@link #start(Stage)} 方法是整个程序的入口点。</li>
 *   <li><b>{@link Stage}</b> —— 顶层窗口。可以理解为"窗户"，对应操作系统的窗口。
 *       一个应用可以有多个 Stage，但主 Stage 由 JavaFX 自动创建并传给 start()。</li>
 *   <li><b>{@link Scene}</b> —— 窗口中的内容。一个 Stage 同一时间只能显示一个 Scene。
 *       Scene 管理一棵"节点树"（Node Tree），所有按钮、文本框、面板都是这棵树上的节点。</li>
 *   <li><b>{@link javafx.scene.Node}</b> —— 所有 UI 元素（控件、布局容器、图形）的基类。</li>
 *   <li><b>布局容器（Layout）</b> —— 专门用来"摆放"其他节点的特殊 Node，如 VBox、HBox、BorderPane。</li>
 * </ul>
 *
 * <h2>Application 生命周期</h2>
 * <ol>
 *   <li>{@link #main} 调用 {@link #launch}（JavaFX 提供）</li>
 *   <li>JavaFX 运行时初始化图形引擎（创建主 Stage）</li>
 *   <li>JavaFX 在 <b>JavaFX Application Thread</b> 上调用 {@link #start}</li>
 *   <li>用户关闭窗口 → 应用结束</li>
 * </ol>
 * <p><b>重要：</b>所有 UI 操作必须在 JavaFX Application Thread 上执行。
 * 如果在其他线程操作 UI（如 new Label()），会抛异常。</p>
 *
 * <h2>启动流程</h2>
 * <ol>
 *   <li>读取用户偏好文件 ~/.mindmap_prefs 中的 lastFile</li>
 *   <li>若文件存在且可读 → 直接加载进入编辑器（showEditor）</li>
 *   <li>若不存在 → 显示欢迎页（showWelcome）</li>
 * </ol>
 *
 * <h2>编辑器界面布局</h2>
 * <pre>
 * AnchorPane（锚定布局，此容器的子节点用"锚点"固定位置）
 * ├── VBox（垂直排列容器）
 * │   ├── Toolbar（工具栏，HBox 水平排列）—— 固定高度
 * │   └── SplitPane（可拖拽分隔条的水平分割容器）—— 填充剩余空间
 * │       ├── DrawingPane（绘图区，继承 StackPane）—— 占 72%
 * │       └── StructureTreeView（结构树，继承 BorderPane）—— 占 28%
 * └── StatusBar（状态栏，HBox）—— 固定在底部 30px
 * </pre>
 *
 * <h2>为什么用 AnchorPane + VBox 而不是单独的 BorderPane？</h2>
 * <p>BorderPane 在某些 JavaFX 布局重算时可能不正确地分配底部空间，
 * 导致状态栏消失。AnchorPane 用绝对锚定解决这个问题。</p>
 */
public class MainApp extends Application {

    /*
     * ========== 字段说明 ==========
     * Stage  —— 对应操作系统窗口
     * Scene  —— 窗口中的内容（可切换，如从欢迎页切换到编辑器）
     * controller —— MVC 中的 Controller，负责所有业务逻辑
     * root    —— 布局根容器
     * statusBar / splitPane —— 需要在多个方法间共享的 UI 组件
     */
    private MindMapController controller;
    private BorderPane root;
    private Scene scene;
    private Stage stage;
    private StatusBar statusBar;
    private SplitPane splitPane;

    /**
     * JavaFX Application 的入口。
     * 由 JavaFX 运行时在初始化完成后自动回调。
     * 此方法在 <b>JavaFX Application Thread</b>（UI 线程）上执行。
     *
     * @param stage JavaFX 创建的主窗口，类似 Swing 的 JFrame
     */
    @Override
    public void start(Stage stage) {
        this.stage = stage;

        // ===== MVC 初始化：先创建 Model，再创建 Controller =====
        // Controller 需要持有 Model 引用才能操作数据
        MindMapModel model = new MindMapModel();
        controller = new MindMapController(model);
        // 将 Stage 传给 Controller，因为文件对话框（FileChooser）需要父窗口引用
        controller.setStage(stage);

        // ===== 启动：尝试恢复上次打开的文件 =====
        String lastFile = PreferencesManager.getLastFile();
        if (lastFile != null) {
            // 有历史文件 → 直接加载进入编辑器
            controller.loadFromFile(new File(lastFile));
            showEditor();
        } else {
            // 没有历史文件 → 显示欢迎页（让用户选择新建或打开）
            showWelcome();
        }

        // 设置窗口标题和最小尺寸
        stage.setTitle("思维导图绘制工具 — KidxMind");
        stage.setMinWidth(800);
        stage.setMinHeight(500);

        /*
         * 窗口关闭事件：用户点击右上角 × 时触发。
         * setOnCloseRequest 设置一个回调（lambda），当关闭请求发生时执行。
         * e.consume() —— "消费"事件，阻止窗口关闭（相当于取消）。
         * Platform.exit() —— 强制退出 JavaFX 运行时。
         */
        stage.setOnCloseRequest(e -> {
            if (!controller.handleExit()) {
                e.consume(); // 用户点击取消，阻止关闭
            } else {
                Platform.exit(); // 正常退出
            }
        });
    }

    /** 构建并显示主编辑器界面 */
    private void showEditor() {
        // ===== 创建 View 组件 =====
        // 每个 View 接收其依赖的对象（Controller 或 Model）
        // 这是"依赖注入"的简化版——通过构造器或 setter 传递依赖
        Toolbar toolbar = new Toolbar(controller);
        DrawingPane drawingPane = new DrawingPane(controller);
        StructureTreeView structureView = new StructureTreeView(controller.getModel());
        statusBar = new StatusBar();

        // 将 View 注入 Controller（Controller 需要它们来刷新界面）
        controller.setDrawingPane(drawingPane);
        controller.setStructureView(structureView);
        controller.setStatusBar(statusBar);

        // ===== 组装布局 =====

        /*
         * SplitPane：可拖拽分隔条的分割面板。
         * - 将两个子组件水平排列，中间有一个可拖拽的分隔条
         * - setDividerPositions(0.72) 表示分隔条初始位置在 72% 处
         * - 设置 minWidth 防止面板被完全折叠
         */
        splitPane = new SplitPane();
        splitPane.getItems().addAll(drawingPane, structureView);
        splitPane.setDividerPositions(0.72);
        drawingPane.setMinWidth(300);
        structureView.setMinWidth(180);

        /*
         * VBox：垂直排列容器。
         * 子节点从上到下依次排列。
         * VBox.setVgrow(splitPane, Priority.ALWAYS) 让 SplitPane 占据所有剩余垂直空间。
         * ——如果没有这一句，SplitPane 只会占自己的"首选高度"（可能为 0）。
         */
        VBox mainArea = new VBox(toolbar, splitPane);
        VBox.setVgrow(splitPane, Priority.ALWAYS);

        /*
         * AnchorPane：锚定布局容器。
         * 子节点通过"锚点"固定位置：
         *   - setTopAnchor：距容器顶部多少像素
         *   - setBottomAnchor：距容器底部多少像素
         *   - setLeftAnchor / setRightAnchor：距左右边多少像素
         *
         * 这里：
         *   - mainArea 占据除底部 30px 外的整个空间
         *   - statusBar 固定在底部 30px 区域内（高度 = 状态栏的 prefHeight）
         */
        AnchorPane anchor = new AnchorPane();
        AnchorPane.setTopAnchor(mainArea, 0.0);
        AnchorPane.setBottomAnchor(mainArea, 30.0);
        AnchorPane.setLeftAnchor(mainArea, 0.0);
        AnchorPane.setRightAnchor(mainArea, 0.0);
        AnchorPane.setBottomAnchor(statusBar, 0.0);
        AnchorPane.setLeftAnchor(statusBar, 0.0);
        AnchorPane.setRightAnchor(statusBar, 0.0);
        anchor.getChildren().addAll(mainArea, statusBar);

        // ===== 创建 Scene（场景）=====
        // Scene 构造函数：Scene(根节点, 宽度, 高度)
        scene = new Scene(anchor, 1200, 750);

        /*
         * 加载 CSS 样式表。
         * getResource("/style.css") 从 classpath 根目录加载文件。
         * toExternalForm() 把资源 URL 转为字符串形式的绝对路径。
         * JavaFX CSS 语法与网页 CSS 类似，但属性名都以 -fx- 开头。
         */
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());

        // ---------------------------------------------------------------
        // 全局键盘快捷键（使用 addEventHandler 注册，在"冒泡阶段"处理）
        // ---------------------------------------------------------------
        /*
         * JavaFX 事件传播机制（与 HTML DOM 类似）：
         * 1. 捕获阶段（Capture Phase）：事件从根节点向下传递到目标节点
         * 2. 目标阶段（Target Phase）：事件到达目标
         * 3. 冒泡阶段（Bubble Phase）：事件从目标节点向上传递回根节点
         *
         * addEventHandler → 在冒泡阶段处理
         * addEventFilter  → 在捕获阶段处理（更早）
         *
         * 这里用 addEventHandler 处理 Ctrl+ 快捷键。
         * TextArea（文本编辑框）会自动消费 Ctrl+C/V/X 等事件，
         * 所以这些快捷键不会与文本编辑冲突。
         */
        scene.addEventHandler(javafx.scene.input.KeyEvent.KEY_PRESSED, e -> {
            boolean ctrl = e.isControlDown();   // Ctrl 键是否按下
            boolean shift = e.isShiftDown();    // Shift 键是否按下
            var code = e.getCode();             // 获取按键代码（如 KeyCode.A）

            // ---- 文件操作 ----
            if (ctrl && !shift && code == javafx.scene.input.KeyCode.N) {
                controller.newFile();
            } else if (ctrl && !shift && code == javafx.scene.input.KeyCode.O) {
                controller.openFile();
            } else if (ctrl && !shift && code == javafx.scene.input.KeyCode.S) {
                controller.saveFile();
            }
            // ---- 撤回/重做 ----
            else if (ctrl && !shift && code == javafx.scene.input.KeyCode.Z) {
                controller.undo();
            } else if (ctrl && !shift && code == javafx.scene.input.KeyCode.Y) {
                controller.redo();
            }
            // ---- 节点编辑 ----
            else if (ctrl && !shift && code == javafx.scene.input.KeyCode.A) {
                controller.addChildNode();
            } else if (ctrl && shift && code == javafx.scene.input.KeyCode.A) {
                controller.addSiblingNode();       // Ctrl+Shift+A
            } else if (ctrl && !shift && code == javafx.scene.input.KeyCode.D) {
                controller.deleteNode();
            }
            // ---- 剪贴板 ----
            else if (ctrl && !shift && code == javafx.scene.input.KeyCode.X) {
                controller.cut();
            } else if (ctrl && !shift && code == javafx.scene.input.KeyCode.C) {
                controller.copy();
            } else if (ctrl && !shift && code == javafx.scene.input.KeyCode.V) {
                controller.paste();
            }
            // ---- 导出 ----
            else if (ctrl && !shift && code == javafx.scene.input.KeyCode.E) {
                controller.exportImage(stage);
            }
            // ---- 编辑文本 ----
            else if (!ctrl && code == javafx.scene.input.KeyCode.F2) {
                controller.startEditingSelected();
            } else {
                return; // 未匹配任何快捷键，不消费事件
            }
            e.consume(); // "消费"事件——阻止它在事件链上继续传播
        });

        // ---------------------------------------------------------------
        // 方向键导航（使用 addEventFilter 注册，在"捕获阶段"处理）
        // ---------------------------------------------------------------
        /*
         * 为什么方向键必须用 addEventFilter（捕获阶段）？
         * 因为 TreeView（结构树）有自己的方向键处理逻辑。
         * 如果我们在冒泡阶段处理，方向键事件会先到达 TreeView，
         * TreeView 会将其拦截（选中树项），不会冒泡到 Scene。
         *
         * 使用 addEventFilter 在捕获阶段拦截，在 TreeView 看到之前
         * 就把方向键事件拿走（消费掉）。
         *
         * 放行条件：事件目标是 TextInputControl（文本编辑框）。
         * 这样编辑文本时方向键仍然可以正常移动光标。
         */
        scene.addEventFilter(javafx.scene.input.KeyEvent.KEY_PRESSED, e -> {
            // 文本编辑框聚焦时放行（用户正在打字，方向键应移动光标）
            if (e.getTarget() instanceof javafx.scene.control.TextInputControl) return;
            var code = e.getCode();
            if (code == javafx.scene.input.KeyCode.UP) {
                controller.navigateUp();
                e.consume();
            } else if (code == javafx.scene.input.KeyCode.DOWN) {
                controller.navigateDown();
                e.consume();
            } else if (code == javafx.scene.input.KeyCode.LEFT) {
                controller.navigateLeft();
                e.consume();
            } else if (code == javafx.scene.input.KeyCode.RIGHT) {
                controller.navigateRight();
                e.consume();
            }
        });

        // ===== 显示窗口 =====
        // setScene 把"内容"放进窗口
        // show()  让窗口可见（此时 JavaFX 开始布局和渲染）
        stage.setScene(scene);
        stage.show();

        // ===== 初始绘制 =====
        // stage.show() 后，各组件有了正确的尺寸（布局已完成）
        // 此时才能正确计算 Canvas 的中心点和节点位置
        drawingPane.redraw();
        structureView.refresh();
        controller.refreshAll(); // 刷新状态栏（更新文件路径、节点数等）
    }

    /**
     * 显示启动欢迎页。
     * <p>当没有历史文件、文件被删除或首次启动时显示。</p>
     * <p>两个大按钮的回调用 lambda 表达式传入：
     * <ul>
     *   <li>新建 → 弹出保存对话框 → 创建 .dt → 切换到编辑器</li>
     *   <li>打开 → 弹出打开对话框 → 加载 .dt → 切换到编辑器</li>
     * </ul>
     * </p>
     */
    private void showWelcome() {
        /*
         * Lambda 表达式：(参数) -> { 函数体 }
         * 这里 () -> { ... } 是 Runnable 接口的匿名实现。
         * 相当于 new Runnable() { public void run() { ... } }
         */
        WelcomeView welcome = new WelcomeView(
            () -> {
                controller.newFile();
                // newFile() 成功后 currentFilePath 被设置；
                // 如果用户取消了保存对话框，currentFilePath 为 null
                if (controller.getModel().getCurrentFilePath() != null) {
                    showEditor();
                }
            },
            () -> {
                controller.openFile();
                if (controller.getModel().getCurrentFilePath() != null) {
                    showEditor();
                }
            }
        );

        // BorderPane 将 WelcomeView 放在中央（上下左右自动居中）
        root = new BorderPane();
        root.setCenter(welcome);

        scene = new Scene(root, 600, 400);
        scene.getStylesheets().add(getClass().getResource("/style.css").toExternalForm());
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Java 程序的标准入口。
     * {@link Application#launch} 是 JavaFX 提供的静态方法，
     * 它会设置 JavaFX 运行时环境，然后回调 start()。
     */
    public static void main(String[] args) {
        launch(args);
    }
}
