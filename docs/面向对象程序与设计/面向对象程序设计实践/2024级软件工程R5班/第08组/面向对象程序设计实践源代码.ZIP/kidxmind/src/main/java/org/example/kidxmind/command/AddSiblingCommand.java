package org.example.kidxmind.command;

import org.example.kidxmind.model.MindMapModel;
import org.example.kidxmind.model.MindMapNode;

/**
 * <h1>添加兄弟节点命令</h1>
 *
 * <h2>这个命令做了什么</h2>
 * <p>在参考节点（reference）之后的位置为其父节点创建一个新的子节点。
 * 新节点和参考节点共享同一个父节点，因此是"兄弟"关系。
 * 执行后自动选中新创建的兄弟节点。</p>
 *
 * <h2>execute() 做什么</h2>
 * <ol>
 *   <li>调用 {@link MindMapModel#addSibling(MindMapNode)} 在 reference 节点的后面
 *       创建一个兄弟节点</li>
 *   <li>选中新创建的兄弟节点</li>
 * </ol>
 *
 * <h2>undo() 做什么</h2>
 * <ol>
 *   <li>将新创建的兄弟节点从父节点中移除</li>
 *   <li>如果当前选中的恰好是这个兄弟节点，则选中回 reference 节点</li>
 * </ol>
 *
 * <h2>与 AddChildCommand 的区别</h2>
 * <ul>
 *   <li>AddChild 是在某个节点<b>内部</b>添加子节点（纵向扩展）</li>
 *   <li>AddSibling 是在某个节点<b>旁边</b>添加兄弟节点（横向扩展）</li>
 *   <li>两者的 undo 逻辑类似，都是移除新节点 + 恢复选中</li>
 * </ul>
 *
 * <h2>用到的 Java 概念</h2>
 * <ul>
 *   <li><b>引用类型字段</b> —— {@code reference} 保存的是节点对象的引用（内存地址），
 *       不是节点的副本。所以即使 execute() 执行后树结构变了，这个引用仍然指向原来的
 *       节点对象。</li>
 *   <li><b>null 初始值</b> —— {@code sibling} 字段声明时不赋值，Java 会自动给引用类型
 *       初始化为 {@code null}。这提醒我们 execute() 必须在 undo() 之前调用。</li>
 * </ul>
 */
public class AddSiblingCommand implements Command {

    /**
     * 思维导图的数据模型。所有对节点树的操作（增删改查）都通过它完成。
     */
    private final MindMapModel model;

    /**
     * 参考节点——新兄弟节点将插在它后面。
     * 保存这个引用有两个目的：
     * <ol>
     *   <li>execute() 时：告诉 model 在谁后面插入兄弟</li>
     *   <li>undo() 时：如果移除兄弟后需要恢复选中，选中回这个 reference 节点</li>
     * </ol>
     */
    private final MindMapNode reference;

    /**
     * 新创建的兄弟节点引用。
     * 命令对象刚创建时这个字段是 {@code null}（Java 引用类型的默认值），
     * 只有在 execute() 调用 {@code model.addSibling(reference)} 之后才会被赋值。
     */
    private MindMapNode sibling;

    /**
     * 构造添加兄弟节点命令。
     *
     * <h3>构造器里的"记录"思想</h3>
     * <p>命令模式的构造器就像一个"快照相机"——在执行操作之前，
     * 先把需要的信息记录下来。这里只记录了 reference，因为 sibling
     * 还不存在，要等 execute() 时才创建。</p>
     *
     * @param model     数据模型
     * @param reference 参考节点，新兄弟将插在它后面的位置
     */
    public AddSiblingCommand(MindMapModel model, MindMapNode reference) {
        this.model = model;
        this.reference = reference;
    }

    /**
     * 执行添加兄弟节点的操作。
     *
     * <p>底层逻辑（在 MindMapModel.addSibling 中）：</p>
     * <ol>
     *   <li>找到 reference 的父节点</li>
     *   <li>找到 reference 在父节点 children 列表中的索引位置</li>
     *   <li>在索引 + 1 的位置插入新节点（即插在 reference 之后）</li>
     *   <li>如果 reference 是根节点（没有父节点），则创建失败</li>
     * </ol>
     *
     * <p>执行后 {@code sibling} 字段持有新节点的引用，供 undo() 使用。</p>
     */
    @Override
    public void execute() {
        sibling = model.addSibling(reference);
        model.selectNode(sibling);
    }

    /**
     * 撤销添加兄弟节点的操作。
     *
     * <p>两步操作：</p>
     * <ol>
     *   <li>把新兄弟节点从树中移除（{@code sibling.removeFromParent()}）</li>
     *   <li>恢复选中状态到 reference 节点（前提是当前选中的恰好是这个 sibling）</li>
     * </ol>
     *
     * <p>注意：{@code removeFromParent()} 只是把节点从父节点的 children 列表中
     * 移除，节点对象本身还在内存中。只要 {@code sibling} 这个字段还引用着它，
     * GC（垃圾回收器）就不会回收，undo() 后它才变成真正无引用的"孤儿"。</p>
     */
    @Override
    public void undo() {
        sibling.removeFromParent();
        if (model.getSelectedNode() == sibling) {
            model.selectNode(reference);
        }
    }

    /**
     * 返回操作的中文描述。
     * @return "添加兄弟节点"
     */
    @Override
    public String getDescription() { return "添加兄弟节点"; }
}
