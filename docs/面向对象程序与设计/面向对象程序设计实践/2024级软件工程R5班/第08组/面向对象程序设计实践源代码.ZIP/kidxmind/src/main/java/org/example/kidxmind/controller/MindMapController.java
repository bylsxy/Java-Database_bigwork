package org.example.kidxmind.controller;

import org.example.kidxmind.command.*;
import org.example.kidxmind.model.FileManager;
import org.example.kidxmind.model.MindMapModel;
import org.example.kidxmind.model.MindMapNode;
import org.example.kidxmind.model.PreferencesManager;
import org.example.kidxmind.view.DrawingPane;
import org.example.kidxmind.view.StatusBar;
import org.example.kidxmind.view.StructureTreeView;

import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.image.WritableImage;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.Window;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;
import java.util.Optional;
import java.util.Stack;

/**
 * <h1>思维导图控制器</h1>
 *
 * <p>在 MVC 架构中扮演 Controller 角色，连接 Model（数据）和 View（界面）。</p>
 *
 * <h2>职责</h2>
 * <ul>
 *   <li>接收来自 UI（工具栏按钮、鼠标事件）的操作请求</li>
 *   <li>通过命令模式（Command Pattern）执行操作，支持撤回/重做</li>
 *   <li>通知 View 层刷新显示</li>
 *   <li>执行前置条件检查（如"有且只有一个节点被选中"）</li>
 * </ul>
 *
 * <h2>命令模式数据流</h2>
 * <pre>
 * 用户操作 → Controller.xxx() → new XxxCommand() → executeCommand(cmd)
 *                                                      ├── cmd.execute()
 *                                                      ├── undoStack.push(cmd)
 *                                                      └── refreshAll()
 *
 * 撤回：Ctrl+Z → undo()
 *                 ├── cmd = undoStack.pop()
 *                 ├── cmd.undo()
 *                 ├── redoStack.push(cmd)
 *                 └── refreshAll()
 * </pre>
 */
public class MindMapController {

    private final MindMapModel model;
    private DrawingPane drawingPane;
    private StructureTreeView structureView;
    private StatusBar statusBar;
    private Stage stage;

    /** 模型变更回调。预留接口，暂未使用。 */
    private Runnable onModelChanged;

    // ========== 命令历史 ==========

    private final Stack<Command> undoStack = new Stack<>();
    private final Stack<Command> redoStack = new Stack<>();

    public MindMapController(MindMapModel model) {
        this.model = model;
    }

    // ========== 依赖注入 ==========

    public void setDrawingPane(DrawingPane drawingPane) { this.drawingPane = drawingPane; }
    public void setStructureView(StructureTreeView structureView) { this.structureView = structureView; }
    public void setStatusBar(StatusBar statusBar) { this.statusBar = statusBar; }
    public void setStage(Stage stage) { this.stage = stage; }
    public void setOnModelChanged(Runnable callback) { this.onModelChanged = callback; }

    // ========== 命令执行核心 ==========

    /**
     * 执行一个命令并推入历史栈。
     * 这是所有可撤销操作的统一入口。
     */
    private void executeCommand(Command cmd) {
        cmd.execute();
        undoStack.push(cmd);
        redoStack.clear();
        model.markDirty();
        refreshAll();
        if (statusBar != null) statusBar.showOperation(cmd.getDescription());
    }

    public void undo() {
        if (undoStack.isEmpty()) return;
        Command cmd = undoStack.pop();
        cmd.undo();
        redoStack.push(cmd);
        model.markDirty();
        refreshAll();
        if (statusBar != null) statusBar.showOperation("撤回: " + cmd.getDescription());
    }

    public void redo() {
        if (redoStack.isEmpty()) return;
        Command cmd = redoStack.pop();
        cmd.execute();
        undoStack.push(cmd);
        model.markDirty();
        refreshAll();
        if (statusBar != null) statusBar.showOperation("重做: " + cmd.getDescription());
    }

    /** 是否有可撤回的操作 */
    public boolean canUndo() { return !undoStack.isEmpty(); }

    /** 是否有可重做的操作 */
    public boolean canRedo() { return !redoStack.isEmpty(); }

    // ==================== 选中操作 ====================

    /** 单击节点：单选。只重绘画布（选中高亮），不影响结构树。 */
    public void selectNode(MindMapNode node) {
        model.selectNode(node);
        if (drawingPane != null) drawingPane.redraw();
        updateStatusBar();
    }

    /** 点击空白区：清除选中。只重绘画布，不影响结构树。 */
    public void clearSelection() {
        model.clearSelection();
        if (drawingPane != null) drawingPane.redraw();
        updateStatusBar();
    }

    /** F2：开始编辑选中节点文本 */
    public void startEditingSelected() {
        MindMapNode sel = model.getSelectedNode();
        if (sel != null && drawingPane != null) {
            drawingPane.startEdit(sel);
        }
    }

    // ==================== 方向键导航 ====================

    /** 上键：在兄弟节点间向上循环移动 */
    public void navigateUp() {
        MindMapNode sel = model.getSelectedNode();
        if (sel == null || sel.isRoot()) return;
        MindMapNode parent = sel.getParent();
        java.util.List<MindMapNode> siblings = parent.getChildren();
        int idx = siblings.indexOf(sel);
        int newIdx = idx - 1;
        if (newIdx < 0) newIdx = siblings.size() - 1;
        model.selectNode(siblings.get(newIdx));
        refreshViews();
    }

    /** 下键：在兄弟节点间向下循环移动 */
    public void navigateDown() {
        MindMapNode sel = model.getSelectedNode();
        if (sel == null || sel.isRoot()) return;
        MindMapNode parent = sel.getParent();
        java.util.List<MindMapNode> siblings = parent.getChildren();
        int idx = siblings.indexOf(sel);
        int newIdx = idx + 1;
        if (newIdx >= siblings.size()) newIdx = 0;
        model.selectNode(siblings.get(newIdx));
        refreshViews();
    }

    /**
     * 左键：根节点→左边第一个子节点；左侧节点→第一个子节点(深入)；右侧节点→父节点(回退)
     */
    public void navigateLeft() {
        MindMapNode sel = model.getSelectedNode();
        if (sel == null) return;
        if (sel.isRoot()) {
            // 根节点：找到第一个左侧子节点
            for (MindMapNode child : sel.getChildren()) {
                if (child.isLeftSide()) {
                    model.selectNode(child);
                    refreshViews();
                    return;
                }
            }
            return;
        }
        if (sel.isLeftSide()) {
            // 左侧节点：向左深入 → 第一个子节点
            if (!sel.isLeaf()) {
                model.selectNode(sel.getChildren().get(0));
            }
        } else {
            // 右侧节点：向左回退 → 父节点
            model.selectNode(sel.getParent());
        }
        refreshViews();
    }

    /**
     * 右键：根节点→右边第一个子节点；右侧节点→第一个子节点(深入)；左侧节点→父节点(回退)
     */
    public void navigateRight() {
        MindMapNode sel = model.getSelectedNode();
        if (sel == null) return;
        if (sel.isRoot()) {
            // 根节点：找到第一个右侧子节点
            for (MindMapNode child : sel.getChildren()) {
                if (!child.isLeftSide()) {
                    model.selectNode(child);
                    refreshViews();
                    return;
                }
            }
            return;
        }
        if (!sel.isLeftSide()) {
            // 右侧节点：向右深入 → 第一个子节点
            if (!sel.isLeaf()) {
                model.selectNode(sel.getChildren().get(0));
            }
        } else {
            // 左侧节点：向右回退 → 父节点
            model.selectNode(sel.getParent());
        }
        refreshViews();
    }

    public MindMapNode getSelectedNode() {
        return model.getSelectedNode();
    }

    // ==================== 节点编辑操作 ====================

    /** 添加子节点 */
    public void addChildNode() {
        MindMapNode selected = model.getSelectedNode();
        if (selected == null) return;
        executeCommand(new AddChildCommand(model, selected));
    }

    /** 添加兄弟节点 */
    public void addSiblingNode() {
        MindMapNode selected = model.getSelectedNode();
        if (selected == null) return;
        if (selected.isRoot()) return;
        executeCommand(new AddSiblingCommand(model, selected));
    }

    /** 删除节点（及整棵子树） */
    public void deleteNode() {
        MindMapNode selected = model.getSelectedNode();
        if (selected == null) return;
        if (selected.isRoot()) return;
        executeCommand(new DeleteNodeCommand(model, selected));
    }

    /**
     * 提交文本编辑（由 DrawingPane 在编辑完成时调用）。
     *
     * @param node    被编辑的节点
     * @param oldText 编辑前的文本
     * @param newText 编辑后的文本
     */
    public void commitEditText(MindMapNode node, String oldText, String newText) {
        if (oldText.equals(newText)) return; // 没有实际变化，不记录
        executeCommand(new TextEditCommand(node, oldText, newText));
    }

    // ==================== 剪贴板操作 ====================

    /** 复制。不记录命令（不改变有意义的状态）。 */
    public void copy() {
        model.copySelected();
    }

    /** 剪切 */
    public void cut() {
        MindMapNode selected = model.getSelectedNode();
        if (selected == null) return;
        if (selected.isRoot()) return;
        executeCommand(new CutCommand(model, selected));
    }

    /** 粘贴 */
    public void paste() {
        if (model.getClipboard() == null) return;
        MindMapNode target = model.getSelectedNode();
        if (target == null) return;
        executeCommand(new PasteCommand(model, target));
    }

    // ==================== 布局操作 ====================

    public void setAutoLayout() {
        MindMapModel.LayoutMode old = model.getLayoutMode();
        if (old == MindMapModel.LayoutMode.AUTO) return;
        executeCommand(new LayoutModeCommand(model, old, MindMapModel.LayoutMode.AUTO));
    }

    public void setLeftLayout() {
        MindMapModel.LayoutMode old = model.getLayoutMode();
        if (old == MindMapModel.LayoutMode.LEFT) return;
        executeCommand(new LayoutModeCommand(model, old, MindMapModel.LayoutMode.LEFT));
    }

    public void setRightLayout() {
        MindMapModel.LayoutMode old = model.getLayoutMode();
        if (old == MindMapModel.LayoutMode.RIGHT) return;
        executeCommand(new LayoutModeCommand(model, old, MindMapModel.LayoutMode.RIGHT));
    }

    // ==================== 导出图像 ====================

    /**
     * 将思维导图全部内容导出为 PNG 或 JPG 图像（非截图，而是完整渲染）。
     *
     * @param parentWindow 文件对话框的父窗口
     */
    public void exportImage(Window parentWindow) {
        if (drawingPane == null) return;

        // 第 1 步：文件选择对话框
        FileChooser chooser = new FileChooser();
        chooser.setTitle("导出思维导图");
        chooser.getExtensionFilters().addAll(
            new FileChooser.ExtensionFilter("PNG 图像", "*.png"),
            new FileChooser.ExtensionFilter("JPG 图像", "*.jpg")
        );
        chooser.setInitialFileName("思维导图.png");
        File file = chooser.showSaveDialog(parentWindow);
        if (file == null) return;

        // 第 2 步：判断格式
        String name = file.getName().toLowerCase();
        String format = name.endsWith(".jpg") || name.endsWith(".jpeg") ? "jpg" : "png";

        // 第 3 步：先在当前布局上重绘一次，确保布局数据最新
        drawingPane.redraw();

        // 第 4 步：创建图像并渲染全部内容
        int imgW = 2560;
        int imgH = 1920;
        WritableImage image = new WritableImage(imgW, imgH);
        drawingPane.renderToImage(image);

        // 第 5 步：裁剪掉空白区域（可选），写入文件
        try {
            ImageIO.write(SwingFXUtils.fromFXImage(image, null), format, file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // ==================== 拖拽操作（由 DrawingPane 调用）====================

    /**
     * 交换两个节点（由 DrawingPane 的拖拽交换调用）。
     */
    public void swapNodes(MindMapNode a, MindMapNode b) {
        if (a.isRoot() || b.isRoot()) return;
        executeCommand(new SwapNodesCommand(model, a, b));
    }

    /**
     * 调整节点宽度（由 DrawingPane 的边框拖拽调用）。
     */
    public void resizeNode(MindMapNode node, double oldUserWidth, double newUserWidth) {
        executeCommand(new ResizeNodeCommand(node, oldUserWidth, newUserWidth));
    }

    // ==================== 文件操作 ====================

    /** 新建：检查脏 → 提示保存 → 保存对话框 → 创建 .dt → 加载 */
    public void newFile() {
        if (!checkDirtyAndPrompt()) return;
        FileChooser chooser = new FileChooser();
        chooser.setTitle("新建思维导图");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("思维导图文件", "*.dt"));
        chooser.setInitialFileName("未命名.dt");
        File file = chooser.showSaveDialog(stage);
        if (file == null) return;

        // 构建新的空白模型
        MindMapModel newModel = new MindMapModel();
        replaceModel(newModel, file.getAbsolutePath());

        // 保存空文件
        saveToFile(file);
        model.clearDirty();
        updateStatusBar();
    }

    /** 打开：检查脏 → 提示 → 打开对话框 → 加载 .dt */
    public void openFile() {
        if (!checkDirtyAndPrompt()) return;
        FileChooser chooser = new FileChooser();
        chooser.setTitle("打开思维导图");
        chooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("思维导图文件", "*.dt"));
        File file = chooser.showOpenDialog(stage);
        if (file == null) return;
        loadFromFile(file);
    }

    /** 保存：覆盖写入当前路径，不弹对话框 */
    public void saveFile() {
        if (model.getCurrentFilePath() == null) return;
        saveToFile(new File(model.getCurrentFilePath()));
        model.clearDirty();
        updateStatusBar();
        if (statusBar != null) statusBar.showTemp("已保存", 2000);
    }

    /**
     * 加载指定文件到当前模型。
     * 从 MainApp 启动时调用，不需要检查脏标记。
     */
    public void loadFromFile(File file) {
        try {
            MindMapModel loaded = FileManager.load(file);
            replaceModel(loaded, file.getAbsolutePath());
            model.clearDirty();
            updateStatusBar();
        } catch (IOException e) {
            showError("无法打开文件", e.getMessage());
        }
    }

    /** 退出前检查：脏标记 → 提示保存 */
    public boolean handleExit() {
        if (!model.isDirty()) {
            // 始终记录当前路径（如果已打开过文件）
            if (model.getCurrentFilePath() != null) {
                PreferencesManager.setLastFile(model.getCurrentFilePath());
            }
            return true;
        }
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("保存修改");
        alert.setHeaderText("是否保存对当前文件的更改？");
        alert.setContentText("文件：" + model.getCurrentFilePath());
        alert.getButtonTypes().setAll(ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.YES) {
            saveFile();
            return true;
        } else if (result.isPresent() && result.get() == ButtonType.NO) {
            return true;
        }
        return false; // 取消
    }

    /** 检查脏标记并弹窗，返回 true 表示可继续（已保存或放弃） */
    private boolean checkDirtyAndPrompt() {
        if (!model.isDirty()) return true;
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("保存修改");
        alert.setHeaderText("是否保存对当前文件的更改？");
        alert.getButtonTypes().setAll(ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.YES) {
            saveFile();
            return true;
        } else if (result.isPresent() && result.get() == ButtonType.NO) {
            return true;
        }
        return false;
    }

    private void saveToFile(File file) {
        try {
            FileManager.save(model, file);
        } catch (IOException e) {
            showError("保存失败", e.getMessage());
        }
    }

    /** 替换当前模型（清空撤销栈等） */
    private void replaceModel(MindMapModel newModel, String filePath) {
        // 用新模型的数据替换旧模型
        MindMapModel oldModel = this.model;
        MindMapNode newRoot = newModel.getRoot();

        // 清空旧根节点的子节点
        oldModel.getRoot().getChildren().clear();
        // 复制根节点属性
        oldModel.getRoot().setText(newRoot.getText());
        oldModel.getRoot().setUserWidth(newRoot.getUserWidth());
        // 移入所有子节点
        for (MindMapNode child : newRoot.getChildren()) {
            oldModel.getRoot().addChild(child);
        }
        oldModel.setLayoutMode(newModel.getLayoutMode());
        oldModel.setCurrentFilePath(filePath);
        oldModel.clearSelection();
        oldModel.clearClipboard();

        undoStack.clear();
        redoStack.clear();

        PreferencesManager.setLastFile(filePath);
        refreshAll();
    }

    private void showError(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    /** 更新状态栏显示 */
    private void updateStatusBar() {
        if (statusBar != null) {
            int selCount = model.getSelectedNode() != null ? 1 : 0;
            statusBar.update(
                model.getCurrentFilePath(),
                model.getTotalNodeCount(),
                selCount,
                model.isDirty()
            );
        }
    }

    public int getTotalNodeCount() {
        return model.getTotalNodeCount();
    }

    // ==================== 视图刷新 ====================

    /** 轻量刷新：只重绘画布和结构树。 */
    public void refreshViews() {
        if (drawingPane != null) drawingPane.redraw();
        if (structureView != null) structureView.refresh();
    }

    /** 完整刷新：刷新所有视图 + 状态栏 + onModelChanged 回调。 */
    public void refreshAll() {
        refreshViews();
        updateStatusBar();
        if (onModelChanged != null) onModelChanged.run();
    }

    // ==================== getters ====================

    public MindMapModel getModel() {
        return model;
    }
}
