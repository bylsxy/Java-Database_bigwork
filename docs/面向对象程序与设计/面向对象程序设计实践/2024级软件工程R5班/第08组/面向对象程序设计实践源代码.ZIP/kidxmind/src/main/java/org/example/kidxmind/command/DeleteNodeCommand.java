package org.example.kidxmind.command;

import org.example.kidxmind.model.MindMapModel;
import org.example.kidxmind.model.MindMapNode;

/**
 * <h1>删除节点命令</h1>
 *
 * <h2>这个命令做了什么</h2>
 * <p>从思维导图树中移除指定节点（包括它的整棵子树）。注意：删除的是整个子树，
 * 如果被删除的节点下面还有子节点，它们也会一起被移除。</p>
 *
 * <h2>execute() 做什么</h2>
 * <ol>
 *   <li>调用 {@link MindMapModel#deleteNode(MindMapNode)} 将节点从父节点的
 *       children 列表中移除</li>
 *   <li>选中被删除节点的父节点（因为被删除的节点已经不在树中了，不能再选中它）</li>
 * </ol>
 *
 * <h2>undo() 做什么</h2>
 * <ol>
 *   <li>将之前被删除的节点（含整棵子树）重新添加回原父节点的原位置</li>
 *   <li>选中恢复后的节点</li>
 * </ol>
 *
 * <h2>为什么要在构造器中"捕获"parent 和 index？</h2>
 * <p>这是这个命令最关键的设计点。设想一下：如果 execute() 执行完之后再问
 * "被删除节点的父节点是谁？它在兄弟中排第几？"——答案是问不到了，因为节点
 * 已经从树中移除了。所以在构造器中、execute() 还没执行之前，就要先把这些
 * 信息记录下来，这样 undo() 时才能把节点准确地放回原位。</p>
 *
 * <p>这种模式在命令模式中非常常见——"执行前先记录足够的状态信息，以便能
 * 完全恢复"。这就像拆东西之前先拍照，回头才能原样装回去。</p>
 *
 * <h2>用到的 Java 概念</h2>
 * <ul>
 *   <li><b>构造器中调用方法</b> —— 构造器中调用了 {@code node.getParent()} 和
 *       {@code parent.getChildren().indexOf(node)}，这是合法的 Java 写法。但要注意
 *       顺序：必须先获取 parent，才能用 parent 来查 index。</li>
 *   <li><b>List.indexOf()</b> —— 利用列表的线性查找返回节点的位置索引。
 *       这个索引在 undo() 时用于精确恢复到原位置。</li>
 * </ul>
 */
public class DeleteNodeCommand implements Command {

    /**
     * 数据模型，提供 deleteNode() 方法来删除节点。
     */
    private final MindMapModel model;

    /**
     * 要删除的节点（含其整棵子树）。
     * 这个引用在整个生命周期中都有效——即使节点被从树中移除，
     * 只要这个字段还引用着它，Java 的垃圾回收器就不会回收。
     */
    private final MindMapNode node;

    /**
     * 被删除节点的父节点。
     *
     * <p><b>为什么必须保存？</b>
     * 删除操作会切断 node 和 parent 之间的父子关系，之后无法再从 node
     * 找回 parent。所以必须在删除前（即构造器中）就把 parent 记录下来，
     * undo 时才能找到"应该把节点插回哪里"。</p>
     */
    private MindMapNode parent;

    /**
     * 被删除节点在父节点 children 列表中的位置索引。
     *
     * <p><b>为什么必须保存？</b>
     * 没有这个索引，undo() 时只能把节点追加到列表末尾，而无法恢复到原来的位置。
     * 用户期望"撤销删除"后节点应该回到原来的位置，而不是跑到最后面。</p>
     *
     * <p>索引从 0 开始。例如 parent 有 3 个子节点 A, B, C，
     * 要删除 B，则 index = 1。undo 时把 B 插回索引 1 的位置，
     * 列表恢复为 A, B, C。</p>
     */
    private int index;

    /**
     * 构造删除节点命令。
     *
     * <h3>为什么在构造器中"捕获"信息？</h3>
     * <p>这是命令模式中"预捕获"（pre-capture）模式的典型应用：
     * 在操作执行之前，先把恢复所需的关键信息全部记录下来。
     * 因为一旦 execute() 执行了删除，节点就脱离了树结构，
     * 届时再也无法获取 parent 和 index 信息。</p>
     *
     * <h3>indexOf 是怎么工作的？</h3>
     * <p>{@code parent.getChildren().indexOf(node)} 会遍历 parent 的 children 列表，
     * 逐个用 {@code equals()} 方法比较，找到匹配的节点后返回它的位置索引。
     * 如果列表中不存在该节点，返回 -1。</p>
     *
     * @param model 数据模型
     * @param node  要删除的节点（含其子树）
     */
    public DeleteNodeCommand(MindMapModel model, MindMapNode node) {
        this.model = model;
        this.node = node;
        // ★ 关键：在 execute 前捕获父节点和索引，以便 undo 时恢复
        this.parent = node.getParent();
        this.index = parent.getChildren().indexOf(node);
    }

    /**
     * 执行删除节点操作。
     *
     * <p>执行流程：</p>
     * <ol>
     *   <li>{@code model.deleteNode(node)} —— 调用 model 的删除方法。
     *       model 内部会调用 {@code node.removeFromParent()} 将节点从父节点
     *       的 children 列表中移除。注意删除的是整棵子树——node 下面的所有
     *       子节点、孙子节点都会跟着一起脱离树结构。</li>
     *   <li>{@code model.selectNode(parent)} —— 被删除的节点已经不在树中了，
     *       必须选中一个仍然存在的节点。选中父节点是最自然的选择：
     *       用户刚删除了一个节点，焦点移到它的"上一级"。</li>
     * </ol>
     */
    @Override
    public void execute() {
        model.deleteNode(node);
        model.selectNode(parent); // 删除后选中父节点
    }

    /**
     * 撤销删除操作，将节点恢复到删除前的状态。
     *
     * <p>撤销流程：</p>
     * <ol>
     *   <li>{@code parent.addChildAt(index, node)} —— 将之前被删除的节点
     *       （含其整棵子树）重新插入到原父节点的原位置（index）。
     *       因为整棵子树一直通过 {@code node} 字段被引用着，从未被 GC 回收，
     *       所以可以直接恢复。</li>
     *   <li>{@code model.selectNode(node)} —— 选中恢复后的节点，
     *       把用户的焦点带回到刚刚恢复的节点上。</li>
     * </ol>
     *
     * <p><b>注意：</b>addChildAt(index, node) 需要 node 当前不在任何父节点下。
     * 由于 delete 已经切断了父子关系，这个前提条件自然满足。</p>
     */
    @Override
    public void undo() {
        parent.addChildAt(index, node);
        model.selectNode(node);
    }

    /**
     * 返回操作的中文描述。
     * @return "删除节点"
     */
    @Override
    public String getDescription() { return "删除节点"; }
}
