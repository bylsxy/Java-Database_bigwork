package org.example.kidxmind.command;

/**
 * <h1>命令接口</h1>
 *
 * <h2>命令模式（Command Pattern）</h2>
 * <p>将"操作"封装成对象，好处：</p>
 * <ol>
 *   <li><b>撤回（Undo）</b>：每个 Command 知道如何撤销自己</li>
 *   <li><b>重做（Redo）</b>：重新调用 execute() 即可</li>
 *   <li><b>操作历史</b>：维护一个栈，按顺序记录所有操作</li>
 *   <li><b>操作描述</b>：可用于状态栏反馈（如"添加子节点"）</li>
 * </ol>
 *
 * <h2>用到的 Java 概念</h2>
 * <ul>
 *   <li><b>接口（interface）</b> —— 定义方法签名，不提供实现。所有 Command 类
 *       都要实现这三个方法。</li>
 *   <li><b>多态（Polymorphism）</b> —— MindMapController 只和 Command 接口打交道，
 *       不需要知道具体是哪个命令类。这叫做"面向接口编程"。</li>
 * </ul>
 *
 * <h2>怎么用</h2>
 * <pre>
 * // 执行新操作
 * Command cmd = new AddChildCommand(model, parent);
 * cmd.execute();           // 执行操作（修改 Model）
 * undoStack.push(cmd);     // 压入撤回栈
 * redoStack.clear();       // 清空重做栈
 *
 * // 撤回
 * Command last = undoStack.pop();
 * last.undo();             // 撤销操作
 * redoStack.push(last);    // 压入重做栈
 *
 * // 重做
 * Command redo = redoStack.pop();
 * redo.execute();          // 重新执行
 * undoStack.push(redo);    // 压入撤回栈
 * </pre>
 */
public interface Command {

    /** 执行操作（首次执行或重做时调用） */
    void execute();

    /** 撤销操作，恢复到 execute() 之前的状态 */
    void undo();

    /** 操作的中文描述（如"添加子节点""删除节点"），用于状态栏显示 */
    String getDescription();
}
