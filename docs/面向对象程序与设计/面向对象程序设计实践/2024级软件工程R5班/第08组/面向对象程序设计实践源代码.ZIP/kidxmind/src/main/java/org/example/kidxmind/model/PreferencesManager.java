package org.example.kidxmind.model;

import java.io.*;
import java.util.Properties;

/**
 * <h1>用户偏好管理</h1>
 *
 * <p>读写 ~/.mindmap_prefs 配置文件，记录上次打开的文件路径。
 * 这样下次启动时可以自动恢复上次编辑的文件。</p>
 *
 * <h2>用到的 Java 概念</h2>
 * <ul>
 *   <li><b>{@link java.util.Properties}</b> —— Java 内置的键值对配置文件读写工具。
 *       .store() 写入 .properties 文件，.load() 读取。格式为 key=value，一行一个。</li>
 *   <li><b>{@link System#getProperty(String)}</b> —— 读取 JVM 系统属性。
 *       user.home 是指当前用户的 home 目录（Windows 上是 C:\Users\用户名）。</li>
 *   <li><b>{@link File#separator}</b> —— 文件路径分隔符（Windows 是 \，Mac/Linux 是 /）。
 *       但其实用 File 构造器串联路径更好。</li>
 *   <li><b>static 方法</b> —— 这个类所有方法都是 static 的，因为它不需要保存任何状态。
 *       每次调用直接读写文件即可。</li>
 *   <li><b>try-with-resources</b> —— try(资源声明) { ... } catch { ... }，
 *       Reader/Writer 会在 try 块结束时自动调用 close()，不用手动关闭。</li>
 * </ul>
 *
 * <h2>文件内容示例</h2>
 * <pre>
 * #KidxMind Preferences
 * lastFile=C:\\Users\\Lenovo\\Documents\\项目规划.dt
 * </pre>
 */
public class PreferencesManager {

    /**
     * 配置文件路径：用户 home 目录下的 .mindmap_prefs 文件。
     * Windows 上通常是 C:\Users\Lenovo\.mindmap_prefs。
     */
    private static final File PREFS_FILE = new File(
        System.getProperty("user.home"), ".mindmap_prefs"
    );

    /**
     * 读取上次打开的文件路径。
     *
     * <p>三步走：
     * <ol>
     *   <li>检查配置文件是否存在（不存在 → null）</li>
     *   <li>读取 Properties 文件中的 lastFile 键</li>
     *   <li>验证该路径对应的文件是否真的存在且可读（文件可能已被删除或移动）</li>
     * </ol>
     *
     * @return 上次打开的文件绝对路径，如果不存在或文件已删除则返回 null
     */
    public static String getLastFile() {
        if (!PREFS_FILE.exists()) return null;

        // Properties.load() 从 Reader 读取 key=value 格式的配置
        Properties props = new Properties();
        try (Reader r = new InputStreamReader(new FileInputStream(PREFS_FILE), "UTF-8")) {
            props.load(r);
        } catch (IOException e) {
            return null; // 文件损坏或不可读
        }

        // getProperty 返回 key 对应的 value，如果 key 不存在返回 null
        String path = props.getProperty("lastFile");
        if (path == null || path.isEmpty()) return null;

        // 验证文件是否真的存在
        File f = new File(path);
        return f.exists() && f.isFile() ? path : null;
    }

    /**
     * 写入（或覆盖）lastFile 配置。
     *
     * <p>在以下时机调用：新建文件后、打开文件后、保存文件后。</p>
     *
     * @param path 文件的绝对路径
     */
    public static void setLastFile(String path) {
        Properties props = new Properties();
        props.setProperty("lastFile", path);

        // Properties.store() 将属性写入 Writer
        // 第二个参数是注释文本（写在文件第一行，以 # 开头）
        try (Writer w = new OutputStreamWriter(new FileOutputStream(PREFS_FILE), "UTF-8")) {
            props.store(w, "KidxMind Preferences");
        } catch (IOException ignored) {
            // 写入失败不影响主流程（只是下次启动无法自动恢复）
        }
    }
}
