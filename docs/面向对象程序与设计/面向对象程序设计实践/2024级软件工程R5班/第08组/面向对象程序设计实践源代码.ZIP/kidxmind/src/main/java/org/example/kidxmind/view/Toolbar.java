package org.example.kidxmind.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import org.example.kidxmind.controller.MindMapController;
import org.kordamp.ikonli.Ikon;
import org.kordamp.ikonli.javafx.FontIcon;
import org.kordamp.ikonli.materialdesign2.*;

/**
 * <h1>顶部工具栏</h1>
 *
 * <h2>JavaFX 相关概念</h2>
 * <ul>
 *   <li><b>{@link HBox}</b> —— 水平排列容器。继承自 Pane，用于水平排列子节点。</li>
 *   <li><b>{@link Button}</b> —— 按钮。setGraphic() 可以设置图标（不限于文字）。</li>
 *   <li><b>{@link Tooltip}</b> —— 鼠标悬停提示。setTooltip() 绑定到按钮上，
 *       鼠标悬停约 0.5 秒后自动弹出。</li>
 *   <li><b>{@link Separator}</b> —— 分隔线。setOrientation(VERTICAL) 表示竖线。</li>
 * </ul>
 *
 * <h2>Ikonli 图标库</h2>
 * <ul>
 *   <li><b>{@link FontIcon}</b> —— 字体图标。本质上是把图标字体中的某个字符渲染成图标。
 *       优点是矢量（任意缩放不失真），类似网页的 Font Awesome。</li>
 *   <li><b>{@link Ikon}</b> —— 图标接口。所有图标枚举（如 MaterialDesignF.FILE_PLUS）
 *       都实现了这个接口。</li>
 *   <li><b>Material Design 2</b> —— Google 的图标集，枚举按首字母分包：
 *       MaterialDesignF（F 开头）、MaterialDesignC（C 开头）等。</li>
 * </ul>
 *
 * <h2>按钮分组</h2>
 * <pre>
 * [标题] ...弹性空间... [文件操作] | [撤回/重做] | [编辑] | [剪贴板] | [布局] | [导出]
 * </pre>
 * 各组之间用竖向 Separator 分隔。
 */
public class Toolbar extends HBox {

    public Toolbar(MindMapController controller) {
        // ---- 容器基本设置 ----
        getStyleClass().add("toolbar");  // 绑定 CSS 类 .toolbar
        setPadding(new Insets(4, 8, 4, 8));
        setSpacing(2);
        setAlignment(Pos.CENTER_LEFT);   // 子节点垂直居中、水平靠左

        // ---- 左侧标题 ----
        Label titleLabel = new Label("KidxMind");
        titleLabel.getStyleClass().add("title-label");

        // ---- 弹性空间（把右侧按钮推到最右边）----
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // ---- 创建各图标按钮（每个按钮 = FontIcon 图标 + Tooltip 提示）----
        // MaterialDesignF.FILE_PLUS 等是 Ikonli 提供的枚举常量，
        // FontIcon.of(icon) 把图标转为 JavaFX Node，然后 setGraphic() 放到按钮上

        // 文件操作
        Button newBtn    = iconBtn(MaterialDesignF.FILE_PLUS,         "新建文件 (Ctrl+N)");
        Button openBtn   = iconBtn(MaterialDesignF.FOLDER_OPEN,       "打开文件 (Ctrl+O)");
        Button saveBtn   = iconBtn(MaterialDesignC.CONTENT_SAVE,      "保存文件 (Ctrl+S)");

        // 撤回/重做
        Button undoBtn   = iconBtn(MaterialDesignU.UNDO,              "撤销 (Ctrl+Z)");
        Button redoBtn   = iconBtn(MaterialDesignR.REDO,              "重做 (Ctrl+Y)");

        // 编辑操作
        Button addChild  = iconBtn(MaterialDesignP.PLUS_BOX,          "添加子节点 (Ctrl+A)");
        Button addSib    = iconBtn(MaterialDesignP.PLUS_BOX_MULTIPLE, "添加兄弟节点 (Ctrl+Shift+A)");
        Button deleteBtn = iconBtn(MaterialDesignD.DELETE,            "删除节点 (Ctrl+D)");

        // 剪贴板
        Button copyBtn   = iconBtn(MaterialDesignC.CONTENT_COPY,      "复制 (Ctrl+C)");
        Button cutBtn    = iconBtn(MaterialDesignC.CONTENT_CUT,       "剪切 (Ctrl+X)");
        Button pasteBtn  = iconBtn(MaterialDesignC.CONTENT_PASTE,     "粘贴 (Ctrl+V)");

        // 布局
        Button leftBtn   = iconBtn(MaterialDesignF.FORMAT_ALIGN_LEFT, "左侧布局");
        Button autoBtn   = iconBtn(MaterialDesignV.VIEW_AGENDA,       "自动布局");
        Button rightBtn  = iconBtn(MaterialDesignF.FORMAT_ALIGN_RIGHT,"右侧布局");

        // 导出
        Button exportBtn = iconBtn(MaterialDesignF.FILE_EXPORT,       "导出图片 (Ctrl+E)");

        // ---- 绑定事件：setOnAction 设置点击回调 ----
        newBtn.setOnAction(e -> controller.newFile());
        openBtn.setOnAction(e -> controller.openFile());
        saveBtn.setOnAction(e -> controller.saveFile());
        undoBtn.setOnAction(e -> controller.undo());
        redoBtn.setOnAction(e -> controller.redo());
        addChild.setOnAction(e -> controller.addChildNode());
        addSib.setOnAction(e -> controller.addSiblingNode());
        deleteBtn.setOnAction(e -> controller.deleteNode());
        copyBtn.setOnAction(e -> controller.copy());
        cutBtn.setOnAction(e -> controller.cut());
        pasteBtn.setOnAction(e -> controller.paste());
        leftBtn.setOnAction(e -> controller.setLeftLayout());
        autoBtn.setOnAction(e -> controller.setAutoLayout());
        rightBtn.setOnAction(e -> controller.setRightLayout());
        exportBtn.setOnAction(e -> controller.exportImage(exportBtn.getScene().getWindow()));
        // 注意：exportImage 需要父窗口（Stage）来显示文件对话框。
        // getScene().getWindow() 从按钮获取所属 Scene，再从 Scene 获取所属 Stage。

        // ---- 组装：按顺序从左到右排列 ----
        getChildren().addAll(
            titleLabel, spacer,
            newBtn, openBtn, saveBtn, sep(),
            undoBtn, redoBtn, sep(),
            addChild, addSib, deleteBtn, sep(),
            copyBtn, cutBtn, pasteBtn, sep(),
            leftBtn, autoBtn, rightBtn, sep(),
            exportBtn
        );
    }

    /**
     * 创建纯图标按钮（无文字），悬停时显示 Tooltip 提示。
     *
     * <p>{@link FontIcon#of(Ikon)} 根据图标枚举创建图标节点，
     * setGraphic() 把它设置到按钮上（Button 可以同时有 Text 和 Graphic，这里只设 Graphic）。</p>
     *
     * @param icon    Ikonli 图标枚举（实现了 Ikon 接口的常量）
     * @param tooltip 悬停提示文字
     */
    private Button iconBtn(Ikon icon, String tooltip) {
        Button btn = new Button();
        btn.setGraphic(FontIcon.of(icon));   // 设置图标（代替文字）
        btn.setTooltip(new Tooltip(tooltip)); // 设置悬停提示
        return btn;
    }

    /** 创建竖向分隔线 */
    private Separator sep() {
        Separator s = new Separator();
        s.setOrientation(javafx.geometry.Orientation.VERTICAL);
        return s;
    }
}
