package org.example.kidxmind.view;

import javafx.scene.control.TreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.layout.BorderPane;
import org.example.kidxmind.model.MindMapModel;
import org.example.kidxmind.model.MindMapNode;

import java.util.HashSet;
import java.util.Set;

/**
 * <h1>右侧结构展示区</h1>
 *
 * <p>用 JavaFX 的 TreeView 以树形结构展示思维导图的节点层次。</p>
 *
 * <h2>JavaFX 相关概念</h2>
 * <ul>
 *   <li><b>{@link TreeView}</b> —— 树形控件。类似文件资源管理器的左侧文件夹树。
 *       泛型参数 {@code <MindMapNode>} 表示每个树节点的数据值是 MindMapNode 对象。</li>
 *   <li><b>{@link TreeItem}</b> —— 树节点。每个 TreeItem 包含一个 value（数据）和
 *       一个 children 列表（子节点）。根 TreeItem 的 value 设为 null，通过
 *       setShowRoot(false) 隐藏根节点，只显示其子节点。</li>
 *   <li><b>{@link TreeCell}</b> —— 树节点的"单元格"（渲染单元）。setCellFactory
 *       自定义每个 TreeItem 如何渲染。这是一个"工厂模式"——TreeView 在需要显示
 *       某个 TreeItem 时，调用工厂创建对应的 TreeCell。</li>
 *   <li><b>{@code setFocusTraversable(false)}</b> —— 禁止控件通过 Tab 键获取焦点。
 *       这样方向键就不会被 TreeView 截获，转由 DrawingPane 处理导航。</li>
 *   <li><b>{@link BorderPane}</b> —— 本类继承 BorderPane，TreeView 放在中心区域。</li>
 * </ul>
 *
 * <h2>展开状态保持机制</h2>
 * <p>当模型发生变化（增删节点、编辑文本等），需要调用 refresh() 重建树。
 * 普通重建会导致所有已展开的节点被折叠。本类通过以下步骤保持展开状态：</p>
 * <ol>
 *   <li>遍历旧树，收集所有已展开 TreeItem 对应的节点 ID → {@code Set<String>}</li>
 *   <li>清空旧树，从 Model 重新构建完整树</li>
 *   <li>遍历新树，检查每个节点的 ID 是否在 Set 中，如果是则展开</li>
 * </ol>
 *
 * <h2>为什么 TreeView 的泛型是 {@code <MindMapNode>} 而不是 {@code <String>}？</h2>
 * <p>最初 TreeView 的泛型是 String（每个 TreeItem 存一段格式化后的文字）。
 * 但这样做有个问题：刷新时无法精确匹配新旧树节点——因为格式化后的文字可能重复。
 * 改为 {@code <MindMapNode>} 后，每个 TreeItem 带有完整的节点对象（包含唯一 ID），
 * 可以精确匹配展开状态。</p>
 */
public class StructureTreeView extends BorderPane {

    /** 节点文本显示的最大长度，超出部分用 ... 截断 */
    private static final int MAX_TEXT_LENGTH = 20;

    /**
     * JavaFX 树形控件。
     * 泛型 {@code <MindMapNode>} 表示每个树项的值类型。
     */
    private final TreeView<MindMapNode> treeView;

    /**
     * 虚拟根节点（不显示）。
     * setShowRoot(false) 隐藏它，只显示 model.getRoot() 作为第一层子节点。
     */
    private final TreeItem<MindMapNode> rootItem;

    /** 数据模型，读取节点树结构 */
    private final MindMapModel model;

    public StructureTreeView(MindMapModel model) {
        this.model = model;

        // 创建 TreeView（泛型自动推断）
        treeView = new TreeView<>();

        // 创建虚拟根（value=null，不显示），model 的根节点作为其子节点
        rootItem = new TreeItem<>(null);
        treeView.setRoot(rootItem);
        treeView.setShowRoot(false);

        // 不可获取键盘焦点——方向键由 DrawingPane 处理节点导航
        treeView.setFocusTraversable(false);

        /*
         * 鼠标点击时清除 TreeView 的选中状态。
         * 为什么？因为 TreeView 点击后会选中相应的行（蓝色高亮），
         * 但这个选中状态没有意义——我们的"选中"是由 MindMapModel.selectedNode 管理的。
         * 不清除会导致视觉上的混乱（TreeView 看似选中了某个节点，但实际不是）。
         *
         * 使用 addEventFilter（捕获阶段）确保在 TreeView 自己的处理器之前清除选中。
         * 注意：不消费事件（不调用 e.consume()），所以展开/收起箭头仍然正常工作。
         */
        treeView.addEventFilter(javafx.scene.input.MouseEvent.MOUSE_PRESSED, e -> {
            treeView.getSelectionModel().clearSelection();
        });

        /*
         * setCellFactory —— 自定义每个 TreeCell 的渲染方式。
         * 参数 tv -> new TreeCell<>() { ... } 是一个 lambda，返回自定义的 TreeCell。
         *
         * TreeCell 是 JavaFX 的"单元格"，它的 updateItem() 方法在内容变化时被调用。
         * 这类似于 Swing 中 JTree 的 TreeCellRenderer。
         */
        treeView.setCellFactory(tv -> new TreeCell<MindMapNode>() {
            @Override
            protected void updateItem(MindMapNode node, boolean empty) {
                // super.updateItem() 必须调用，它会处理基本的单元格状态
                super.updateItem(node, empty);

                if (empty || node == null) {
                    // 空单元格不显示任何内容
                    setText(null);
                    setGraphic(null);
                } else {
                    // 格式化节点文本
                    String text = node.getText().isEmpty() ? "(空)" : node.getText();
                    String displayText = truncateText(text);
                    // 叶子节点前加 • 标记，父节点前只留缩进空格
                    String prefix = node.isLeaf() ? "  • " : "  ";
                    setText(prefix + displayText);
                }
            }
        });

        setCenter(treeView);
        setPrefWidth(250); // 初始宽度 250px
        refresh(); // 首次加载树
    }

    /**
     * 刷新整棵树，保留已有的展开状态。
     * <p>当 Model 发生结构性变化（增删节点、编辑文本等）时由 Controller 调用。</p>
     */
    public void refresh() {
        // 第 1 步：收集当前所有已展开项的节点 ID
        Set<String> expandedIds = new HashSet<>();
        collectExpanded(rootItem, expandedIds);

        // 第 2 步：清空并重建整棵树
        rootItem.getChildren().clear();
        TreeItem<MindMapNode> rootTI = createTreeItem(model.getRoot());
        rootItem.getChildren().add(rootTI);

        // 第 3 步：恢复展开状态（按节点 ID 匹配）
        restoreExpanded(rootTI, expandedIds);
        rootTI.setExpanded(true); // 根节点始终展开
    }

    /**
     * 递归收集所有已展开 TreeItem 对应的节点 ID。
     * <p>遍历整棵现有树，如果某个 TreeItem 处于展开状态，
     * 就把它对应的 MindMapNode 的 ID 存入 Set。</p>
     */
    private void collectExpanded(TreeItem<MindMapNode> item, Set<String> ids) {
        if (item.getValue() != null && item.isExpanded()) {
            ids.add(item.getValue().getId());
        }
        for (TreeItem<MindMapNode> child : item.getChildren()) {
            collectExpanded(child, ids);
        }
    }

    /**
     * 递归恢复展开状态。
     * <p>遍历新树，如果某个 TreeItem 的节点 ID 在 expandedIds 集合中，
     * 就将其展开。</p>
     */
    private void restoreExpanded(TreeItem<MindMapNode> item, Set<String> ids) {
        MindMapNode node = item.getValue();
        if (node != null && ids.contains(node.getId())) {
            item.setExpanded(true);
        }
        for (TreeItem<MindMapNode> child : item.getChildren()) {
            restoreExpanded(child, ids);
        }
    }

    /**
     * 递归从 MindMapNode 树构建 TreeItem 树。
     * <p>这是"深度优先"的递归构建——先构建当前节点，再递归构建所有子节点。</p>
     *
     * @param node 模型中的节点
     * @return 对应的 TreeItem（value=node，children=递归构建的子项）
     */
    private TreeItem<MindMapNode> createTreeItem(MindMapNode node) {
        TreeItem<MindMapNode> item = new TreeItem<>(node);
        for (MindMapNode child : node.getChildren()) {
            item.getChildren().add(createTreeItem(child));
        }
        return item;
    }

    /**
     * 截断过长文本，超过 MAX_TEXT_LENGTH 的部分用 "..." 替代。
     * <p>例如 "一个非常非常长的节点名称" → "一个非常非常长的节点名..."</p>
     */
    private static String truncateText(String text) {
        if (text.isEmpty()) return "(空)";
        if (text.length() > MAX_TEXT_LENGTH) {
            return text.substring(0, MAX_TEXT_LENGTH) + "...";
        }
        return text;
    }
}
