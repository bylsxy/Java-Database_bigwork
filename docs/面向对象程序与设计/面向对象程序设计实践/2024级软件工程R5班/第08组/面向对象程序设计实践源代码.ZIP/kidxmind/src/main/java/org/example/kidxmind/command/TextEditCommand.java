package org.example.kidxmind.command;

import org.example.kidxmind.model.MindMapNode;

/**
 * <h1>文本编辑命令</h1>
 *
 * <h2>这个命令做了什么</h2>
 * <p>修改思维导图节点的文本内容。这是最"经典"的命令模式示例——
 * 保存旧值和新值，execute 设新值，undo 恢复旧值。</p>
 *
 * <h2>execute() 做什么</h2>
 * <p>将节点的文本设置为新文本（newText）。</p>
 *
 * <h2>undo() 做什么</h2>
 * <p>将节点的文本恢复为旧文本（oldText）。</p>
 *
 * <h2>为什么这个命令不需要 model？</h2>
 * <p>与其他命令不同，TextEditCommand 不依赖 MindMapModel。
 * 它只修改单个节点的文本属性，不需要通过 model 来操作。
 * 这体现了"最小依赖原则"——如果某个命令不需要 model，
 * 就不应该传入 model。</p>
 *
 * <p>注意：命令执行后，调用方（controller）需要自行触发界面刷新，
 * 因为节点的文本变了，Canvas 上的显示也需要更新。</p>
 *
 * <h2>用到的 Java 概念</h2>
 * <ul>
 *   <li><b>不可变对象（Immutable）</b> —— {@code oldText} 和 {@code newText} 都是
 *       {@code String} 类型，而 Java 的 String 是不可变的。一旦创建，内容就不能修改。
 *       所以构造器中保存的字符串引用永远指向原始值，不会意外被改动。</li>
 *   <li><b>简单命令模式</b> —— 这是命令模式最基础的形式：只保存"旧状态"和"新状态"，
 *       execute 切换到新状态，undo 切换回旧状态。适合状态切换类的操作。</li>
 * </ul>
 */
public class TextEditCommand implements Command {

    /**
     * 被修改文本的节点引用。
     * 注意：保存的是引用（内存地址），不是节点的副本。
     * 所以直接调用 node.setText() 就能修改原节点。
     */
    private final MindMapNode node;

    /**
     * 修改前的文本内容。
     * undo() 时需要用这个值来恢复节点的文本。
     *
     * <p>使用 String 类型（不可变）确保这个值不会被意外修改。
     * 即使外部代码改变了原来的字符串变量，这里的 oldText 也不会变。</p>
     */
    private final String oldText;

    /**
     * 修改后的文本内容。
     * execute() 时把这个值设入节点。
     */
    private final String newText;

    /**
     * 构造文本编辑命令。
     *
     * <h3>为什么 oldText 和 newText 都由调用方传入？</h3>
     * <p>命令本身不负责"获取"旧文本——它只知道"从旧文本改到新文本"。
     * 旧文本由调用方（通常是 controller）在构造命令前从节点读取，
     * 新文本是用户在编辑器中输入的内容。这种设计让命令职责单一：
     * 只管执行和撤销，不管数据来源。</p>
     *
     * @param node    要修改文本的节点
     * @param oldText 修改前的文本（从节点读取）
     * @param newText 修改后的文本（用户输入的新内容）
     */
    public TextEditCommand(MindMapNode node, String oldText, String newText) {
        this.node = node;
        this.oldText = oldText;
        this.newText = newText;
    }

    /**
     * 执行文本修改：将节点的文本设置为新文本。
     *
     * <p>{@code node.setText(newText)} 会修改节点内部的 text 字段值。
     * 这个操作不会改变树结构，只改变节点的显示内容。</p>
     */
    @Override
    public void execute() {
        node.setText(newText);
    }

    /**
     * 撤销文本修改：将节点的文本恢复为旧文本。
     *
     * <p>{@code node.setText(oldText)} 把文本改回修改前的值。
     * 因为 String 是不可变的，保存的 oldText 引用始终指向原始字符串。</p>
     */
    @Override
    public void undo() {
        node.setText(oldText);
    }

    /**
     * 返回操作的中文描述。
     * @return "编辑文本"
     */
    @Override
    public String getDescription() { return "编辑文本"; }
}
