package org.example.kidxmind.view;

import javafx.animation.PauseTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.util.Duration;

/**
 * <h1>底部状态栏</h1>
 *
 * <h2>JavaFX 相关概念</h2>
 * <ul>
 *   <li><b>{@link HBox}</b> —— 水平排列容器。子节点从左到右排列。</li>
 *   <li><b>{@link Label}</b> —— 文本标签。用于显示不可编辑的文本。</li>
 *   <li><b>{@link Region}</b> —— 不可见的占位元素。配合 setHgrow 实现弹性空间。</li>
 *   <li><b>{@link HBox#setHgrow}</b> —— 设置子节点的水平增长优先级。
 *       Priority.ALWAYS 表示该子节点会占据所有剩余水平空间。</li>
 *   <li><b>{@link Priority}</b> —— 枚举：NEVER（不增长）、ALWAYS（总是增长）、SOMETIMES。</li>
 *   <li><b>{@link PauseTransition}</b> —— 暂停过渡动画。在指定的 Duration 后触发回调。
 *       用于实现"显示 N 秒后自动消失"的效果。</li>
 * </ul>
 *
 * <h2>显示格式</h2>
 * <pre>
 * [文件路径] [操作描述] ......弹性空间...... 节点总数: N | 选中: M ●
 * </pre>
 * 脏标记 ● 仅在未保存时显示。
 */
public class StatusBar extends HBox {

    private final Label pathLabel;   // 左侧：文件路径
    private final Label opLabel;     // 路径后：最近操作描述
    private final Label infoLabel;   // 右侧：节点总数 + 选中数
    private final Label dirtyLabel;  // 最右侧：脏标记●

    // 保存当前的显示文本，供临时消息恢复用
    private String savedPathText = "";
    private String savedInfoText = "";
    private String savedDirtyText = "";

    public StatusBar() {
        /*
         * getStyleClass().add("status-bar") 给组件添加一个 CSS 类名。
         * CSS 文件中用 .status-bar 选择器为其设置样式（背景色、边框、字体等）。
         * 这是 JavaFX 推荐的样式管理方式——CSS 与 Java 代码分离。
         */
        getStyleClass().add("status-bar");

        // Insets：内边距。参数顺序 上, 右, 下, 左
        setPadding(new Insets(3, 10, 3, 10));

        // setMinHeight 和 setPrefHeight 确保状态栏在布局中至少 26px 高
        // BorderPane/AnchorPane 会读取 prefHeight 来决定底部区域的大小
        setMinHeight(26);
        setPrefHeight(26);

        setAlignment(Pos.CENTER_LEFT);   // 子节点垂直居中、水平靠左
        setSpacing(6);                   // 子节点之间的间距 6px

        // 创建各标签（初始文本为空或默认值）
        pathLabel = new Label("未打开文件");
        opLabel = new Label("");         // 操作描述初始为空

        // Region 是一个不可见的矩形区域。配合 setHgrow 它会把左右内容"挤"到两端
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        infoLabel = new Label("节点总数: 0 | 选中: 0");

        // 脏标记样式使用独立的 CSS 类
        dirtyLabel = new Label("");
        dirtyLabel.getStyleClass().add("dirty-indicator");

        /*
         * getChildren().addAll() 按顺序从左到右添加子节点：
         * [路径] [操作] ....spacer(弹性空间).... [节点总数 | 选中] [●]
         */
        getChildren().addAll(pathLabel, opLabel, spacer, infoLabel, dirtyLabel);
    }

    /**
     * 更新状态栏全部内容（数据变更时由 Controller 调用）。
     *
     * @param filePath   文件路径，null 时显示"未保存"
     * @param totalNodes 节点总数（递归统计整棵树）
     * @param selCount   选中节点数，目前只有 0 或 1（单选模式）
     * @param dirty      脏标记，true 时显示 ●
     */
    public void update(String filePath, int totalNodes, int selCount, boolean dirty) {
        savedPathText = filePath != null ? filePath : "未保存";
        savedInfoText = "节点总数: " + totalNodes + " | 选中: " + selCount;
        savedDirtyText = dirty ? " ●" : "";
        pathLabel.setText(savedPathText);
        infoLabel.setText(savedInfoText);
        dirtyLabel.setText(savedDirtyText);
    }

    /**
     * 显示最近操作描述（如"添加子节点"）。
     * 持续显示，直到下次操作覆盖（不会自动消失）。
     */
    public void showOperation(String desc) {
        opLabel.setText(" — " + desc);
    }

    /**
     * 显示临时消息，millis 毫秒后自动恢复原样。
     * 用于"已保存"等瞬态反馈。
     *
     * @param msg    要显示的消息
     * @param millis 显示时长（毫秒）
     */
    public void showTemp(String msg, int millis) {
        // 先用临时消息替换三个标签的内容
        pathLabel.setText(msg);
        infoLabel.setText("");
        dirtyLabel.setText("");

        // PauseTransition：暂停 millis 毫秒，然后执行 setOnFinished 中的回调
        PauseTransition pause = new PauseTransition(Duration.millis(millis));
        pause.setOnFinished(e -> {
            // 恢复为保存的原始内容
            pathLabel.setText(savedPathText);
            infoLabel.setText(savedInfoText);
            dirtyLabel.setText(savedDirtyText);
        });
        pause.play(); // 启动！（PauseTransition 默认不自动播放）
    }
}
