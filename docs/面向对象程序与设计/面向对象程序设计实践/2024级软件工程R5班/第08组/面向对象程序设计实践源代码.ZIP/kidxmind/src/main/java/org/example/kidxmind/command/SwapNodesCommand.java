package org.example.kidxmind.command;

import org.example.kidxmind.model.MindMapModel;
import org.example.kidxmind.model.MindMapNode;

/**
 * <h1>节点交换命令</h1>
 *
 * <h2>这个命令做了什么</h2>
 * <p>交换思维导图树中两个节点的位置。支持两种情况：</p>
 * <ul>
 *   <li><b>同父节点交换</b>：两个节点有同一个父节点，直接交换它们在 children 列表中的位置</li>
 *   <li><b>跨父节点交换</b>：两个节点属于不同的父节点，需要各自脱离原父节点再挂到对方的位置</li>
 * </ul>
 *
 * <h2>为什么 execute 和 undo 是同一个操作？</h2>
 * <p>交换操作是<b>对称的</b>（symmetric / self-inverse）：</p>
 * <ul>
 *   <li>execute()：交换 A 和 B 的位置（交换后 B 在前，A 在后）</li>
 *   <li>undo()：再次交换 B 和 A（又变回 A 在前，B 在后）</li>
 * </ul>
 * <p>数学上这叫做"对合"（involution），即 f(f(x)) = x。执行两次就回到原始状态。
 * 因此 execute 和 undo 调用同一个 doSwap() 方法，只是之后选中的节点不同。</p>
 *
 * <h2>execute() 做什么</h2>
 * <ol>
 *   <li>调用 doSwap() 交换 A 和 B 的位置</li>
 *   <li>选中 B（因为 B 被换到了 A 原来的位置，用户焦点跟随 B）</li>
 * </ol>
 *
 * <h2>undo() 做什么</h2>
 * <ol>
 *   <li>再次调用 doSwap() 交换 B 和 A（恢复原位）</li>
 *   <li>选中 A（恢复原来的选中节点）</li>
 * </ol>
 *
 * <h2>同父节点 vs 跨父节点交换的区别</h2>
 *
 * <h3>同父节点交换</h3>
 * <pre>
 * 交换前: parent -> [A, B, C]
 * 交换后: parent -> [B, A, C]   （直接 set 两个位置）
 * </pre>
 * <p>因为 A 和 B 在同一个 children 列表中，直接交换列表元素即可。</p>
 *
 * <h3>跨父节点交换</h3>
 * <pre>
 * 交换前: parent1 -> [A, X]    parent2 -> [B, Y]
 * 交换后: parent1 -> [B, X]    parent2 -> [A, Y]
 * </pre>
 * <p>需要进行四步操作：A 脱离 parent1，B 脱离 parent2，B 加入 parent1，A 加入 parent2。
 * 顺序很重要——必须先记录索引，再执行脱离，最后加入。</p>
 *
 * <h2>用到的 Java 概念</h2>
 * <ul>
 *   <li><b>List.set(index, element)</b> —— 替换列表中指定位置的元素，返回被替换的旧元素。
 *       同父交换用这个方法高效地交换两个位置。</li>
 *   <li><b>对称操作（Self-inverse）</b> —— 是一种特殊的 undo 实现方式。
 *       不是"执行反向操作"，而是"同一个操作再执行一次就是反向"。</li>
 *   <li><b>引用保存</b> —— 先保存 A 和 B 的父节点引用和索引，避免在脱离/加入
 *       操作中丢失位置信息。</li>
 * </ul>
 */
public class SwapNodesCommand implements Command {

    /** 数据模型 */
    private final MindMapModel model;

    /**
     * 参与交换的第一个节点。
     * 在 execute() 中 A 会被换到 B 原来的位置。
     */
    private final MindMapNode a;

    /**
     * 参与交换的第二个节点。
     * 在 execute() 中 B 会被换到 A 原来的位置。
     */
    private final MindMapNode b;

    /**
     * 构造节点交换命令。
     *
     * <p><b>注意：</b>构造器中不需要预捕获 parent 和 index，
     * 因为交换操作在 doSwap() 中自行管理这些信息——它先记录索引再操作，
     * 而不是依赖构造器中保存的快照。</p>
     *
     * @param model 数据模型
     * @param a     第一个节点
     * @param b     第二个节点
     */
    public SwapNodesCommand(MindMapModel model, MindMapNode a, MindMapNode b) {
        this.model = model;
        this.a = a;
        this.b = b;
    }

    /**
     * 执行交换操作（A 和 B 互换位置）。
     */
    @Override
    public void execute() {
        doSwap();
        model.selectNode(b); // 焦点跟随被换过来的 B
    }

    /**
     * 撤销交换操作（B 和 A 再换一次恢复原位）。
     *
     * <p>因为交换是对称操作，undo 直接再次调用 doSwap() 即可。
     * 撤销后选中原先的节点 A。</p>
     */
    @Override
    public void undo() {
        // 对称操作：把 b 和 a 再交换一次就恢复原位
        doSwap();
        model.selectNode(a);
    }

    /**
     * 执行实际的交换逻辑。
     *
     * <h3>同父节点情况</h3>
     * <p>A 和 B 在同一个 children 列表中，直接用 {@code List.set()} 交换：</p>
     * <ol>
     *   <li>获取父子列表</li>
     *   <li>找到 A 的索引 idxA，B 的索引 idxB</li>
     *   <li>在 idxA 位置放入 B，在 idxB 位置放入 A</li>
     * </ol>
     *
     * <h3>跨父节点情况</h3>
     * <p>A 和 B 在不同父节点下，需要分四步走：</p>
     * <ol>
     *   <li>记录 idxA = A 在 parentA 中的位置，idxB = B 在 parentB 中的位置</li>
     *   <li>A.removeFromParent() —— 把 A 从 parentA 脱离（此时 parentA 的列表缩小，
     *       但 idxB 不受影响，因为 A 和 B 在不同的列表中）</li>
     *   <li>B.removeFromParent() —— 把 B 从 parentB 脱离</li>
     *   <li>parentA.addChildAt(idxA, B) —— 把 B 插入到 A 原来的位置</li>
     *   <li>parentB.addChildAt(idxB, A) —— 把 A 插入到 B 原来的位置</li>
     * </ol>
     *
     * <p><b>为什么先记录索引再执行脱离？</b>
     * 因为一旦执行了 {@code removeFromParent()}，节点就不再属于
     * 原来的 children 列表，无法再通过 {@code indexOf()} 查位置了。</p>
     */
    private void doSwap() {
        MindMapNode parentA = a.getParent();
        MindMapNode parentB = b.getParent();

        if (parentA == parentB) {
            // 同父节点：直接交换 children 列表中的两个位置
            java.util.List<MindMapNode> children = parentA.getChildren();
            int idxA = children.indexOf(a);
            int idxB = children.indexOf(b);
            children.set(idxA, b);
            children.set(idxB, a);
        } else {
            // 跨父节点：先记录索引，再脱离，最后重新挂载
            int idxA = parentA.getChildren().indexOf(a);
            int idxB = parentB.getChildren().indexOf(b);
            a.removeFromParent();
            b.removeFromParent();
            parentA.addChildAt(idxA, b);
            parentB.addChildAt(idxB, a);
        }
    }

    /**
     * 返回操作的中文描述。
     * @return "交换节点"
     */
    @Override
    public String getDescription() { return "交换节点"; }
}
