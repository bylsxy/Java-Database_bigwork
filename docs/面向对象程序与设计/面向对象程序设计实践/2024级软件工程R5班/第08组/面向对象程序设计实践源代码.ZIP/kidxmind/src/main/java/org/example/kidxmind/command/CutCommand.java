package org.example.kidxmind.command;

import org.example.kidxmind.model.MindMapModel;
import org.example.kidxmind.model.MindMapNode;

/**
 * <h1>剪切节点命令</h1>
 *
 * <h2>这个命令做了什么</h2>
 * <p>将选中的节点深拷贝到剪贴板并标记为"剪切模式"。注意：剪切操作本身<b>不删除</b>节点，
 * 删除操作延迟到粘贴（PasteCommand）时才执行。这个设计是为了支持"剪切后不粘贴
 * 也能撤销"的场景。</p>
 *
 * <h2>execute() 做什么</h2>
 * <ol>
 *   <li>将选中节点深拷贝（deep copy）到 model 的剪贴板中</li>
 *   <li>将剪贴板标记为"剪切模式"（而非"复制模式"）</li>
 *   <li>设置剪切源节点引用（cutSourceNode），供粘贴时删除源节点用</li>
 * </ol>
 *
 * <h2>undo() 做什么</h2>
 * <p>恢复剪切前的剪贴板状态：</p>
 * <ol>
 *   <li>将剪贴板内容恢复为剪切之前的内容</li>
 *   <li>将剪贴板的剪切/复制标记恢复为旧值</li>
 *   <li>将 cutSourceNode 恢复为旧值</li>
 *   <li>选中回之前被剪切的节点</li>
 * </ol>
 *
 * <h2>为什么不对称（execute 不删除，undo 要恢复剪贴板）？</h2>
 * <p>这是本项目的特殊设计。通常的剪切操作会立即删除节点，但这里采用了
 * "标记剪切模式 + 粘贴时删除"的方案。undo 时只需要恢复剪贴板状态，
 * 因为节点还完好地在树中。</p>
 *
 * <h2>用到的 Java 概念</h2>
 * <ul>
 *   <li><b>深拷贝（Deep Copy）</b> —— 拷贝整个节点及其子树，新旧对象互相独立。
 *       修改拷贝不会影响原节点。Java 中通常通过手动递归复制实现。</li>
 *   <li><b>状态保存</b> —— 剪切前的剪贴板可能不为空（用户之前可能复制/剪切过
 *       其他内容），undo 时必须能精确恢复那段旧状态。所以要在构造器中保存
 *       oldClipboard、oldClipboardCut、oldCutSourceNode 三个值。</li>
 * </ul>
 */
public class CutCommand implements Command {

    /** 数据模型 */
    private final MindMapModel model;

    /** 被剪切的节点（不会被删除，只是被"标记"为剪切源） */
    private final MindMapNode cutNode;

    // ========== 剪切前的剪贴板状态（undo 时用来恢复） ==========

    /**
     * 剪切前剪贴板中保存的节点副本。
     * 可能为 null（如果剪切前剪贴板为空）。
     * undo() 时需要把这个旧值写回 model 的剪贴板。
     */
    private final MindMapNode oldClipboard;

    /**
     * 剪切前剪贴板的剪切/复制标记。
     * true = 剪切模式，false = 复制模式。
     * 这个标记会影响 PasteCommand 的行为（是否删除源节点）。
     */
    private final boolean oldClipboardCut;

    /**
     * 剪切前 model 中记录的剪切源节点引用。
     * 可能为 null（如果之前是复制模式或者剪贴板为空）。
     */
    private final MindMapNode oldCutSourceNode;

    /**
     * 构造剪切命令。
     *
     * <h3>为什么要在构造器中保存"旧剪贴板状态"？</h3>
     * <p>命令模式的 undo 要求把状态<b>完全</b>恢复到执行前。
     * 如果用户在剪切之前剪贴板里已经有内容（比如之前复制了一个节点），
     * 那么 undo 剪切时应该把那段旧内容恢复出来，而不是清空剪贴板。</p>
     *
     * <p>类比：就像你替换桌面壁纸前先记住旧壁纸是什么，这样如果觉得
     * 新壁纸不好看，还能换回去。</p>
     *
     * @param model   数据模型
     * @param cutNode 被剪切的节点
     */
    public CutCommand(MindMapModel model, MindMapNode cutNode) {
        this.model = model;
        this.cutNode = cutNode;
        // 保存剪切前的剪贴板完整快照
        this.oldClipboard = model.getClipboard();
        this.oldClipboardCut = model.isClipboardCut();
        this.oldCutSourceNode = model.getCutSourceNode();
    }

    /**
     * 执行剪切操作。
     *
     * <p>调用 {@code model.cutSelected()}，内部会做：</p>
     * <ol>
     *   <li>深拷贝 cutNode（含整棵子树）存入剪贴板</li>
     *   <li>设置剪贴板为"剪切模式"（clipboardCut = true）</li>
     *   <li>记录 cutSourceNode = cutNode（这样粘贴时才知道要删除谁）</li>
     * </ol>
     *
     * <p>注意：节点<b>不会</b>在剪切时被删除，它仍然在原来的树中。
     * 删除会在粘贴命令的 execute() 中完成。</p>
     */
    @Override
    public void execute() {
        model.cutSelected();
    }

    /**
     * 撤销剪切操作，恢复剪贴板到剪切前的状态。
     *
     * <p>撤销流程：</p>
     * <ol>
     *   <li>{@code model.restoreClipboard(oldClipboard, oldClipboardCut, oldCutSourceNode)}
     *       —— 把剪贴板的三个属性全部恢复为剪切前的值</li>
     *   <li>{@code model.selectNode(cutNode)} —— 选中回被剪切的节点
     *       （虽然它从未被取消选中，但为了一致性还是显式设置）</li>
     * </ol>
     *
     * <p>注意：节点没有被删除过，所以不需要恢复节点本身，只需恢复剪贴板。</p>
     */
    @Override
    public void undo() {
        model.restoreClipboard(oldClipboard, oldClipboardCut, oldCutSourceNode);
        model.selectNode(cutNode);
    }

    /**
     * 返回操作的中文描述。
     * @return "剪切节点"
     */
    @Override
    public String getDescription() { return "剪切节点"; }
}
