# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 项目概述

KidxMind 是一个基于 JavaFX 17 的思维导图绘制工具，采用 MVC 架构。IntelliJ IDEA 浅色主题风格，Material Design 2 图标，用JDK 17 编译。

## 构建与运行

```bash
mvn compile                          # 编译
mvn javafx:run                       # 开发运行
mvn clean package -DskipTests        # 打包 JAR（含 lib 依赖目录）
```

打包后目录结构：
```
target/
├── kidxmind-1.0-SNAPSHOT.jar        # 应用 JAR
└── lib/                             # 所有依赖（JavaFX, Ikonli, Gson）
```

 `dist/run.bat` 启动（使用 `%~dp0` 自定位路径，可移动到任意目录）。

JDK 17，JavaFX 17.0.13 通过 Maven 依赖引入，无需额外安装 JavaFX SDK。

## 架构

```
command/        命令模式：Command 接口 + 9 个操作命令（撤回/重做）
model/          MindMapNode (树节点 + 几何坐标), MindMapModel (选中/剪贴板/布局模式/脏标记),
                FileManager (.dt JSON 读写), PreferencesManager (用户偏好 ~/.mindmap_prefs)
view/           DrawingPane (Canvas 绘制 + 交互), StructureTreeView (结构树),
                Toolbar (IDEA 风格图标按钮), StatusBar (底部状态栏), WelcomeView (启动页)
controller/     MindMapController (所有业务操作入口，命令历史管理)
MainApp.java    Application 入口，启动流程、键盘快捷键
```

**数据流**：用户操作 → Controller 创建 Command → executeCommand() → cmd.execute() → Model 变更 → refreshAll() → DrawingPane.redraw() + StructureTreeView.refresh() + StatusBar.update()

## 关键设计决策

### 命令模式（撤回/重做）

`MindMapController` 维护 `undoStack` / `redoStack`，所有数据变更通过 `executeCommand(Command)` 统一入口。每个 Command 实现 `execute()` / `undo()` / `getDescription()`。Ctrl+Z 撤回，Ctrl+Y 重做。`getDescription()` 用于状态栏操作反馈。

### 文件持久化（.dt 格式）

扩展名 `.dt`，UTF-8 JSON 格式，Gson 序列化。含 `version`, `layout`, `nodes` 递归结构（id, text, x, y, width, height, userWidth, children）。容错：坐标/尺寸缺失补默认值。

- **新建**：即保存（弹出保存对话框创建 .dt 后立即进入编辑）
- **保存**：覆盖写入当前路径，不弹框
- **打开**：解析 JSON 重建节点树

### 脏标记与状态栏

`MindMapModel.dirty` 标记未保存修改。`executeCommand()` / `undo()` / `redo()` 自动标记脏。保存/新建/打开后清除。

状态栏格式：`[路径] — 操作描述 | 节点总数: N | 选中: 0/1 ●`，操作描述持续显示至下次操作。

### 节点尺寸（XMind 风格）

`DrawingPane.calcNodeSize()` 固定宽度 `NODE_WIDTH=120`，高度随文本换行自适应。用户可拖拽节点边框调整宽度（`userWidth`），最小为 `NODE_WIDTH`。节点内边距由 `NODE_PADDING_X/Y` 控制。

### 三种布局算法

全部在 `DrawingPane` 中递归计算：

- **LEFT/RIGHT**：所有子节点统一放某一侧，从上到下按原顺序排列
- **AUTO**：遍历所有分割点 k，选使左右两侧总高度最接近的 k。前 k 个子节点放左侧，剩余放右侧。**保持子节点原有顺序不变**

`calcSubtreeHeight()` 递归计算子树总高度（含兄弟间 `V_GAP`），是布局平衡的基础。

### Canvas 绘制与变换

- 逻辑坐标系统：中心节点在 `(0, 0)`，子节点通过 `layoutSubtree()` 递归分配坐标
- 屏幕变换：`gc.translate(cx,cy)` → `gc.scale(scale,scale)` → `gc.translate(translateX,translateY)`
- 命中测试：绘制时将每个节点的屏幕坐标存入 `nodeScreenBounds` Map，点击时遍历查找
- 缩放以鼠标位置为中心：调整 `translateX/Y` 使缩放前后鼠标下的模型坐标不变
- 所有绘制方法接受 `GraphicsContext` + `drawScale` 参数，导出时复用同一套绘制逻辑渲染到临时 Canvas

### 文本编辑

双击节点或 F2 → 在 Canvas 上方叠加 `TextArea`（`setManaged(false)` 避免 StackPane 自动布局干扰），输入实时触发布局重算和编辑器重新定位。Enter 提交编辑，Esc/失焦也提交。空文本时节点仍显示矩形。

### 克隆与复制

深拷贝：递归复制节点及其所有子节点，不复制 parent 引用。

### 剪切/粘贴

`MindMapModel` 保存剪切源节点引用 `cutSourceNode`，粘贴时先插入副本再删除源节点（需求要求在粘贴后删除）。

### 方向键导航（↑↓←→）

- **↑↓**：在兄弟节点间循环移动（到边界时回绕）
- **←→**：左侧节点左=深入子节点、右=回退父节点；右侧节点相反
- **根节点**：←移到左侧第一个子节点，→移到右侧第一个子节点
- 使用 `addEventFilter` 捕获阶段拦截，放行 TextArea 和 TreeView

### 导出图像

导出为 PNG/JPG：创建临时 Canvas → 计算所有节点逻辑边界 → 自动缩放适配 → 渲染全部内容（非截屏）。Ctrl+E 触发。

### 结构树

`TreeView<MindMapNode>` 展示树结构。刷新时保存/恢复展开状态（按节点 ID 匹配）。不可获焦不可选中，点击只响应展开/收起箭头（用 EventFilter 清除选中）。箭头样式：展开▼，收起▶。叶子节点前缀 `•`。

### 键盘快捷键

| 快捷键 | 功能 |
|--------|------|
| Ctrl+N/O/S | 新建/打开/保存 |
| Ctrl+Z/Y | 撤回/重做 |
| Ctrl+A/Shift+A | 添加子/兄弟节点 |
| Ctrl+D | 删除节点 |
| Ctrl+C/X/V | 复制/剪切/粘贴 |
| Ctrl+E | 导出图片 |
| F2 | 编辑选中节点文本 |
| ↑↓←→ | 节点导航 |

### 拖动交互

- **拖拽空白区**：平移画布（<6px 不启动防误触）
- **拖拽节点**：交换两个节点位置（>6px 启动）
- **拖拽节点边框**：调整节点宽度（左或右边缘 6px 范围内，> 默认宽度 120px）

### 防抖与尺寸监听

Canvas 绑定 DrawingPane 尺寸。Canvas 自身尺寸变化 >2px 时触发重绘（覆盖 SplitPane 拖拽和窗口缩放），2px 阈值过滤按钮悬停 CSS 微调。Scene 尺寸监听作为兜底。

### UI 风格

IntelliJ IDEA 浅色主题，`style.css` 统一样式。Material Design 2 图标（Ikonli）。`#4B6EAF` 选中蓝，`#FAFAFA` 节点填充。
