
package controller;

import service.ContactService;
import service.GroupService;
import ui.GroupTreePanel;
import ui.MainFrame;
import util.Constants;
import util.ErrorHandler;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;

public class GroupController {
    private final GroupService groupService;
    private final ContactService contactService;
    private final MainFrame mainFrame;

    public GroupController(GroupService groupService, ContactService contactService, MainFrame mainFrame) {
        this.groupService = groupService;
        this.contactService = contactService;
        this.mainFrame = mainFrame;
    }

    public void doAddGroup() {
        String name = JOptionPane.showInputDialog(mainFrame, "请输入分组名称：", "新增分组", JOptionPane.PLAIN_MESSAGE);
        if (name == null || name.isBlank()) return;
        groupService.addGroup(name);
        ErrorHandler.showInfo(mainFrame, "分组【" + name + "】添加成功！");
    }

    public void doDeleteGroup() {
        GroupTreePanel treePanel = mainFrame.getTreePanel();
        DefaultMutableTreeNode node = (DefaultMutableTreeNode) treePanel.getTree().getLastSelectedPathComponent();
        if (node == null) {
            ErrorHandler.showWarning(mainFrame, "请先选择一个分组！");
            return;
        }
        String groupName = node.toString();
        if (Constants.ALL_CONTACTS_GROUP.equals(groupName)) {
            ErrorHandler.showWarning(mainFrame, "【所有联系人】不能删除！");
            return;
        }
        if (ErrorHandler.showConfirm(mainFrame,
                "确定要删除分组：" + groupName + "？" + System.lineSeparator() + "（联系人不会删除）", "确认删除")) {
            groupService.deleteGroup(groupName, contactService.getAll());
        }
    }
}
