
package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Contact implements Serializable {
    private static final long serialVersionUID = 1L;

    private String name;
    private String telephone;
    private String im;
    private String email;
    private String birthday;
    private String company;
    private String address;
    private String zipCode;
    private List<String> groups;
    private String remark;

    public Contact() {
        groups = new ArrayList<>();
    }

    public Contact(String name, String telephone, String im, String email,
                   String birthday, String company, String address,
                   String zipCode, List<String> groups, String remark) {
        this.name = name;
        this.telephone = telephone;
        this.im = im;
        this.email = email;
        this.birthday = birthday;
        this.company = company;
        this.address = address;
        this.zipCode = zipCode;
        this.groups = groups == null ? new ArrayList<>() : groups;
        this.remark = remark;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getTelephone() { return telephone; }
    public void setTelephone(String telephone) { this.telephone = telephone; }
    public String getIm() { return im; }
    public void setIm(String im) { this.im = im; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getBirthday() { return birthday; }
    public void setBirthday(String birthday) { this.birthday = birthday; }
    public String getCompany() { return company; }
    public void setCompany(String company) { this.company = company; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getZipCode() { return zipCode; }
    public void setZipCode(String zipCode) { this.zipCode = zipCode; }
    public List<String> getGroups() { return groups; }
    public void setGroups(List<String> groups) { this.groups = groups; }
    public String getRemark() { return remark; }
    public void setRemark(String remark) { this.remark = remark; }

    public String getGroupText() {
        return String.join(",", groups);
    }
}
