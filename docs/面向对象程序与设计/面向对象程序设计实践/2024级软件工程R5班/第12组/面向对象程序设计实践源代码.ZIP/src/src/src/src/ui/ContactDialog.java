
package ui;

import model.Contact;
import service.GroupService;
import util.Constants;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class ContactDialog extends JDialog {
    private boolean ok = false;
    private Contact contact;

    private JTextField name, tel, im, email, birth, comp, addr, zip;
    private JTextArea remark;
    private JCheckBox[] groupChecks;

    public ContactDialog(Frame owner, String title, Contact c, GroupService groupService) {
        super(owner, title, true);
        setSize(520, 520);
        setLocationRelativeTo(owner);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(Color.WHITE);

        // 表单面板
        JPanel panel = new JPanel(new GridLayout(11, 2, 10, 10));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // 初始化输入框
        name = addRow(panel, "姓名");
        tel = addRow(panel, "电话");
        im = addRow(panel, "即时通讯");
        email = addRow(panel, "邮箱");
        birth = addRow(panel, "生日(如2000-01-01)");
        comp = addRow(panel, "单位");
        addr = addRow(panel, "地址");
        zip = addRow(panel, "邮编");

        // 分组选择（从 GroupService 动态获取）
        panel.add(createStyledLabel("分组:"));
        JPanel gp = new JPanel(new FlowLayout(FlowLayout.LEFT, 15, 5));
        gp.setBackground(Color.WHITE);
        List<String> availableGroups = groupService.getAvailableGroups();
        groupChecks = new JCheckBox[availableGroups.size()];
        for (int i = 0; i < availableGroups.size(); i++) {
            groupChecks[i] = new JCheckBox(availableGroups.get(i));
            groupChecks[i].setFont(Constants.FONT_PLAIN);
            gp.add(groupChecks[i]);
        }
        panel.add(gp);

        // 备注
        panel.add(createStyledLabel("备注:"));
        remark = new JTextArea(4, 20);
        remark.setFont(Constants.FONT_PLAIN);
        remark.setLineWrap(true);
        remark.setWrapStyleWord(true);
        panel.add(new JScrollPane(remark));

        add(panel, BorderLayout.CENTER);

        // 按钮面板
        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        btnPanel.setBackground(Color.WHITE);
        JButton okBtn = new JButton("确定");
        JButton cancelBtn = new JButton("取消");

        styleButton(okBtn, Constants.BTN_GREEN, Color.WHITE, Constants.BTN_GREEN_HOVER);
        styleButton(cancelBtn, Constants.BTN_CANCEL, Color.WHITE, Constants.BTN_CANCEL_HOVER);

        btnPanel.add(okBtn);
        btnPanel.add(cancelBtn);
        add(btnPanel, BorderLayout.SOUTH);

        // 加载已有数据（修改时）
        if (c != null) {
            name.setText(c.getName());
            tel.setText(c.getTelephone());
            im.setText(c.getIm());
            email.setText(c.getEmail());
            birth.setText(c.getBirthday());
            comp.setText(c.getCompany());
            addr.setText(c.getAddress());
            zip.setText(c.getZipCode());
            remark.setText(c.getRemark());

            List<String> userGroups = c.getGroups();
            for (JCheckBox cb : groupChecks) {
                cb.setSelected(userGroups.contains(cb.getText()));
            }
        }

        // 按钮事件
        okBtn.addActionListener(e -> {
            ok = true;
            buildContact();
            dispose();
        });
        cancelBtn.addActionListener(e -> dispose());
    }

    private JTextField addRow(JPanel p, String label) {
        p.add(createStyledLabel(label + ":"));
        JTextField tf = createStyledTextField();
        p.add(tf);
        return tf;
    }

    private void buildContact() {
        contact = new Contact();
        contact.setName(name.getText().trim());
        contact.setTelephone(tel.getText().trim());
        contact.setIm(im.getText().trim());
        contact.setEmail(email.getText().trim());
        contact.setBirthday(birth.getText().trim());
        contact.setCompany(comp.getText().trim());
        contact.setAddress(addr.getText().trim());
        contact.setZipCode(zip.getText().trim());
        contact.setRemark(remark.getText().trim());

        for (JCheckBox cb : groupChecks) {
            if (cb.isSelected()) {
                contact.getGroups().add(cb.getText());
            }
        }
    }

    public boolean isOk() { return ok; }
    public Contact getContact() { return contact; }

    // ======================  工具方法 ======================

    public static JLabel createStyledLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(Constants.FONT_BOLD);
        return label;
    }

    public static JTextField createStyledTextField() {
        JTextField tf = new JTextField();
        tf.setFont(Constants.FONT_PLAIN);
        return tf;
    }

    public static void styleButton(JButton btn, Color bg, Color fg) {
        styleButton(btn, bg, fg, bg);
    }

    public static void styleButton(JButton btn, Color bg, Color fg, Color hoverBg) {
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFont(Constants.FONT_PLAIN);
        btn.setFocusPainted(false);
        btn.setBorderPainted(true);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setOpaque(true);

        // 圆角边框
        int arc = 8;
        btn.setBorder(BorderFactory.createEmptyBorder(6, 16, 6, 16));

        // 悬停效果
        Color originalBg = bg;
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(hoverBg);
            }
            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(originalBg);
            }
        });
    }
}
