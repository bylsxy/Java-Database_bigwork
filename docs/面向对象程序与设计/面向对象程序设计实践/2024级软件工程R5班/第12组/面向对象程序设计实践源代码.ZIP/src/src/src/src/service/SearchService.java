
package service;

import model.Contact;

import java.util.*;
import java.util.stream.Collectors;

public class SearchService {

    /**
     * 按关键词搜索联系人（匹配姓名、电话、邮箱）
     * @param contacts 联系人列表
     * @param keyword 搜索关键词
     * @return 匹配的联系人列表
     */
    public List<Contact> search(List<Contact> contacts, String keyword) {
        if (keyword == null || keyword.isBlank()) return contacts;
        String k = keyword.toLowerCase();
        return contacts.stream()
                .filter(c -> c.getName().toLowerCase().contains(k)
                        || c.getTelephone().contains(k)
                        || c.getEmail().toLowerCase().contains(k))
                .collect(Collectors.toList());
    }

    /**
     * 按分组筛选联系人
     * @param contacts 联系人列表
     * @param group 分组名称
     * @return 属于该分组的联系人列表
     */
    public List<Contact> filterByGroup(List<Contact> contacts, String group) {
        if (group == null || group.isBlank() || "所有联系人".equals(group))
            return contacts;
        return contacts.stream()
                .filter(c -> c.getGroups().contains(group))
                .collect(Collectors.toList());
    }
}
