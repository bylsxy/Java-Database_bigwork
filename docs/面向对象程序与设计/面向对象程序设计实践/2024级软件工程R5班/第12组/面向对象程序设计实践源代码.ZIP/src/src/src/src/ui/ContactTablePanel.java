
package ui;

import model.Contact;
import util.Constants;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ContactTablePanel {
    private final JTable table;
    private final DefaultTableModel model;

    public ContactTablePanel() {
        model = createTableModel();
        table = new JTable(model);
        configureTable();
    }

    private DefaultTableModel createTableModel() {
        return new DefaultTableModel(Constants.TABLE_COLUMNS, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 0) return Boolean.class;
                return String.class;
            }

            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 0; // 只有复选框可编辑
            }
        };
    }

    private void configureTable() {
        table.setModel(model);
        table.setFont(Constants.FONT_PLAIN);
        table.setRowHeight(35);
        table.getTableHeader().setFont(Constants.FONT_BOLD);
        table.getTableHeader().setPreferredSize(new Dimension(0, 40));
        table.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable tbl, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(tbl, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? Constants.BG_ROW_EVEN : Constants.BG_ROW_ODD);
                } else {
                    c.setBackground(Constants.BG_SELECTED);
                }
                setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
                return c;
            }
        });
    }

    /**
     * 刷新表格数据
     */
    public void refresh(List<Contact> list) {
        model.setRowCount(0);
        if (list == null) return;
        for (Contact c : list) {
            model.addRow(new Object[]{
                    Boolean.FALSE,
                    c.getName(),
                    c.getTelephone(),
                    c.getIm(),
                    c.getEmail(),
                    c.getGroupText(),
                    c.getRemark()
            });
        }
    }

    /**
     * 全选/取消全选
     */
    public void toggleSelectAll() {
        boolean allSelected = true;
        for (int i = 0; i < model.getRowCount(); i++) {
            Boolean checked = (Boolean) model.getValueAt(i, 0);
            if (checked == null || !checked) {
                allSelected = false;
                break;
            }
        }
        boolean newValue = !allSelected;
        for (int i = 0; i < model.getRowCount(); i++) {
            model.setValueAt(newValue, i, 0);
        }
    }

    /**
     * 清除所有勾选
     */
    public void clearAllChecks() {
        for (int i = 0; i < model.getRowCount(); i++) {
            model.setValueAt(false, i, 0);
        }
    }

    /**
     * 获取所有被勾选的行索引
     */
    public java.util.List<Integer> getCheckedRows() {
        java.util.List<Integer> checkedRows = new java.util.ArrayList<>();
        for (int i = 0; i < table.getRowCount(); i++) {
            Boolean checked = (Boolean) model.getValueAt(i, 0);
            if (checked != null && checked) {
                checkedRows.add(i);
            }
        }
        return checkedRows;
    }

    public JTable getTable() { return table; }
    public DefaultTableModel getModel() { return model; }

    /**
     * 将面板包装为滚动面板
     */
    public JScrollPane toScrollPane() {
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.getViewport().setBackground(Color.WHITE);
        scrollPane.setBorder(BorderFactory.createLineBorder(Constants.BORDER_COLOR));
        return scrollPane;
    }
}
