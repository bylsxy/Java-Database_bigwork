
package util;

import javax.swing.*;

public class ErrorHandler {

    /**
     * 显示错误消息对话框
     */
    public static void showError(java.awt.Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "错误", JOptionPane.ERROR_MESSAGE);
    }

    /**
     * 显示警告消息对话框
     */
    public static void showWarning(java.awt.Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "警告", JOptionPane.WARNING_MESSAGE);
    }

    /**
     * 显示信息消息对话框
     */
    public static void showInfo(java.awt.Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "提示", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * 显示确认对话框
     * @return 用户是否选择了"是"
     */
    public static boolean showConfirm(java.awt.Component parent, String message, String title) {
        return JOptionPane.showConfirmDialog(parent, message, title, JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }

    /**
     * 处理异常，打印堆栈并显示用户友好的错误消息
     */
    public static void handleException(java.awt.Component parent, Exception e, String userMessage) {
        e.printStackTrace();
        showError(parent, userMessage + "：" + e.getMessage());
    }
}
