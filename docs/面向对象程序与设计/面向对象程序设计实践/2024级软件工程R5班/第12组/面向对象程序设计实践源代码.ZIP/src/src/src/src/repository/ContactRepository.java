
package repository;

import model.Contact;

import java.io.*;
import java.util.*;

public class ContactRepository {
    private static final String CONTACT_FILE = "contacts.data";
    private static final String GROUP_FILE = "groups.data";

    // ====================== 联系人持久化 ======================

    @SuppressWarnings("unchecked")
    public List<Contact> loadContacts() {
        File f = new File(CONTACT_FILE);
        if (!f.exists()) return new ArrayList<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))) {
            return (List<Contact>) ois.readObject();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }

    public void saveContacts(List<Contact> contacts) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(CONTACT_FILE))) {
            oos.writeObject(contacts);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ====================== 分组持久化 ======================

    @SuppressWarnings("unchecked")
    public Set<String> loadGroups() {
        File f = new File(GROUP_FILE);
        if (!f.exists()) return null;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))) {
            return (Set<String>) ois.readObject();
        } catch (Exception e) {
            return null;
        }
    }

    public void saveGroups(Set<String> groupSet) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(GROUP_FILE))) {
            oos.writeObject(groupSet);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
