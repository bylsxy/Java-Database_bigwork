
package ui;

import util.Constants;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import java.awt.*;
import java.util.*;
import java.util.List;

public class GroupTreePanel {
    private final JTree groupTree;
    private final DefaultTreeModel treeModel;

    public GroupTreePanel() {
        treeModel = new DefaultTreeModel(new DefaultMutableTreeNode("分组"));
        groupTree = new JTree(treeModel);
        configureTree();
    }

    private void configureTree() {
        groupTree.setFont(Constants.FONT_PLAIN);
        groupTree.setRowHeight(30);

        // 美化树节点渲染
        DefaultTreeCellRenderer renderer = new DefaultTreeCellRenderer();
        renderer.setLeafIcon(null);
        renderer.setOpenIcon(null);
        renderer.setClosedIcon(null);
        renderer.setBackgroundNonSelectionColor(Color.WHITE);
        renderer.setTextSelectionColor(new Color(66, 133, 244));
        renderer.setBackgroundSelectionColor(new Color(230, 236, 255));
        groupTree.setCellRenderer(renderer);
    }

    /**
     * 刷新分组树
     */
    public void refresh(Set<String> groups) {
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("分组");
        List<String> sorted = new ArrayList<>(groups);
        // 先移除"所有联系人"，排序其余分组
        sorted.remove(Constants.ALL_CONTACTS_GROUP);
        Collections.sort(sorted);
        // "所有联系人"始终排在首位
        root.add(new DefaultMutableTreeNode(Constants.ALL_CONTACTS_GROUP));
        for (String g : sorted) {
            root.add(new DefaultMutableTreeNode(g));
        }
        treeModel.setRoot(root);
        groupTree.expandRow(0);
    }

    /**
     * 获取当前选中的分组名称
     * @return 选中的分组名称，如果没有选中则返回"所有联系人"
     */
    public String getSelectedGroup() {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode) groupTree.getLastSelectedPathComponent();
        if (node == null) return Constants.ALL_CONTACTS_GROUP;
        String selectedGroup = node.toString();
        if (Constants.ALL_CONTACTS_GROUP.equals(selectedGroup)) return Constants.ALL_CONTACTS_GROUP;
        return selectedGroup;
    }

    public JTree getTree() { return groupTree; }
    public DefaultTreeModel getTreeModel() { return treeModel; }

    /**
     * 将面板包装为带标题的滚动面板
     */
    public JScrollPane toScrollPane() {
        JScrollPane scrollPane = new JScrollPane(groupTree);
        scrollPane.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Constants.BORDER_COLOR),
                "分组", TitledBorder.LEFT, TitledBorder.TOP, Constants.FONT_BOLD));
        scrollPane.getViewport().setBackground(Color.WHITE);
        return scrollPane;
    }
}
