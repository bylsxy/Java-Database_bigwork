
package controller;

import model.Contact;
import service.ContactService;
import service.GroupService;
import ui.ContactDialog;
import ui.MainFrame;
import util.CsvUtil;
import util.Constants;
import util.ErrorHandler;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;
import java.util.Arrays;
import java.util.List;

public class ContactController {
    private final ContactService contactService;
    private final GroupService groupService;
    private final MainFrame mainFrame;

    public ContactController(ContactService contactService, GroupService groupService, MainFrame mainFrame) {
        this.contactService = contactService;
        this.groupService = groupService;
        this.mainFrame = mainFrame;
    }

    // ====================== 联系人操作 ======================

    public void doAddContact() {
        ContactDialog d = new ContactDialog(mainFrame, "新增联系人", null, groupService);
        d.setVisible(true);
        if (d.isOk()) {
            contactService.add(d.getContact());
        }
    }

    public void doEditContact(int modelIndex) {
        if (modelIndex < 0) {
            ErrorHandler.showWarning(mainFrame, "请先选择一行");
            return;
        }
        Contact c = contactService.get(modelIndex);
        if (c == null) {
            ErrorHandler.showWarning(mainFrame, "请先选择一行");
            return;
        }
        ContactDialog d = new ContactDialog(mainFrame, "修改联系人", c, groupService);
        d.setVisible(true);
        if (d.isOk()) {
            contactService.update(modelIndex, d.getContact());
        }
    }

    public void doDeleteContact(int modelIndex) {
        if (modelIndex < 0) {
            ErrorHandler.showWarning(mainFrame, "请先选择");
            return;
        }
        if (ErrorHandler.showConfirm(mainFrame, "确定删除选中的联系人？", "提示")) {
            contactService.delete(modelIndex);
        }
    }

    public void doDeleteMultipleContacts(int[] modelIndices) {
        if (modelIndices == null || modelIndices.length == 0) {
            ErrorHandler.showWarning(mainFrame, "请先选择要删除的联系人");
            return;
        }
        String message = String.format("确定要删除选中的 %d 个联系人吗？", modelIndices.length);
        if (ErrorHandler.showConfirm(mainFrame, message, "确认删除")) {
            contactService.deleteMultiple(modelIndices);
            ErrorHandler.showInfo(mainFrame, "已成功删除 " + modelIndices.length + " 个联系人！");
        }
    }

    // ====================== 联系人分组调整 ======================

    public void doAddContactsToGroups(int[] modelIndices) {
        if (modelIndices == null || modelIndices.length == 0) {
            ErrorHandler.showWarning(mainFrame, "请先选择要添加到分组的联系人！");
            return;
        }

        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        List<String> availableGroups = groupService.getAvailableGroups();
        JList<String> groupList = new JList<>(availableGroups.toArray(new String[0]));
        groupList.setVisibleRowCount(8);
        groupList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        JScrollPane scrollPane = new JScrollPane(groupList);
        scrollPane.setBorder(BorderFactory.createLineBorder(Constants.BORDER_COLOR));

        JLabel label = new JLabel("请选择要添加的分组（可多选）：", JLabel.CENTER);
        label.setFont(Constants.FONT_BOLD);
        label.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

        panel.add(label, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        int result = JOptionPane.showConfirmDialog(mainFrame, panel, "添加联系人到分组",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            Object[] selectedGroups = groupList.getSelectedValuesList().toArray();
            if (selectedGroups.length > 0) {
                String[] groupNames = Arrays.copyOf(selectedGroups, selectedGroups.length, String[].class);
                contactService.addContactsToGroups(modelIndices, groupNames);
                ErrorHandler.showInfo(mainFrame, "已成功将联系人添加到选中的分组中！");
            }
        }
    }

    public void doRemoveContactsFromGroup(int[] modelIndices, String currentGroup) {
        if (modelIndices == null || modelIndices.length == 0) {
            ErrorHandler.showWarning(mainFrame, "请先选择要从分组中移除的联系人！");
            return;
        }
        if (currentGroup == null || currentGroup.isBlank() || Constants.ALL_CONTACTS_GROUP.equals(currentGroup)) {
            ErrorHandler.showWarning(mainFrame, "请先选择一个分组！");
            return;
        }
        String message = "确定要将选中的联系人从分组【" + currentGroup + "】中移除吗？";
        if (ErrorHandler.showConfirm(mainFrame, message, "确认移除")) {
            contactService.removeContactsFromGroup(modelIndices, currentGroup);
            ErrorHandler.showInfo(mainFrame, "已成功将联系人从分组中移除！");
        }
    }

    // ====================== 导入导出 ======================

    public void doImportCSV() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("选择要导入的CSV文件");
        chooser.setFileFilter(new FileNameExtensionFilter("CSV文件 (*.csv)", "csv"));

        if (chooser.showOpenDialog(mainFrame) != JFileChooser.APPROVE_OPTION) return;

        try {
            List<Contact> imported = CsvUtil.importCSV(chooser.getSelectedFile().getAbsolutePath(), groupService);
            for (Contact c : imported) {
                contactService.add(c);
            }
            ErrorHandler.showInfo(mainFrame, "导入成功！共导入 " + imported.size() + " 条数据");
        } catch (Exception ex) {
            ErrorHandler.handleException(mainFrame, ex, "导入失败");
        }
    }

    public void doExportCSV() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("选择CSV保存路径");
        chooser.setFileFilter(new FileNameExtensionFilter("CSV文件 (*.csv)", "csv"));

        if (chooser.showSaveDialog(mainFrame) != JFileChooser.APPROVE_OPTION) return;

        File file = chooser.getSelectedFile();
        if (!file.getName().toLowerCase().endsWith(".csv")) {
            file = new File(file.getParentFile(), file.getName() + ".csv");
        }

        if (file.exists()) {
            if (!ErrorHandler.showConfirm(mainFrame,
                    "文件已存在，是否覆盖？" + System.lineSeparator() + file.getAbsolutePath(), "确认覆盖")) return;
        }

        try {
            CsvUtil.exportCSV(file.getAbsolutePath(), contactService.getAll());
            ErrorHandler.showInfo(mainFrame, "导出成功！" + System.lineSeparator() + "保存到：" + System.lineSeparator() + file.getAbsolutePath());
        } catch (Exception ex) {
            ErrorHandler.handleException(mainFrame, ex, "导出失败");
        }
    }
}
