
package controller;

import model.Contact;
import repository.ContactRepository;
import service.ContactService;
import service.GroupService;
import service.SearchService;
import ui.ContactTablePanel;
import ui.GroupTreePanel;
import ui.MainFrame;
import util.Constants;
import util.ErrorHandler;

import java.util.List;

public class AppController implements MainFrame.ActionListenerHolder, MainFrame.TreeSelectionHandler, MainFrame.SearchActionHandler {
    private final MainFrame mainFrame;
    private final ContactService contactService;
    private final GroupService groupService;
    private final ContactController contactController;
    private final GroupController groupController;

    private List<Contact> displayedContacts;

    public AppController() {
        // 初始化 Service 层
        ContactRepository repository = new ContactRepository();
        this.groupService = new GroupService(repository);
        SearchService searchService = new SearchService();
        this.contactService = new ContactService(repository, groupService, searchService);

        // 初始化
        this.mainFrame = new MainFrame();

        // 初始化子控制器
        this.contactController = new ContactController(contactService, groupService, mainFrame);
        this.groupController = new GroupController(groupService, contactService, mainFrame);

        // 布局并绑定事件
        mainFrame.layoutComponents(this, this, this);

        // 初始刷新
        refreshAll();
    }

    /**
     * 刷新所有数据（分组树 + 表格）
     */
    public void refreshAll() {
        GroupTreePanel treePanel = mainFrame.getTreePanel();
        treePanel.refresh(groupService.getGroups());
        displayedContacts = contactService.getAll();
        mainFrame.getTablePanel().refresh(displayedContacts);
    }

    /**
     * 将视图行索引转换为 contacts 列表中的实际索引
     */
    private int toModelIndex(int viewRow) {
        if (viewRow < 0 || viewRow >= displayedContacts.size()) return -1;
        Contact c = displayedContacts.get(viewRow);
        return contactService.getAll().indexOf(c);
    }

    /**
     * 将视图行索引数组转换为 contacts 列表中的实际索引数组
     */
    private int[] toModelIndices(int[] viewRows) {
        int[] result = new int[viewRows.length];
        for (int i = 0; i < viewRows.length; i++) {
            result[i] = toModelIndex(viewRows[i]);
        }
        return result;
    }

    public void show() {
        mainFrame.setVisible(true);
    }

    // ====================== ActionListenerHolder 实现 ======================

    @Override
    public void onAddContact() {
        contactController.doAddContact();
        refreshAll();
    }

    /**
     * 获取当前选中的行索引（优先使用勾选框，其次使用行选中）
     */
    private int[] getSelectedIndices() {
        ContactTablePanel tablePanel = mainFrame.getTablePanel();
        List<Integer> checkedRows = tablePanel.getCheckedRows();
        if (!checkedRows.isEmpty()) {
            return checkedRows.stream().mapToInt(Integer::intValue).toArray();
        }
        return tablePanel.getTable().getSelectedRows();
    }

    /**
     * 判断当前是否在"所有联系人"视图中
     */
    private boolean isAllContactsView() {
        String group = mainFrame.getTreePanel().getSelectedGroup();
        return Constants.ALL_CONTACTS_GROUP.equals(group);
    }

    @Override
    public void onEditContact() {
        int[] selected = getSelectedIndices();
        if (selected.length == 1) {
            contactController.doEditContact(toModelIndex(selected[0]));
        } else if (selected.length > 1) {
            util.ErrorHandler.showWarning(mainFrame, "修改联系人只能选择一条记录！");
            return;
        }
        refreshAll();
    }

    @Override
    public void onDeleteContact() {
        int[] selected = getSelectedIndices();
        if (selected.length == 0) return;
        int[] modelIndices = toModelIndices(selected);
        if (modelIndices.length == 1) {
            contactController.doDeleteContact(modelIndices[0]);
        } else {
            contactController.doDeleteMultipleContacts(modelIndices);
        }
        mainFrame.getTablePanel().clearAllChecks();
        refreshAll();
    }

    @Override
    public void onSelectAll() {
        mainFrame.getTablePanel().toggleSelectAll();
    }

    @Override
    public void onAddGroup() {
        groupController.doAddGroup();
        refreshAll();
    }

    @Override
    public void onDeleteGroup() {
        if (isAllContactsView()) {
            ErrorHandler.showWarning(mainFrame, "【所有联系人】组不能删除！");
            return;
        }
        groupController.doDeleteGroup();
        refreshAll();
    }

    @Override
    public void onAddContactsToGroups() {
        int[] selected = getSelectedIndices();
        contactController.doAddContactsToGroups(toModelIndices(selected));
        mainFrame.getTablePanel().clearAllChecks();
        refreshAll();
    }

    @Override
    public void onRemoveContactsFromGroup() {
        int[] selected = getSelectedIndices();
        String currentGroup = mainFrame.getTreePanel().getSelectedGroup();
        contactController.doRemoveContactsFromGroup(toModelIndices(selected), currentGroup);
        mainFrame.getTablePanel().clearAllChecks();
        refreshAll();
    }

    @Override
    public void onImportCSV() {
        contactController.doImportCSV();
        refreshAll();
    }

    @Override
    public void onExportCSV() {
        contactController.doExportCSV();
    }

    // ====================== TreeSelectionHandler 实现 ======================

    @Override
    public void onGroupSelected(String group) {
        displayedContacts = contactService.filterByGroup(group);
        mainFrame.getTablePanel().refresh(displayedContacts);
    }

    // ====================== SearchActionHandler 实现 ======================

    @Override
    public void onSearch(String keyword) {
        displayedContacts = contactService.search(keyword);
        mainFrame.getTablePanel().refresh(displayedContacts);
    }

    @Override
    public void onReset() {
        displayedContacts = contactService.getAll();
        mainFrame.getTablePanel().refresh(displayedContacts);
    }
}
