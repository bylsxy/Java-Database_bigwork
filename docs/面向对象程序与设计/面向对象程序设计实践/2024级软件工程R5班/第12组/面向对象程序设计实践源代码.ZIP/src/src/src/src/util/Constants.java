
package util;

import java.awt.*;
import java.util.Arrays;
import java.util.List;

public class Constants {
    // ====================== 应用配置 ======================
    public static final String APP_TITLE = "通讯录管理系统";
    public static final int APP_WIDTH = 1050;
    public static final int APP_HEIGHT = 680;
    public static final int DIVIDER_LOCATION = 240;

    // ====================== 默认分组 ======================
    public static final String ALL_CONTACTS_GROUP = "所有联系人";
    public static final List<String> DEFAULT_GROUPS = Arrays.asList("所有联系人", "家人", "朋友", "同学", "同事");

    // ====================== 表格列名 ======================
    public static final String[] TABLE_COLUMNS = {"", "姓名", "电话", "即时通讯", "邮箱", "分组", "备注"};

    // ====================== CSV 表头 ======================
    public static final String CSV_HEADER = "姓名,电话,即时通讯,邮箱,生日,单位,地址,邮编,分组,备注";

    // ====================== 字体 ======================
    public static final String FONT_NAME = "Microsoft YaHei";
    public static final Font FONT_PLAIN = new Font(FONT_NAME, Font.PLAIN, 14);
    public static final Font FONT_BOLD = new Font(FONT_NAME, Font.BOLD, 14);

    // ====================== 颜色 ======================
    public static final Color BG_MAIN = new Color(245, 247, 250);
    public static final Color BG_WHITE = Color.WHITE;
    public static final Color BG_ROW_EVEN = Color.WHITE;
    public static final Color BG_ROW_ODD = new Color(248, 249, 252);
    public static final Color BG_SELECTED = new Color(230, 236, 255);
    // 按钮颜色 - 红（危险/删除）
    public static final Color BTN_RED = new Color(234, 67, 53);
    public static final Color BTN_RED_HOVER = new Color(211, 47, 47);
    // 按钮颜色 - 黄（警告/移出）
    public static final Color BTN_YELLOW = new Color(251, 188, 4);
    public static final Color BTN_YELLOW_HOVER = new Color(245, 166, 35);
    // 按钮颜色 - 绿（新增/添加）
    public static final Color BTN_GREEN = new Color(52, 168, 83);
    public static final Color BTN_GREEN_HOVER = new Color(46, 139, 87);
    // 按钮颜色 - 蓝（主要/常规）
    public static final Color BTN_BLUE = new Color(66, 133, 244);
    public static final Color BTN_BLUE_HOVER = new Color(48, 113, 224);
    // 按钮颜色 - 灰（取消/次要）
    public static final Color BTN_CANCEL = new Color(158, 158, 158);
    public static final Color BTN_CANCEL_HOVER = new Color(138, 138, 138);
    // 原有颜色
    public static final Color BTN_PRIMARY = BTN_BLUE;
    public static final Color BORDER_COLOR = new Color(220, 224, 231);

    // ====================== 数据文件 ======================
    public static final String CONTACT_FILE = "contacts.data";
    public static final String GROUP_FILE = "groups.data";
}
