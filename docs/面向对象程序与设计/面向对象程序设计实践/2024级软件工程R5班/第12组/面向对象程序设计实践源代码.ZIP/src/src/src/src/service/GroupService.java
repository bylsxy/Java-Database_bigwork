
package service;

import model.Contact;
import repository.ContactRepository;
import util.Constants;

import java.util.*;
import java.util.stream.Collectors;

public class GroupService {
    private final ContactRepository repository;
    private Set<String> groupSet;

    public GroupService(ContactRepository repository) {
        this.repository = repository;
        Set<String> loadedGroups = repository.loadGroups();
        this.groupSet = loadedGroups != null ? loadedGroups : new HashSet<>();

        // 默认分组
        if (groupSet.isEmpty()) {
            groupSet.addAll(Constants.DEFAULT_GROUPS);
        }
    }

    // ====================== 分组查询 ======================

    public Set<String> getGroups() {
        return new HashSet<>(groupSet);
    }

    /**
     * 获取可用分组（排除"所有联系人"）
     */
    public List<String> getAvailableGroups() {
        return groupSet.stream()
                .filter(g -> !Constants.ALL_CONTACTS_GROUP.equals(g))
                .sorted()
                .collect(Collectors.toList());
    }

    // ====================== 分组操作 ======================

    public void addGroup(String groupName) {
        if (groupName == null || groupName.isBlank()) return;
        groupSet.add(groupName.trim());
        repository.saveGroups(groupSet);
    }

    public void deleteGroup(String groupName, List<Contact> contacts) {
        if (groupName == null || groupName.isBlank()) return;
        if (Constants.ALL_CONTACTS_GROUP.equals(groupName)) return;

        groupSet.remove(groupName);
        for (Contact c : contacts) {
            c.getGroups().remove(groupName);
        }
        repository.saveGroups(groupSet);
        repository.saveContacts(contacts);
    }
}
