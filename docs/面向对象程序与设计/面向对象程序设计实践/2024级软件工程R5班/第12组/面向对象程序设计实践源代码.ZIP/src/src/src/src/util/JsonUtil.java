
package util;

/**
 * JSON 工具类（预留）
 * 未来可用于 JSON 格式的数据导入/导出
 */
public class JsonUtil {

    private JsonUtil() {
        // 工具类不允许实例化
    }

    /**
     * 将联系人列表序列化为 JSON 字符串
     * @param obj 要序列化的对象
     * @return JSON 字符串
     */
    public static String toJson(Object obj) {
        // TODO: 未来实现 JSON 序列化
        throw new UnsupportedOperationException("JSON 序列化尚未实现");
    }

    /**
     * 将 JSON 字符串反序列化为对象
     * @param json JSON 字符串
     * @param clazz 目标类型
     * @return 反序列化后的对象
     */
    public static <T> T fromJson(String json, Class<T> clazz) {
        // TODO: 未来实现 JSON 反序列化
        throw new UnsupportedOperationException("JSON 反序列化尚未实现");
    }
}
