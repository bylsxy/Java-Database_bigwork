
package service;

import model.Contact;
import repository.ContactRepository;

import java.util.*;
import java.util.stream.Collectors;

public class ContactService {
    private final ContactRepository repository;
    private final GroupService groupService;
    private final SearchService searchService;
    private List<Contact> contacts;

    public ContactService(ContactRepository repository, GroupService groupService, SearchService searchService) {
        this.repository = repository;
        this.groupService = groupService;
        this.searchService = searchService;
        this.contacts = repository.loadContacts();
    }

    // ====================== 联系人 CRUD ======================

    public void add(Contact c) {
        contacts.add(c);
        repository.saveContacts(contacts);
    }

    public void update(int index, Contact c) {
        if (index >= 0 && index < contacts.size()) {
            contacts.set(index, c);
            repository.saveContacts(contacts);
        }
    }

    public void delete(int index) {
        if (index >= 0 && index < contacts.size()) {
            contacts.remove(index);
            repository.saveContacts(contacts);
        }
    }

    public void deleteMultiple(int[] indices) {
        if (indices == null || indices.length == 0) return;
        Arrays.sort(indices);
        for (int i = indices.length - 1; i >= 0; i--) {
            int index = indices[i];
            if (index >= 0 && index < contacts.size()) {
                contacts.remove(index);
            }
        }
        repository.saveContacts(contacts);
    }

    public List<Contact> getAll() {
        return contacts;
    }

    public Contact get(int index) {
        if (index >= 0 && index < contacts.size()) {
            return contacts.get(index);
        }
        return null;
    }

    // ====================== 联系人分组管理 ======================

    /**
     * 将一个或多个联系人添加到一个或多个分组中
     */
    public void addContactsToGroups(int[] indices, String[] groupNames) {
        if (indices == null || indices.length == 0 || groupNames == null || groupNames.length == 0) return;

        Set<String> groups = groupService.getGroups();
        for (String groupName : groupNames) {
            if (!groups.contains(groupName)) return;
        }

        for (int index : indices) {
            if (index >= 0 && index < contacts.size()) {
                Contact contact = contacts.get(index);
                List<String> contactGroups = contact.getGroups();
                for (String groupName : groupNames) {
                    if (!contactGroups.contains(groupName)) {
                        contactGroups.add(groupName);
                    }
                }
            }
        }
        repository.saveContacts(contacts);
    }

    /**
     * 将一个或多个联系人从某个分组中移除
     */
    public void removeContactsFromGroup(int[] indices, String groupName) {
        if (indices == null || indices.length == 0 || groupName == null || groupName.isBlank()) return;
        if (!groupService.getGroups().contains(groupName)) return;

        for (int index : indices) {
            if (index >= 0 && index < contacts.size()) {
                contacts.get(index).getGroups().remove(groupName);
            }
        }
        repository.saveContacts(contacts);
    }

    // ====================== 检索功能 ======================

    public List<Contact> filterByGroup(String group) {
        return searchService.filterByGroup(contacts, group);
    }

    public List<Contact> search(String keyword) {
        return searchService.search(contacts, keyword);
    }
}
