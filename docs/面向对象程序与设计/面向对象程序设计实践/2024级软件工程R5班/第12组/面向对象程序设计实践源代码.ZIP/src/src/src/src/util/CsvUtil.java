
package util;

import model.Contact;
import service.GroupService;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class CsvUtil {

    /**
     * 从CSV文件导入联系人
     * @param filePath CSV文件路径
     * @param groupService 分组服务（用于自动创建分组）
     * @return 导入的联系人列表
     */
    public static List<Contact> importCSV(String filePath, GroupService groupService) throws Exception {
        List<Contact> imported = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            br.readLine(); // 跳过表头

            while ((line = br.readLine()) != null) {
                String[] arr = line.split(",", -1);
                if (arr.length < 10) continue;

                Contact c = new Contact();
                c.setName(arr[0]);
                c.setTelephone(arr[1]);
                c.setIm(arr[2]);
                c.setEmail(arr[3]);
                c.setBirthday(arr[4]);
                c.setCompany(arr[5]);
                c.setAddress(arr[6]);
                c.setZipCode(arr[7]);

                String groupStr = arr[8];
                if (!groupStr.isEmpty()) {
                    String[] gs = groupStr.split(",");
                    for (String g : gs) {
                        if (!g.isEmpty()) {
                            c.getGroups().add(g.trim());
                            groupService.addGroup(g.trim());
                        }
                    }
                }
                c.setRemark(arr[9]);

                imported.add(c);
            }
        }
        return imported;
    }

    /**
     * 导出联系人到CSV文件
     * @param filePath CSV文件路径
     * @param contacts 联系人列表
     */
    public static void exportCSV(String filePath, List<Contact> contacts) throws Exception {
        try (FileWriter fw = new FileWriter(filePath)) {
            fw.write(Constants.CSV_HEADER + System.lineSeparator());
            for (Contact c : contacts) {
                fw.write(String.format("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s%n",
                        c.getName(),
                        c.getTelephone(),
                        c.getIm(),
                        c.getEmail(),
                        c.getBirthday(),
                        c.getCompany(),
                        c.getAddress(),
                        c.getZipCode(),
                        c.getGroupText(),
                        c.getRemark()
                ));
            }
        }
    }
}
