
package ui;

import util.Constants;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private final ContactTablePanel tablePanel;
    private final GroupTreePanel treePanel;
    private final JTextField searchField;

    public MainFrame() {
        setTitle(Constants.APP_TITLE);
        setSize(Constants.APP_WIDTH, Constants.APP_HEIGHT);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(12, 12));
        getContentPane().setBackground(Constants.BG_MAIN);

        // 设置全局字体
        setUIFont(Constants.FONT_PLAIN);

        // 初始化子面板
        tablePanel = new ContactTablePanel();
        treePanel = new GroupTreePanel();
        searchField = new JTextField(22);
    }

    /**
     * 布局所有组件，需要传入各区域的操作监听器
     */
    public void layoutComponents(
            ActionListenerHolder actionListener,
            TreeSelectionHandler treeSelectionHandler,
            SearchActionHandler searchActionHandler) {

        // 顶部工具栏
        add(createTopPanel(actionListener), BorderLayout.NORTH);

        // 中间分割面板
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                treePanel.toScrollPane(),
                tablePanel.toScrollPane());
        split.setDividerLocation(Constants.DIVIDER_LOCATION);
        split.setBorder(null);
        add(split, BorderLayout.CENTER);

        // 底部搜索栏
        add(createSearchPanel(searchActionHandler), BorderLayout.SOUTH);

        // 树选择监听
        treePanel.getTree().addTreeSelectionListener(e -> {
            String group = treePanel.getSelectedGroup();
            treeSelectionHandler.onGroupSelected(group);
        });
    }

    // ====================== 顶部工具栏 ======================

    private JPanel createTopPanel(ActionListenerHolder holder) {
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        top.setBackground(Constants.BG_MAIN);

        // 绿色 - 新增/添加操作
        JButton addBtn = new JButton("新增联系人");
        JButton addGroupBtn = new JButton("新增分组");
        JButton addToGroupBtn = new JButton("加入分组");

        // 蓝色 - 常规操作
        JButton editBtn = new JButton("修改联系人");
        JButton selectAllBtn = new JButton("全选/取消");
        JButton importBtn = new JButton("导入CSV");
        JButton exportBtn = new JButton("导出CSV");

        // 红色 - 删除操作
        JButton deleteBtn = new JButton("删除联系人");
        JButton deleteGroupBtn = new JButton("删除分组");

        // 黄色 - 移出/警告操作
        JButton removeFromGroupBtn = new JButton("移出分组");

        // 按功能分组着色
        ContactDialog.styleButton(addBtn, Constants.BTN_GREEN, Color.WHITE, Constants.BTN_GREEN_HOVER);
        ContactDialog.styleButton(addGroupBtn, Constants.BTN_GREEN, Color.WHITE, Constants.BTN_GREEN_HOVER);
        ContactDialog.styleButton(addToGroupBtn, Constants.BTN_GREEN, Color.WHITE, Constants.BTN_GREEN_HOVER);

        ContactDialog.styleButton(editBtn, Constants.BTN_BLUE, Color.WHITE, Constants.BTN_BLUE_HOVER);
        ContactDialog.styleButton(selectAllBtn, Constants.BTN_BLUE, Color.WHITE, Constants.BTN_BLUE_HOVER);
        ContactDialog.styleButton(importBtn, Constants.BTN_BLUE, Color.WHITE, Constants.BTN_BLUE_HOVER);
        ContactDialog.styleButton(exportBtn, Constants.BTN_BLUE, Color.WHITE, Constants.BTN_BLUE_HOVER);

        ContactDialog.styleButton(deleteBtn, Constants.BTN_RED, Color.WHITE, Constants.BTN_RED_HOVER);
        ContactDialog.styleButton(deleteGroupBtn, Constants.BTN_RED, Color.WHITE, Constants.BTN_RED_HOVER);

        ContactDialog.styleButton(removeFromGroupBtn, Constants.BTN_YELLOW, Color.WHITE, Constants.BTN_YELLOW_HOVER);

        // 按顺序添加按钮
        JButton[] buttons = {addBtn, editBtn, deleteBtn, selectAllBtn, addGroupBtn,
                deleteGroupBtn, addToGroupBtn, removeFromGroupBtn, importBtn, exportBtn};
        for (JButton btn : buttons) {
            top.add(btn);
        }

        addBtn.addActionListener(e -> holder.onAddContact());
        editBtn.addActionListener(e -> holder.onEditContact());
        deleteBtn.addActionListener(e -> holder.onDeleteContact());
        selectAllBtn.addActionListener(e -> holder.onSelectAll());
        addGroupBtn.addActionListener(e -> holder.onAddGroup());
        deleteGroupBtn.addActionListener(e -> holder.onDeleteGroup());
        addToGroupBtn.addActionListener(e -> holder.onAddContactsToGroups());
        removeFromGroupBtn.addActionListener(e -> holder.onRemoveContactsFromGroup());
        importBtn.addActionListener(e -> holder.onImportCSV());
        exportBtn.addActionListener(e -> holder.onExportCSV());

        return top;
    }

    // ====================== 底部搜索栏 ======================

    private JPanel createSearchPanel(SearchActionHandler handler) {
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));
        bottom.setBackground(Constants.BG_MAIN);

        JLabel label = new JLabel("搜索：");
        label.setFont(Constants.FONT_BOLD);
        bottom.add(label);

        searchField.setFont(Constants.FONT_PLAIN);
        bottom.add(searchField);

        JButton searchBtn = new JButton("搜索");
        JButton resetBtn = new JButton("重置");
        ContactDialog.styleButton(searchBtn, Constants.BTN_BLUE, Color.WHITE, Constants.BTN_BLUE_HOVER);
        ContactDialog.styleButton(resetBtn, Constants.BTN_CANCEL, Color.WHITE, Constants.BTN_CANCEL_HOVER);
        bottom.add(searchBtn);
        bottom.add(resetBtn);

        searchBtn.addActionListener(e -> handler.onSearch(searchField.getText().trim()));
        resetBtn.addActionListener(e -> {
            searchField.setText("");
            handler.onReset();
        });

        // 回车搜索
        searchField.addActionListener(e -> handler.onSearch(searchField.getText().trim()));

        return bottom;
    }

    // ====================== 全局字体设置 ======================

    private static void setUIFont(Font font) {
        java.util.Enumeration<Object> keys = UIManager.getDefaults().keys();
        while (keys.hasMoreElements()) {
            Object key = keys.nextElement();
            Object value = UIManager.get(key);
            if (value instanceof javax.swing.plaf.FontUIResource) {
                UIManager.put(key, font);
            }
        }
    }

    // ====================== Getter ======================

    public ContactTablePanel getTablePanel() { return tablePanel; }
    public GroupTreePanel getTreePanel() { return treePanel; }

    // ====================== 接口定义 ======================

    public interface ActionListenerHolder {
        void onAddContact();
        void onEditContact();
        void onDeleteContact();
        void onSelectAll();
        void onAddGroup();
        void onDeleteGroup();
        void onAddContactsToGroups();
        void onRemoveContactsFromGroup();
        void onImportCSV();
        void onExportCSV();
    }

    public interface TreeSelectionHandler {
        void onGroupSelected(String group);
    }

    public interface SearchActionHandler {
        void onSearch(String keyword);
        void onReset();
    }
}
