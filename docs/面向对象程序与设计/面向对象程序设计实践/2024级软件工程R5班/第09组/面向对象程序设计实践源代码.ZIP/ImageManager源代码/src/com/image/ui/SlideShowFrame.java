package com.image.ui;

import com.image.util.ImageUtils;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

public class SlideShowFrame extends JFrame {
    private List<File> list;
    private JLabel picLabel = new JLabel("", SwingConstants.CENTER);
    private JLabel infoLabel = new JLabel(" ");
    private JButton playBtn = new JButton("播放");
    private int nowIndex;
    private double scale = 1.0;
    private Timer timer;

    public SlideShowFrame(List<File> list, int start) {
        this.list = list;
        this.nowIndex = Math.max(0, Math.min(start, list.size() - 1));

        setTitle("幻灯片播放");
        setSize(980, 720);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout(0, 10));

        picLabel.setOpaque(true);
        picLabel.setBackground(Color.BLACK);
        JScrollPane scrollPane = new JScrollPane(picLabel);
        scrollPane.getViewport().setBackground(Color.BLACK);
        add(scrollPane, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel();
        JButton lastBtn = new JButton("上一张");
        JButton nextBtn = new JButton("下一张");
        JButton bigBtn = new JButton("放大");
        JButton smallBtn = new JButton("缩小");
        JButton leftBtn = new JButton("左转90度");
        JButton rightBtn = new JButton("右转90度");
        JButton flipBtn = new JButton("水平翻转");

        lastBtn.addActionListener(e -> lastPic(true));
        nextBtn.addActionListener(e -> nextPic(true));
        bigBtn.addActionListener(e -> changeSize(0.2));
        smallBtn.addActionListener(e -> changeSize(-0.2));
        leftBtn.addActionListener(e -> rotateNow("left"));
        rightBtn.addActionListener(e -> rotateNow("right"));
        flipBtn.addActionListener(e -> rotateNow("flip"));
        playBtn.addActionListener(e -> autoPlay());

        btnPanel.add(lastBtn);
        btnPanel.add(nextBtn);
        btnPanel.add(bigBtn);
        btnPanel.add(smallBtn);
        btnPanel.add(leftBtn);
        btnPanel.add(rightBtn);
        btnPanel.add(flipBtn);
        btnPanel.add(playBtn);

        infoLabel.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));

        JPanel downPanel = new JPanel(new BorderLayout());
        downPanel.add(btnPanel, BorderLayout.CENTER);
        downPanel.add(infoLabel, BorderLayout.SOUTH);
        add(downPanel, BorderLayout.SOUTH);

        addKey();
        showPic();
    }

    private void addKey() {
        picLabel.getInputMap(JLabel.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("LEFT"), "left");
        picLabel.getInputMap(JLabel.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("RIGHT"), "right");
        picLabel.getInputMap(JLabel.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("ESCAPE"), "stop");

        picLabel.getActionMap().put("left", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                lastPic(true);
            }
        });

        picLabel.getActionMap().put("right", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                nextPic(true);
            }
        });

        picLabel.getActionMap().put("stop", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                stopPlay();
            }
        });
    }

    private void showPic() {
        if (list.isEmpty()) {
            picLabel.setIcon(null);
            picLabel.setText("当前文件夹没有图片");
            infoLabel.setText("当前没有可播放的图片");
            return;
        }

        File file = list.get(nowIndex);
        try {
            BufferedImage img = ImageUtils.readImage(file);
            BufferedImage newImg = ImageUtils.scaleImage(img, scale);
            picLabel.setIcon(new ImageIcon(newImg));
            picLabel.setText("");
            picLabel.setPreferredSize(new Dimension(newImg.getWidth(), newImg.getHeight()));
            picLabel.revalidate();
            setTitle("幻灯片播放 - " + file.getName());
            infoLabel.setText("图片：" + file.getName() + "  (" + (nowIndex + 1) + "/" + list.size() + ")  缩放：" + (int) (scale * 100) + "%");
        } catch (IOException e) {
            picLabel.setIcon(null);
            picLabel.setText("图片加载失败");
            infoLabel.setText("图片加载失败：" + file.getName());
        }
    }

    private void lastPic(boolean showMsg) {
        scale = 1.0;
        if (nowIndex == 0) {
            if (showMsg) {
                JOptionPane.showMessageDialog(this, "已经是第一张图片了。", "提示", JOptionPane.INFORMATION_MESSAGE);
            }
            return;
        }
        nowIndex--;
        showPic();
    }

    private void nextPic(boolean showMsg) {
        scale = 1.0;
        if (nowIndex >= list.size() - 1) {
            if (timer != null && timer.isRunning()) {
                stopPlay();
            }
            if (showMsg) {
                JOptionPane.showMessageDialog(this, "已经是最后一张图片了。", "提示", JOptionPane.INFORMATION_MESSAGE);
            }
            return;
        }
        nowIndex++;
        showPic();
    }

    private void changeSize(double n) {
        scale = scale + n;
        if (scale < 0.1) {
            scale = 0.1;
        }
        if (scale > 5.0) {
            scale = 5.0;
        }
        showPic();
    }

    private void rotateNow(String type) {
        if (list.isEmpty()) {
            return;
        }

        File file = list.get(nowIndex);
        boolean ok = false;

        if ("left".equals(type)) {
            ok = ImageUtils.rotateLeft(file);
        } else if ("right".equals(type)) {
            ok = ImageUtils.rotateRight(file);
        } else if ("flip".equals(type)) {
            ok = ImageUtils.flipHorizontal(file);
        }

        if (ok) {
            scale = 1.0;
            showPic();
        } else {
            JOptionPane.showMessageDialog(this, "图片处理失败。", "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void autoPlay() {
        if (timer == null) {
            timer = new Timer(1000, e -> nextPic(false));
        }

        if (timer.isRunning()) {
            stopPlay();
        } else {
            timer.start();
            playBtn.setText("停止");
            infoLabel.setText(infoLabel.getText() + "  |  自动播放中");
        }
    }

    private void stopPlay() {
        if (timer != null) {
            timer.stop();
        }
        playBtn.setText("播放");
    }
}
