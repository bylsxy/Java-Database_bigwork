package com.image.util;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class ImageUtils {
    public static ImageIcon getScaledIcon(File file, int w, int h) {
        try {
            BufferedImage img = ImageIO.read(file);
            if (img == null) {
                return new ImageIcon();
            }

            int oldW = img.getWidth();
            int oldH = img.getHeight();
            if (oldW <= 0 || oldH <= 0) {
                return new ImageIcon();
            }

            double r1 = (double) w / oldW;
            double r2 = (double) h / oldH;
            double r = Math.min(r1, r2);
            if (r > 1.0) {
                r = 1.0;
            }

            int newW = Math.max(1, (int) Math.round(oldW * r));
            int newH = Math.max(1, (int) Math.round(oldH * r));
            Image newImg = img.getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
            return new ImageIcon(newImg);
        } catch (IOException e) {
            return new ImageIcon();
        }
    }

    public static BufferedImage readImage(File file) throws IOException {
        BufferedImage img = ImageIO.read(file);
        if (img == null) {
            throw new IOException("Cannot read image file: " + file.getAbsolutePath());
        }
        return img;
    }

    public static BufferedImage scaleImage(BufferedImage img, double scale) {
        int w = Math.max(1, (int) Math.round(img.getWidth() * scale));
        int h = Math.max(1, (int) Math.round(img.getHeight() * scale));
        BufferedImage newImg = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = newImg.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g.drawImage(img, 0, 0, w, h, null);
        g.dispose();
        return newImg;
    }

    public static boolean rotateLeft(File file) {
        try {
            BufferedImage img = readImage(file);
            int w = img.getWidth();
            int h = img.getHeight();
            BufferedImage newImg = new BufferedImage(h, w, getType(file));
            Graphics2D g = newImg.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.translate(0, w);
            g.rotate(Math.toRadians(-90));
            g.drawImage(img, 0, 0, null);
            g.dispose();
            return saveImage(newImg, file);
        } catch (IOException e) {
            return false;
        }
    }

    public static boolean rotateRight(File file) {
        try {
            BufferedImage img = readImage(file);
            int w = img.getWidth();
            int h = img.getHeight();
            BufferedImage newImg = new BufferedImage(h, w, getType(file));
            Graphics2D g = newImg.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.translate(h, 0);
            g.rotate(Math.toRadians(90));
            g.drawImage(img, 0, 0, null);
            g.dispose();
            return saveImage(newImg, file);
        } catch (IOException e) {
            return false;
        }
    }

    public static boolean flipHorizontal(File file) {
        try {
            BufferedImage img = readImage(file);
            int w = img.getWidth();
            int h = img.getHeight();
            BufferedImage newImg = new BufferedImage(w, h, getType(file));
            Graphics2D g = newImg.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            AffineTransform at = new AffineTransform();
            at.scale(-1, 1);
            at.translate(-w, 0);
            g.drawImage(img, at, null);
            g.dispose();
            return saveImage(newImg, file);
        } catch (IOException e) {
            return false;
        }
    }

    private static boolean saveImage(BufferedImage img, File file) throws IOException {
        String ext = getExt(file.getName());
        BufferedImage out = img;

        if ("jpg".equals(ext) || "jpeg".equals(ext) || "bmp".equals(ext)) {
            BufferedImage rgb = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_RGB);
            Graphics2D g = rgb.createGraphics();
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, rgb.getWidth(), rgb.getHeight());
            g.drawImage(img, 0, 0, null);
            g.dispose();
            out = rgb;
        }

        return ImageIO.write(out, ext, file);
    }

    private static int getType(File file) {
        String ext = getExt(file.getName());
        if ("jpg".equals(ext) || "jpeg".equals(ext) || "bmp".equals(ext)) {
            return BufferedImage.TYPE_INT_RGB;
        }
        return BufferedImage.TYPE_INT_ARGB;
    }

    private static String getExt(String name) {
        int dot = name.lastIndexOf(".");
        if (dot < 0 || dot == name.length() - 1) {
            return "png";
        }
        return name.substring(dot + 1).toLowerCase();
    }
}
