package com.image.ui;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.io.File;

public class ImageLabel extends JPanel {
    private File file;
    private JLabel picLabel = new JLabel();
    private JLabel nameLabel = new JLabel();
    private boolean selected;

    public ImageLabel(File file, ImageIcon icon) {
        this.file = file;

        setLayout(new BorderLayout(0, 8));
        setPreferredSize(new Dimension(150, 170));
        setBackground(Color.WHITE);
        setOpaque(true);

        picLabel.setHorizontalAlignment(SwingConstants.CENTER);
        picLabel.setVerticalAlignment(SwingConstants.CENTER);
        picLabel.setPreferredSize(new Dimension(130, 120));
        picLabel.setIcon(icon);

        nameLabel.setHorizontalAlignment(SwingConstants.CENTER);
        nameLabel.setText("<html><div style='text-align:center;width:120px;'>" + file.getName() + "</div></html>");

        add(picLabel, BorderLayout.CENTER);
        add(nameLabel, BorderLayout.SOUTH);
        changeBorder();
    }

    public File getFile() {
        return file;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
        changeBorder();
    }

    private void changeBorder() {
        if (selected) {
            setBackground(new Color(220, 235, 255));
            setBorder(BorderFactory.createLineBorder(new Color(30, 100, 210), 2));
        } else {
            setBackground(Color.WHITE);
            setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(230, 230, 230)),
                    BorderFactory.createEmptyBorder(1, 1, 1, 1)
            ));
        }
        repaint();
    }
}
