package com.image.ui;

import com.image.util.ImageUtils;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JViewport;
import javax.swing.Scrollable;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeWillExpandListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.ExpandVetoException;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class MainFrame extends JFrame {
    private static final String TEMP_NODE = "正在加载...";

    private List<ImageLabel> picList = new ArrayList<>();
    private List<File> copyList = new ArrayList<>();

    private JLabel folderLabel = new JLabel("当前目录：未选择");
    private JLabel countLabel = new JLabel("图片数量：0");
    private JLabel tipLabel = new JLabel("提示：请先在目录树中选择一个文件夹");

    private JTree tree;
    private MyPanel picPanel;
    private JScrollPane picScroll;
    private JPopupMenu menu;
    private File nowFolder;

    public MainFrame() {
        setTitle("电子图片管理程序");
        setSize(1200, 820);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        initTree();
        initPicPanel();
        initMenu();

        JPanel rightPanel = new JPanel(new BorderLayout(0, 10));
        rightPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        rightPanel.add(topPanel(), BorderLayout.NORTH);
        picScroll = new JScrollPane(picPanel);
        picScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        picScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        picScroll.getVerticalScrollBar().setUnitIncrement(24);
        rightPanel.add(picScroll, BorderLayout.CENTER);

        JScrollPane leftScroll = new JScrollPane(tree);
        leftScroll.setPreferredSize(new Dimension(300, 0));

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftScroll, rightPanel);
        splitPane.setDividerLocation(320);

        tipLabel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(220, 220, 220)),
                BorderFactory.createEmptyBorder(8, 12, 8, 12)
        ));

        add(splitPane, BorderLayout.CENTER);
        add(tipLabel, BorderLayout.SOUTH);
    }

    private JPanel topPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        left.add(folderLabel);
        left.add(countLabel);

        JButton playBtn = new JButton("进入幻灯片播放");
        playBtn.addActionListener(e -> openPlay());

        panel.add(left, BorderLayout.WEST);
        panel.add(playBtn, BorderLayout.EAST);
        return panel;
    }

    private void initTree() {
        DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode("我的电脑");
        File[] roots = File.listRoots();
        if (roots != null) {
            for (File root : roots) {
                rootNode.add(makeNode(root));
            }
        }

        tree = new JTree(rootNode);
        tree.addTreeSelectionListener(e -> clickTree());
        tree.addTreeWillExpandListener(new TreeWillExpandListener() {
            @Override
            public void treeWillExpand(TreeExpansionEvent event) throws ExpandVetoException {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode) event.getPath().getLastPathComponent();
                addChildNode(node);
            }

            @Override
            public void treeWillCollapse(TreeExpansionEvent event) {
            }
        });
    }

    private void initPicPanel() {
        picPanel = new MyPanel();
        picPanel.setLayout(new FlowLayout(FlowLayout.LEFT, MyPanel.H_GAP, MyPanel.V_GAP));
        picPanel.setBackground(Color.WHITE);
    }

    private void initMenu() {
        menu = new JPopupMenu();

        JMenuItem copyItem = new JMenuItem("复制");
        JMenuItem pasteItem = new JMenuItem("粘贴");
        JMenuItem deleteItem = new JMenuItem("删除");
        JMenuItem renameItem = new JMenuItem("重命名");
        JMenuItem leftItem = new JMenuItem("向左旋转90度");
        JMenuItem rightItem = new JMenuItem("向右旋转90度");
        JMenuItem flipItem = new JMenuItem("水平翻转");

        copyItem.addActionListener(e -> copyPic());
        pasteItem.addActionListener(e -> pastePic());
        deleteItem.addActionListener(e -> deletePic());
        renameItem.addActionListener(e -> renamePic());
        leftItem.addActionListener(e -> editPic("left"));
        rightItem.addActionListener(e -> editPic("right"));
        flipItem.addActionListener(e -> editPic("flip"));

        menu.add(copyItem);
        menu.add(pasteItem);
        menu.addSeparator();
        menu.add(deleteItem);
        menu.add(renameItem);
        menu.addSeparator();
        menu.add(leftItem);
        menu.add(rightItem);
        menu.add(flipItem);
    }

    private DefaultMutableTreeNode makeNode(File folder) {
        DefaultMutableTreeNode node = new DefaultMutableTreeNode(folder);
        if (hasFolder(folder)) {
            node.add(new DefaultMutableTreeNode(TEMP_NODE));
        }
        return node;
    }

    private boolean hasFolder(File folder) {
        File[] arr = folder.listFiles(file -> file.isDirectory() && !file.isHidden());
        return arr != null && arr.length > 0;
    }

    private void addChildNode(DefaultMutableTreeNode node) {
        Object obj = node.getUserObject();
        if (!(obj instanceof File)) {
            return;
        }

        if (node.getChildCount() == 1) {
            DefaultMutableTreeNode first = (DefaultMutableTreeNode) node.getChildAt(0);
            if (!TEMP_NODE.equals(first.getUserObject())) {
                return;
            }
        } else if (node.getChildCount() > 1) {
            return;
        }

        node.removeAllChildren();
        File folder = (File) obj;
        File[] arr = folder.listFiles(file -> file.isDirectory() && !file.isHidden());
        if (arr != null) {
            List<File> list = new ArrayList<>(Arrays.asList(arr));
            list.sort(Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER));
            for (File f : list) {
                node.add(makeNode(f));
            }
        }
        ((DefaultTreeModel) tree.getModel()).reload(node);
    }

    private void clickTree() {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
        if (node == null || !(node.getUserObject() instanceof File)) {
            return;
        }

        nowFolder = (File) node.getUserObject();
        showPictures(nowFolder);
    }

    private void showPictures(File folder) {
        picPanel.removeAll();
        picList.clear();

        File[] files = folder.listFiles(this::isPic);
        List<File> list = new ArrayList<>();
        if (files != null) {
            list.addAll(Arrays.asList(files));
            list.sort(Comparator.comparing(File::getName, String.CASE_INSENSITIVE_ORDER));
        }

        for (File f : list) {
            ImageLabel label = new ImageLabel(f, ImageUtils.getScaledIcon(f, 120, 100));
            addPicEvent(label);
            picList.add(label);
            picPanel.add(label);
        }

        folderLabel.setText("当前目录：" + folder.getAbsolutePath());
        countLabel.setText("图片数量：" + list.size());

        picPanel.revalidate();
        picPanel.repaint();
        updateTip();
    }

    private void addPicEvent(ImageLabel label) {
        MouseAdapter mouse = new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (!SwingUtilities.isLeftMouseButton(e)) {
                    return;
                }

                if (e.getClickCount() == 2) {
                    openPlay(picList.indexOf(label));
                    return;
                }

                if (e.isControlDown()) {
                    label.setSelected(!label.isSelected());
                } else {
                    clearChoose();
                    label.setSelected(true);
                }
                updateTip();
            }

            @Override
            public void mousePressed(MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e)) {
                    if (!label.isSelected()) {
                        clearChoose();
                        label.setSelected(true);
                    }
                    updateTip();
                    menu.show((Component) e.getSource(), e.getX(), e.getY());
                }
            }
        };

        addMouse(label, mouse);
    }

    private void addMouse(Component com, MouseAdapter mouse) {
        com.addMouseListener(mouse);
        if (com instanceof JPanel) {
            Component[] arr = ((JPanel) com).getComponents();
            for (Component c : arr) {
                addMouse(c, mouse);
            }
        }
    }

    private void clearChoose() {
        for (ImageLabel label : picList) {
            label.setSelected(false);
        }
    }

    private void updateTip() {
        int chooseCount = 0;
        long total = 0;

        for (ImageLabel label : picList) {
            total += label.getFile().length();
            if (label.isSelected()) {
                chooseCount++;
            }
        }

        String name;
        if (nowFolder == null) {
            name = "未选择";
        } else {
            name = nowFolder.getAbsolutePath();
        }

        tipLabel.setText("提示：当前目录 " + name + "，共有 " + picList.size() + " 张图片，总大小 "
                + getSizeText(total) + "，已选中 " + chooseCount + " 张。");
    }

    private void copyPic() {
        copyList.clear();
        List<ImageLabel> chooseList = getChooseList();
        for (ImageLabel label : chooseList) {
            copyList.add(label.getFile());
        }

        if (copyList.isEmpty()) {
            JOptionPane.showMessageDialog(this, "请先选择图片。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        tipLabel.setText("提示：已复制 " + copyList.size() + " 张图片。");
    }

    private void pastePic() {
        if (nowFolder == null) {
            JOptionPane.showMessageDialog(this, "请先选择目标文件夹。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        if (copyList.isEmpty()) {
            JOptionPane.showMessageDialog(this, "没有可粘贴的图片。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        int ok = 0;
        for (File oldFile : copyList) {
            if (!oldFile.exists()) {
                continue;
            }

            File newFile = getNewFile(nowFolder, oldFile.getName());
            try {
                Files.copy(oldFile.toPath(), newFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
                ok++;
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "复制失败：" + oldFile.getName(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        }

        showPictures(nowFolder);
        tipLabel.setText("提示：成功粘贴 " + ok + " 张图片。");
    }

    private void deletePic() {
        List<ImageLabel> chooseList = getChooseList();
        if (chooseList.isEmpty()) {
            JOptionPane.showMessageDialog(this, "请先选择图片。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        int result = JOptionPane.showConfirmDialog(this,
                "确定删除选中的 " + chooseList.size() + " 张图片吗？",
                "确认删除",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);
        if (result != JOptionPane.YES_OPTION) {
            return;
        }

        int ok = 0;
        for (ImageLabel label : chooseList) {
            if (label.getFile().delete()) {
                ok++;
            }
        }

        showPictures(nowFolder);
        tipLabel.setText("提示：成功删除 " + ok + " 张图片。");
    }

    private void renamePic() {
        List<ImageLabel> chooseList = getChooseList();
        if (chooseList.isEmpty()) {
            JOptionPane.showMessageDialog(this, "请先选择图片。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        if (chooseList.size() == 1) {
            renameOne(chooseList.get(0));
        } else {
            renameMore(chooseList);
        }
    }

    private void renameOne(ImageLabel label) {
        File oldFile = label.getFile();
        String oldName = oldFile.getName();
        int dot = oldName.lastIndexOf(".");
        String ext = dot >= 0 ? oldName.substring(dot) : "";
        String base = dot >= 0 ? oldName.substring(0, dot) : oldName;

        String newBase = JOptionPane.showInputDialog(this, "请输入新的文件名（不含扩展名）：", base);
        if (newBase == null) {
            return;
        }

        newBase = newBase.trim();
        if (newBase.isEmpty()) {
            JOptionPane.showMessageDialog(this, "文件名不能为空。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        File newFile = new File(oldFile.getParentFile(), newBase + ext);
        if (newFile.exists() && !newFile.equals(oldFile)) {
            JOptionPane.showMessageDialog(this, "目标文件已存在。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        if (oldFile.renameTo(newFile)) {
            showPictures(nowFolder);
            tipLabel.setText("提示：已重命名为 " + newFile.getName() + "。");
        } else {
            JOptionPane.showMessageDialog(this, "重命名失败。", "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void renameMore(List<ImageLabel> chooseList) {
        String pre = JOptionPane.showInputDialog(this, "请输入名称前缀：", "NewName");
        if (pre == null || pre.trim().isEmpty()) {
            return;
        }

        Integer start = getInt("请输入起始编号：", 1);
        if (start == null) {
            return;
        }

        Integer width = getInt("请输入编号位数：", 4);
        if (width == null || width <= 0) {
            JOptionPane.showMessageDialog(this, "编号位数必须大于 0。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        List<ImageLabel> tempList = new ArrayList<>(chooseList);
        tempList.sort(Comparator.comparing(a -> a.getFile().getName(), String.CASE_INSENSITIVE_ORDER));

        List<File> newNames = new ArrayList<>();
        for (int i = 0; i < tempList.size(); i++) {
            File oldFile = tempList.get(i).getFile();
            String ext = getExt(oldFile.getName());
            String newName = pre.trim() + String.format("%0" + width + "d", start + i) + ext;
            File newFile = new File(oldFile.getParentFile(), newName);

            if (newFile.exists() && !newFile.equals(oldFile)) {
                JOptionPane.showMessageDialog(this,
                        "批量重命名失败，文件已存在：" + newFile.getName(),
                        "提示",
                        JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            newNames.add(newFile);
        }

        List<File> middleFiles = new ArrayList<>();
        for (int i = 0; i < tempList.size(); i++) {
            File oldFile = tempList.get(i).getFile();
            File middle = new File(oldFile.getParentFile(), oldFile.getName() + ".tmp" + System.nanoTime());
            if (!oldFile.renameTo(middle)) {
                JOptionPane.showMessageDialog(this, "批量重命名失败。", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }
            middleFiles.add(middle);
        }

        for (int i = 0; i < middleFiles.size(); i++) {
            if (!middleFiles.get(i).renameTo(newNames.get(i))) {
                JOptionPane.showMessageDialog(this, "批量重命名失败。", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        showPictures(nowFolder);
        tipLabel.setText("提示：成功批量重命名 " + chooseList.size() + " 张图片。");
    }

    private void editPic(String type) {
        List<ImageLabel> chooseList = getChooseList();
        if (chooseList.isEmpty()) {
            JOptionPane.showMessageDialog(this, "请先选择图片。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        int ok = 0;
        for (ImageLabel label : chooseList) {
            File file = label.getFile();
            boolean done = false;

            if ("left".equals(type)) {
                done = ImageUtils.rotateLeft(file);
            } else if ("right".equals(type)) {
                done = ImageUtils.rotateRight(file);
            } else if ("flip".equals(type)) {
                done = ImageUtils.flipHorizontal(file);
            }

            if (done) {
                ok++;
            }
        }

        if (nowFolder != null) {
            showPictures(nowFolder);
        }

        if (ok == chooseList.size()) {
            if ("left".equals(type)) {
                tipLabel.setText("提示：成功向左旋转 " + ok + " 张图片。");
            } else if ("right".equals(type)) {
                tipLabel.setText("提示：成功向右旋转 " + ok + " 张图片。");
            } else {
                tipLabel.setText("提示：成功水平翻转 " + ok + " 张图片。");
            }
        } else {
            JOptionPane.showMessageDialog(this, "有图片处理失败。", "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Integer getInt(String msg, int defaultValue) {
        String s = JOptionPane.showInputDialog(this, msg, defaultValue);
        if (s == null) {
            return null;
        }
        try {
            return Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "请输入有效的整数。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return null;
        }
    }

    private List<ImageLabel> getChooseList() {
        List<ImageLabel> list = new ArrayList<>();
        for (ImageLabel label : picList) {
            if (label.isSelected()) {
                list.add(label);
            }
        }
        return list;
    }

    private void openPlay() {
        if (picList.isEmpty()) {
            JOptionPane.showMessageDialog(this, "当前文件夹没有可以播放的图片。", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        openPlay(0);
    }

    private void openPlay(int index) {
        if (picList.isEmpty()) {
            return;
        }

        List<File> list = new ArrayList<>();
        for (ImageLabel label : picList) {
            list.add(label.getFile());
        }
        new SlideShowFrame(list, index).setVisible(true);
    }

    private File getNewFile(File folder, String oldName) {
        int dot = oldName.lastIndexOf(".");
        String base = dot >= 0 ? oldName.substring(0, dot) : oldName;
        String ext = dot >= 0 ? oldName.substring(dot) : "";

        File file = new File(folder, oldName);
        int i = 1;
        while (file.exists()) {
            file = new File(folder, base + "_copy" + i + ext);
            i++;
        }
        return file;
    }

    private boolean isPic(File folder, String name) {
        File file = new File(folder, name);
        if (!file.isFile() || file.isHidden()) {
            return false;
        }

        String s = name.toLowerCase();
        return s.endsWith(".jpg")
                || s.endsWith(".jpeg")
                || s.endsWith(".gif")
                || s.endsWith(".png")
                || s.endsWith(".bmp");
    }

    private String getExt(String name) {
        int dot = name.lastIndexOf(".");
        if (dot >= 0) {
            return name.substring(dot);
        }
        return "";
    }

    private String getSizeText(long size) {
        if (size < 1024) {
            return size + " B";
        }

        String[] unit = {"KB", "MB", "GB", "TB"};
        double num = size;
        int i = -1;
        while (num >= 1024 && i < unit.length - 1) {
            num /= 1024;
            i++;
        }
        return String.format("%.2f %s", num, unit[i]);
    }

    private class MyPanel extends JPanel implements Scrollable {
        private static final int H_GAP = 15;
        private static final int V_GAP = 15;
        private Point startPoint;
        private Rectangle rect;

        public MyPanel() {
            MouseAdapter mouse = new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    if (!SwingUtilities.isLeftMouseButton(e)) {
                        return;
                    }

                    if (findLabel(e.getPoint()) == null) {
                        clearChoose();
                        updateTip();
                    }

                    startPoint = e.getPoint();
                    rect = new Rectangle(startPoint);
                    repaint();
                }

                @Override
                public void mouseDragged(MouseEvent e) {
                    if (startPoint == null) {
                        return;
                    }

                    rect = makeRect(startPoint, e.getPoint());
                    chooseByRect(rect, e.isControlDown());
                    repaint();
                }

                @Override
                public void mouseReleased(MouseEvent e) {
                    startPoint = null;
                    rect = null;
                    repaint();
                    updateTip();
                }
            };

            addMouseListener(mouse);
            addMouseMotionListener(mouse);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (rect == null) {
                return;
            }

            Graphics2D g2 = (Graphics2D) g.create();
            g2.setColor(new Color(70, 130, 255, 50));
            g2.fill(rect);
            g2.setColor(new Color(70, 130, 255));
            g2.draw(rect);
            g2.dispose();
        }

        @Override
        public Dimension getPreferredSize() {
            Dimension preferred = super.getPreferredSize();
            int width = getScrollableWidth();
            if (width <= 0 || getComponentCount() == 0) {
                return preferred;
            }

            int rowWidth = 0;
            int rowHeight = 0;
            int totalHeight = V_GAP;
            int maxWidth = Math.max(1, width - getInsets().left - getInsets().right - H_GAP * 2);

            for (Component component : getComponents()) {
                if (!component.isVisible()) {
                    continue;
                }

                Dimension size = component.getPreferredSize();
                if (rowWidth == 0) {
                    rowWidth = size.width;
                    rowHeight = size.height;
                } else if (rowWidth + H_GAP + size.width <= maxWidth) {
                    rowWidth += H_GAP + size.width;
                    rowHeight = Math.max(rowHeight, size.height);
                } else {
                    totalHeight += rowHeight + V_GAP;
                    rowWidth = size.width;
                    rowHeight = size.height;
                }
            }

            if (rowWidth > 0) {
                totalHeight += rowHeight + V_GAP;
            }
            return new Dimension(width, Math.max(preferred.height, totalHeight));
        }

        @Override
        public Dimension getPreferredScrollableViewportSize() {
            return getPreferredSize();
        }

        @Override
        public int getScrollableUnitIncrement(Rectangle visibleRect, int orientation, int direction) {
            return 24;
        }

        @Override
        public int getScrollableBlockIncrement(Rectangle visibleRect, int orientation, int direction) {
            return Math.max(24, visibleRect.height - 24);
        }

        @Override
        public boolean getScrollableTracksViewportWidth() {
            return true;
        }

        @Override
        public boolean getScrollableTracksViewportHeight() {
            return false;
        }

        private void chooseByRect(Rectangle r, boolean addMode) {
            if (!addMode) {
                clearChoose();
            }
            for (ImageLabel label : picList) {
                if (r.intersects(label.getBounds())) {
                    label.setSelected(true);
                }
            }
            updateTip();
        }

        private ImageLabel findLabel(Point p) {
            for (ImageLabel label : picList) {
                if (label.getBounds().contains(p)) {
                    return label;
                }
            }
            return null;
        }

        private Rectangle makeRect(Point p1, Point p2) {
            int x = Math.min(p1.x, p2.x);
            int y = Math.min(p1.y, p2.y);
            int w = Math.abs(p1.x - p2.x);
            int h = Math.abs(p1.y - p2.y);
            return new Rectangle(x, y, w, h);
        }

        private int getScrollableWidth() {
            if (getParent() instanceof JViewport) {
                return getParent().getWidth();
            }
            return getWidth();
        }
    }
}
