import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.event.TreeWillExpandListener;
import javax.swing.tree.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.tree.TreeNode;

/**
 * 电子图片管理程序 - 主类
 * 实现图片预览和幻灯片播放功能
 */
public class ImageManager extends JFrame {
    
    // 主界面组件
    private JTree directoryTree;
    private JPanel thumbnailPanel;
    private JScrollPane thumbnailScrollPane;
    private JLabel statusLabel;
    private JTextField pathField;
    private JPanel headerPanel;
    
    // 幻灯片播放窗口
    private SlideShowWindow slideShowWindow;
    
    // 当前目录和图片列表
    private File currentDirectory;
    private List<File> currentImages;
    private List<File> selectedImages;
    
    // 剪贴板（用于复制粘贴）
    private List<File> clipboard;
    private boolean isCut = false;
    
    // 支持的图片格式
    private static final String[] IMAGE_EXTENSIONS = {"jpg", "jpeg", "gif", "png", "bmp"};
    
    // 缩略图大小
    private static final int THUMBNAIL_WIDTH = 120;
    private static final int THUMBNAIL_HEIGHT = 120;
    
    public ImageManager() {
        setTitle("电子图片管理程序");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        selectedImages = new ArrayList<>();
        currentImages = new ArrayList<>();
        clipboard = new ArrayList<>();
        
        initComponents();
        initMenuBar();
        initToolBar();
    }
    
    /**
     * 初始化界面组件
     */
    private void initComponents() {
        setLayout(new BorderLayout());
        
        // 顶部路径显示
        headerPanel = new JPanel(new BorderLayout());
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        topPanel.add(new JLabel("当前路径: "), BorderLayout.WEST);
        pathField = new JTextField();
        pathField.setEditable(false);
        topPanel.add(pathField, BorderLayout.CENTER);
        headerPanel.add(topPanel, BorderLayout.NORTH);
        add(headerPanel, BorderLayout.NORTH);
        
        // 创建分割面板
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(250);
        
        // 左侧目录树
        directoryTree = createDirectoryTree();
        JScrollPane treeScrollPane = new JScrollPane(directoryTree);
        treeScrollPane.setBorder(new TitledBorder("目录树"));
        splitPane.setLeftComponent(treeScrollPane);
        
        // 右侧缩略图面板（支持框选）
        thumbnailPanel = new SelectionPanel();
        thumbnailPanel.setBackground(Color.WHITE);
        thumbnailScrollPane = new JScrollPane(thumbnailPanel);
        thumbnailScrollPane.setBorder(new TitledBorder("图片预览"));
        thumbnailScrollPane.getVerticalScrollBar().setUnitIncrement(20);
        splitPane.setRightComponent(thumbnailScrollPane);
        
        add(splitPane, BorderLayout.CENTER);
        
        // 底部信息面板（包含提示信息和状态栏）
        JPanel bottomPanel = new JPanel(new BorderLayout());
        bottomPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
        
        // 提示信息区域（红色线标出部分）
        JLabel hintLabel = new JLabel("提示：单击选择图片，Ctrl+单击多选，Shift+单击范围选择，双击打开幻灯片播放");
        hintLabel.setForeground(Color.RED);
        hintLabel.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        bottomPanel.add(hintLabel, BorderLayout.NORTH);
        
        // 状态栏
        statusLabel = new JLabel("就绪");
        statusLabel.setBorder(new EmptyBorder(5, 0, 0, 0));
        bottomPanel.add(statusLabel, BorderLayout.CENTER);
        
        add(bottomPanel, BorderLayout.SOUTH);
    }
    
    /**
     * 创建目录树
     */
    private JTree createDirectoryTree() {
        // 获取所有根目录（Windows下是各个盘符）
        File[] roots = File.listRoots();
        DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode("我的电脑");
        
        for (File root : roots) {
            DefaultMutableTreeNode driveNode = new DefaultMutableTreeNode(root);
            rootNode.add(driveNode);
            // 添加占位节点，用于显示展开图标
            driveNode.add(new DefaultMutableTreeNode("loading..."));
        }
        
        DefaultTreeModel treeModel = new DefaultTreeModel(rootNode);
        JTree tree = new JTree(treeModel);
        tree.setCellRenderer(new DefaultTreeCellRenderer() {
            @Override
            public Component getTreeCellRendererComponent(JTree tree, Object value,
                    boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus) {
                super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
                DefaultMutableTreeNode node = (DefaultMutableTreeNode) value;
                Object userObject = node.getUserObject();
                if (userObject instanceof File) {
                    File file = (File) userObject;
                    setText(file.getAbsolutePath());
                    setIcon(UIManager.getIcon("FileView.hardDriveIcon"));
                } else {
                    setIcon(UIManager.getIcon("FileView.computerIcon"));
                }
                return this;
            }
        });
        
        // 监听树展开事件，动态加载子目录
        tree.addTreeWillExpandListener(new TreeWillExpandListener() {
            @Override
            public void treeWillExpand(TreeExpansionEvent event) {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode) event.getPath().getLastPathComponent();
                if (node.getChildCount() == 1 && 
                    ((DefaultMutableTreeNode)node.getFirstChild()).getUserObject().equals("loading...")) {
                    node.removeAllChildren();
                    loadChildren(node);
                    treeModel.reload(node);
                }
            }
            
            @Override
            public void treeWillCollapse(TreeExpansionEvent event) {}
        });
        
        // 监听树选择事件
        tree.addTreeSelectionListener(e -> {
            DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();
            if (node != null && node.getUserObject() instanceof File) {
                File dir = (File) node.getUserObject();
                if (dir.isDirectory()) {
                    loadImages(dir);
                }
            }
        });
        
        return tree;
    }
    
    /**
     * 加载子目录
     */
    private void loadChildren(DefaultMutableTreeNode parentNode) {
        File parent = (File) parentNode.getUserObject();
        File[] files = parent.listFiles(File::isDirectory);
        if (files != null) {
            Arrays.sort(files);
            for (File file : files) {
                if (!file.isHidden()) {
                    DefaultMutableTreeNode childNode = new DefaultMutableTreeNode(file);
                    parentNode.add(childNode);
                    // 如果有子目录，添加占位节点
                    File[] subDirs = file.listFiles(File::isDirectory);
                    if (subDirs != null && subDirs.length > 0) {
                        childNode.add(new DefaultMutableTreeNode("loading..."));
                    }
                }
            }
        }
    }
    
    /**
     * 加载指定目录下的图片
     */
    private void loadImages(File directory) {
        currentDirectory = directory;
        pathField.setText(directory.getAbsolutePath());
        
        currentImages.clear();
        selectedImages.clear();
        
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (isImageFile(file)) {
                    currentImages.add(file);
                }
            }
        }
        
        // 按文件名排序
        currentImages.sort(Comparator.comparing(File::getName));
        
        refreshThumbnailPanel();
        updateStatus();
    }
    
    /**
     * 判断文件是否为图片
     */
    private boolean isImageFile(File file) {
        if (!file.isFile()) return false;
        String name = file.getName().toLowerCase();
        for (String ext : IMAGE_EXTENSIONS) {
            if (name.endsWith("." + ext)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * 刷新缩略图面板
     */
    private void refreshThumbnailPanel() {
        thumbnailPanel.removeAll();
        
        for (File imageFile : currentImages) {
            ThumbnailLabel label = new ThumbnailLabel(imageFile);
            thumbnailPanel.add(label);
        }
        
        thumbnailPanel.revalidate();
        thumbnailPanel.repaint();
    }
    
    /**
     * 更新状态栏
     */
    private void updateStatus() {
        long directoryTotalSize = 0;
        for (File img : currentImages) {
            directoryTotalSize += img.length();
        }
        
        long selectedTotalSize = 0;
        for (File img : selectedImages) {
            selectedTotalSize += img.length();
        }
        
        String status = String.format("当前目录共 %d 张图片，总大小 %s；已选中 %d 张，选中图片总大小 %s",
            currentImages.size(),
            formatFileSize(directoryTotalSize),
            selectedImages.size(),
            formatFileSize(selectedTotalSize));
        statusLabel.setText(status);
    }
    
    /**
     * 格式化文件大小
     */
    private String formatFileSize(long size) {
        if (size < 1024) return size + " B";
        if (size < 1024 * 1024) return String.format("%.2f KB", size / 1024.0);
        return String.format("%.2f MB", size / (1024.0 * 1024));
    }
    
    /**
     * 初始化菜单栏
     */
    private void initMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        
        // 文件菜单
        JMenu fileMenu = new JMenu("文件");
        
        JMenuItem openFolderItem = new JMenuItem("打开文件夹");
        openFolderItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, KeyEvent.CTRL_DOWN_MASK));
        openFolderItem.addActionListener(e -> openFolder());
        fileMenu.add(openFolderItem);
        
        JMenuItem refreshItem = new JMenuItem("刷新");
        refreshItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F5, 0));
        refreshItem.addActionListener(e -> refreshCurrentFolder());
        fileMenu.add(refreshItem);
        
        fileMenu.addSeparator();
        
        JMenuItem newFolderItem = new JMenuItem("新建文件夹");
        newFolderItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, KeyEvent.CTRL_DOWN_MASK));
        newFolderItem.addActionListener(e -> createNewFolder());
        fileMenu.add(newFolderItem);
        
        fileMenu.addSeparator();
        
        JMenuItem bgColorItem = new JMenuItem("设置背景颜色");
        bgColorItem.addActionListener(e -> changeBackgroundColor());
        fileMenu.add(bgColorItem);
        
        fileMenu.addSeparator();
        
        JMenuItem exitItem = new JMenuItem("退出");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);
        menuBar.add(fileMenu);
        
        // 编辑菜单
        JMenu editMenu = new JMenu("编辑");
        
        JMenuItem copyItem = new JMenuItem("复制");
        copyItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, KeyEvent.CTRL_DOWN_MASK));
        copyItem.addActionListener(e -> copyImages());
        editMenu.add(copyItem);
        
        JMenuItem cutItem = new JMenuItem("剪切");
        cutItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, KeyEvent.CTRL_DOWN_MASK));
        cutItem.addActionListener(e -> cutImages());
        editMenu.add(cutItem);
        
        JMenuItem pasteItem = new JMenuItem("粘贴");
        pasteItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, KeyEvent.CTRL_DOWN_MASK));
        pasteItem.addActionListener(e -> pasteImages());
        editMenu.add(pasteItem);
        
        editMenu.addSeparator();
        
        JMenuItem deleteItem = new JMenuItem("删除");
        deleteItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0));
        deleteItem.addActionListener(e -> deleteImages());
        editMenu.add(deleteItem);
        
        JMenuItem renameItem = new JMenuItem("重命名");
        renameItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F2, 0));
        renameItem.addActionListener(e -> renameImage());
        editMenu.add(renameItem);
        
        menuBar.add(editMenu);
        
        // 播放菜单
        JMenu playMenu = new JMenu("播放");
        JMenuItem slideShowItem = new JMenuItem("幻灯片播放");
        slideShowItem.addActionListener(e -> startSlideShow());
        playMenu.add(slideShowItem);
        menuBar.add(playMenu);
        
        setJMenuBar(menuBar);
    }
    
    /**
     * 初始化工具栏
     */
    private void initToolBar() {
        JToolBar toolBar = new JToolBar();
        toolBar.setFloatable(false);
        
        JButton copyBtn = new JButton("复制");
        copyBtn.addActionListener(e -> copyImages());
        toolBar.add(copyBtn);
        
        JButton cutBtn = new JButton("剪切");
        cutBtn.addActionListener(e -> cutImages());
        toolBar.add(cutBtn);
        
        JButton pasteBtn = new JButton("粘贴");
        pasteBtn.addActionListener(e -> pasteImages());
        toolBar.add(pasteBtn);
        
        toolBar.addSeparator();
        
        JButton deleteBtn = new JButton("删除");
        deleteBtn.addActionListener(e -> deleteImages());
        toolBar.add(deleteBtn);
        
        JButton renameBtn = new JButton("重命名");
        renameBtn.addActionListener(e -> renameImage());
        toolBar.add(renameBtn);
        
        toolBar.addSeparator();
        
        JButton slideBtn = new JButton("幻灯片播放");
        slideBtn.addActionListener(e -> startSlideShow());
        toolBar.add(slideBtn);
        
        if (headerPanel != null) {
            headerPanel.add(toolBar, BorderLayout.SOUTH);
            headerPanel.revalidate();
        } else {
            add(toolBar, BorderLayout.NORTH);
        }
    }
    
    // ==================== 文件操作功能 ====================
    
    /**
     * 打开文件夹
     */
    private void openFolder() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        chooser.setDialogTitle("选择图片文件夹");
        
        int result = chooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File selectedFolder = chooser.getSelectedFile();
            loadImages(selectedFolder);
            
            // 在目录树中选中该文件夹
            selectNodeInTree(selectedFolder);
        }
    }
    
    /**
     * 在目录树中选中指定文件夹
     */
    private void selectNodeInTree(File folder) {
        DefaultTreeModel model = (DefaultTreeModel) directoryTree.getModel();
        DefaultMutableTreeNode root = (DefaultMutableTreeNode) model.getRoot();
        
        // 递归查找节点
        DefaultMutableTreeNode targetNode = findNode(root, folder);
        if (targetNode != null) {
            TreeNode[] path = model.getPathToRoot(targetNode);
            directoryTree.setSelectionPath(new TreePath(path));
            directoryTree.scrollPathToVisible(new TreePath(path));
        }
    }
    
    /**
     * 递归查找节点
     */
    private DefaultMutableTreeNode findNode(DefaultMutableTreeNode node, File target) {
        Object userObject = node.getUserObject();
        if (userObject instanceof File && ((File) userObject).equals(target)) {
            return node;
        }
        
        for (int i = 0; i < node.getChildCount(); i++) {
            DefaultMutableTreeNode child = (DefaultMutableTreeNode) node.getChildAt(i);
            DefaultMutableTreeNode found = findNode(child, target);
            if (found != null) {
                return found;
            }
        }
        return null;
    }
    
    /**
     * 刷新当前文件夹
     */
    private void refreshCurrentFolder() {
        if (currentDirectory != null) {
            loadImages(currentDirectory);
            statusLabel.setText("已刷新");
        } else {
            JOptionPane.showMessageDialog(this, "请先选择一个文件夹");
        }
    }
    
    /**
     * 新建文件夹
     */
    private void createNewFolder() {
        if (currentDirectory == null) {
            JOptionPane.showMessageDialog(this, "请先选择一个父目录");
            return;
        }
        
        String folderName = JOptionPane.showInputDialog(this, "请输入文件夹名称:");
        if (folderName != null && !folderName.trim().isEmpty()) {
            File newFolder = new File(currentDirectory, folderName.trim());
            if (newFolder.mkdir()) {
                JOptionPane.showMessageDialog(this, "文件夹创建成功");
                // 刷新目录树
                refreshDirectoryTree();
            } else {
                JOptionPane.showMessageDialog(this, "文件夹创建失败，可能已存在同名文件夹");
            }
        }
    }
    
    /**
     * 刷新目录树
     */
    private void refreshDirectoryTree() {
        // 重新加载当前选中节点的父节点
        DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) directoryTree.getLastSelectedPathComponent();
        if (selectedNode != null) {
            DefaultTreeModel model = (DefaultTreeModel) directoryTree.getModel();
            model.reload(selectedNode);
        }
    }
    
    /**
     * 修改背景颜色
     */
    private void changeBackgroundColor() {
        Color newColor = JColorChooser.showDialog(this, "选择背景颜色", thumbnailPanel.getBackground());
        if (newColor != null) {
            thumbnailPanel.setBackground(newColor);
            // 更新所有缩略图的背景色
            for (Component comp : thumbnailPanel.getComponents()) {
                if (comp instanceof ThumbnailLabel) {
                    ThumbnailLabel label = (ThumbnailLabel) comp;
                    if (!selectedImages.contains(label.getImageFile())) {
                        label.setBackground(newColor);
                    }
                }
            }
            thumbnailPanel.repaint();
        }
    }
    
    // ==================== 图片操作功能 ====================
    
    /**
     * 复制图片
     */
    private void copyImages() {
        if (selectedImages.isEmpty()) {
            JOptionPane.showMessageDialog(this, "请先选择要复制的图片");
            return;
        }
        clipboard.clear();
        clipboard.addAll(selectedImages);
        isCut = false;
        statusLabel.setText("已复制 " + selectedImages.size() + " 张图片");
    }
    
    /**
     * 剪切图片
     */
    private void cutImages() {
        if (selectedImages.isEmpty()) {
            JOptionPane.showMessageDialog(this, "请先选择要剪切的图片");
            return;
        }
        clipboard.clear();
        clipboard.addAll(selectedImages);
        isCut = true;
        statusLabel.setText("已剪切 " + selectedImages.size() + " 张图片");
    }
    
    /**
     * 粘贴图片
     */
    private void pasteImages() {
        if (clipboard.isEmpty()) {
            JOptionPane.showMessageDialog(this, "剪贴板为空");
            return;
        }
        if (currentDirectory == null) {
            JOptionPane.showMessageDialog(this, "请先选择一个目标目录");
            return;
        }
        
        int successCount = 0;
        for (File srcFile : clipboard) {
            File destFile = new File(currentDirectory, srcFile.getName());
            
            // 如果目标文件已存在，重命名
            int counter = 1;
            String baseName = getBaseName(srcFile.getName());
            String extension = getExtension(srcFile.getName());
            while (destFile.exists()) {
                destFile = new File(currentDirectory, baseName + "_" + counter + "." + extension);
                counter++;
            }
            
            try {
                if (isCut) {
                    Files.move(srcFile.toPath(), destFile.toPath());
                } else {
                    Files.copy(srcFile.toPath(), destFile.toPath());
                }
                successCount++;
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "操作失败: " + srcFile.getName());
            }
        }
        
        if (isCut) {
            clipboard.clear();
        }
        
        loadImages(currentDirectory);
        JOptionPane.showMessageDialog(this, "成功粘贴 " + successCount + " 张图片");
    }
    
    /**
     * 删除图片
     */
    private void deleteImages() {
        if (selectedImages.isEmpty()) {
            JOptionPane.showMessageDialog(this, "请先选择要删除的图片");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "确定要删除选中的 " + selectedImages.size() + " 张图片吗？",
            "确认删除", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            int successCount = 0;
            for (File file : selectedImages) {
                if (file.delete()) {
                    successCount++;
                }
            }
            selectedImages.clear();
            loadImages(currentDirectory);
            JOptionPane.showMessageDialog(this, "成功删除 " + successCount + " 张图片");
        }
    }
    
    /**
     * 重命名图片
     */
    private void renameImage() {
        if (selectedImages.isEmpty()) {
            JOptionPane.showMessageDialog(this, "请先选择要重命名的图片");
            return;
        }
        
        if (selectedImages.size() == 1) {
            File file = selectedImages.get(0);
            String oldBaseName = getBaseName(file.getName());
            String extension = getExtension(file.getName());
            String newBaseName = JOptionPane.showInputDialog(this, "请输入新的文件主名称（扩展名保持不变）:", oldBaseName);
            if (newBaseName != null && !newBaseName.trim().isEmpty()) {
                newBaseName = getBaseName(newBaseName.trim());
                File newFile = new File(file.getParentFile(), newBaseName + "." + extension);
                if (file.renameTo(newFile)) {
                    loadImages(currentDirectory);
                } else {
                    JOptionPane.showMessageDialog(this, "重命名失败");
                }
            }
        } else {
            String prefix = JOptionPane.showInputDialog(this, "请输入文件名前缀:");
            if (prefix != null && !prefix.trim().isEmpty()) {
                String startNumStr = JOptionPane.showInputDialog(this, "请输入起始编号:", "1");
                String digitCountStr = JOptionPane.showInputDialog(this, "请输入编号位数:", "3");
                
                try {
                    int startNum = Integer.parseInt(startNumStr);
                    int digitCount = Integer.parseInt(digitCountStr);
                    
                    int count = 0;
                    for (File file : selectedImages) {
                        String extension = getExtension(file.getName());
                        String newName = prefix.trim() + String.format("%0" + digitCount + "d", startNum + count) + "." + extension;
                        File newFile = new File(file.getParentFile(), newName);
                        file.renameTo(newFile);
                        count++;
                    }
                    loadImages(currentDirectory);
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "输入格式错误");
                }
            }
        }
    }
    
    /**
     * 获取文件名（不含扩展名）
     */
    private String getBaseName(String filename) {
        int dotIndex = filename.lastIndexOf('.');
        return dotIndex > 0 ? filename.substring(0, dotIndex) : filename;
    }
    
    /**
     * 获取文件扩展名
     */
    private String getExtension(String filename) {
        int dotIndex = filename.lastIndexOf('.');
        return dotIndex > 0 ? filename.substring(dotIndex + 1) : "";
    }
    
    /**
     * 开始幻灯片播放
     */
    private void startSlideShow() {
        if (currentImages.isEmpty()) {
            JOptionPane.showMessageDialog(this, "当前目录没有图片");
            return;
        }
        
        slideShowWindow = new SlideShowWindow(currentImages, 0);
        slideShowWindow.setVisible(true);
    }
    
    // ==================== 缩略图标签类 ====================
    
    /**
     * 缩略图标签类，用于显示图片缩略图
     */
    private class ThumbnailLabel extends JPanel {
        private File imageFile;
        private JLabel imageLabel;
        private JLabel nameLabel;
        private boolean selected = false;
        
        public ThumbnailLabel(File imageFile) {
            this.imageFile = imageFile;
            setLayout(new BorderLayout());
            setPreferredSize(new Dimension(THUMBNAIL_WIDTH + 20, THUMBNAIL_HEIGHT + 40));
            setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
            setBackground(Color.WHITE);
            setOpaque(true);
            
            // 图片缩略图
            imageLabel = new JLabel();
            imageLabel.setHorizontalAlignment(JLabel.CENTER);
            imageLabel.setPreferredSize(new Dimension(THUMBNAIL_WIDTH, THUMBNAIL_HEIGHT));
            imageLabel.setOpaque(false); // 透明，让父面板背景色显示
            loadThumbnail();
            add(imageLabel, BorderLayout.CENTER);
            
            // 文件名标签
            nameLabel = new JLabel(imageFile.getName());
            nameLabel.setHorizontalAlignment(JLabel.CENTER);
            nameLabel.setPreferredSize(new Dimension(THUMBNAIL_WIDTH, 20));
            nameLabel.setOpaque(false); // 透明，让父面板背景色显示
            add(nameLabel, BorderLayout.SOUTH);
            
            // 鼠标事件
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    handleClick(e);
                }
                
                @Override
                public void mousePressed(MouseEvent e) {
                    if (e.isPopupTrigger()) {
                        showContextMenu(e);
                    }
                }
                
                @Override
                public void mouseReleased(MouseEvent e) {
                    if (e.isPopupTrigger()) {
                        showContextMenu(e);
                    }
                }
            });
        }
        
        /**
         * 加载缩略图
         */
        private void loadThumbnail() {
            try {
                ImageIcon icon = createThumbnail(imageFile);
                imageLabel.setIcon(icon);
            } catch (Exception e) {
                imageLabel.setText("无法加载");
            }
        }
        
        /**
         * 获取图片文件
         */
        public File getImageFile() {
            return imageFile;
        }
        
        /**
         * 创建缩略图
         */
        private ImageIcon createThumbnail(File file) throws IOException {
            BufferedImage originalImage = ImageIO.read(file);
            if (originalImage == null) {
                return new ImageIcon();
            }
            
            int width = originalImage.getWidth();
            int height = originalImage.getHeight();
            
            // 计算缩放比例
            double scale = Math.min(
                (double) THUMBNAIL_WIDTH / width,
                (double) THUMBNAIL_HEIGHT / height
            );
            
            int newWidth = (int) (width * scale);
            int newHeight = (int) (height * scale);
            
            Image scaledImage = originalImage.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
            return new ImageIcon(scaledImage);
        }
        
        /**
         * 处理点击事件
         */
        private void handleClick(MouseEvent e) {
            if (e.getClickCount() == 2) {
                // 双击打开幻灯片播放，从当前图片开始播放所有图片
                slideShowWindow = new SlideShowWindow(currentImages, currentImages.indexOf(imageFile));
                slideShowWindow.setVisible(true);
            } else {
                // 单击选择
                if (e.isControlDown()) {
                    // Ctrl+点击：多选切换
                    toggleSelection();
                } else if (e.isShiftDown()) {
                    // Shift+点击：范围选择
                    rangeSelect();
                } else {
                    // 普通点击：单选
                    clearAllSelections();
                    setSelected(true);
                }
                updateStatus();
            }
        }
        
        /**
         * 切换选择状态
         */
        private void toggleSelection() {
            setSelected(!selected);
        }
        
        /**
         * 设置选择状态
         */
        public void setSelected(boolean selected) {
            this.selected = selected;
            if (selected) {
                setBackground(new Color(0, 200, 200)); // 深青色，更明显
                setBorder(BorderFactory.createLineBorder(Color.BLUE, 2));
                if (!selectedImages.contains(imageFile)) {
                    selectedImages.add(imageFile);
                }
            } else {
                setBackground(thumbnailPanel.getBackground()); // 使用面板背景色
                setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
                selectedImages.remove(imageFile);
            }
            repaint();
        }
        
        /**
         * 范围选择
         */
        private void rangeSelect() {
            if (selectedImages.isEmpty()) {
                setSelected(true);
                return;
            }
            
            File lastSelected = selectedImages.get(selectedImages.size() - 1);
            int lastIndex = currentImages.indexOf(lastSelected);
            int currentIndex = currentImages.indexOf(imageFile);
            
            int start = Math.min(lastIndex, currentIndex);
            int end = Math.max(lastIndex, currentIndex);
            
            for (int i = start; i <= end; i++) {
                File file = currentImages.get(i);
                if (!selectedImages.contains(file)) {
                    selectedImages.add(file);
                }
            }
            
            refreshThumbnailPanel();
        }
        
        /**
         * 清除所有选择
         */
        private void clearAllSelections() {
            selectedImages.clear();
            for (Component comp : thumbnailPanel.getComponents()) {
                if (comp instanceof ThumbnailLabel) {
                    ((ThumbnailLabel) comp).setSelected(false);
                }
            }
        }
        
        /**
         * 显示右键菜单
         */
        private void showContextMenu(MouseEvent e) {
            JPopupMenu menu = new JPopupMenu();
            
            JMenuItem copyItem = new JMenuItem("复制");
            copyItem.addActionListener(ev -> copyImages());
            menu.add(copyItem);
            
            JMenuItem cutItem = new JMenuItem("剪切");
            cutItem.addActionListener(ev -> cutImages());
            menu.add(cutItem);
            
            JMenuItem deleteItem = new JMenuItem("删除");
            deleteItem.addActionListener(ev -> deleteImages());
            menu.add(deleteItem);
            
            JMenuItem renameItem = new JMenuItem("重命名");
            renameItem.addActionListener(ev -> renameImage());
            menu.add(renameItem);
            
            menu.show(e.getComponent(), e.getX(), e.getY());
        }
    }
    
    // ==================== 幻灯片播放窗口 ====================
    
    /**
     * 幻灯片播放窗口类
     */
    private class SlideShowWindow extends JFrame {
        private List<File> images;
        private int currentIndex = 0;
        private JLabel imageLabel;
        private JLabel infoLabel;
        private Timer autoPlayTimer;
        private boolean isPlaying = false;
        private BufferedImage currentImage;
        private int interval = 1; // 默认1秒间隔
        
        public SlideShowWindow(List<File> images, int startIndex) {
            this.images = images;
            this.currentIndex = startIndex;
            
            setTitle("幻灯片播放");
            setSize(1000, 750);
            setLocationRelativeTo(ImageManager.this);
            setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            
            initComponents();
            showImage(currentIndex); // 显示起始图片
        }
        
        private void initComponents() {
            setLayout(new BorderLayout());
            
            // 图片显示区域（可拖拽）
            imageLabel = new JLabel();
            imageLabel.setHorizontalAlignment(JLabel.CENTER);
            imageLabel.setVerticalAlignment(JLabel.CENTER);
            imageLabel.setBackground(Color.BLACK);
            imageLabel.setOpaque(true);
            
            // 使用滚动面板实现拖拽移动
            JScrollPane scrollPane = new JScrollPane(imageLabel);
            scrollPane.setBackground(Color.BLACK);
            scrollPane.getViewport().setBackground(Color.BLACK);
            scrollPane.setBorder(null);
            scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
            
            // 添加鼠标拖拽监听器
            MouseAdapter dragAdapter = new MouseAdapter() {
                private Point startPoint;
                
                @Override
                public void mousePressed(MouseEvent e) {
                    startPoint = e.getPoint();
                    imageLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
                }
                
                @Override
                public void mouseReleased(MouseEvent e) {
                    imageLabel.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                }
                
                @Override
                public void mouseDragged(MouseEvent e) {
                    if (startPoint != null) {
                        JViewport viewport = scrollPane.getViewport();
                        Point viewPos = viewport.getViewPosition();
                        
                        int newX = viewPos.x + (startPoint.x - e.getX());
                        int newY = viewPos.y + (startPoint.y - e.getY());
                        
                        // 限制拖拽范围
                        int maxX = imageLabel.getWidth() - viewport.getWidth();
                        int maxY = imageLabel.getHeight() - viewport.getHeight();
                        
                        newX = Math.max(0, Math.min(newX, maxX));
                        newY = Math.max(0, Math.min(newY, maxY));
                        
                        viewport.setViewPosition(new Point(newX, newY));
                    }
                }
            };
            
            imageLabel.addMouseListener(dragAdapter);
            imageLabel.addMouseMotionListener(dragAdapter);
            
            add(scrollPane, BorderLayout.CENTER);
            
            // 顶部信息栏
            infoLabel = new JLabel(" ", JLabel.CENTER);
            infoLabel.setForeground(Color.WHITE);
            infoLabel.setBackground(new Color(50, 50, 50));
            infoLabel.setOpaque(true);
            infoLabel.setFont(new Font("微软雅黑", Font.PLAIN, 14));
            infoLabel.setBorder(new EmptyBorder(8, 10, 8, 10));
            add(infoLabel, BorderLayout.NORTH);
            
            // 底部控制面板
            JPanel controlPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
            controlPanel.setBackground(new Color(60, 60, 60));
            
            JButton prevBtn = new JButton("上一张");
            prevBtn.setFont(new Font("微软雅黑", Font.PLAIN, 13));
            prevBtn.addActionListener(e -> showPrevious());
            controlPanel.add(prevBtn);
            
            JButton playBtn = new JButton("播放");
            playBtn.setFont(new Font("微软雅黑", Font.PLAIN, 13));
            playBtn.addActionListener(e -> toggleAutoPlay());
            controlPanel.add(playBtn);
            
            JButton nextBtn = new JButton("下一张");
            nextBtn.setFont(new Font("微软雅黑", Font.PLAIN, 13));
            nextBtn.addActionListener(e -> showNext());
            controlPanel.add(nextBtn);
            
            controlPanel.add(new JLabel("  ")); // 间隔
            
            JButton zoomInBtn = new JButton("放大");
            zoomInBtn.setFont(new Font("微软雅黑", Font.PLAIN, 13));
            zoomInBtn.addActionListener(e -> zoomIn());
            controlPanel.add(zoomInBtn);
            
            JButton zoomOutBtn = new JButton("缩小");
            zoomOutBtn.setFont(new Font("微软雅黑", Font.PLAIN, 13));
            zoomOutBtn.addActionListener(e -> zoomOut());
            controlPanel.add(zoomOutBtn);
            
            JButton originalBtn = new JButton("原始大小");
            originalBtn.setFont(new Font("微软雅黑", Font.PLAIN, 13));
            originalBtn.addActionListener(e -> showOriginalSize());
            controlPanel.add(originalBtn);
            
            controlPanel.add(new JLabel("  ")); // 间隔
            
            // 播放间隔设置
            JLabel intervalLabel = new JLabel("间隔:");
            intervalLabel.setForeground(Color.WHITE);
            intervalLabel.setFont(new Font("微软雅黑", Font.PLAIN, 13));
            controlPanel.add(intervalLabel);
            
            JSpinner intervalSpinner = new JSpinner(new SpinnerNumberModel(1, 1, 60, 1));
            intervalSpinner.setFont(new Font("微软雅黑", Font.PLAIN, 13));
            intervalSpinner.setPreferredSize(new Dimension(60, 25));
            intervalSpinner.addChangeListener(e -> {
                interval = (Integer) intervalSpinner.getValue();
                if (isPlaying && autoPlayTimer != null) {
                    // 如果正在播放，重新设置间隔
                    autoPlayTimer.setDelay(interval * 1000);
                }
            });
            controlPanel.add(intervalSpinner);
            
            JLabel secondLabel = new JLabel("秒");
            secondLabel.setForeground(Color.WHITE);
            secondLabel.setFont(new Font("微软雅黑", Font.PLAIN, 13));
            controlPanel.add(secondLabel);
            
            controlPanel.add(new JLabel("  ")); // 间隔
            
            JButton exitBtn = new JButton("退出播放");
            exitBtn.setFont(new Font("微软雅黑", Font.PLAIN, 13));
            exitBtn.setBackground(new Color(200, 80, 80));
            exitBtn.addActionListener(e -> dispose());
            controlPanel.add(exitBtn);
            
            add(controlPanel, BorderLayout.SOUTH);
            
            // 键盘事件
            addKeyListener(new KeyAdapter() {
                @Override
                public void keyPressed(KeyEvent e) {
                    switch (e.getKeyCode()) {
                        case KeyEvent.VK_LEFT:
                        case KeyEvent.VK_UP:
                            showPrevious();
                            break;
                        case KeyEvent.VK_RIGHT:
                        case KeyEvent.VK_DOWN:
                        case KeyEvent.VK_SPACE:
                            showNext();
                            break;
                        case KeyEvent.VK_ENTER:
                            toggleAutoPlay();
                            break;
                        case KeyEvent.VK_ESCAPE:
                            dispose();
                            break;
                    }
                }
            });
            setFocusable(true);
        }
        
        /**
         * 显示指定索引的图片（自适应窗口大小）
         */
        private void showImage(int index) {
            if (index < 0 || index >= images.size()) return;
            
            currentIndex = index;
            File imageFile = images.get(currentIndex);
            
            try {
                currentImage = ImageIO.read(imageFile);
                if (currentImage != null) {
                    displayImageFitToWindow();
                    updateInfoLabel();
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this, "无法加载图片: " + imageFile.getName());
            }
        }
        
        /**
         * 更新信息标签
         */
        private void updateInfoLabel() {
            File imageFile = images.get(currentIndex);
            String playStatus = isPlaying ? " [播放中]" : "";
            infoLabel.setText(String.format("%s (%d/%d) - 分辨率: %d×%d%s",
                imageFile.getName(),
                currentIndex + 1,
                images.size(),
                currentImage.getWidth(),
                currentImage.getHeight(),
                playStatus));
        }
        
        /**
         * 显示适应窗口大小的图片（高质量）
         */
        private void displayImageFitToWindow() {
            if (currentImage == null) return;

            int imgWidth = currentImage.getWidth();
            int imgHeight = currentImage.getHeight();

            // 获取可用区域大小
            int availWidth = getWidth() - 40;
            int availHeight = getHeight() - 150;

            // 计算缩放比例，保持宽高比
            double scaleW = (double) availWidth / imgWidth;
            double scaleH = (double) availHeight / imgHeight;
            double scale = Math.min(scaleW, scaleH);

            // 如果图片比窗口小，显示原始大小
            if (scale > 1.0) scale = 1.0;

            int newWidth = (int) (imgWidth * scale);
            int newHeight = (int) (imgHeight * scale);

            // 使用 SCALE_SMOOTH 获得最佳缩放质量
            Image scaledImage = currentImage.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
            imageLabel.setIcon(new ImageIcon(scaledImage));
            imageLabel.setPreferredSize(new Dimension(newWidth, newHeight));
            imageLabel.revalidate();
        }
        
        /**
         * 显示原始大小
         */
        private void showOriginalSize() {
            if (currentImage != null) {
                imageLabel.setIcon(new ImageIcon(currentImage));
                imageLabel.setPreferredSize(new Dimension(currentImage.getWidth(), currentImage.getHeight()));
                imageLabel.revalidate();
            }
        }
        
        /**
         * 显示上一张
         */
        private void showPrevious() {
            if (currentIndex > 0) {
                showImage(currentIndex - 1);
                if (currentIndex == 0) {
                    infoLabel.setText(infoLabel.getText() + " - 已切换到第一张");
                }
            } else {
                JOptionPane.showMessageDialog(this, "已经是第一张图片");
            }
        }
        
        /**
         * 显示下一张
         */
        private void showNext() {
            if (currentIndex < images.size() - 1) {
                showImage(currentIndex + 1);
                if (currentIndex == images.size() - 1) {
                    infoLabel.setText(infoLabel.getText() + " - 已切换到最后一张");
                }
            } else {
                if (isPlaying && autoPlayTimer != null) {
                    autoPlayTimer.stop();
                    isPlaying = false;
                    updateInfoLabel();
                    infoLabel.setText(infoLabel.getText() + " - 已播放到最后一张");
                } else {
                    JOptionPane.showMessageDialog(this, "已经是最后一张图片");
                }
            }
        }
        
        /**
         * 放大
         */
        private void zoomIn() {
            if (currentImage == null) return;

            int newWidth = (int) (imageLabel.getIcon().getIconWidth() * 1.2);
            int newHeight = (int) (imageLabel.getIcon().getIconHeight() * 1.2);

            Image scaledImage = currentImage.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
            imageLabel.setIcon(new ImageIcon(scaledImage));
            imageLabel.setPreferredSize(new Dimension(newWidth, newHeight));
            imageLabel.revalidate();
        }

        /**
         * 缩小
         */
        private void zoomOut() {
            if (currentImage == null) return;

            int newWidth = (int) (imageLabel.getIcon().getIconWidth() / 1.2);
            int newHeight = (int) (imageLabel.getIcon().getIconHeight() / 1.2);

            Image scaledImage = currentImage.getScaledInstance(newWidth, newHeight, Image.SCALE_SMOOTH);
            imageLabel.setIcon(new ImageIcon(scaledImage));
            imageLabel.setPreferredSize(new Dimension(newWidth, newHeight));
            imageLabel.revalidate();
        }
        
        /**
         * 切换自动播放
         */
        private void toggleAutoPlay() {
            if (isPlaying) {
                // 停止播放
                if (autoPlayTimer != null) {
                    autoPlayTimer.stop();
                }
                isPlaying = false;
                updateInfoLabel();
            } else {
                // 开始播放
                isPlaying = true;
                autoPlayTimer = new Timer(interval * 1000, e -> {
                    showNext();
                });
                autoPlayTimer.start();
                updateInfoLabel();
            }
        }
        
        @Override
        public void dispose() {
            if (autoPlayTimer != null) {
                autoPlayTimer.stop();
            }
            super.dispose();
        }
    }
    
    // ==================== 框选面板类 ====================
    
    /**
     * 支持鼠标框选的面板
     */
    private class SelectionPanel extends JPanel {
        private Point startPoint;
        private Point currentPoint;
        private boolean isSelecting = false;
        private Rectangle selectionRect;
        
        public SelectionPanel() {
            setLayout(new FlowLayout(FlowLayout.LEFT, 10, 10));
            
            // 鼠标监听器
            MouseAdapter mouseAdapter = new MouseAdapter() {
                @Override
                public void mousePressed(MouseEvent e) {
                    // 只在空白区域开始框选
                    if (e.getComponent() == SelectionPanel.this) {
                        startPoint = e.getPoint();
                        currentPoint = e.getPoint();
                        isSelecting = true;
                        selectionRect = new Rectangle();
                    }
                }
                
                @Override
                public void mouseDragged(MouseEvent e) {
                    if (isSelecting) {
                        currentPoint = e.getPoint();
                        updateSelectionRect();
                        highlightSelectedLabels();
                        repaint();
                    }
                }
                
                @Override
                public void mouseReleased(MouseEvent e) {
                    if (isSelecting) {
                        isSelecting = false;
                        selectLabelsInRect();
                        repaint();
                        updateStatus();
                    }
                }
            };
            
            addMouseListener(mouseAdapter);
            addMouseMotionListener(mouseAdapter);
        }
        
        /**
         * 更新选框矩形
         */
        private void updateSelectionRect() {
            int x = Math.min(startPoint.x, currentPoint.x);
            int y = Math.min(startPoint.y, currentPoint.y);
            int width = Math.abs(currentPoint.x - startPoint.x);
            int height = Math.abs(currentPoint.y - startPoint.y);
            selectionRect.setBounds(x, y, width, height);
        }
        
        /**
         * 高亮显示框选范围内的标签
         */
        private void highlightSelectedLabels() {
            for (Component comp : getComponents()) {
                if (comp instanceof ThumbnailLabel) {
                    ThumbnailLabel label = (ThumbnailLabel) comp;
                    Rectangle labelRect = label.getBounds();
                    
                    if (selectionRect.intersects(labelRect)) {
                        // 预选中状态：浅蓝色背景 + 蓝色边框
                        label.setBackground(new Color(200, 230, 255));
                        label.setBorder(BorderFactory.createLineBorder(Color.BLUE, 2));
                    } else if (!selectedImages.contains(label.getImageFile())) {
                        // 未选中状态：使用面板背景色 + 无边框
                        label.setBackground(thumbnailPanel.getBackground());
                        label.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
                    }
                }
            }
        }
        
        /**
         * 选中框选范围内的所有图片
         */
        private void selectLabelsInRect() {
            boolean appendSelection = false;
            
            if (!appendSelection) {
                selectedImages.clear();
                for (Component comp : getComponents()) {
                    if (comp instanceof ThumbnailLabel) {
                        ((ThumbnailLabel) comp).setSelected(false);
                    }
                }
            }
            
            for (Component comp : getComponents()) {
                if (comp instanceof ThumbnailLabel) {
                    ThumbnailLabel label = (ThumbnailLabel) comp;
                    Rectangle labelRect = label.getBounds();
                    
                    if (selectionRect.intersects(labelRect)) {
                        label.setSelected(true);
                    }
                }
            }
            
            revalidate();
            repaint();
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            
            // 绘制选框
            if (isSelecting && selectionRect != null) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setColor(new Color(0, 120, 215, 50));
                g2d.fill(selectionRect);
                g2d.setColor(new Color(0, 120, 215));
                g2d.setStroke(new BasicStroke(1, BasicStroke.CAP_BUTT, 
                    BasicStroke.JOIN_BEVEL, 0, new float[]{5}, 0));
                g2d.draw(selectionRect);
                g2d.dispose();
            }
        }
    }
    
    // ==================== 主方法 ====================
    
    public static void main(String[] args) {
        // 设置外观
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        SwingUtilities.invokeLater(() -> {
            new ImageManager().setVisible(true);
        });
    }
}
