@echo off
chcp 65001 >nul
title 思维导图应用程序

REM 检查PowerShell是否可用，如果可用则使用PowerShell脚本
where powershell >nul 2>&1
if %errorlevel% == 0 (
    powershell -ExecutionPolicy Bypass -File "%~dp0运行.ps1"
    if %errorlevel% neq 0 (
        echo.
        echo PowerShell脚本执行失败，使用批处理脚本...
        echo.
        call "%~dp0运行.bat"
    )
) else (
    call "%~dp0运行.bat"
)

