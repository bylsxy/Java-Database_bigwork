@echo off
chcp 65001 > nul
cd /d "%~dp0"
echo Compiling...
javac -d bin -encoding UTF-8 src\mindmap\*.java
if %errorlevel% == 0 (
    echo SUCCESS
) else (
    echo FAILED
    pause
)


