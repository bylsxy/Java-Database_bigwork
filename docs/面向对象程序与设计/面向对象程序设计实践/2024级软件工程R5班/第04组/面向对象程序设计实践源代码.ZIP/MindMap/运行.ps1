# 思维导图应用程序 - 一键运行脚本
# PowerShell脚本

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "   思维导图应用程序 - 编译并运行" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# 创建必要的目录
if (-not (Test-Path "bin")) {
    New-Item -ItemType Directory -Path "bin" | Out-Null
    Write-Host "已创建 bin 目录" -ForegroundColor Green
}

if (-not (Test-Path "src\mindmap")) {
    New-Item -ItemType Directory -Path "src\mindmap" | Out-Null
    Write-Host "已创建 src\mindmap 目录" -ForegroundColor Green
    
    # 移动Java文件到正确位置
    if (Test-Path "src\*.java") {
        Get-ChildItem -Path "src\*.java" | Move-Item -Destination "src\mindmap\" -Force
        Write-Host "已移动Java文件到 src\mindmap 目录" -ForegroundColor Green
    }
}

Write-Host ""
Write-Host "正在编译Java文件..." -ForegroundColor Yellow

# 检查Java文件位置
$javaFiles = $null
if (Test-Path "src\mindmap\*.java") {
    $javaFiles = Get-ChildItem -Path "src\mindmap\*.java"
} elseif (Test-Path "src\*.java") {
    # 如果文件在src目录，移动到mindmap目录
    if (-not (Test-Path "src\mindmap")) {
        New-Item -ItemType Directory -Path "src\mindmap" | Out-Null
    }
    Get-ChildItem -Path "src\*.java" | Move-Item -Destination "src\mindmap\" -Force
    Write-Host "已移动Java文件到 src\mindmap 目录" -ForegroundColor Green
    $javaFiles = Get-ChildItem -Path "src\mindmap\*.java"
}

if ($null -eq $javaFiles -or $javaFiles.Count -eq 0) {
    Write-Host "错误: 未找到Java源文件！" -ForegroundColor Red
    Write-Host "请确保Java文件在 src\ 或 src\mindmap\ 目录下" -ForegroundColor Red
    pause
    exit 1
}

# 编译Java文件
$javaFilePaths = $javaFiles.FullName
javac -d bin -encoding UTF-8 $javaFilePaths

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "编译成功！" -ForegroundColor Green
    Write-Host ""
    Write-Host "正在启动程序..." -ForegroundColor Yellow
    Write-Host ""
    
    # 运行程序
    java -cp bin mindmap.MindMapFrame
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host ""
        Write-Host "程序运行出错！" -ForegroundColor Red
        pause
    }
} else {
    Write-Host ""
    Write-Host "编译失败！请检查错误信息。" -ForegroundColor Red
    pause
}

