@echo off
echo 正在启动思维导图应用程序...
java -cp bin mindmap.MindMapFrame
pause

