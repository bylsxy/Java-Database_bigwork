@echo off
chcp 65001 >nul
title 思维导图应用程序

echo ========================================
echo    思维导图应用程序 - 快速运行
echo ========================================
echo.

REM 创建目录
if not exist "bin" mkdir bin
if not exist "src\mindmap" mkdir "src\mindmap"

REM 移动Java文件（如果存在）
if exist "src\*.java" (
    for %%f in (src\*.java) do move "%%f" "src\mindmap\" >nul 2>&1
)

REM 编译（使用dir命令获取文件列表）
dir /b "src\mindmap\*.java" >nul 2>&1
if errorlevel 1 (
    echo 错误: 未找到Java源文件！
    pause
    exit /b 1
)

echo 正在编译...
for %%f in ("src\mindmap\*.java") do (
    javac -d bin -encoding UTF-8 "%%f"
    if errorlevel 1 (
        echo 编译失败！
        pause
        exit /b 1
    )
)

echo 编译成功！
echo.
echo 正在启动程序...
echo.

java -cp bin mindmap.MindMapFrame

if errorlevel 1 (
    echo.
    echo 程序运行出错！
    pause
)

