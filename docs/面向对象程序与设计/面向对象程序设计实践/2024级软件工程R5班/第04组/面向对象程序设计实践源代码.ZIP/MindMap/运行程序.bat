@echo off
chcp 65001
title 思维导图应用程序

cls
echo.
echo ========================================
echo    思维导图应用程序 - 启动脚本
echo ========================================
echo.

REM 切换到脚本所在目录
cd /d "%~dp0"

REM 检查Java环境
echo [1/4] 检查Java环境...
java -version >nul 2>&1
if errorlevel 1 (
    echo    错误: 未找到Java！请先安装Java JDK。
    echo.
    pause
    exit /b 1
)
javac -version >nul 2>&1
if errorlevel 1 (
    echo    错误: 未找到javac编译器！请先安装Java JDK。
    echo.
    pause
    exit /b 1
)
echo    通过

REM 创建目录
echo [2/4] 检查目录结构...
if not exist "bin" mkdir bin
if not exist "src\mindmap" mkdir "src\mindmap"
echo    通过

REM 检查源文件
echo [3/4] 检查Java源文件...
set FILE_COUNT=0
for %%f in ("src\mindmap\*.java") do set /a FILE_COUNT+=1
if %FILE_COUNT%==0 (
    echo    错误: 未找到Java源文件！
    echo    请确保Java文件在 src\mindmap\ 目录下
    echo.
    pause
    exit /b 1
)
echo    找到 %FILE_COUNT% 个Java文件

REM 编译
echo [4/4] 编译Java文件...
echo.
javac -d bin -encoding UTF-8 "src\mindmap\*.java" 2>&1
if errorlevel 1 (
    echo.
    echo ========================================
    echo 编译失败！请检查上面的错误信息。
    echo ========================================
    echo.
    pause
    exit /b 1
)

echo.
echo ========================================
echo 编译成功！
echo ========================================
echo.
echo 正在启动程序...
echo 如果程序窗口没有出现，请查看上面的信息。
echo.

REM 运行程序
java -cp bin mindmap.MindMapFrame

echo.
echo 程序已退出。
pause

