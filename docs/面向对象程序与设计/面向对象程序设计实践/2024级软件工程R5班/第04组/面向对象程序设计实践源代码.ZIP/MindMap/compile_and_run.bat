@echo off
echo 正在编译思维导图应用程序...
javac -d bin -encoding UTF-8 src\mindmap\*.java
if %errorlevel% == 0 (
    echo 编译成功！
    echo.
    echo 正在启动程序...
    java -cp bin mindmap.MindMapFrame
) else (
    echo 编译失败！
    pause
)

