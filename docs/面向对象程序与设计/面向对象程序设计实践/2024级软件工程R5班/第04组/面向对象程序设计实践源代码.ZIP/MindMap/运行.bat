@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion
echo ========================================
echo    思维导图应用程序 - 一键运行
echo ========================================
echo.

REM 创建必要的目录
if not exist "bin" (
    mkdir bin
    echo 已创建 bin 目录
)

REM 检查并整理Java文件位置
if not exist "src\mindmap" (
    mkdir "src\mindmap"
    echo 已创建 src\mindmap 目录
)

REM 如果src目录下有Java文件，移动到mindmap目录
if exist "src\*.java" (
    for %%f in (src\*.java) do (
        move "%%f" "src\mindmap\" >nul 2>&1
    )
    echo 已移动Java文件到 src\mindmap 目录
)

echo.
echo 正在编译Java文件...

REM 收集所有Java文件路径
set FILES=
for %%f in (src\mindmap\*.java) do (
    set FILES=!FILES! "%%f"
)

if "!FILES!"=="" (
    echo 错误: 未找到Java源文件！
    echo 请确保Java文件在 src\mindmap\ 目录下
    pause
    exit /b 1
)

REM 编译Java文件
javac -d bin -encoding UTF-8 !FILES!

if %errorlevel% == 0 (
    echo.
    echo 编译成功！
    echo.
    echo 正在启动程序...
    echo.
    
    REM 运行程序
    java -cp bin mindmap.MindMapFrame
    
    if %errorlevel% neq 0 (
        echo.
        echo 程序运行出错！
        pause
    )
) else (
    echo.
    echo 编译失败！请检查错误信息。
    pause
)

