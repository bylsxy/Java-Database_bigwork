@echo off
chcp 65001 >nul
title 思维导图应用程序

echo ========================================
echo    思维导图应用程序
echo ========================================
echo.

REM 检查Java是否安装
where java >nul 2>&1
if errorlevel 1 (
    echo [错误] 未找到Java！请先安装Java JDK。
    echo.
    pause
    exit /b 1
)

REM 检查javac是否安装
where javac >nul 2>&1
if errorlevel 1 (
    echo [错误] 未找到javac编译器！请先安装Java JDK。
    echo.
    pause
    exit /b 1
)

REM 创建必要的目录
if not exist "bin" (
    mkdir bin
    echo [信息] 已创建 bin 目录
)

if not exist "src\mindmap" (
    mkdir "src\mindmap"
    echo [信息] 已创建 src\mindmap 目录
)

REM 清理src目录下可能存在的重复Java文件
if exist "src\*.java" (
    echo [信息] 发现src目录下有Java文件，正在清理...
    for %%f in ("src\*.java") do (
        if not exist "src\mindmap\%%~nxf" (
            move "%%f" "src\mindmap\" >nul 2>&1
        ) else (
            del "%%f" >nul 2>&1
        )
    )
    echo [信息] 文件已整理完成
    echo.
)

REM 检查Java文件是否存在
dir /b "src\mindmap\*.java" >nul 2>&1
if errorlevel 1 (
    echo [错误] 未找到Java源文件！
    echo [错误] 请确保Java文件在 src\mindmap\ 目录下
    echo.
    pause
    exit /b 1
)

echo [信息] 找到以下Java文件：
dir /b "src\mindmap\*.java"
echo.

echo ========================================
echo 正在编译Java文件...
echo ========================================
echo.

REM 清空bin目录中的旧文件
if exist "bin\mindmap\*.class" del /q "bin\mindmap\*.class" >nul 2>&1

REM 使用for循环逐个编译所有Java文件
set COMPILE_ERROR=0
for %%f in ("src\mindmap\*.java") do (
    echo [编译] %%~nxf
    javac -d bin -encoding UTF-8 "%%f"
    if errorlevel 1 (
        echo [错误] 编译失败: %%~nxf
        set COMPILE_ERROR=1
    ) else (
        echo [成功] %%~nxf
    )
)

echo.

if %COMPILE_ERROR%==1 (
    echo ========================================
    echo 编译失败！请检查上面的错误信息。
    echo ========================================
    echo.
    pause
    exit /b 1
)

echo ========================================
echo 编译成功！所有文件已编译完成。
echo ========================================
echo.

REM 检查主类是否存在
if not exist "bin\mindmap\MindMapFrame.class" (
    echo [错误] 未找到主类文件！
    echo.
    pause
    exit /b 1
)

echo ========================================
echo 正在启动程序...
echo ========================================
echo.
echo 如果程序窗口没有出现，请检查上面的错误信息。
echo.

REM 运行程序
java -cp bin mindmap.MindMapFrame

set RUN_ERROR=%errorlevel%

echo.
if %RUN_ERROR% neq 0 (
    echo ========================================
    echo 程序运行出错！错误代码: %RUN_ERROR%
    echo ========================================
    echo.
)

pause
