package mindmap;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.io.*;

/**
 * 文件管理器，负责保存和加载思维导图
 */
public class FileManager {
    
    public static void saveMindMap(MindMap mindMap, JFrame parent) {
        if (mindMap == null) return;
        
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("保存思维导图");
        fileChooser.setFileFilter(new FileNameExtensionFilter("思维导图文件 (*.dt)", "dt"));
        
        // 如果文件已保存过，使用原文件名
        if (mindMap.getName() != null && !mindMap.getName().equals("未命名思维导图")) {
            File currentFile = new File(mindMap.getName() + ".dt");
            fileChooser.setSelectedFile(currentFile);
        }
        
        int result = fileChooser.showSaveDialog(parent);
        if (result == JFileChooser.APPROVE_OPTION) {//若点击保存
            File file = fileChooser.getSelectedFile();
            String fileName = file.getName();
            
            // 确保文件扩展名为.dt
            if (!fileName.endsWith(".dt")) {
                file = new File(file.getParent(), fileName + ".dt");
            }
            
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(file))) {
                oos.writeObject(mindMap);
                mindMap.setName(file.getName().replace(".dt", ""));//去掉后缀dt
                JOptionPane.showMessageDialog(parent, "保存成功！", "提示", JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(parent, "保存失败：" + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    public static MindMap loadMindMap(JFrame parent) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("打开思维导图");
        fileChooser.setFileFilter(new FileNameExtensionFilter("思维导图文件 (*.dt)", "dt"));
        
        int result = fileChooser.showOpenDialog(parent);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
                MindMap mindMap = (MindMap) ois.readObject();
                mindMap.setName(file.getName().replace(".dt", ""));
                return mindMap;
            } catch (IOException | ClassNotFoundException e) {
                JOptionPane.showMessageDialog(parent, "打开失败：" + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
                return null;
            }
        }
        
        return null;
    }
}

