package mindmap;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 布局管理器，负责计算节点的位置 (已加入动态防重叠重排算法)
 */
public class LayoutManager {

    /**
     * 全局布局：应用到整个思维导图
     */
    public static void applyLayout(MindMapNode rootNode, LayoutType layoutType) {
        if (rootNode == null) return;
        switch (layoutType) {
            case AUTO:  applyAutoLayout(rootNode);  break;
            case LEFT:  applyLeftLayout(rootNode);  break;
            case RIGHT: applyRightLayout(rootNode); break;
        }
    }

    /**
     * 局部布局：将指定的节点移动到特定的侧面，并防止兄弟节点重叠
     */
    public static void applySubtreeLayout(MindMapNode node, LayoutType type) {
        if (node == null || node.getParent() == null) return;

        MindMapNode parent = node.getParent();
        Point parentPos = parent.getPosition();
        Dimension parentSize = parent.getSize();

        // 1. 先粗略改变目标节点的 X 坐标，将其扔到对应的方向
        int newX;
        if (type == LayoutType.LEFT) {
            newX = parentPos.x - MindMapNode.HORIZONTAL_SPACING - node.getSize().width;
            node.setPosition(newX, node.getPosition().y);
        } else if (type == LayoutType.RIGHT || type == LayoutType.AUTO) {
            // AUTO 针对单个分支时，默认向外（右侧）发散
            newX = parentPos.x + parentSize.width + MindMapNode.HORIZONTAL_SPACING;
            node.setPosition(newX, node.getPosition().y);
        }

        // 2. 核心修复：重新整理父节点的所有子节点（按当前左右位置重新上下对齐，消除重叠）
        realignSiblings(parent);
    }

    /**
     * 重新整理兄弟节点：防重叠核心算法
     */
    private static void realignSiblings(MindMapNode parent) {
        if (parent == null) return;
        List<MindMapNode> lefties = new ArrayList<>();
        List<MindMapNode> righties = new ArrayList<>();

        int parentCenterX = parent.getPosition().x + parent.getSize().width / 2;

        // 根据当前 X 坐标，区分哪些节点在左侧，哪些在右侧
        for (MindMapNode child : parent.getChildren()) {
            int childCenterX = child.getPosition().x + child.getSize().width / 2;
            if (childCenterX < parentCenterX) {
                lefties.add(child);
            } else {
                righties.add(child);
            }
        }

        int parentY = parent.getPosition().y + parent.getSize().height / 2;

        // 整理左侧的节点，平均分布 Y 坐标
        if (!lefties.isEmpty()) {
            int leftHeight = calculateTotalHeight(lefties);
            int leftStartY = parentY - leftHeight / 2;
            layoutChildrenLeft(lefties, parent, leftStartY);
            // 递归重排左侧子节点的子树
            for (MindMapNode child : lefties) applyLeftLayout(child);
        }

        // 整理右侧的节点，平均分布 Y 坐标
        if (!righties.isEmpty()) {
            int rightHeight = calculateTotalHeight(righties);
            int rightStartY = parentY - rightHeight / 2;
            layoutChildrenRight(righties, parent, rightStartY);
            // 递归重排右侧子节点的子树
            for (MindMapNode child : righties) applyRightLayout(child);
        }
    }

    // ================================================================
    //  AUTO 布局：标准的思维导图平衡布局（中心辐射，左右交替发散）
    // ================================================================
    private static void applyAutoLayout(MindMapNode root) {
        if (root == null) return;
        List<MindMapNode> children = root.getChildren();
        if (children.isEmpty()) return;

        List<MindMapNode> rightChildren = new ArrayList<>();
        List<MindMapNode> leftChildren = new ArrayList<>();

        for (int i = 0; i < children.size(); i++) {
            if (i % 2 == 0) rightChildren.add(children.get(i));
            else leftChildren.add(children.get(i));
        }

        int rootY = root.getPosition().y + root.getSize().height / 2;

        if (!rightChildren.isEmpty()) {
            int rightHeight = calculateTotalHeight(rightChildren);
            int rightStartY = rootY - rightHeight / 2;
            layoutChildrenRight(rightChildren, root, rightStartY);
            for (MindMapNode child : rightChildren) applyRightLayout(child);
        }

        if (!leftChildren.isEmpty()) {
            int leftHeight = calculateTotalHeight(leftChildren);
            int leftStartY = rootY - leftHeight / 2;
            layoutChildrenLeft(leftChildren, root, leftStartY);
            for (MindMapNode child : leftChildren) applyLeftLayout(child);
        }
    }

    // ================================================================
    //  LEFT 布局：所有子节点在左侧（水平）
    // ================================================================
    private static void applyLeftLayout(MindMapNode node) {
        if (node == null) return;
        List<MindMapNode> children = node.getChildren();
        if (children.isEmpty()) return;
        int totalHeight = calculateTotalHeight(children);
        int startY = node.getPosition().y + node.getSize().height / 2 - totalHeight / 2;
        layoutChildrenLeft(children, node, startY);
        for (MindMapNode child : children) applyLeftLayout(child);
    }

    // ================================================================
    //  RIGHT 布局：所有子节点在右侧（水平）
    // ================================================================
    private static void applyRightLayout(MindMapNode node) {
        if (node == null) return;
        List<MindMapNode> children = node.getChildren();
        if (children.isEmpty()) return;
        int totalHeight = calculateTotalHeight(children);
        int startY = node.getPosition().y + node.getSize().height / 2 - totalHeight / 2;
        layoutChildrenRight(children, node, startY);
        for (MindMapNode child : children) applyRightLayout(child);
    }

    private static void layoutChildrenLeft(List<MindMapNode> children, MindMapNode parent, int startY) {
        int currentY = startY;
        Point parentPos = parent.getPosition();
        for (MindMapNode child : children) {
            int childHeight = calculateNodeHeight(child);
            int childY = currentY + childHeight / 2 - child.getSize().height / 2;
            child.setPosition(parentPos.x - MindMapNode.HORIZONTAL_SPACING - child.getSize().width, childY);
            currentY += childHeight + MindMapNode.VERTICAL_SPACING;
        }
    }

    private static void layoutChildrenRight(List<MindMapNode> children, MindMapNode parent, int startY) {
        int currentY = startY;
        Point parentPos = parent.getPosition();
        for (MindMapNode child : children) {
            int childHeight = calculateNodeHeight(child);
            int childY = currentY + childHeight / 2 - child.getSize().height / 2;
            child.setPosition(parentPos.x + parent.getSize().width + MindMapNode.HORIZONTAL_SPACING, childY);
            currentY += childHeight + MindMapNode.VERTICAL_SPACING;
        }
    }

    private static int calculateNodeHeight(MindMapNode node) {
        List<MindMapNode> children = node.getChildren();
        if (children.isEmpty()) return node.getSize().height;
        int total = 0;
        for (MindMapNode child : children)
            total += calculateNodeHeight(child) + MindMapNode.VERTICAL_SPACING;
        return Math.max(node.getSize().height, total - MindMapNode.VERTICAL_SPACING);
    }

    private static int calculateTotalHeight(List<MindMapNode> nodes) {
        if (nodes.isEmpty()) return 0;
        int total = 0;
        for (MindMapNode node : nodes)
            total += calculateNodeHeight(node) + MindMapNode.VERTICAL_SPACING;
        return total - MindMapNode.VERTICAL_SPACING;
    }
}