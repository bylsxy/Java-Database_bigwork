package mindmap;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import java.awt.*;

/**
 * 思维导图树形结构展示面板
 */
public class TreePanel extends JPanel {
    private JTree tree;
    private DefaultTreeModel treeModel;
    private DefaultMutableTreeNode rootTreeNode;
    
    public TreePanel() {
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(250, 600));
        TitledBorder tb = BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(160, 170, 210), 1, true), "思维导图结构");
        tb.setTitleFont(new Font("微软雅黑", Font.BOLD, 13));
        tb.setTitleColor(Color.BLACK);
        setBorder(tb);
        
        rootTreeNode = new DefaultMutableTreeNode("中心节点");
        treeModel = new DefaultTreeModel(rootTreeNode);
        tree = new JTree(treeModel);
        tree.setRootVisible(true);
        tree.setShowsRootHandles(true);
        
        JScrollPane scrollPane = new JScrollPane(tree);
        scrollPane.setPreferredSize(new Dimension(250, 600));
        add(scrollPane, BorderLayout.CENTER);
    }
    
    public void updateTree(MindMap mindMap) {
        if (mindMap == null || mindMap.getRootNode() == null) {
            rootTreeNode.removeAllChildren();
            treeModel.reload();
            return;
        }
        
        rootTreeNode.removeAllChildren();
        buildTree(rootTreeNode, mindMap.getRootNode());
        treeModel.reload();
        
        // 展开所有节点
        for (int i = 0; i < tree.getRowCount(); i++) {
            tree.expandRow(i);
        }
    }
    
    private void buildTree(DefaultMutableTreeNode treeNode, MindMapNode node) {
        for (MindMapNode child : node.getChildren()) {
            DefaultMutableTreeNode childTreeNode = new DefaultMutableTreeNode(child.getText());
            treeNode.add(childTreeNode);
            buildTree(childTreeNode, child);
        }
    }
}

