package mindmap;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 思维导图主窗口
 */
public class MindMapFrame extends JFrame {
    private MindMapPanel mindMapPanel;
    private TreePanel treePanel;
    private JLabel nameLabel;
    private JComboBox<LayoutType> layoutComboBox;
    private JPanel colorPanel;
    private List<MindMap> savedMindMaps = new ArrayList<>();
    private JPanel savedMapsListPanel;

    // 撤销重做模块
    private HistoryManager historyManager;
    private JButton undoBtn;
    private JButton redoBtn;

    public MindMapFrame() {
        historyManager = new HistoryManager(this);
        initializeUI();
    }

    private void initializeUI() {
        setTitle("思维导图应用程序");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel contentPane = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(
                        0, 0, new Color(0xE8, 0xEE, 0xFF),
                        getWidth(), getHeight(), new Color(0xD0, 0xDE, 0xFF));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        contentPane.setOpaque(true);
        setContentPane(contentPane);

        // 绑定键盘快捷键 Ctrl+Z, Ctrl+Y
        setupShortcuts(contentPane);

        contentPane.add(createToolbar(), BorderLayout.NORTH);
        JSplitPane main = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        main.setOpaque(false);
        mindMapPanel = new MindMapPanel(this);
        JScrollPane drawScroll = new JScrollPane(mindMapPanel);
        drawScroll.setBorder(boldBorder("绘图区"));
        colorPanel = createColorPanel();
        JPanel leftToolbar = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        leftToolbar.setOpaque(false);
        leftToolbar.add(colorPanel);
        leftToolbar.add(createConnectorPanel());
        JPanel left = new JPanel(new BorderLayout());
        left.setOpaque(false);
        left.add(leftToolbar, BorderLayout.NORTH);
        left.add(drawScroll, BorderLayout.CENTER);
        main.setLeftComponent(left);
        treePanel = new TreePanel();
        JSplitPane rightPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        rightPane.setOpaque(false);
        rightPane.setTopComponent(treePanel);
        rightPane.setBottomComponent(createLayoutAndSavePanel());
        rightPane.setResizeWeight(0.45);
        main.setRightComponent(rightPane);
        main.setDividerLocation(750);
        main.setResizeWeight(0.7);
        contentPane.add(main, BorderLayout.CENTER);

        // 初始化一次初始状态
        historyManager.saveState(mindMapPanel.getMindMap());
        updateTreePanel();

        setSize(1200, 800);
        setLocationRelativeTo(null);
    }

    private void setupShortcuts(JPanel contentPane) {
        InputMap im = contentPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        ActionMap am = contentPane.getActionMap();
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_Z, InputEvent.CTRL_DOWN_MASK), "Undo");
        am.put("Undo", new AbstractAction() { public void actionPerformed(ActionEvent e) { undo(); } });
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_Y, InputEvent.CTRL_DOWN_MASK), "Redo");
        am.put("Redo", new AbstractAction() { public void actionPerformed(ActionEvent e) { redo(); } });
    }

    private JPanel createToolbar() {
        JPanel tb = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                GradientPaint gp = new GradientPaint(0, 0, new Color(0x4A, 0x5C, 0xCC),
                        getWidth(), 0, new Color(0x6A, 0x82, 0xEE));
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        tb.setOpaque(true);
        tb.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));
        nameLabel = new JLabel("未命名思维导图");
        nameLabel.setFont(new Font("微软雅黑", Font.BOLD, 14));
        nameLabel.setForeground(Color.WHITE);
        tb.add(nameLabel, BorderLayout.WEST);

        JPanel bp = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 0));
        bp.setOpaque(false);

        // 文件操作
        bp.add(makeToolBtn("新建", this::newMindMap));
        bp.add(makeToolBtn("打开", this::openMindMap));
        bp.add(makeToolBtn("保存", this::saveMindMap));
        bp.add(makeToolBtn("导出", this::exportMindMap));

        // 撤销重做按钮
        undoBtn = makeToolBtn("撤销 (Ctrl+Z)", this::undo);
        redoBtn = makeToolBtn("重做 (Ctrl+Y)", this::redo);
        bp.add(undoBtn);
        bp.add(redoBtn);

        // 节点操作
        bp.add(makeToolBtn("添加节点", this::addNode));
        bp.add(makeToolBtn("删除节点", this::deleteSelectedNode));

        bp.add(makeToolLabel("布局："));
        layoutComboBox = new JComboBox<>(LayoutType.values());
        layoutComboBox.setSelectedItem(LayoutType.AUTO);
        layoutComboBox.setFont(new Font("微软雅黑", Font.BOLD, 12));
        layoutComboBox.setForeground(Color.BLACK);
        layoutComboBox.addActionListener(e -> changeLayout());
        bp.add(layoutComboBox);

        bp.add(makeToolBtn("－", () -> mindMapPanel.zoomOut()));
        bp.add(makeToolBtn("100%", () -> mindMapPanel.resetView()));
        bp.add(makeToolBtn("＋", () -> mindMapPanel.zoomIn()));

        updateUndoRedoButtons();
        tb.add(bp, BorderLayout.EAST);
        return tb;
    }

    private JButton makeToolBtn(String text, Runnable action) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("微软雅黑", Font.BOLD, 12));
        btn.setForeground(Color.BLACK);
        btn.setBackground(new Color(255, 255, 255, 200));
        btn.setOpaque(true);
        btn.setBorderPainted(true);
        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 190, 230), 1, true),
                BorderFactory.createEmptyBorder(3, 8, 3, 8)));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addActionListener(e -> action.run());
        return btn;
    }

    private JLabel makeToolLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setForeground(Color.BLACK);
        lbl.setFont(new Font("微软雅黑", Font.BOLD, 12));
        return lbl;
    }

    // ---------- 对外暴露供 Panel 调用的历史记录方法 ----------
    public void saveStateToHistory() {
        if (historyManager != null && mindMapPanel.getMindMap() != null) {
            historyManager.saveState(mindMapPanel.getMindMap());
        }
    }

    public void undo() {
        if (historyManager != null && historyManager.canUndo()) {
            MindMap restored = historyManager.undo(mindMapPanel.getMindMap());
            mindMapPanel.setMindMap(restored);
            nameLabel.setText(restored.getName());
            layoutComboBox.setSelectedItem(restored.getLayoutType());
            updateTreePanel();
            mindMapPanel.repaint();
        }
    }

    public void redo() {
        if (historyManager != null && historyManager.canRedo()) {
            MindMap restored = historyManager.redo(mindMapPanel.getMindMap());
            mindMapPanel.setMindMap(restored);
            nameLabel.setText(restored.getName());
            layoutComboBox.setSelectedItem(restored.getLayoutType());
            updateTreePanel();
            mindMapPanel.repaint();
        }
    }

    public void updateUndoRedoButtons() {
        if (undoBtn != null) undoBtn.setEnabled(historyManager.canUndo());
        if (redoBtn != null) redoBtn.setEnabled(historyManager.canRedo());
    }

    private JPanel createColorPanel() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT));
        p.setBorder(boldBorder("颜色设置"));
        JButton nc = new JButton("节点颜色");
        nc.addActionListener(e -> {
            MindMap m = mindMapPanel.getMindMap();
            if (m != null && !m.getSelectedNodes().isEmpty()) {
                Color c = JColorChooser.showDialog(this, "选择节点颜色", m.getSelectedNodes().get(0).getBackgroundColor());
                if (c != null) {
                    saveStateToHistory(); // 记录历史
                    for (MindMapNode n : m.getSelectedNodes()) n.setBackgroundColor(c);
                    mindMapPanel.repaint();
                }
            } else {
                JOptionPane.showMessageDialog(this, "请先选中节点", "提示", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        p.add(nc);
        JButton bc = new JButton("背景颜色");
        bc.addActionListener(e -> {
            Color c = JColorChooser.showDialog(this, "选择背景颜色", mindMapPanel.getBackground());
            if (c != null) {
                mindMapPanel.setBackground(c);
                mindMapPanel.repaint();
            }
        });
        p.add(bc);
        return p;
    }

    private JPanel createConnectorPanel() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 2));
        p.setBorder(boldBorder("符号选择"));
        p.setOpaque(false);

        ButtonGroup bg = new ButtonGroup();
        for (ConnectorType ct : ConnectorType.values()) {
            JToggleButton btn = new JToggleButton(ct.getDescription());
            btn.setFont(new Font("微软雅黑", Font.PLAIN, 12));
            btn.setFocusPainted(false);
            if (ct == ConnectorType.LINE) btn.setSelected(true);
            btn.addActionListener(e -> {
                MindMap m = mindMapPanel.getMindMap();
                if (m != null && m.getConnectorType() != ct) {
                    saveStateToHistory(); // 记录历史
                    m.setConnectorType(ct);
                    mindMapPanel.repaint();
                }
            });
            bg.add(btn);
            p.add(btn);
        }
        return p;
    }

    private JPanel createLayoutAndSavePanel() {
        JPanel p = new JPanel(new GridLayout(1, 2, 4, 0));
        p.add(createLayoutSelectorPanel());
        p.add(createSavedMapsPanel());
        return p;
    }

    private JPanel createLayoutSelectorPanel() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBorder(boldBorder("思维导图结构"));
        JPanel grid = new JPanel(new GridLayout(3, 1, 6, 6));
        grid.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
        grid.add(makeLayoutPreview("自动布局", LayoutType.AUTO));
        grid.add(makeLayoutPreview("向右布局", LayoutType.RIGHT));
        grid.add(makeLayoutPreview("向左布局", LayoutType.LEFT));
        outer.add(grid, BorderLayout.CENTER);
        return outer;
    }

    private JPanel makeLayoutPreview(String label, LayoutType type) {
        JPanel card = new JPanel(new BorderLayout(4, 0));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(180, 180, 200), 1, true),
                BorderFactory.createEmptyBorder(4, 4, 4, 4)));
        card.setBackground(new Color(248, 249, 255));
        card.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        LayoutPreviewCanvas canvas = new LayoutPreviewCanvas(type);
        canvas.setPreferredSize(new Dimension(70, 44));
        card.add(canvas, BorderLayout.WEST);
        JLabel lbl = new JLabel(label, SwingConstants.LEFT);
        lbl.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        card.add(lbl, BorderLayout.CENTER);
        MouseAdapter ma = new MouseAdapter() {
            public void mouseClicked(MouseEvent e) { applyLayoutToCurrentMap(type); }
            public void mouseEntered(MouseEvent e) { card.setBackground(new Color(220, 230, 255)); card.repaint(); }
            public void mouseExited(MouseEvent e) { card.setBackground(new Color(248, 249, 255)); card.repaint(); }
        };
        card.addMouseListener(ma);
        canvas.addMouseListener(ma);
        lbl.addMouseListener(ma);
        return card;
    }

    /** * 用户点击右下角结构预览图时触发
     * 支持一键生成模板布局
     */
    // 找到 MindMapFrame.java 中的 applyLayoutToCurrentMap 方法并替换
    private void applyLayoutToCurrentMap(LayoutType type) {
        MindMap m = mindMapPanel.getMindMap();
        if (m == null) return;

        saveStateToHistory(); // 记录历史用于撤销

        java.util.List<MindMapNode> selected = m.getSelectedNodes();

        // 情况 A：没有选中节点，或者选中的是中心节点 -> 执行全局布局
        if (selected.isEmpty() || selected.get(0) == m.getRootNode()) {
            m.setLayoutType(type);
            layoutComboBox.setSelectedItem(type);

            // 如果只有中心节点，生成模板（保留你之前的需求）
            if (m.getRootNode().getChildren().isEmpty()) {
                generateTemplateNodes(m, type);
            }

            LayoutManager.applyLayout(m.getRootNode(), type);
        }
        // 情况 B：选中了某个普通节点 -> 仅对该节点分支进行重排
        else {
            MindMapNode targetNode = selected.get(0);
            LayoutManager.applySubtreeLayout(targetNode, type);
        }

        mindMapPanel.repaint();
        updateTreePanel();
    }

    // 辅助方法：生成模板节点
    private void generateTemplateNodes(MindMap m, LayoutType type) {
        if (type == LayoutType.AUTO) {
            m.getRootNode().addChild(new MindMapNode("分支主题 1"));
            m.getRootNode().addChild(new MindMapNode("分支主题 2"));
            m.getRootNode().addChild(new MindMapNode("分支主题 3"));
            m.getRootNode().addChild(new MindMapNode("分支主题 4"));
        } else {
            m.getRootNode().addChild(new MindMapNode("分支主题 1"));
            m.getRootNode().addChild(new MindMapNode("分支主题 2"));
            m.getRootNode().addChild(new MindMapNode("分支主题 3"));
        }
    }

    private JPanel createSavedMapsPanel() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBorder(boldBorder("已保存"));
        savedMapsListPanel = new JPanel();
        savedMapsListPanel.setLayout(new BoxLayout(savedMapsListPanel, BoxLayout.Y_AXIS));
        savedMapsListPanel.setBackground(Color.WHITE);
        JScrollPane sp = new JScrollPane(savedMapsListPanel);
        sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        outer.add(sp, BorderLayout.CENTER);
        JButton btn = new JButton("保存到程序");
        btn.setFont(new Font("微软雅黑", Font.PLAIN, 12));
        btn.addActionListener(e -> saveCurrentToList());
        outer.add(btn, BorderLayout.SOUTH);
        return outer;
    }

    /**
     * 将当前思维导图保存到程序的内部列表中，并支持自定义命名
     */
    private void saveCurrentToList() {
        MindMap cur = mindMapPanel.getMindMap();
        if (cur == null) return;

        // 1. 弹出输入框，让用户给这个版本起个名字
        // 默认显示当前的导图名称，方便快速保存
        String inputName = JOptionPane.showInputDialog(this,
                "请为这个保存版本命名：",
                cur.getName());

        // 如果点击了取消或者输入为空，则不执行保存
        if (inputName == null || inputName.trim().isEmpty()) {
            return;
        }

        try {
            // 2. 执行深拷贝，确保保存的是当前状态的快照，后续修改不会影响已保存的版本
            MindMap copy = deepCopy(cur);

            // 3. 设置用户输入的新名称
            copy.setName(inputName.trim());

            // 4. 添加到列表并刷新右侧 UI
            savedMindMaps.add(copy);
            refreshSavedMapsList();

            JOptionPane.showMessageDialog(this, "已成功保存版本：" + copy.getName(), "提示", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "保存失败：" + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void refreshSavedMapsList() {
        savedMapsListPanel.removeAll();
        for (int i = 0; i < savedMindMaps.size(); i++) {
            final MindMap map = savedMindMaps.get(i);
            final int idx = i;
            JPanel item = new JPanel(new BorderLayout(4, 0));
            item.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
            item.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(220, 220, 220)),
                    BorderFactory.createEmptyBorder(4, 6, 4, 6)));
            item.setBackground(Color.WHITE);
            item.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            JLabel lbl = new JLabel(map.getName());
            lbl.setFont(new Font("微软雅黑", Font.PLAIN, 12));
            item.add(lbl, BorderLayout.CENTER);
            JButton del = new JButton("x");
            del.setMargin(new Insets(0, 4, 0, 4));
            del.setForeground(Color.RED);
            del.setToolTipText("从列表删除");
            del.addActionListener(e -> { savedMindMaps.remove(idx); refreshSavedMapsList(); });
            item.add(del, BorderLayout.EAST);
            MouseAdapter ma = new MouseAdapter() {
                public void mouseClicked(MouseEvent e) { openSavedMap(map); }
                public void mouseEntered(MouseEvent e) { item.setBackground(new Color(235, 242, 255)); }
                public void mouseExited(MouseEvent e) { item.setBackground(Color.WHITE); }
            };
            item.addMouseListener(ma);
            lbl.addMouseListener(ma);
            savedMapsListPanel.add(item);
        }
        savedMapsListPanel.add(Box.createVerticalGlue());
        savedMapsListPanel.revalidate();
        savedMapsListPanel.repaint();
    }

    private void openSavedMap(MindMap map) {
        try {
            MindMap copy = deepCopy(map);
            historyManager.clear();
            mindMapPanel.setMindMap(copy);
            nameLabel.setText(copy.getName());
            layoutComboBox.setSelectedItem(copy.getLayoutType());
            historyManager.saveState(copy);
            updateTreePanel();
            mindMapPanel.repaint();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "打开失败：" + ex.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private MindMap deepCopy(MindMap src) throws IOException, ClassNotFoundException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(src);
        oos.flush();
        ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
        return (MindMap) ois.readObject();
    }

    // ---- 基本操作 ----
    private void newMindMap() {
        MindMap newMap = new MindMap("未命名思维导图");
        historyManager.clear();
        mindMapPanel.setMindMap(newMap);
        nameLabel.setText("未命名思维导图");
        historyManager.saveState(newMap);
        updateTreePanel();
        mindMapPanel.repaint();
    }

    private void openMindMap() {
        MindMap m = FileManager.loadMindMap(this);
        if (m != null) {
            historyManager.clear();
            mindMapPanel.setMindMap(m);
            nameLabel.setText(m.getName());
            layoutComboBox.setSelectedItem(m.getLayoutType());
            historyManager.saveState(m);
            updateTreePanel();
            mindMapPanel.repaint();
        }
    }

    private void saveMindMap() {
        MindMap m = mindMapPanel.getMindMap();
        if (m != null) {
            FileManager.saveMindMap(m, this);
            nameLabel.setText(m.getName());
        }
    }

    private void exportMindMap() {
        ImageExporter.exportToImage(mindMapPanel, this);
    }

    // 主按钮的添加节点功能
    private void addNode() {
        MindMap mindMap = mindMapPanel.getMindMap();
        if (mindMap == null) return;
        List<MindMapNode> sel = mindMap.getSelectedNodes();
        if (sel.isEmpty()) {
            JOptionPane.showMessageDialog(this, "请先选择一个节点", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }
        MindMapNode selNode = sel.get(0);
        String[] opts = {"子节点", "兄弟节点"};
        int choice = JOptionPane.showOptionDialog(this, "请选择要添加的节点类型：", "添加节点",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, opts, opts[0]);
        if (choice == JOptionPane.CLOSED_OPTION) return;

        addNodeAction(selNode, choice == 0);
    }

    // 供右键菜单调用的添加节点功能
    public void addNodeFromContextMenu(boolean isChild) {
        MindMap mindMap = mindMapPanel.getMindMap();
        if (mindMap == null || mindMap.getSelectedNodes().isEmpty()) return;
        addNodeAction(mindMap.getSelectedNodes().get(0), isChild);
    }

    // 真正的添加核心（支持自动应用布局）
    // 修改 MindMapFrame.java 中的 addNodeAction 方法
    private void addNodeAction(MindMapNode selNode, boolean isChild) {
        String txt = JOptionPane.showInputDialog(this, "请输入节点文本：", "添加节点", JOptionPane.PLAIN_MESSAGE);
        if (txt == null || txt.trim().isEmpty()) return;

        MindMap mindMap = mindMapPanel.getMindMap();
        saveStateToHistory();
        MindMapNode newNode = new MindMapNode(txt.trim());

        if (isChild) {
            selNode.addChild(newNode);
            // 计算初始位置：放在父节点右侧或左侧，避免重叠
            Point p = selNode.getPosition();
            newNode.setPosition(p.x + 200, p.y + (selNode.getChildren().size() * 50));
        } else {
            if (selNode.getParent() != null) {
                selNode.getParent().addChild(newNode);
                Point p = selNode.getPosition();
                newNode.setPosition(p.x, p.y + 60);
            } else {
                selNode.addChild(newNode);
                Point p = selNode.getPosition();
                newNode.setPosition(p.x + 200, p.y);
            }
        }

        // 【关键修复】：删除下面这行代码！
        // LayoutManager.applyLayout(mindMap.getRootNode(), mindMap.getLayoutType());
        // 只有当用户点击右下角的“布局图片”或工具栏“布局按钮”时，才调用 applyLayout。

        mindMap.selectNode(newNode);
        updateTreePanel();
        mindMapPanel.repaint();
        mindMapPanel.requestFocusInWindow(); // 重新让画布获得焦点，方便连续使用快捷键
    }

    // 编辑节点
    public void editNode() {
        MindMap mindMap = mindMapPanel.getMindMap();
        if (mindMap == null || mindMap.getSelectedNodes().isEmpty()) return;
        MindMapNode selNode = mindMap.getSelectedNodes().get(0);
        String newText = JOptionPane.showInputDialog(this, "请输入新的节点名称：", selNode.getText());
        if (newText != null && !newText.trim().isEmpty()) {
            saveStateToHistory();
            selNode.setText(newText.trim());
            updateTreePanel();
            mindMapPanel.repaint();
        }
    }

    // 删除节点
    /**
     * 删除节点功能：提供“仅删除单节点”和“删除整个分支”两个选项
     */
    public void deleteSelectedNode() {
        MindMap mindMap = mindMapPanel.getMindMap();
        if (mindMap == null) return;

        java.util.List<MindMapNode> sel = mindMap.getSelectedNodes();
        if (sel.isEmpty()) {
            JOptionPane.showMessageDialog(this, "请先选择一个节点", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }

        MindMapNode selNode = sel.get(0);
        // 中心节点禁止删除
        if (selNode == mindMap.getRootNode()) {
            JOptionPane.showMessageDialog(this, "不能删除中心节点", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 使用自定义按钮的 OptionDialog 替换 ConfirmDialog
        Object[] options = {"仅删除该节点", "删除整个分支", "取消"};
        int choice = JOptionPane.showOptionDialog(this,
                "请选择删除方式：\n\n1. '仅删除该节点'：保留其子节点并移交给父节点。\n2. '删除整个分支'：同时删除该节点及其所有子内容。",
                "确认删除",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null, options, options[0]);

        if (choice == 0) { // 仅删除该节点
            saveStateToHistory(); // 记录历史
            mindMap.deleteSingleNode(selNode);
            // 重新应用布局以确保新接管的子节点位置正确
            LayoutManager.applyLayout(mindMap.getRootNode(), mindMap.getLayoutType());
            updateTreePanel();
            mindMapPanel.repaint();
        } else if (choice == 1) { // 删除整个分支
            saveStateToHistory(); // 记录历史
            mindMap.deleteNode(selNode);
            // 重新应用布局
            LayoutManager.applyLayout(mindMap.getRootNode(), mindMap.getLayoutType());
            updateTreePanel();
            mindMapPanel.repaint();
        }
        // 若点击取消或关闭窗口，则不执行任何操作
    }

    private void changeLayout() {
        MindMap m = mindMapPanel.getMindMap();
        if (m == null) return;
        LayoutType lt = (LayoutType) layoutComboBox.getSelectedItem();
        if (m.getLayoutType() == lt) return; // 避免重复保存状态

        saveStateToHistory(); // 记录历史
        m.setLayoutType(lt);
        LayoutManager.applyLayout(m.getRootNode(), lt);
        mindMapPanel.repaint();
    }

    public void updateTreePanel() {
        if (mindMapPanel != null && treePanel != null)
            treePanel.updateTree(mindMapPanel.getMindMap());
    }

    private static TitledBorder boldBorder(String title) {
        TitledBorder tb = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(160, 170, 210), 1, true),
                title);
        tb.setTitleFont(new Font("微软雅黑", Font.BOLD, 13));
        tb.setTitleColor(Color.BLACK);
        return tb;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
            catch (Exception e) { e.printStackTrace(); }
            MindMapFrame frame = new MindMapFrame();
            frame.setVisible(true);
        });
    }

    // 布局结构缩略图画布
    static class LayoutPreviewCanvas extends JPanel {
        private final LayoutType type;

        LayoutPreviewCanvas(LayoutType type) {
            this.type = type;
            setPreferredSize(new Dimension(70, 44));
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int w = getWidth(), h = getHeight();
            int cx = w / 2, cy = h / 2;
            int nw = 18, nh = 10;
            Color rootCol  = new Color(0x50, 0x5C, 0xD9);
            Color childCol = new Color(0xA0, 0xB8, 0xFF);

            if (type == LayoutType.AUTO) {
                drawPreviewNode(g2, cx - nw/2, cy - nh/2, nw, nh, rootCol);
                int[] lys = {cy - 10, cy + 4};
                for (int ly : lys) {
                    drawPreviewLine(g2, cx - nw/2, cy, cx - nw/2 - 5, ly + nh/2);
                    drawPreviewNode(g2, cx - nw/2 - 5 - 16, ly, 16, nh, childCol);
                }
                int[] rys = {cy - 10, cy + 4};
                for (int ry : rys) {
                    drawPreviewLine(g2, cx + nw/2, cy, cx + nw/2 + 5, ry + nh/2);
                    drawPreviewNode(g2, cx + nw/2 + 5, ry, 16, nh, childCol);
                }
            } else if (type == LayoutType.RIGHT) {
                int rx = 6;
                drawPreviewNode(g2, rx, cy - nh/2, nw, nh, rootCol);
                int[] rys = {cy - 13, cy, cy + 13};
                for (int ry : rys) {
                    drawPreviewLine(g2, rx + nw, cy, rx + nw + 6, ry + nh/2);
                    drawPreviewNode(g2, rx + nw + 6, ry, 16, nh, childCol);
                }
            } else {
                int rx = w - 6 - nw;
                drawPreviewNode(g2, rx, cy - nh/2, nw, nh, rootCol);
                int[] lys = {cy - 13, cy, cy + 13};
                for (int ly : lys) {
                    drawPreviewLine(g2, rx, cy, rx - 6, ly + nh/2);
                    drawPreviewNode(g2, rx - 6 - 16, ly, 16, nh, childCol);
                }
            }
        }

        private void drawPreviewNode(Graphics2D g2, int x, int y, int w, int h, Color color) {
            g2.setColor(color);
            g2.fillRoundRect(x, y, w, h, 6, 6);
            g2.setColor(color.darker());
            g2.setStroke(new BasicStroke(1f));
            g2.drawRoundRect(x, y, w, h, 6, 6);
        }

        private void drawPreviewLine(Graphics2D g2, int x1, int y1, int x2, int y2) {
            g2.setColor(new Color(160, 160, 180));
            g2.setStroke(new BasicStroke(1.2f));
            g2.drawLine(x1, y1, x2, y2);
        }
    }
}