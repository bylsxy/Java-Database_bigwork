package mindmap;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * 历史记录管理器，基于对象深拷贝实现撤销(Undo)与重做(Redo)
 */
public class HistoryManager {
    private List<byte[]> undoStack = new ArrayList<>();
    private List<byte[]> redoStack = new ArrayList<>();
    private MindMapFrame frame;

    public HistoryManager(MindMapFrame frame) {
        this.frame = frame;
    }

    /** 保存当前状态到撤销栈 */
    public void saveState(MindMap mindMap) {
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(bos);
            oos.writeObject(mindMap);
            oos.flush();
            undoStack.add(bos.toByteArray());
            redoStack.clear(); // 发生新操作时，清空重做栈
            frame.updateUndoRedoButtons();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public MindMap undo(MindMap currentMap) {
        if (!canUndo()) return currentMap;
        try {
            // 1. 将当前状态存入重做栈
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(bos);
            oos.writeObject(currentMap);
            oos.flush();
            redoStack.add(bos.toByteArray());

            // 2. 从撤销栈取出上一个状态
            byte[] state = undoStack.remove(undoStack.size() - 1);
            ByteArrayInputStream bis = new ByteArrayInputStream(state);
            ObjectInputStream ois = new ObjectInputStream(bis);
            MindMap restored = (MindMap) ois.readObject();

            frame.updateUndoRedoButtons();
            return restored;
        } catch (Exception e) {
            e.printStackTrace();
            return currentMap;
        }
    }

    public MindMap redo(MindMap currentMap) {
        if (!canRedo()) return currentMap;//未来相册
        try {
            // 1. 将当前状态存入撤销栈
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(bos);
            oos.writeObject(currentMap);
            oos.flush();
            undoStack.add(bos.toByteArray());

            // 2. 从重做栈取出状态
            byte[] state = redoStack.remove(redoStack.size() - 1);
            ByteArrayInputStream bis = new ByteArrayInputStream(state);
            ObjectInputStream ois = new ObjectInputStream(bis);
            MindMap restored = (MindMap) ois.readObject();

            frame.updateUndoRedoButtons();
            return restored;
        } catch (Exception e) {
            e.printStackTrace();
            return currentMap;
        }
    }

    public boolean canUndo() { return !undoStack.isEmpty(); }
    public boolean canRedo() { return !redoStack.isEmpty(); }

    public void clear() {
        undoStack.clear();
        redoStack.clear();
        if (frame != null) frame.updateUndoRedoButtons();
    }
}