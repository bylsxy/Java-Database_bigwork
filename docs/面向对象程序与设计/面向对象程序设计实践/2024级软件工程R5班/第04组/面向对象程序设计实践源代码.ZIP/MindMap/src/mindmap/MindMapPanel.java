package mindmap;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;

/**
 * 思维导图绘图面板 (已集成右键菜单、拖拽历史记录、动态宽度及快捷键)
 */
public class MindMapPanel extends JPanel {
    private MindMap mindMap;
    private MindMapFrame parentFrame;
    private double scale = 1.0;
    private static final double MIN_SCALE = 0.3;
    private static final double MAX_SCALE = 2.5;
    private int offsetX = 0;
    private int offsetY = 0;
    private Point lastDragPointScreen;
    private Point lastDragPointWorld;
    private boolean draggingCanvas = false;
    private MindMapNode draggingNode = null;
    private boolean nodeMoved = false;

    public MindMapPanel(MindMapFrame parentFrame) {
        this.parentFrame = parentFrame;
        this.mindMap = new MindMap("未命名思维导图");
        setBackground(new Color(240, 245, 255));
        setPreferredSize(new Dimension(1600, 1200));

        // 允许面板获取焦点以接收按键事件
        setFocusable(true);
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (mindMap == null || mindMap.getSelectedNodes().isEmpty()) return;
                switch (e.getKeyCode()) {
                    case KeyEvent.VK_INSERT: parentFrame.addNodeFromContextMenu(true); break;
                    case KeyEvent.VK_DELETE: parentFrame.deleteSelectedNode(); break;
                    case KeyEvent.VK_ENTER:  parentFrame.editNode(); break;
                }
            }
        });

        addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) { handleMouseClick(e); }
            @Override public void mousePressed(MouseEvent e) { handleMousePressed(e); }
            @Override public void mouseReleased(MouseEvent e) {
                draggingCanvas = false;
                draggingNode = null;
                nodeMoved = false;
                lastDragPointScreen = null;
                lastDragPointWorld = null;
            }
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            @Override public void mouseDragged(MouseEvent e) { handleMouseDragged(e); }
        });
        addMouseWheelListener(new MouseWheelListener() {
            @Override public void mouseWheelMoved(MouseWheelEvent e) { handleMouseWheel(e); }
        });
    }

    public void setMindMap(MindMap mindMap) {
        this.mindMap = mindMap;
        repaint();
    }

    public MindMap getMindMap() { return mindMap; }

    // ---- 鼠标事件 ----
    private void handleMouseClick(MouseEvent e) {
        // 点击后让画布获取焦点，确保快捷键生效
        requestFocusInWindow();

        Point p = screenToWorld(e.getPoint());
        MindMapNode clickedNode = mindMap.findNodeAt(p);

        // 处理右键菜单
        if (SwingUtilities.isRightMouseButton(e)) {
            if (clickedNode != null) {
                mindMap.selectNode(clickedNode);
                repaint();
                parentFrame.updateTreePanel();
                showContextMenu(e.getPoint(), clickedNode);
            } else {
                mindMap.clearSelection();
                repaint();
            }
            return;
        }

        // 双击编辑
        if (e.getClickCount() == 2 && clickedNode != null) {
            parentFrame.editNode();
            return;
        }

        // 左键选择
        if (clickedNode != null) {
            if (e.isControlDown() || e.isShiftDown()) mindMap.addToSelection(clickedNode);
            else mindMap.selectNode(clickedNode);
        } else {
            mindMap.clearSelection();
        }
        repaint();
        parentFrame.updateTreePanel();
    }

    // 弹出右键菜单
    private void showContextMenu(Point screenPt, MindMapNode node) {
        JPopupMenu popup = new JPopupMenu();

        JMenuItem addSub = new JMenuItem("添加子节点 (Insert)");
        addSub.addActionListener(e -> parentFrame.addNodeFromContextMenu(true));
        popup.add(addSub);

        JMenuItem addSibling = new JMenuItem("添加兄弟节点");
        addSibling.addActionListener(e -> parentFrame.addNodeFromContextMenu(false));
        if (node.getParent() == null) addSibling.setEnabled(false);
        popup.add(addSibling);

        JMenuItem editItem = new JMenuItem("编辑节点 (Enter)");
        editItem.addActionListener(e -> parentFrame.editNode());
        popup.add(editItem);

        popup.addSeparator();

        JMenuItem delItem = new JMenuItem("删除节点 (Delete)");
        delItem.setForeground(Color.RED);
        delItem.addActionListener(e -> parentFrame.deleteSelectedNode());
        if (node.getParent() == null) delItem.setEnabled(false);
        popup.add(delItem);

        popup.show(this, screenPt.x, screenPt.y);
    }

    private void handleMousePressed(MouseEvent e) {
        if (SwingUtilities.isRightMouseButton(e)) return;
        Point worldPoint = screenToWorld(e.getPoint());
        MindMapNode clickedNode = mindMap.findNodeAt(worldPoint);
        if (clickedNode != null) {
            draggingNode = clickedNode;
            lastDragPointWorld = worldPoint;
            nodeMoved = false;
        } else {
            draggingCanvas = true;
            lastDragPointScreen = e.getPoint();
        }
    }

    private void handleMouseDragged(MouseEvent e) {
        if (SwingUtilities.isRightMouseButton(e)) return;
        if (draggingNode != null && lastDragPointWorld != null) {
            Point currentWorld = screenToWorld(e.getPoint());
            int dx = currentWorld.x - lastDragPointWorld.x;
            int dy = currentWorld.y - lastDragPointWorld.y;
            if (dx != 0 || dy != 0) {
                if (!nodeMoved) {
                    parentFrame.saveStateToHistory();
                    nodeMoved = true;
                }
                moveSubtree(draggingNode, dx, dy);
                lastDragPointWorld = currentWorld;
                repaint();
            }
        } else if (draggingCanvas && lastDragPointScreen != null) {
            Point cur = e.getPoint();
            offsetX += cur.x - lastDragPointScreen.x;
            offsetY += cur.y - lastDragPointScreen.y;
            lastDragPointScreen = cur;
            repaint();
        }
    }

    private void handleMouseWheel(MouseWheelEvent e) {
        double oldScale = scale;
        scale = e.getWheelRotation() < 0 ? scale * 1.1 : scale / 1.1;
        scale = Math.max(MIN_SCALE, Math.min(MAX_SCALE, scale));
        Point p = e.getPoint();
        offsetX = (int)(p.x - (p.x - offsetX) * (scale / oldScale));
        offsetY = (int)(p.y - (p.y - offsetY) * (scale / oldScale));
        repaint();
    }

    private Point screenToWorld(Point p) {
        return new Point((int)((p.x - offsetX) / scale), (int)((p.y - offsetY) / scale));
    }

    private void moveSubtree(MindMapNode node, int dx, int dy) {
        if (node.getPosition() != null)
            node.setPosition(node.getPosition().x + dx, node.getPosition().y + dy);
        for (MindMapNode child : node.getChildren()) moveSubtree(child, dx, dy);
    }

    public void zoomIn()  { scale = Math.min(MAX_SCALE, scale * 1.2); repaint(); }
    public void zoomOut() { scale = Math.max(MIN_SCALE, scale / 1.2); repaint(); }
    public void resetView() { scale = 1.0; offsetX = 0; offsetY = 0; repaint(); }

    // ---- 绘制 ----
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

        int w = getWidth(), h = getHeight();
        Color base = getBackground();
        int r2 = Math.max(0, base.getRed()   - 25);
        int g2c = Math.max(0, base.getGreen() - 20);
        int b2 = Math.max(0, base.getBlue()  - 15);
        GradientPaint bgGrad = new GradientPaint(0, 0, base, w, h, new Color(r2, g2c, b2));
        g2d.setPaint(bgGrad);
        g2d.fillRect(0, 0, w, h);

        g2d.setColor(new Color(0, 0, 0, 18));
        int gridStep = 28;
        for (int gx = 0; gx < w; gx += gridStep)
            for (int gy = 0; gy < h; gy += gridStep)
                g2d.fillOval(gx - 1, gy - 1, 2, 2);

        g2d.translate(offsetX, offsetY);
        g2d.scale(scale, scale);

        if (mindMap != null && mindMap.getRootNode() != null) {
            // 绘制前先更新所有节点的动态尺寸
            updateAllNodesSize(g2d, mindMap.getRootNode());
            drawNode(g2d, mindMap.getRootNode());
        }
    }

    // 递归更新所有节点的尺寸以适应文字长度
    private void updateAllNodesSize(Graphics2D g2d, MindMapNode node) {
        node.updateSize(g2d.getFontMetrics(new Font("微软雅黑", Font.PLAIN, 14)));
        for (MindMapNode child : node.getChildren()) {
            updateAllNodesSize(g2d, child);
        }
    }

    private void drawNode(Graphics2D g2d, MindMapNode node) {
        if (node.getPosition() == null) return;
        if (node.getParent() != null) drawConnection(g2d, node.getParent(), node);
        for (MindMapNode child : node.getChildren()) drawNode(g2d, child);

        Rectangle bounds = node.getBounds();
        NodeShape shape = node.getShape();

        g2d.setColor(new Color(0, 0, 0, 30));
        g2d.fillRoundRect(bounds.x + 3, bounds.y + 3, bounds.width, bounds.height, 14, 14);

        g2d.setColor(node.isSelected() ? new Color(173, 216, 230) : node.getBackgroundColor());
        switch (shape) {
            case PILL:
                g2d.fillRoundRect(bounds.x, bounds.y, bounds.width, bounds.height, bounds.height, bounds.height); break;
            case DIAMOND: {
                int cx = bounds.x + bounds.width/2, cy = bounds.y + bounds.height/2;
                g2d.fillPolygon(new int[]{cx, bounds.x+bounds.width, cx, bounds.x},
                        new int[]{bounds.y, cy, bounds.y+bounds.height, cy}, 4); break;
            }
            case CIRCLE:
                g2d.fillOval(bounds.x, bounds.y, bounds.width, bounds.height); break;
            default:
                g2d.fillRoundRect(bounds.x, bounds.y, bounds.width, bounds.height, 12, 12);
        }

        g2d.setColor(node.isSelected() ? Color.BLUE : node.getBorderColor());
        g2d.setStroke(new BasicStroke(node.isSelected() ? 3 : 1.5f));
        switch (shape) {
            case PILL:
                g2d.drawRoundRect(bounds.x, bounds.y, bounds.width, bounds.height, bounds.height, bounds.height); break;
            case DIAMOND: {
                int cx = bounds.x + bounds.width/2, cy = bounds.y + bounds.height/2;
                g2d.drawPolygon(new int[]{cx, bounds.x+bounds.width, cx, bounds.x},
                        new int[]{bounds.y, cy, bounds.y+bounds.height, cy}, 4); break;
            }
            case CIRCLE:
                g2d.drawOval(bounds.x, bounds.y, bounds.width, bounds.height); break;
            default:
                g2d.drawRoundRect(bounds.x, bounds.y, bounds.width, bounds.height, 12, 12);
        }

        g2d.setColor(Color.BLACK);
        g2d.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        FontMetrics fm = g2d.getFontMetrics();
        String text = node.getText();
        int tx = bounds.x + (bounds.width - fm.stringWidth(text)) / 2;
        int ty = bounds.y + (bounds.height + fm.getAscent() - fm.getDescent()) / 2;
        g2d.drawString(text, tx, ty);
    }

    /**
     * 已修复的真正直线连接逻辑
     */
    private void drawConnection(Graphics2D g2d, MindMapNode parent, MindMapNode child) {
        Point pp = parent.getPosition();
        Point cp = child.getPosition();
        Dimension ps = parent.getSize();
        Dimension cs = child.getSize();

        int px, py, cx, cy;
        int parentCenterX = pp.x + ps.width / 2;
        int childCenterX  = cp.x + cs.width / 2;

        if (childCenterX < parentCenterX) { // 子节点在左侧
            px = pp.x;
            py = pp.y + ps.height / 2;
            cx = cp.x + cs.width;
            cy = cp.y + cs.height / 2;
        } else { // 子节点在右侧或正下方
            px = pp.x + ps.width;
            py = pp.y + ps.height / 2;
            cx = cp.x;
            cy = cp.y + cs.height / 2;
        }

        ConnectorType ct = (mindMap != null) ? mindMap.getConnectorType() : ConnectorType.LINE;
        g2d.setColor(new Color(90, 110, 160));
        g2d.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

        switch (ct) {
            case ARROW:
                drawArrow(g2d, px, py, cx, cy);
                break;
            case BRACKET:
                drawBracket(g2d, px, py, cx, cy);
                break;
            case LINE:
            default:
                // 直接使用 drawLine 画出真正的直线
                g2d.drawLine(px, py, cx, cy);
                break;
        }
    }

    private void drawArrow(Graphics2D g2d, int x1, int y1, int x2, int y2) {
        int mx = (x1 + x2) / 2;
        Path2D curve = new Path2D.Double();
        curve.moveTo(x1, y1);
        curve.curveTo(mx, y1, mx, y2, x2, y2);
        g2d.draw(curve);

        double angle = Math.atan2(y2 - y1, x2 - x1);
        int aLen = 12, aWid = 6;
        int[] ax = {
                x2,
                (int)(x2 - aLen * Math.cos(angle - Math.toRadians(25))),
                (int)(x2 - aLen * Math.cos(angle + Math.toRadians(25)))
        };
        int[] ay = {
                y2,
                (int)(y2 - aLen * Math.sin(angle - Math.toRadians(25))),
                (int)(y2 - aLen * Math.sin(angle + Math.toRadians(25)))
        };
        g2d.fillPolygon(ax, ay, 3);
    }

    private void drawBracket(Graphics2D g2d, int x1, int y1, int x2, int y2) {
        int midX = x1 + (x2 - x1) / 3;
        g2d.drawLine(x1, y1, midX, y1);
        g2d.drawLine(midX, y1, midX, y2);
        g2d.drawLine(midX, y2, x2, y2);
    }
}