package mindmap;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

/**
 * 图像导出器，负责将思维导图导出为图片
 */
public class ImageExporter {

    public static void exportToImage(MindMapPanel panel, JFrame parent) {
        if (panel == null || panel.getMindMap() == null) {
            JOptionPane.showMessageDialog(parent, "没有可导出的思维导图", "提示", JOptionPane.WARNING_MESSAGE);
            return;
        }

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("导出思维导图");
        fileChooser.setFileFilter(new FileNameExtensionFilter("PNG图像 (*.png)", "png"));
        fileChooser.addChoosableFileFilter(new FileNameExtensionFilter("JPEG图像 (*.jpg)", "jpg"));

        // 【新增 1：自动填入默认名字，防止用户忘打字导致报错】
        MindMap mindMap = panel.getMindMap();
        String defaultName = (mindMap.getName() != null && !mindMap.getName().equals("未命名思维导图"))
                ? mindMap.getName()
                : "我的思维导图";
        fileChooser.setSelectedFile(new File(defaultName + ".png"));

        int result = fileChooser.showSaveDialog(parent);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();

            // 【新增 2：修复文件名后缀拼接逻辑】
            String originalName = file.getName();
            String lowerName = originalName.toLowerCase();
            String format = "png";

            // 判断用户是不是想存为 jpg
            javax.swing.filechooser.FileFilter selectedFilter = fileChooser.getFileFilter();
            if (selectedFilter.getDescription().contains("JPEG") || lowerName.endsWith(".jpg") || lowerName.endsWith(".jpeg")) {
                format = "jpg";
                if (!lowerName.endsWith(".jpg") && !lowerName.endsWith(".jpeg")) {
                    file = new File(file.getParent(), originalName + ".jpg");
                }
            } else {
                if (!lowerName.endsWith(".png")) {
                    file = new File(file.getParent(), originalName + ".png");
                }
            }

            // 【新增 3：在画图前，提前检查文件到底能不能写】
            if (file.exists() && !file.canWrite()) {
                JOptionPane.showMessageDialog(parent, "文件被占用或无权限覆盖！\n请换个名字，或关掉正在打开的同名图片。", "拒绝访问", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                // 算出导图大小并准备相纸
                Rectangle bounds = calculateBounds(mindMap.getRootNode());
                int padding = 50;
                int width = Math.max(bounds.width + bounds.x + padding * 2, 800);
                int height = Math.max(bounds.height + bounds.y + padding * 2, 600);

                BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
                Graphics2D g2d = image.createGraphics();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(Color.WHITE);
                g2d.fillRect(0, 0, width, height);

                g2d.translate(padding - bounds.x, padding - bounds.y);
                drawNodeToImage(g2d, mindMap.getRootNode());
                g2d.dispose();

                // 正式导出到硬盘
                ImageIO.write(image, format, file);
                JOptionPane.showMessageDialog(parent, "导出成功！\n文件已存至：" + file.getAbsolutePath(), "提示", JOptionPane.INFORMATION_MESSAGE);

            } catch (IOException e) {
                // 【新增 4：如果是拒绝访问，给用户提供大白话解决方案】
                String errorMsg = e.getMessage();
                if (errorMsg.contains("拒绝访问") || errorMsg.contains("Access is denied")) {
                    errorMsg = "系统权限不足！\n请不要保存在桌面或C盘，请尝试保存在 D盘 或 你的项目文件夹内。";
                }
                JOptionPane.showMessageDialog(parent, "导出失败：" + errorMsg, "错误", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private static Rectangle calculateBounds(MindMapNode node) {
        if (node == null || node.getPosition() == null) {
            return new Rectangle(0, 0, 800, 600);
        }
        
        Rectangle bounds = new Rectangle(node.getBounds());
        
        for (MindMapNode child : node.getChildren()) {
            Rectangle childBounds = calculateBounds(child);
            bounds = bounds.union(childBounds);
        }
        
        return bounds;
    }
    
    private static void drawNodeToImage(Graphics2D g2d, MindMapNode node) {
        if (node.getPosition() == null) return;
        
        // 绘制连接线
        if (node.getParent() != null) {
            drawConnectionToImage(g2d, node.getParent(), node);
        }
        
        // 绘制子节点：递归
        for (MindMapNode child : node.getChildren()) {
            drawNodeToImage(g2d, child);
        }
        
        // 绘制节点本身
        Rectangle bounds = node.getBounds();//拿到x，y
        NodeShape shape = node.getShape();//看看形状
        
        // 绘制背景
        if (node.isSelected()) {//被选中
            g2d.setColor(new Color(173, 216, 230));
        } else {
            g2d.setColor(node.getBackgroundColor());//自己的背景颜色
        }

        switch (shape) {//涂色块
            case PILL:
                g2d.fillRoundRect(bounds.x, bounds.y, bounds.width, bounds.height, bounds.height, bounds.height);
                break;
            case DIAMOND:
                int cx = bounds.x + bounds.width / 2;
                int cy = bounds.y + bounds.height / 2;
                Polygon diamond = new Polygon(
                        new int[]{cx, bounds.x + bounds.width, cx, bounds.x},
                        new int[]{bounds.y, cy, bounds.y + bounds.height, cy},
                        4);
                g2d.fillPolygon(diamond);
                break;
            case CIRCLE:
                g2d.fillOval(bounds.x, bounds.y, bounds.width, bounds.height);
                break;
            case RECT:
            default:
                g2d.fillRoundRect(bounds.x, bounds.y, bounds.width, bounds.height, 12, 12);
                break;
        }
        
        // 绘制边框
        if (node.isSelected()) {
            g2d.setColor(Color.BLUE);
            g2d.setStroke(new BasicStroke(3));//加粗
        } else {
            g2d.setColor(node.getBorderColor());
            g2d.setStroke(new BasicStroke(1));
        }

        switch (shape) {
            case PILL:
                g2d.drawRoundRect(bounds.x, bounds.y, bounds.width, bounds.height, bounds.height, bounds.height);
                break;
            case DIAMOND:
                int cx2 = bounds.x + bounds.width / 2;
                int cy2 = bounds.y + bounds.height / 2;
                Polygon diamondBorder = new Polygon(
                        new int[]{cx2, bounds.x + bounds.width, cx2, bounds.x},
                        new int[]{bounds.y, cy2, bounds.y + bounds.height, cy2},
                        4);
                g2d.drawPolygon(diamondBorder);
                break;
            case CIRCLE:
                g2d.drawOval(bounds.x, bounds.y, bounds.width, bounds.height);
                break;
            case RECT:
            default:
                g2d.drawRoundRect(bounds.x, bounds.y, bounds.width, bounds.height, 12, 12);
                break;
        }
        
        // 绘制文本
        g2d.setColor(Color.BLACK);//换黑笔
        g2d.setFont(new Font("微软雅黑", Font.PLAIN, 14));
        FontMetrics fm = g2d.getFontMetrics();
        String text = node.getText();
        int textWidth = fm.stringWidth(text);
        int textHeight = fm.getHeight();
        int x = bounds.x + (bounds.width - textWidth) / 2;
        int y = bounds.y + (bounds.height + textHeight) / 2 - fm.getDescent();
        g2d.drawString(text, x, y);
    }
    
    private static void drawConnectionToImage(Graphics2D g2d, MindMapNode parent, MindMapNode child) {
        Point parentPos = parent.getPosition();
        Point childPos = child.getPosition();
        Dimension parentSize = parent.getSize();
        Dimension childSize = child.getSize();
        
        int parentX, parentY, childX, childY;
        
        if (childPos.x < parentPos.x) {
            parentX = parentPos.x;
            parentY = parentPos.y + parentSize.height / 2;
            childX = childPos.x + childSize.width;
            childY = childPos.y + childSize.height / 2;
        } else {
            parentX = parentPos.x + parentSize.width;
            parentY = parentPos.y + parentSize.height / 2;
            childX = childPos.x;
            childY = childPos.y + childSize.height / 2;
        }
        
        g2d.setColor(Color.GRAY);
        g2d.setStroke(new BasicStroke(2));
        g2d.drawLine(parentX, parentY, childX, childY);
    }
}

