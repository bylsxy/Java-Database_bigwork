package mindmap;

/**
 * 布局类型枚举
 */
public enum LayoutType {
    AUTO("自动布局"),
    LEFT("左侧布局"),
    RIGHT("右侧布局");
    
    private String description;
    
    LayoutType(String description) {
        this.description = description;
    }
    
    public String getDescription() {
        return description;
    }
    
    @Override
    public String toString() {
        return description;
    }
}

