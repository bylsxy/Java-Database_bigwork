package mindmap;

/**
 * 节点连接符号类型
 */
public enum ConnectorType {
    LINE("直线"),
    ARROW("箭头"),
    BRACKET("括号");


    private final String description;

    ConnectorType(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return description;
    }//控制屏幕输出文字
}


