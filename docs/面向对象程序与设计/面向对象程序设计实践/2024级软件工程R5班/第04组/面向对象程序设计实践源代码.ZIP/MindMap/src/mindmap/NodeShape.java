package mindmap;

/**
 * 节点形状类型
 */
public enum NodeShape {
    RECT,          // 普通矩形/圆角矩形
    PILL,          // 胶囊形（开始/结束）
    DIAMOND,       // 菱形（判断）
    CIRCLE         // 圆形（鱼骨图小圆点）
}




