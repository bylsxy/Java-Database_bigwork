package mindmap;

import java.awt.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 思维导图数据模型
 */
public class MindMap implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private String name;
    private MindMapNode rootNode;
    private LayoutType layoutType;
    private ConnectorType connectorType;
    private List<MindMapNode> selectedNodes;
    
    public MindMap(String name) {
        this.name = name;
        this.rootNode = new MindMapNode("中心节点");
        this.rootNode.setPosition(400, 300); // 初始位置
        this.layoutType = LayoutType.AUTO;
        this.connectorType = ConnectorType.LINE;
        this.selectedNodes = new ArrayList<>();
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public MindMapNode getRootNode() {
        return rootNode;
    }
    
    public void setRootNode(MindMapNode rootNode) {
        this.rootNode = rootNode;
    }
    
    public LayoutType getLayoutType() {
        return layoutType;
    }
    
    public void setLayoutType(LayoutType layoutType) {
        this.layoutType = layoutType;
    }

    public ConnectorType getConnectorType() {
        return connectorType == null ? ConnectorType.LINE : connectorType;
    }

    public void setConnectorType(ConnectorType connectorType) {
        this.connectorType = connectorType;
    }
    
    public List<MindMapNode> getSelectedNodes() {
        return selectedNodes;
    }
    
    public void clearSelection() {
        for (MindMapNode node : selectedNodes) {
            node.setSelected(false);
        }
        selectedNodes.clear();
    }
    
    public void selectNode(MindMapNode node) {
        clearSelection();
        if (node != null) {
            node.setSelected(true);
            selectedNodes.add(node);
        }
    }
    
    public void addToSelection(MindMapNode node) {
        if (node != null && !selectedNodes.contains(node)) {
            node.setSelected(true);
            selectedNodes.add(node);
        }
    }
    
    /**
     * 查找包含指定点的节点
     */
    public MindMapNode findNodeAt(Point p) {
        return findNodeAt(rootNode, p);
    }
    
    private MindMapNode findNodeAt(MindMapNode node, Point p) {
        if (node.contains(p)) {
            return node;
        }
        for (MindMapNode child : node.getChildren()) {
            MindMapNode found = findNodeAt(child, p);
            if (found != null) {
                return found;
            }
        }
        return null;
    }
    
    /**
     * 删除节点及其所有子节点
     */
    public void deleteNode(MindMapNode node) {
        if (node == rootNode) {
            // 不能删除根节点，只能清空其子节点
            rootNode.getChildren().clear();
            return;
        }
        
        if (node.getParent() != null) {
            node.getParent().removeChild(node);
        }
        
        // 从选中列表中移除
        selectedNodes.remove(node);
    }
    /**
     * 仅删除单个节点，其原有的子节点将自动提升并连接到该节点的父节点上
     */
    public void deleteSingleNode(MindMapNode node) {
        if (node == null || node == rootNode) return; // 根节点不可按此方式删除

        MindMapNode parent = node.getParent();
        if (parent != null) {
            // 1. 获取待删除节点的所有子节点（创建副本以防并发修改异常）
            java.util.List<MindMapNode> children = new java.util.ArrayList<>(node.getChildren());

            // 2. 从父节点中移除当前节点
            parent.removeChild(node);

            // 3. 将当前节点的所有子节点重新添加给父节点
            for (MindMapNode child : children) {
                parent.addChild(child);
            }
        }

        // 从选中列表中移除
        selectedNodes.remove(node);
    }
}

