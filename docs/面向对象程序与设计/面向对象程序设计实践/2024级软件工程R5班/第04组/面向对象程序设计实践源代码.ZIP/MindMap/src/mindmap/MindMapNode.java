package mindmap;

import java.awt.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 思维导图节点类
 */
public class MindMapNode implements Serializable {
    private static final long serialVersionUID = 1L;
    private String text;
    private MindMapNode parent;
    private List<MindMapNode> children;
    private Point position;
    private Dimension size;
    private boolean selected;
    private Color backgroundColor;
    private Color borderColor;
    private NodeShape shape = NodeShape.RECT;

    // 节点尺寸 (已更新为动态计算所需的最小常量)
    public static final int MIN_WIDTH = 100;
    public static final int DEFAULT_HEIGHT = 40;
    public static final int HORIZONTAL_SPACING = 150;
    public static final int VERTICAL_SPACING = 80;

    public MindMapNode(String text) {
        this.text = text;
        this.children = new ArrayList<>();
        this.size = new Dimension(MIN_WIDTH, DEFAULT_HEIGHT); // 使用默认最小宽度
        this.selected = false;
        this.backgroundColor = Color.WHITE;
        this.borderColor = Color.BLACK;
    }

    /**
     * 根据文字内容和字体动态计算节点宽度
     */
    public void updateSize(FontMetrics fm) {
        int textWidth = fm.stringWidth(this.text);
        // 留出左右各 20 像素的间距
        int newWidth = Math.max(MIN_WIDTH, textWidth + 40);
        this.size = new Dimension(newWidth, DEFAULT_HEIGHT);
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public MindMapNode getParent() {
        return parent;
    }

    public void setParent(MindMapNode parent) {
        this.parent = parent;
    }

    public List<MindMapNode> getChildren() {
        return children;
    }

    public void addChild(MindMapNode child) {
        if (child != null) {
            child.setParent(this);
            children.add(child);
        }
    }

    public void removeChild(MindMapNode child) {
        if (children.remove(child)) {
            child.setParent(null);
        }
    }

    public Point getPosition() {
        return position;
    }

    public void setPosition(Point position) {
        this.position = position;
    }

    public void setPosition(int x, int y) {
        this.position = new Point(x, y);
    }

    public Dimension getSize() {
        return size;
    }

    public void setSize(Dimension size) {
        this.size = size;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public Color getBackgroundColor() {
        return backgroundColor;
    }

    public void setBackgroundColor(Color backgroundColor) {
        this.backgroundColor = backgroundColor;
    }

    public Color getBorderColor() {
        return borderColor;
    }

    public void setBorderColor(Color borderColor) {
        this.borderColor = borderColor;
    }

    public NodeShape getShape() {
        return shape;
    }

    public void setShape(NodeShape shape) {
        this.shape = shape;
    }

    /**
     * 检查点是否在节点内
     */
    public boolean contains(Point p) {
        if (position == null) return false;
        Rectangle bounds = new Rectangle(position.x, position.y, size.width, size.height);
        return bounds.contains(p);
    }

    /**
     * 获取节点的边界矩形
     */
    public Rectangle getBounds() {
        if (position == null) return new Rectangle(0, 0, 0, 0);
        return new Rectangle(position.x, position.y, size.width, size.height);
    }

    /**
     * 获取所有后代节点的数量（包括自己）
     */
    public int getTotalDescendantCount() {
        int count = 1;
        for (MindMapNode child : children) {
            count += child.getTotalDescendantCount();
        }
        return count;
    }

    /**
     * 获取子树的高度（节点层级数）
     */
    public int getTreeHeight() {
        if (children.isEmpty()) {
            return 1;
        }
        int maxHeight = 0;
        for (MindMapNode child : children) {
            maxHeight = Math.max(maxHeight, child.getTreeHeight());
        }
        return maxHeight + 1;
    }
}