@echo off
echo 测试脚本运行...
echo 当前目录: %CD%
echo.
echo 检查Java文件...
dir /b "src\mindmap\*.java" 2>nul
if errorlevel 1 (
    echo 未找到Java文件！
    pause
    exit /b 1
)
echo.
echo 检查Java环境...
java -version
if errorlevel 1 (
    echo Java未安装或未配置！
    pause
    exit /b 1
)
echo.
echo 检查javac...
javac -version
if errorlevel 1 (
    echo javac未安装或未配置！
    pause
    exit /b 1
)
echo.
echo 所有检查通过！
pause

