@echo off
chcp 65001
title 诊断工具

cls
echo.
echo ========================================
echo    问题诊断工具
echo ========================================
echo.

echo [检查1] 当前目录
echo %CD%
echo.

echo [检查2] Java环境
java -version 2>&1
if errorlevel 1 (
    echo    状态: 未找到Java
) else (
    echo    状态: Java已安装
)
echo.

echo [检查3] javac编译器
javac -version 2>&1
if errorlevel 1 (
    echo    状态: 未找到javac
) else (
    echo    状态: javac已安装
)
echo.

echo [检查4] 目录结构
if exist "src\mindmap" (
    echo    src\mindmap\ 目录: 存在
) else (
    echo    src\mindmap\ 目录: 不存在
)
if exist "bin" (
    echo    bin\ 目录: 存在
) else (
    echo    bin\ 目录: 不存在
)
echo.

echo [检查5] Java源文件
set COUNT=0
for %%f in ("src\mindmap\*.java") do (
    echo    找到: %%~nxf
    set /a COUNT+=1
)
if %COUNT%==0 (
    echo    状态: 未找到Java文件
) else (
    echo    状态: 找到 %COUNT% 个Java文件
)
echo.

echo [检查6] 编译测试
echo    尝试编译一个文件...
javac -d bin -encoding UTF-8 "src\mindmap\MindMapFrame.java" 2>&1
if errorlevel 1 (
    echo    状态: 编译失败（见上方错误信息）
) else (
    echo    状态: 编译成功
)
echo.

echo ========================================
echo 诊断完成！请查看上面的信息。
echo ========================================
echo.
pause

