@echo off
setlocal
cd /d "%~dp0"

echo Building project, please wait...
call mvn -q -Dmaven.test.skip=true package
if errorlevel 1 (
    echo.
    echo Build failed. Please make sure Java 17 and Maven are installed.
    echo Press any key to close this window.
    pause >nul
    exit /b %errorlevel%
)

echo Starting program...
java -jar "%~dp0target\mindmap-course-design-1.0-SNAPSHOT.jar"
if errorlevel 1 (
    echo.
    echo Program exited with an error.
    echo Press any key to close this window.
    pause >nul
)