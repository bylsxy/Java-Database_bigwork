/*
Script: MindMapFileManager.java
Purpose: Save and load mind map documents, including node fill, border, text, and branch styles.
Author: chenyuchong
Created: 2026-03-14
Last Updated: 2026-05-10
Dependencies: Java XML APIs, com.course.mindmap.model
Usage: Called by MainFrame when persisting or opening .dt mind map files.

Changelog:
- 2026-03-14 chenyuchong: Initial creation.
- 2026-04-27 陈宗波: Added persistence for node text, fill, and line colors. Original author: chenyuchong. Reason: preserve user-selected node styles across save and load operations. Impact: backward compatible.
- 2026-04-28 陈宗波: Simplified persistence to fill-only styling with no-fill support. Original author: chenyuchong. Reason: match the reduced UI styling scope while preserving border-only nodes. Impact: backward compatible.
- 2026-04-28 陈宗波: Extended persistence to border, text, and branch styles for the node property popup. Original author: chenyuchong. Reason: keep styling behavior consistent after saving and reopening mind maps. Impact: backward compatible.
- 2026-05-10 陈宗波: Added persistence for per-node manual position offsets. Original author: chenyuchong. Reason: retain user-dragged module positions after saving and reopening a mind map. Impact: backward compatible.
*/
package com.course.mindmap.io;

import com.course.mindmap.model.LayoutMode;
import com.course.mindmap.model.MindMapDocument;
import com.course.mindmap.model.MindMapNode;
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class MindMapFileManager {
    public void save(MindMapDocument document, File file) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        org.w3c.dom.Document xmlDocument = builder.newDocument();

        Element rootElement = xmlDocument.createElement("mind-map");
        rootElement.setAttribute("title", document.getTitle());
        rootElement.setAttribute("layout", document.getLayoutMode().name());
        xmlDocument.appendChild(rootElement);
        rootElement.appendChild(writeNode(xmlDocument, document.getRoot()));

        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
        transformer.transform(new DOMSource(xmlDocument), new StreamResult(file));
    }

    public MindMapDocument load(File file) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        org.w3c.dom.Document xmlDocument = builder.parse(file);
        xmlDocument.getDocumentElement().normalize();

        Element rootElement = xmlDocument.getDocumentElement();
        if (!"mind-map".equals(rootElement.getNodeName())) {
            throw new ParserConfigurationException("Invalid mind map file.");
        }

        Element rootNodeElement = firstNodeElement(rootElement);
        if (rootNodeElement == null) {
            throw new ParserConfigurationException("Mind map file does not contain any node.");
        }

        MindMapNode rootNode = readNode(rootNodeElement);
        String title = rootElement.getAttribute("title");
        LayoutMode layoutMode = LayoutMode.fromPersistentName(rootElement.getAttribute("layout"));
        return new MindMapDocument(title, rootNode, layoutMode);
    }

    private Element writeNode(org.w3c.dom.Document xmlDocument, MindMapNode node) {
        Element element = xmlDocument.createElement("node");
        element.setAttribute("id", node.getId());
        element.setAttribute("text", node.getText());
        writeOptionalAttribute(element, "fill-color", node.getFillColorHex());
        if (node.isFillTransparent()) {
            element.setAttribute("fill-transparent", "true");
        }
        writeOptionalAttribute(element, "border-color", node.getBorderColorHex());
        writeOptionalAttribute(element, "text-color", node.getTextColorHex());
        if (node.getFontSize() != MindMapNode.DEFAULT_FONT_SIZE) {
            element.setAttribute("font-size", String.valueOf(node.getFontSize()));
        }
        if (node.isBold()) {
            element.setAttribute("bold", "true");
        }
        writeOptionalAttribute(element, "branch-color", node.getBranchColorHex());
        if (node.getManualOffsetX() != 0) {
            element.setAttribute("offset-x", String.valueOf(node.getManualOffsetX()));
        }
        if (node.getManualOffsetY() != 0) {
            element.setAttribute("offset-y", String.valueOf(node.getManualOffsetY()));
        }

        for (MindMapNode child : node.getChildren()) {
            element.appendChild(writeNode(xmlDocument, child));
        }
        return element;
    }

    private MindMapNode readNode(Element element) {
        MindMapNode node = new MindMapNode(element.getAttribute("id"), element.getAttribute("text"));
        node.setFillColorHex(readOptionalAttribute(element, "fill-color"));
        if (Boolean.parseBoolean(readOptionalAttribute(element, "fill-transparent"))) {
            node.setFillTransparent(true);
        }

        String borderColor = readOptionalAttribute(element, "border-color");
        if (borderColor == null) {
            borderColor = readOptionalAttribute(element, "line-color");
        }
        node.setBorderColorHex(borderColor);
        node.setTextColorHex(readOptionalAttribute(element, "text-color"));

        Integer fontSize = readOptionalIntegerAttribute(element, "font-size");
        if (fontSize != null) {
            node.setFontSize(fontSize);
        }
        node.setBold(Boolean.parseBoolean(readOptionalAttribute(element, "bold")));
        node.setBranchColorHex(readOptionalAttribute(element, "branch-color"));
        Integer offsetX = readOptionalIntegerAttribute(element, "offset-x");
        Integer offsetY = readOptionalIntegerAttribute(element, "offset-y");
        node.setManualOffset(offsetX == null ? 0 : offsetX, offsetY == null ? 0 : offsetY);

        NodeList childNodes = element.getChildNodes();
        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);
            if (childNode.getNodeType() == Node.ELEMENT_NODE && "node".equals(childNode.getNodeName())) {
                node.addChild(readNode((Element) childNode));
            }
        }
        return node;
    }

    private Element firstNodeElement(Element parent) {
        NodeList childNodes = parent.getChildNodes();
        for (int i = 0; i < childNodes.getLength(); i++) {
            Node childNode = childNodes.item(i);
            if (childNode.getNodeType() == Node.ELEMENT_NODE && "node".equals(childNode.getNodeName())) {
                return (Element) childNode;
            }
        }
        return null;
    }

    private void writeOptionalAttribute(Element element, String name, String value) {
        if (value != null && !value.isBlank()) {
            element.setAttribute(name, value);
        }
    }

    private String readOptionalAttribute(Element element, String name) {
        String value = element.getAttribute(name);
        return value == null || value.isBlank() ? null : value;
    }

    private Integer readOptionalIntegerAttribute(Element element, String name) {
        String value = readOptionalAttribute(element, name);
        if (value == null) {
            return null;
        }
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException exception) {
            return null;
        }
    }
}
