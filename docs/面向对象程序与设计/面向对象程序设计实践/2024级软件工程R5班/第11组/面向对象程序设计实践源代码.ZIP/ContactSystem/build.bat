@echo off
cd /d "%~dp0"
setlocal enabledelayedexpansion

set SRC_DIR=src
set OUT_DIR=out/build
set JAR_NAME=ContactSystem.jar
set MANIFEST_FILE=manifest.txt
set LIB_JAR=lib/pinyin4j-2.5.1.jar

if exist "%OUT_DIR%" rd /s /q "%OUT_DIR%"
mkdir "%OUT_DIR%"

if exist "%MANIFEST_FILE%" del /q "%MANIFEST_FILE%"

echo Main-Class: com.contactsystem.Main>"%MANIFEST_FILE%"
echo Class-Path: %LIB_JAR%>>"%MANIFEST_FILE%"

set "SOURCES="
for /r "%SRC_DIR%" %%f in (*.java) do (
    set "SOURCES=!SOURCES! "%%~f""
)

echo 正在编译 Java 源码...
javac -encoding UTF-8 -cp "%LIB_JAR%" -d "%OUT_DIR%" !SOURCES!
if errorlevel 1 (
    echo 编译失败，请检查源码文件编码和依赖。
    pause
    exit /b 1
)

echo 正在创建 JAR 包...
jar cfm "%JAR_NAME%" "%MANIFEST_FILE%" -C "%OUT_DIR%" . -C "%SRC_DIR%\com\resources" .
if errorlevel 1 (
    echo JAR 打包失败。
    pause
    exit /b 1
)

del /q "%MANIFEST_FILE%"

echo 构建完成: %JAR_NAME%
if exist "%JAR_NAME%" (
    echo 运行命令: javaw -jar "%JAR_NAME%"
) else (
    echo 未找到生成的 %JAR_NAME%
)
pause
