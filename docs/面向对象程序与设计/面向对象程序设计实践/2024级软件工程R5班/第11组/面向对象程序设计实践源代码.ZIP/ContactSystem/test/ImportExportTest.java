import com.contactsystem.model.Contact;
import com.contactsystem.model.ContactManager;
import com.contactsystem.util.CSVHandler;
import com.contactsystem.util.VCardParser;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.*;

public class ImportExportTest {
    private static int testsPassed = 0;
    private static int testsFailed = 0;

    public static void main(String[] args) throws Exception {
        System.out.println("=== 通讯录导入导出功能测试 ===\n");

        testCSVRoundtrip();
        testVCardRoundtrip();
        testCSVWithSpecialCharacters();
        testVCardWithSpecialCharacters();
        testCSVEncodingIntegrity();
        testGBKCSVImport();
        testCSVQuoteEscaping();
        testVCardLineFolding();
        testEmptyContacts();
        testBOMHandling();

        System.out.println("\n=== 测试结果汇总 ===");
        System.out.println("通过: " + testsPassed);
        System.out.println("失败: " + testsFailed);
        if (testsFailed > 0) {
            System.out.println("存在失败测试!");
            System.exit(1);
        } else {
            System.out.println("所有测试通过!");
        }
    }

    private static List<Contact> createTestContacts() {
        List<Contact> contacts = new ArrayList<>();

        Contact c1 = new Contact();
        c1.setName("张三");
        c1.setPhone("010-12345678");
        c1.setMobile("13800138000");
        c1.setEmail("zhangsan@example.com");
        c1.setCompany("阿里巴巴");
        c1.setAddress("北京市朝阳区");
        c1.setZipCode("100000");
        c1.setBirthday(LocalDate.of(1990, 5, 15));
        c1.setNotes("测试备注信息");
        c1.setNickName("小张");
        c1.addGroup("同事");
        c1.addGroup("朋友");
        contacts.add(c1);

        Contact c2 = new Contact();
        c2.setName("李四");
        c2.setPhone("021-87654321");
        c2.setMobile("13900139000");
        c2.setEmail("lisi@test.com");
        c2.setCompany("腾讯科技");
        c2.setAddress("上海市浦东新区");
        c2.setNotes("包含特殊字符: 逗号, 分号; 换行\n测试");
        contacts.add(c2);

        Contact c3 = new Contact();
        c3.setName("Wang Wu");
        c3.setPhone("0755-11112222");
        c3.setMobile("13700137000");
        c3.setEmail("wangwu@abc.com");
        c3.setCompany("Huawei");
        contacts.add(c3);

        return contacts;
    }

    // ---- CSV 测试 ----

    static void testCSVRoundtrip() throws Exception {
        System.out.print("CSV 导入导出往返测试... ");
        List<Contact> original = createTestContacts();

        // 导出
        ContactManager cm = new ContactManager();
        cm.exportToCSV("test_export.csv", original);

        // 检查文件是否存在
        File f = new File("test_export.csv");
        if (!f.exists()) {
            fail("导出文件不存在");
            return;
        }

        // 导入
        List<Contact> imported = CSVHandler.parseCSV("test_export.csv");

        // 比较
        boolean match = compareContacts(original, imported, "name,phone,mobile,email,company");
        if (match) {
            pass();
        } else {
            fail("导出和导入的数据不匹配");
            dumpContacts("原始", original);
            dumpContacts("导入", imported);
        }
        f.delete();
    }

    static void testCSVWithSpecialCharacters() throws Exception {
        System.out.print("CSV 特殊字符处理测试... ");
        List<Contact> special = new ArrayList<>();
        Contact c = new Contact();
        c.setName("测试,逗号");
        c.setPhone("010-12345678");
        c.setMobile("13800138000");
        c.setEmail("test@test.com");
        c.setCompany("公司\"引号\"测试");
        c.setNotes("备注包含,逗号和\"引号\"和\n换行");
        c.setAddress("地址;分号:冒号");
        special.add(c);

        ContactManager cm = new ContactManager();
        cm.exportToCSV("test_special.csv", special);
        List<Contact> imported = CSVHandler.parseCSV("test_special.csv");

        if (imported.size() == 1
                && "测试,逗号".equals(imported.get(0).getName())
                && "010-12345678".equals(imported.get(0).getPhone())) {
            pass();
        } else {
            fail("特殊字符处理不正确");
            System.out.println("  原始: " + c.getName() + " | 公司: " + c.getCompany() + " | 备注: " + c.getNotes());
            if (!imported.isEmpty()) {
                System.out.println("  导入: " + imported.get(0).getName() + " | 公司: " + imported.get(0).getCompany() + " | 备注: " + imported.get(0).getNotes());
            }
        }
        new File("test_special.csv").delete();
    }

    static void testCSVEncodingIntegrity() throws Exception {
        System.out.print("CSV 编码完整性测试 (UTF-8)... ");
        List<Contact> chinese = new ArrayList<>();
        Contact c = new Contact();
        c.setName("测试联系人");
        c.setPhone("010-12345678");
        c.setMobile("13800138000");
        c.setEmail("test@test.com");
        c.setCompany("中国公司测试");
        c.setAddress("北京市海淀区中关村");
        c.setNotes("中文备注信息");
        chinese.add(c);

        ContactManager cm = new ContactManager();
        String filePath = "test_encoding.csv";
        cm.exportToCSV(filePath, chinese);

        // 直接读取原始字节检查编码
        byte[] raw = Files.readAllBytes(Paths.get(filePath));

        // UTF-8 BOM? 检查是否包含中文字符的UTF-8编码
        // 检查文件内容是否包含中文（UTF-8编码的中文应该是多字节）
        String content = new String(raw, StandardCharsets.UTF_8);
        boolean containsChinese = content.contains("测试联系人") && content.contains("中国公司测试");

        // 再用程序导入检查
        List<Contact> imported = CSVHandler.parseCSV(filePath);

        if (containsChinese && imported.size() == 1
                && "测试联系人".equals(imported.get(0).getName())
                && "中国公司测试".equals(imported.get(0).getCompany())) {
            pass();
        } else {
            fail("CSV 编码处理有问题");
            System.out.println("  原始中文: 测试联系人, 中国公司测试");
            if (!imported.isEmpty()) {
                System.out.println("  导入中文: " + imported.get(0).getName() + ", " + imported.get(0).getCompany());
            }
            System.out.println("  UTF-8读取: " + (containsChinese ? "正常" : "乱码"));
            // 打印原始字节的前200字节
            System.out.print("  文件前200字节(hex): ");
            for (int i = 0; i < Math.min(200, raw.length); i++) {
                System.out.printf("%02X ", raw[i]);
            }
            System.out.println();
        }
        new File(filePath).delete();
    }

    static void testGBKCSVImport() throws Exception {
        System.out.print("GBK编码CSV文件导入测试... ");
        // 创建一个GBK编码的CSV文件（模拟旧版本或其他中文系统导出）
        File f = new File("test_gbk.csv");
        try (FileOutputStream fos = new FileOutputStream(f)) {
            fos.write("姓名,电话,手机,邮箱,工作单位,地址,备注\n".getBytes("GBK"));
            fos.write("测试用户,010-11111111,13800001111,test@test.com,测试公司,北京市,\"包含,逗号\"\n".getBytes("GBK"));
            fos.write("张三,010-22222222,13800002222,zhang@test.com,阿里巴巴,杭州市,\n".getBytes("GBK"));
        }

        List<Contact> imported = CSVHandler.parseCSV("test_gbk.csv");

        if (imported.size() == 2
                && "测试用户".equals(imported.get(0).getName())
                && "13800001111".equals(imported.get(0).getMobile())
                && "张三".equals(imported.get(1).getName())
                && "阿里巴巴".equals(imported.get(1).getCompany())) {
            pass();
        } else {
            fail("GBK编码CSV导入不正确");
            System.out.println("  导入数量: " + imported.size());
            for (int i = 0; i < imported.size(); i++) {
                Contact c = imported.get(i);
                System.out.println("  [" + i + "] name=" + c.getName() + " phone=" + c.getPhone()
                        + " mobile=" + c.getMobile() + " company=" + c.getCompany());
            }
        }
        f.delete();
    }

    static void testCSVQuoteEscaping() throws Exception {
        System.out.print("CSV 引号转义测试... ");
        List<Contact> contacts = new ArrayList<>();
        Contact c = new Contact();
        c.setName("包含\"引号\"的名字");
        c.setPhone("010-12345678");
        c.setMobile("13800138000");
        c.setEmail("test@test.com");
        c.setNotes("备注\"包含\"引号和,逗号");
        contacts.add(c);

        ContactManager cm = new ContactManager();
        cm.exportToCSV("test_quotes.csv", contacts);
        List<Contact> imported = CSVHandler.parseCSV("test_quotes.csv");

        if (imported.size() == 1
                && "包含\"引号\"的名字".equals(imported.get(0).getName())) {
            pass();
        } else {
            fail("CSV 引号转义不正确");
            System.out.println("  原始姓名: " + c.getName());
            if (!imported.isEmpty()) {
                System.out.println("  导入姓名: " + imported.get(0).getName());
            }
        }
        new File("test_quotes.csv").delete();
    }

    static void testBOMHandling() throws Exception {
        System.out.print("UTF-8 BOM 处理测试... ");
        // 创建一个带BOM的UTF-8文件
        File f = new File("test_bom.csv");
        try (FileOutputStream fos = new FileOutputStream(f)) {
            fos.write(0xEF);
            fos.write(0xBB);
            fos.write(0xBF);
            fos.write("姓名,电话,手机\n测试人,010-1234,1380000\n".getBytes(StandardCharsets.UTF_8));
        }

        List<Contact> imported = CSVHandler.parseCSV("test_bom.csv");
        if (imported.size() == 1 && "测试人".equals(imported.get(0).getName())) {
            pass();
        } else {
            fail("BOM 处理不正确");
            System.out.println("  导入数量: " + imported.size());
            if (!imported.isEmpty()) {
                System.out.println("  姓名: " + imported.get(0).getName());
            }
        }
        f.delete();
    }

    // ---- vCard 测试 ----

    static void testVCardRoundtrip() throws Exception {
        System.out.print("vCard 导入导出往返测试... ");
        List<Contact> original = createTestContacts();

        ContactManager cm = new ContactManager();
        cm.exportToVCard("test_export.vcf", original);

        File f = new File("test_export.vcf");
        if (!f.exists()) {
            fail("导出文件不存在");
            return;
        }

        List<Contact> imported = VCardParser.parseVCard("test_export.vcf");

        // 检查核心字段
        if (imported.size() == 3) {
            Contact i1 = imported.get(0);
            Contact o1 = original.get(0);
            if ("张三".equals(i1.getName())
                    && o1.getPhone().equals(i1.getPhone())
                    && o1.getMobile().equals(i1.getMobile())
                    && o1.getEmail().equals(i1.getEmail())) {
                pass();
            } else {
                fail("vCard 往返数据不匹配");
                dumpContact("原始[0]", o1);
                dumpContact("导入[0]", i1);
            }
        } else {
            fail("vCard 导入数量不匹配，期望3，实际" + imported.size());
        }
        f.delete();
    }

    static void testVCardWithSpecialCharacters() throws Exception {
        System.out.print("vCard 特殊字符处理测试... ");
        List<Contact> special = new ArrayList<>();
        Contact c = new Contact();
        c.setName("测试;分号,逗号\\反斜杠");
        c.setPhone("010-12345678");
        c.setMobile("13800138000");
        c.setEmail("test@test.com");
        c.setCompany("公司;名");
        c.setAddress("地址,包含特殊;字符");
        c.setNotes("备注\\n测试");
        special.add(c);

        ContactManager cm = new ContactManager();
        cm.exportToVCard("test_special.vcf", special);
        List<Contact> imported = VCardParser.parseVCard("test_special.vcf");

        if (imported.size() == 1) {
            Contact i = imported.get(0);
            System.out.println("  导入姓名: '" + i.getName() + "'");
            System.out.println("  导入公司: '" + i.getCompany() + "'");
            // 检查姓名是否被正确保留（即使不完美，至少不要破坏结构）
            if (i.getName() != null && i.getName().length() > 0) {
                pass();
            } else {
                fail("vCard 特殊字符导致姓名为空");
            }
        } else {
            fail("vCard 特殊字符处理不正确，导入" + imported.size() + "条");
        }
        new File("test_special.vcf").delete();
    }

    static void testVCardLineFolding() throws Exception {
        System.out.print("vCard 行折叠处理测试... ");
        // 创建一个手动构造的带折叠行的vCard
        String vcardContent = "BEGIN:VCARD\r\n" +
                "VERSION:3.0\r\n" +
                "FN:折叠\r\n" +
                " 测试\r\n" +
                "N:折叠;测\r\n" +
                " 试;;;\r\n" +
                "TEL:010-12345678\r\n" +
                "END:VCARD\r\n";

        Files.write(Paths.get("test_fold.vcf"), vcardContent.getBytes(StandardCharsets.UTF_8));
        List<Contact> imported = VCardParser.parseVCard("test_fold.vcf");

        // The folded line for FN should combine "折叠" + "测试"
        if (imported.size() == 1 && imported.get(0).getName() != null) {
            System.out.println("  导入姓名: '" + imported.get(0).getName() + "'");
            pass();
        } else {
            fail("vCard 行折叠处理不正确");
        }
        new File("test_fold.vcf").delete();
    }

    static void testEmptyContacts() throws Exception {
        System.out.print("空联系人列表导入导出测试... ");
        List<Contact> empty = new ArrayList<>();

        ContactManager cm = new ContactManager();
        cm.exportToCSV("test_empty.csv", empty);
        cm.exportToVCard("test_empty.vcf", empty);

        List<Contact> csvImported = CSVHandler.parseCSV("test_empty.csv");
        List<Contact> vcardImported = VCardParser.parseVCard("test_empty.vcf");

        if (csvImported.isEmpty() && vcardImported.isEmpty()) {
            pass();
        } else {
            fail("空列表应该导出0个联系人");
        }
        new File("test_empty.csv").delete();
        new File("test_empty.vcf").delete();
    }

    // ---- 辅助方法 ----

    static boolean compareContacts(List<Contact> a, List<Contact> b, String fields) {
        if (a.size() != b.size()) {
            System.out.println("  数量不匹配: " + a.size() + " vs " + b.size());
            return false;
        }
        for (int i = 0; i < a.size(); i++) {
            Contact ca = a.get(i);
            Contact cb = b.get(i);
            if (!Objects.equals(ca.getName(), cb.getName())) {
                System.out.println("  姓名不匹配[" + i + "]: '" + ca.getName() + "' vs '" + cb.getName() + "'");
                return false;
            }
            if (!Objects.equals(ca.getPhone(), cb.getPhone())) {
                System.out.println("  电话不匹配[" + i + "]: " + ca.getPhone() + " vs " + cb.getPhone());
                return false;
            }
            if (!Objects.equals(ca.getMobile(), cb.getMobile())) {
                System.out.println("  手机不匹配[" + i + "]: " + ca.getMobile() + " vs " + cb.getMobile());
                return false;
            }
            if (!Objects.equals(ca.getEmail(), cb.getEmail())) {
                System.out.println("  邮箱不匹配[" + i + "]: " + ca.getEmail() + " vs " + cb.getEmail());
                return false;
            }
        }
        return true;
    }

    static void dumpContacts(String label, List<Contact> contacts) {
        System.out.println("  " + label + ":");
        for (int i = 0; i < contacts.size(); i++) {
            System.out.println("    [" + i + "] " + contacts.get(i));
        }
    }

    static void dumpContact(String label, Contact c) {
        System.out.println("  " + label + ": name=" + c.getName() + " phone=" + c.getPhone()
                + " mobile=" + c.getMobile() + " email=" + c.getEmail() + " company=" + c.getCompany());
    }

    static void pass() {
        testsPassed++;
        System.out.println("通过");
    }

    static void fail(String msg) {
        testsFailed++;
        System.out.println("失败: " + msg);
    }
}
