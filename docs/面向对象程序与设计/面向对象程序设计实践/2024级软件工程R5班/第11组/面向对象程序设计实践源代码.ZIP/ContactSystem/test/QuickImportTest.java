import com.contactsystem.util.CSVHandler;
import com.contactsystem.model.Contact;
import java.util.List;

public class QuickImportTest {
    public static void main(String[] args) throws Exception {
        List<Contact> contacts = CSVHandler.parseCSV("C:/Users/tomato/Desktop/contacts.csv");
        System.out.println("导入联系人数量: " + contacts.size());
        for (Contact c : contacts) {
            System.out.println("  姓名: " + c.getName() + " | 电话: " + c.getPhone() + " | 手机: " + c.getMobile());
        }
    }
}
