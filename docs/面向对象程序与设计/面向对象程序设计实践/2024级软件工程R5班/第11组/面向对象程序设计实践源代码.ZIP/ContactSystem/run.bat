@echo off
cd /d "%~dp0"
if not exist "ContactSystem.jar" (
    echo 未找到 ContactSystem.jar，请先运行 build.bat 生成。
    pause
    exit /b 1
)
javaw -jar "ContactSystem.jar"