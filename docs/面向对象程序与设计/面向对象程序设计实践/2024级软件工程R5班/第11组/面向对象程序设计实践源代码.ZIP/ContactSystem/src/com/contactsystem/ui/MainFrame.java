package com.contactsystem.ui;

import com.contactsystem.model.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

public class MainFrame extends JFrame {
    private ContactManager contactManager;

    // 左侧组件
    private JTree groupTree;
    private DefaultMutableTreeNode rootNode;
    private DefaultTreeModel treeModel;
    private JButton addGroupButton;
    private JButton deleteGroupButton;
    private JButton manageGroupButton;

    // 右侧组件
    private JTable contactTable;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JButton searchButton;
    private JButton addContactButton;
    private JButton editContactButton;
    private JButton deleteContactButton;
    private JButton exportButton;
    private JButton importButton;
    private JButton refreshButton;
    private JComboBox<String> displayColumnsCombo;

    // 状态栏
    private JLabel statusLabel;

    // 照片预览
    private JLabel photoPreviewLabel;

    // 当前选中的分组
    private String currentGroupId = null;

    public MainFrame() {
        contactManager = new ContactManager();
        initUI();
        loadContacts();
    }

    private void initUI() {
        setTitle("通讯录管理系统");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 700);
        setLocationRelativeTo(null);

        // 创建菜单栏
        createMenuBar();

        // 主面板
        JPanel mainPanel = new JPanel(new BorderLayout(5, 5));
        mainPanel.setBorder(new EmptyBorder(5, 5, 5, 5));

        // 左侧分组面板
        JPanel leftPanel = createLeftPanel();

        // 右侧联系人面板
        JPanel rightPanel = createRightPanel();

        // 分割面板
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftPanel, rightPanel);
        splitPane.setDividerLocation(250);
        splitPane.setOneTouchExpandable(true);

        // 状态栏
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusLabel = new JLabel("就绪");
        statusPanel.add(statusLabel, BorderLayout.WEST);
        statusPanel.setBorder(BorderFactory.createEtchedBorder());

        mainPanel.add(splitPane, BorderLayout.CENTER);
        mainPanel.add(statusPanel, BorderLayout.SOUTH);

        add(mainPanel);

        // 设置窗口图标
        try {
            java.net.URL iconUrl = getClass().getResource("/icons/contacts.png");
            if (iconUrl != null) {
                setIconImage(new ImageIcon(iconUrl).getImage());
            }
        } catch (Exception ignored) {
        }
    }

    private void createMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        // 文件菜单
        JMenu fileMenu = new JMenu("文件");
        JMenuItem exportItem = new JMenuItem("导出...");
        JMenuItem importItem = new JMenuItem("导入...");
        JMenuItem exitItem = new JMenuItem("退出");

        exportItem.addActionListener(e -> showExportDialog());
        importItem.addActionListener(e -> showImportDialog());
        exitItem.addActionListener(e -> System.exit(0));

        fileMenu.add(exportItem);
        fileMenu.add(importItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);

        // 工具菜单
        JMenu toolsMenu = new JMenu("工具");
        JMenuItem backupItem = new JMenuItem("备份数据");
        JMenuItem restoreItem = new JMenuItem("恢复数据");

        backupItem.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setSelectedFile(new File("contacts_backup.dat"));
            if (fileChooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
                String path = fileChooser.getSelectedFile().getAbsolutePath();
                if (contactManager.backupData(path)) {
                    JOptionPane.showMessageDialog(this, "数据备份成功!", "备份", JOptionPane.INFORMATION_MESSAGE);
                    statusLabel.setText("已备份到: " + path);
                } else {
                    JOptionPane.showMessageDialog(this, "备份失败! 请先添加联系人数据。", "错误", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        restoreItem.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this,
                    "恢复数据将覆盖当前所有数据，确定继续?", "确认恢复", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
                    "数据备份文件 (*.dat)", "dat"));
            if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                String path = fileChooser.getSelectedFile().getAbsolutePath();
                if (contactManager.restoreData(path)) {
                    refreshContactList();
                    loadGroups();
                    JOptionPane.showMessageDialog(this, "数据恢复成功!", "恢复", JOptionPane.INFORMATION_MESSAGE);
                    statusLabel.setText("已从 " + path + " 恢复数据");
                } else {
                    JOptionPane.showMessageDialog(this, "恢复失败!", "错误", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        toolsMenu.add(backupItem);
        toolsMenu.add(restoreItem);

        // 帮助菜单
        JMenu helpMenu = new JMenu("帮助");
        JMenuItem aboutItem = new JMenuItem("关于");

        aboutItem.addActionListener(e -> showAboutDialog());
        helpMenu.add(aboutItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        menuBar.add(helpMenu);

        setJMenuBar(menuBar);
    }

    // ---- Display columns management ----

    private void updateDisplayColumns() {
        int selected = displayColumnsCombo.getSelectedIndex();
        // 列: 0=选择, 1=ID(隐藏), 2=姓名, 3=电话, 4=手机, 5=邮箱, 6=公司, 7=分组, 8=照片
        boolean showAll = selected == 0 || selected == 2;
        boolean showBasic = selected == 1;

        // 电话和手机在基本和全部模式下显示
        for (int col : new int[]{3, 4}) {
            contactTable.getColumnModel().getColumn(col).setMinWidth(showAll || showBasic ? 90 : 0);
            contactTable.getColumnModel().getColumn(col).setMaxWidth(showAll || showBasic ? 200 : 0);
            contactTable.getColumnModel().getColumn(col).setPreferredWidth(showAll || showBasic ? 90 : 0);
        }
        // 邮箱、公司、分组、照片只在全部/详细模式下显示
        for (int col : new int[]{5, 6, 7, 8}) {
            int w = col == 8 ? 44 : 140;
            contactTable.getColumnModel().getColumn(col).setMinWidth(showAll ? w : 0);
            contactTable.getColumnModel().getColumn(col).setMaxWidth(showAll ? (col == 8 ? 44 : 300) : 0);
            contactTable.getColumnModel().getColumn(col).setPreferredWidth(showAll ? w : 0);
        }
        contactTable.revalidate();
        contactTable.repaint();
    }

    private void showAdvancedSearchDialog() {
        JDialog dialog = new JDialog(this, "高级搜索", true);
        dialog.setSize(450, 250);
        dialog.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(new EmptyBorder(15, 15, 15, 15));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("搜索类型:"), gbc);
        gbc.gridx = 1;
        JComboBox<String> typeCombo = new JComboBox<>(
                new String[]{"全部", "姓名", "电话", "手机", "邮箱", "公司", "拼音"});
        panel.add(typeCombo, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("关键字:"), gbc);
        gbc.gridx = 1;
        JTextField keywordField = new JTextField(20);
        panel.add(keywordField, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        JPanel btnPanel = new JPanel(new FlowLayout());
        JButton searchBtn = new JButton("搜索");
        JButton cancelBtn = new JButton("取消");
        btnPanel.add(searchBtn);
        btnPanel.add(cancelBtn);
        panel.add(btnPanel, gbc);

        searchBtn.addActionListener(e -> {
            String keyword = keywordField.getText().trim();
            if (keyword.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "请输入搜索关键字!", "提示", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String type = (String) typeCombo.getSelectedItem();
            List<Contact> results = contactManager.getAllContacts().stream()
                    .filter(c -> {
                        String ctx;
                        switch (type) {
                            case "姓名": ctx = c.getName(); break;
                            case "电话": ctx = c.getPhone(); break;
                            case "手机": ctx = c.getMobile(); break;
                            case "邮箱": ctx = c.getEmail(); break;
                            case "公司": ctx = c.getCompany(); break;
                            case "拼音":
                                ctx = (c.getFullPinyin() != null ? c.getFullPinyin() : "")
                                    + (c.getPinyinInitial() != null ? c.getPinyinInitial() : "");
                                break;
                            default:
                                return contactManager.searchContacts(keyword).contains(c);
                        }
                        return ctx != null && ctx.toLowerCase().contains(keyword.toLowerCase());
                    })
                    .sorted()
                    .collect(Collectors.toList());
            updateContactTable(results);
            statusLabel.setText("高级搜索找到 " + results.size() + " 个匹配的联系人");
            dialog.dispose();
        });

        cancelBtn.addActionListener(e -> dialog.dispose());
        dialog.add(panel);
        dialog.setVisible(true);
    }

    private JPanel createLeftPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));
        panel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "联系人分组", TitledBorder.LEFT, TitledBorder.TOP));

        // 创建分组树
        rootNode = new DefaultMutableTreeNode("所有联系人");
        treeModel = new DefaultTreeModel(rootNode);
        groupTree = new JTree(treeModel);
        groupTree.setRootVisible(true);
        groupTree.setShowsRootHandles(true);

        // 加载分组
        loadGroups();

        JScrollPane treeScroll = new JScrollPane(groupTree);
        treeScroll.setPreferredSize(new Dimension(200, 400));

        // 分组按钮面板
        JPanel buttonPanel = new JPanel(new GridLayout(1, 3, 5, 5));
        addGroupButton = new JButton("新建分组");
        deleteGroupButton = new JButton("删除分组");
        manageGroupButton = new JButton("管理分组");

        buttonPanel.add(addGroupButton);
        buttonPanel.add(deleteGroupButton);
        buttonPanel.add(manageGroupButton);

        panel.add(treeScroll, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        // 添加事件监听
        setupTreeListeners();
        setupButtonListeners();

        return panel;
    }

    private JPanel createRightPanel() {
        JPanel panel = new JPanel(new BorderLayout(5, 5));

        // 搜索面板
        JPanel searchPanel = new JPanel(new BorderLayout(5, 5));
        searchField = new JTextField(20);
        searchButton = new JButton("搜索");
        JButton advancedSearchButton = new JButton("高级搜索");

        JPanel searchInputPanel = new JPanel(new BorderLayout(5, 5));
        searchInputPanel.add(new JLabel("搜索:"), BorderLayout.WEST);
        searchInputPanel.add(searchField, BorderLayout.CENTER);

        JPanel searchButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        searchButtonPanel.add(searchButton);
        searchButtonPanel.add(advancedSearchButton);

        advancedSearchButton.addActionListener(e -> showAdvancedSearchDialog());

        searchPanel.add(searchInputPanel, BorderLayout.CENTER);
        searchPanel.add(searchButtonPanel, BorderLayout.EAST);

        // 工具面板
        JPanel toolPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 5));
        addContactButton = new JButton("新建联系人");
        editContactButton = new JButton("编辑联系人");
        deleteContactButton = new JButton("删除联系人");
        exportButton = new JButton("导出");
        importButton = new JButton("导入");
        refreshButton = new JButton("刷新");

        // 显示列选择
        JPanel displayPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        displayPanel.add(new JLabel("显示列:"));
        String[] columnOptions = {"全部", "基本信息", "详细资料"};
        displayColumnsCombo = new JComboBox<>(columnOptions);
        displayColumnsCombo.setSelectedIndex(0);
        displayPanel.add(displayColumnsCombo);

        toolPanel.add(addContactButton);
        toolPanel.add(editContactButton);
        toolPanel.add(deleteContactButton);
        toolPanel.add(new JSeparator(SwingConstants.VERTICAL));
        toolPanel.add(exportButton);
        toolPanel.add(importButton);
        toolPanel.add(new JSeparator(SwingConstants.VERTICAL));
        toolPanel.add(refreshButton);

        // 联系人表格（ID列隐藏存储，照片列用自定义渲染器）
        String[] columnNames = {"选择", "ID", "姓名", "电话", "手机", "邮箱", "公司", "分组", "照片"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                if (columnIndex == 0) {
                    return Boolean.class; // 选择列使用复选框
                }
                return String.class;
            }

            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 0; // 只有选择列可编辑
            }
        };

        contactTable = new JTable(tableModel);
        contactTable.setRowHeight(40);
        contactTable.setAutoCreateRowSorter(true);
        contactTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // 设置列宽：隐藏ID列，照片列用自定义渲染器
        contactTable.getColumnModel().getColumn(0).setPreferredWidth(30);
        contactTable.getColumnModel().getColumn(0).setMaxWidth(30);
        contactTable.getColumnModel().getColumn(1).setMinWidth(0);
        contactTable.getColumnModel().getColumn(1).setMaxWidth(0);
        contactTable.getColumnModel().getColumn(1).setWidth(0);
        contactTable.getColumnModel().getColumn(2).setPreferredWidth(100);
        contactTable.getColumnModel().getColumn(3).setPreferredWidth(90);
        contactTable.getColumnModel().getColumn(4).setPreferredWidth(90);
        contactTable.getColumnModel().getColumn(5).setPreferredWidth(140);
        contactTable.getColumnModel().getColumn(6).setPreferredWidth(130);
        contactTable.getColumnModel().getColumn(7).setPreferredWidth(80);
        contactTable.getColumnModel().getColumn(8).setPreferredWidth(44);
        contactTable.getColumnModel().getColumn(8).setMaxWidth(44);
        contactTable.getColumnModel().getColumn(8).setCellRenderer(
                new com.contactsystem.ui.renderer.PhotoCellRenderer());

        JScrollPane tableScroll = new JScrollPane(contactTable);
        tableScroll.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "联系人列表", TitledBorder.LEFT, TitledBorder.TOP));

        // 照片预览面板
        JPanel photoPreviewPanel = new JPanel(new BorderLayout(5, 5));
        photoPreviewPanel.setBorder(BorderFactory.createTitledBorder("照片预览"));
        photoPreviewLabel = new JLabel("选择联系人查看照片", SwingConstants.CENTER);
        photoPreviewLabel.setPreferredSize(new Dimension(100, 100));
        photoPreviewPanel.add(photoPreviewLabel, BorderLayout.CENTER);
        photoPreviewPanel.setPreferredSize(new Dimension(160, 130));

        // 统计信息面板
        JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JLabel countLabel = new JLabel("共 0 个联系人");
        infoPanel.add(countLabel);

        panel.add(searchPanel, BorderLayout.NORTH);

        // 把工具栏、显示列和表格组合到中心区域
        JPanel centerPanel = new JPanel(new BorderLayout(0, 5));
        JPanel toolAndDisplayPanel = new JPanel(new BorderLayout(5, 0));
        toolAndDisplayPanel.add(toolPanel, BorderLayout.WEST);
        toolAndDisplayPanel.add(displayPanel, BorderLayout.EAST);
        centerPanel.add(toolAndDisplayPanel, BorderLayout.NORTH);
        centerPanel.add(tableScroll, BorderLayout.CENTER);

        // 底部：照片预览 + 统计信息
        JPanel southPanel = new JPanel(new BorderLayout(5, 0));
        southPanel.add(infoPanel, BorderLayout.CENTER);
        southPanel.add(photoPreviewPanel, BorderLayout.EAST);
        centerPanel.add(southPanel, BorderLayout.SOUTH);

        panel.add(centerPanel, BorderLayout.CENTER);

        // 添加事件监听
        setupContactListeners();

        return panel;
    }

    private void setupTreeListeners() {
        groupTree.addTreeSelectionListener(e -> {
            TreePath path = e.getPath();
            if (path != null) {
                Object lastPath = path.getLastPathComponent();
                if (lastPath instanceof DefaultMutableTreeNode) {
                    DefaultMutableTreeNode node = (DefaultMutableTreeNode) lastPath;
                    Object userObject = node.getUserObject();
                    if (userObject instanceof ContactGroup) {
                        ContactGroup group = (ContactGroup) userObject;
                        currentGroupId = group.getId();
                        showContactsInGroup(currentGroupId);
                    } else if ("所有联系人".equals(userObject)) {
                        currentGroupId = null;
                        showAllContacts();
                    }
                }
            }
        });

        // 双击分组节点管理分组
        groupTree.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    manageGroupButton.doClick();
                }
            }
        });
    }

    private void setupButtonListeners() {
        // 新建分组
        addGroupButton.addActionListener(e -> {
            String groupName = JOptionPane.showInputDialog(this, "请输入分组名称:", "新建分组", JOptionPane.PLAIN_MESSAGE);
            if (groupName != null && !groupName.trim().isEmpty()) {
                ContactGroup group = new ContactGroup(groupName.trim());
                if (contactManager.addGroup(group)) {
                    DefaultMutableTreeNode groupNode = new DefaultMutableTreeNode(group);
                    rootNode.add(groupNode);
                    treeModel.reload(rootNode);
                    expandAllTreeNodes();
                    statusLabel.setText("分组创建成功: " + groupName);
                } else {
                    JOptionPane.showMessageDialog(this, "分组已存在!", "错误", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // 删除分组
        deleteGroupButton.addActionListener(e -> {
            TreePath path = groupTree.getSelectionPath();
            if (path != null) {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode) path.getLastPathComponent();
                Object userObject = node.getUserObject();
                if (userObject instanceof ContactGroup) {
                    ContactGroup group = (ContactGroup) userObject;
                    int confirm = JOptionPane.showConfirmDialog(this,
                            "确定要删除分组 '" + group.getName() + "' 吗?\n(不会删除分组中的联系人)",
                            "确认删除", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.YES_OPTION) {
                        if (contactManager.deleteGroup(group.getId())) {
                            rootNode.remove(node);
                            treeModel.reload(rootNode);
                            statusLabel.setText("分组删除成功: " + group.getName());
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "不能删除根节点!", "提示", JOptionPane.WARNING_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "请先选择一个分组!", "提示", JOptionPane.WARNING_MESSAGE);
            }
        });

        // 管理分组
        manageGroupButton.addActionListener(e -> {
            TreePath path = groupTree.getSelectionPath();
            if (path != null) {
                DefaultMutableTreeNode node = (DefaultMutableTreeNode) path.getLastPathComponent();
                Object userObject = node.getUserObject();
                if (userObject instanceof ContactGroup) {
                    ContactGroup group = (ContactGroup) userObject;
                    new GroupDialog(this, contactManager, group).setVisible(true);
                }
            } else {
                JOptionPane.showMessageDialog(this, "请先选择一个分组!", "提示", JOptionPane.WARNING_MESSAGE);
            }
        });
    }

    private void setupContactListeners() {
        // 新建联系人
        addContactButton.addActionListener(e -> {
            ContactDialog dialog = new ContactDialog(this, contactManager, null);
            dialog.setVisible(true);
            if (dialog.isSuccess()) {
                refreshContactList();
                loadGroups();
            }
        });

        // 编辑联系人
        editContactButton.addActionListener(e -> {
            int selectedRow = contactTable.getSelectedRow();
            if (selectedRow >= 0) {
                int modelRow = contactTable.convertRowIndexToModel(selectedRow);
                String contactId = (String) contactTable.getModel().getValueAt(modelRow, 1);
                Contact contact = contactManager.getContact(contactId);
                if (contact != null) {
                    ContactDialog dialog = new ContactDialog(this, contactManager, contact);
                    dialog.setVisible(true);
                    if (dialog.isSuccess()) {
                        refreshContactList();
                        loadGroups();
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "请先选择一个联系人!", "提示", JOptionPane.WARNING_MESSAGE);
            }
        });

        // 删除联系人
        deleteContactButton.addActionListener(e -> {
            List<String> selectedIds = getSelectedContactIds();
            if (!selectedIds.isEmpty()) {
                int confirm = JOptionPane.showConfirmDialog(this,
                        "确定要删除选中的 " + selectedIds.size() + " 个联系人吗?",
                        "确认删除", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    int count = 0;
                    for (String id : selectedIds) {
                        if (contactManager.deleteContact(id)) {
                            count++;
                        }
                    }
                    refreshContactList();
                    statusLabel.setText("成功删除 " + count + " 个联系人");
                }
            } else {
                JOptionPane.showMessageDialog(this, "请先选择联系人!", "提示", JOptionPane.WARNING_MESSAGE);
            }
        });

        // 搜索联系人
        searchButton.addActionListener(e -> {
            String keyword = searchField.getText().trim();
            if (!keyword.isEmpty()) {
                List<Contact> results = contactManager.searchContacts(keyword);
                updateContactTable(results);
                statusLabel.setText("找到 " + results.size() + " 个匹配的联系人");
            } else {
                refreshContactList();
            }
        });

        searchField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    searchButton.doClick();
                }
            }
        });

        // 导出
        exportButton.addActionListener(e -> showExportDialog());

        // 导入
        importButton.addActionListener(e -> showImportDialog());

        // 刷新
        refreshButton.addActionListener(e -> {
            refreshContactList();
            searchField.setText("");
            statusLabel.setText("已刷新");
        });

        // 显示列选择
        displayColumnsCombo.addActionListener(e -> {
            updateDisplayColumns();
        });

        // 选中行时更新照片预览
        contactTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                updatePhotoPreview();
            }
        });

        // 双击表格编辑
        contactTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    editContactButton.doClick();
                }
            }
        });
    }

    private void loadGroups() {
        rootNode.removeAllChildren();

        // 加载所有分组
        for (ContactGroup group : contactManager.getAllGroups()) {
            DefaultMutableTreeNode groupNode = new DefaultMutableTreeNode(group);
            rootNode.add(groupNode);
        }

        treeModel.reload(rootNode);
        expandAllTreeNodes();
    }

    private void loadContacts() {
        refreshContactList();
    }

    private void refreshContactList() {
        if (currentGroupId != null) {
            showContactsInGroup(currentGroupId);
        } else {
            showAllContacts();
        }
    }

    private void showAllContacts() {
        List<Contact> contacts = contactManager.getAllContacts();
        updateContactTable(contacts);
        statusLabel.setText("显示所有联系人 (" + contacts.size() + " 个)");
    }

    private void showContactsInGroup(String groupId) {
        ContactGroup group = contactManager.getGroup(groupId);
        if (group != null) {
            List<Contact> contacts = contactManager.getContactsInGroup(groupId);
            updateContactTable(contacts);
            statusLabel.setText("分组: " + group.getName() + " (" + contacts.size() + " 个联系人)");
        }
    }

    private void updateContactTable(List<Contact> contacts) {
        tableModel.setRowCount(0);

        for (Contact contact : contacts) {
            Object[] row = {
                    false, // 选择框 (0)
                    contact.getID(), // 隐藏的ID (1)
                    contact.getName(), // 姓名 (2)
                    contact.getPhone() != null ? contact.getPhone() : "", // 电话 (3)
                    contact.getMobile() != null ? contact.getMobile() : "", // 手机 (4)
                    contact.getEmail() != null ? contact.getEmail() : "", // 邮箱 (5)
                    contact.getCompany() != null ? contact.getCompany() : "", // 公司 (6)
                    contact.getGroupsString(), // 分组 (7)
                    contact.getPhotoPath() != null ? contact.getPhotoPath() : "" // 照片 (8)
            };
            tableModel.addRow(row);
        }
    }

    private List<String> getSelectedContactIds() {
        List<String> selectedIds = new ArrayList<>();
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            Boolean selected = (Boolean) tableModel.getValueAt(i, 0);
            if (selected != null && selected) {
                String contactId = (String) tableModel.getValueAt(i, 1);
                selectedIds.add(contactId);
            }
        }
        return selectedIds;
    }

    private void expandAllTreeNodes() {
        for (int i = 0; i < groupTree.getRowCount(); i++) {
            groupTree.expandRow(i);
        }
    }

    private void showExportDialog() {
        JDialog dialog = new JDialog(this, "导出联系人", true);
        dialog.setSize(400, 300);
        dialog.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridLayout(5, 1, 10, 10));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel formatLabel = new JLabel("选择导出格式:");
        JComboBox<String> formatCombo = new JComboBox<>(new String[]{"CSV", "vCard"});

        JLabel scopeLabel = new JLabel("选择导出范围:");
        ButtonGroup scopeGroup = new ButtonGroup();
        JRadioButton allRadio = new JRadioButton("所有联系人", true);
        JRadioButton selectedRadio = new JRadioButton("选中的联系人");
        JRadioButton currentGroupRadio = new JRadioButton("当前分组");

        scopeGroup.add(allRadio);
        scopeGroup.add(selectedRadio);
        scopeGroup.add(currentGroupRadio);

        JPanel scopePanel = new JPanel(new GridLayout(3, 1));
        scopePanel.add(allRadio);
        scopePanel.add(selectedRadio);
        scopePanel.add(currentGroupRadio);

        JButton exportButton = new JButton("导出");
        JButton cancelButton = new JButton("取消");

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(exportButton);
        buttonPanel.add(cancelButton);

        panel.add(formatLabel);
        panel.add(formatCombo);
        panel.add(scopeLabel);
        panel.add(scopePanel);
        panel.add(buttonPanel);

        exportButton.addActionListener(e -> {
            int format = formatCombo.getSelectedIndex();
            String fileExtension = format == 0 ? "csv" : "vcf";

            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setSelectedFile(new File("contacts." + fileExtension));
            int result = fileChooser.showSaveDialog(dialog);

            if (result == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                try {
                    List<Contact> contactsToExport = getContactsToExport(allRadio, selectedRadio, currentGroupRadio);

                    if (format == 0) {
                        contactManager.exportToCSV(file.getAbsolutePath(), contactsToExport);
                    } else {
                        contactManager.exportToVCard(file.getAbsolutePath(), contactsToExport);
                    }

                    JOptionPane.showMessageDialog(dialog,
                            "成功导出 " + contactsToExport.size() + " 个联系人",
                            "导出成功", JOptionPane.INFORMATION_MESSAGE);
                    dialog.dispose();

                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog,
                            "导出失败: " + ex.getMessage(),
                            "错误", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        cancelButton.addActionListener(e -> dialog.dispose());

        dialog.add(panel);
        dialog.setVisible(true);
    }

    private List<Contact> getContactsToExport(JRadioButton allRadio, JRadioButton selectedRadio,
                                              JRadioButton currentGroupRadio) {
        if (selectedRadio.isSelected()) {
            List<String> selectedIds = getSelectedContactIds();
            return selectedIds.stream()
                    .map(contactManager::getContact)
                    .filter(Objects::nonNull)
                    .collect(Collectors.toList());
        } else if (currentGroupRadio.isSelected() && currentGroupId != null) {
            return contactManager.getContactsInGroup(currentGroupId);
        } else {
            return contactManager.getAllContacts();
        }
    }

    private void showImportDialog() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
                "通讯录文件 (*.csv, *.vcf)", "csv", "vcf"));

        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            String fileName = file.getName().toLowerCase();

            try {
                List<Contact> importedContacts;
                if (fileName.endsWith(".csv")) {
                    importedContacts = contactManager.importFromCSV(file.getAbsolutePath());
                } else if (fileName.endsWith(".vcf")) {
                    importedContacts = contactManager.importFromVCard(file.getAbsolutePath());
                } else {
                    JOptionPane.showMessageDialog(this,
                            "不支持的文件格式!", "错误", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (importedContacts != null && !importedContacts.isEmpty()) {
                    int importedCount = 0;
                    for (Contact contact : importedContacts) {
                        if (contactManager.addContact(contact)) {
                            importedCount++;
                        }
                    }

                    JOptionPane.showMessageDialog(this,
                            "成功导入 " + importedCount + " 个联系人",
                            "导入成功", JOptionPane.INFORMATION_MESSAGE);

                    refreshContactList();
                    loadGroups();
                }

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                        "导入失败: " + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void updatePhotoPreview() {
        int selectedRow = contactTable.getSelectedRow();
        if (selectedRow >= 0) {
            int modelRow = contactTable.convertRowIndexToModel(selectedRow);
            String photoPath = (String) contactTable.getModel().getValueAt(modelRow, 8);
            showPreviewImage(photoPath);
        } else {
            photoPreviewLabel.setIcon(null);
            photoPreviewLabel.setText("选择联系人查看照片");
        }
    }

    private void showPreviewImage(String path) {
        if (path == null || path.isEmpty()) {
            photoPreviewLabel.setIcon(null);
            photoPreviewLabel.setText("无照片");
            return;
        }
        try {
            java.io.File file = new java.io.File(path);
            if (!file.exists()) {
                photoPreviewLabel.setIcon(null);
                photoPreviewLabel.setText("照片文件不存在");
                return;
            }
            java.awt.image.BufferedImage img = javax.imageio.ImageIO.read(file);
            if (img != null) {
                int maxSize = 100;
                int w = img.getWidth(), h = img.getHeight();
                double ratio = Math.min((double) maxSize / w, (double) maxSize / h);
                java.awt.Image scaled = img.getScaledInstance(
                        (int) (w * ratio), (int) (h * ratio), java.awt.Image.SCALE_SMOOTH);
                photoPreviewLabel.setIcon(new javax.swing.ImageIcon(scaled));
                photoPreviewLabel.setText("");
            }
        } catch (Exception e) {
            photoPreviewLabel.setIcon(null);
            photoPreviewLabel.setText("加载失败");
        }
    }

    private void showAboutDialog() {
        JOptionPane.showMessageDialog(this,
                "通讯录管理系统 v1.0\n\n" +
                        "功能：\n" +
                        "• 联系人管理（增删改查）\n" +
                        "• 分组管理\n" +
                        "• 联系人分组调整\n" +
                        "• 多条件搜索（支持模糊查询）\n" +
                        "• 导入导出（CSV/vCard格式）\n" +
                        "• 拼音搜索支持",
                "关于", JOptionPane.INFORMATION_MESSAGE);
    }
}