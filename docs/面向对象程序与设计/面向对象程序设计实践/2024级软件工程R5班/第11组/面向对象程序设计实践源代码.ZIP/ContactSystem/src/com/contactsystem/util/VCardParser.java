package com.contactsystem.util;

import com.contactsystem.model.Contact;
import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

public class VCardParser {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE;

    public static List<Contact> parseVCard(String filePath) throws IOException {
        List<Contact> contacts = new ArrayList<>();

        // 检测编码
        String encoding = detectEncoding(filePath);

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(filePath), encoding))) {

            String line;
            Contact currentContact = null;
            StringBuilder foldedLine = new StringBuilder();

            while ((line = reader.readLine()) != null) {
                // vCard line folding: line starting with space/tab continues previous line
                if (!line.isEmpty() && (line.charAt(0) == ' ' || line.charAt(0) == '\t')) {
                    foldedLine.append(line.substring(1));
                    continue;
                }

                // Process previous folded line
                if (foldedLine.length() > 0 && currentContact != null) {
                    processVCardLine(currentContact, foldedLine.toString());
                }
                foldedLine = new StringBuilder(line);

                if (line.trim().equalsIgnoreCase("BEGIN:VCARD")) {
                    currentContact = new Contact();
                } else if (line.trim().equalsIgnoreCase("END:VCARD")) {
                    if (currentContact != null) {
                        contacts.add(currentContact);
                        currentContact = null;
                    }
                    foldedLine = new StringBuilder();
                }
            }

            // Process last folded line
            if (foldedLine.length() > 0 && currentContact != null) {
                processVCardLine(currentContact, foldedLine.toString());
            }

            // Handle case where last vCard has no END:VCARD
            if (currentContact != null) {
                contacts.add(currentContact);
            }
        }
        return contacts;
    }

    private static String detectEncoding(String filePath) throws IOException {
        byte[] rawBytes = new byte[4096];
        int bytesRead;
        try (FileInputStream fis = new FileInputStream(filePath)) {
            bytesRead = fis.read(rawBytes);
        }
        if (bytesRead <= 0) {
            return "UTF-8";
        }
        // 检查UTF-8 BOM
        if (bytesRead >= 3
                && (rawBytes[0] & 0xFF) == 0xEF
                && (rawBytes[1] & 0xFF) == 0xBB
                && (rawBytes[2] & 0xFF) == 0xBF) {
            return "UTF-8";
        }
        // 尝试用UTF-8解码，检查是否包含vCard关键字
        int sampleLen = Math.min(bytesRead, 4000);
        String utf8Sample = new String(rawBytes, 0, sampleLen, "UTF-8");
        if (utf8Sample.contains("VCARD") || utf8Sample.contains("VERSION")
                || utf8Sample.contains("BEGIN:") || utf8Sample.contains("FN:")) {
            return "UTF-8";
        }
        // 尝试GBK
        String gbkSample = new String(rawBytes, 0, sampleLen, "GBK");
        if (gbkSample.contains("VCARD") || gbkSample.contains("VERSION")
                || gbkSample.contains("BEGIN:") || gbkSample.contains("FN:")) {
            return "GBK";
        }
        // 默认UTF-8
        return "UTF-8";
    }

    private static void processVCardLine(Contact contact, String line) {
        if (line == null || line.trim().isEmpty()) {
            return;
        }

        int colonIndex = line.indexOf(':');
        if (colonIndex < 0) {
            return;
        }

        String property = line.substring(0, colonIndex).trim().toUpperCase();
        String value = line.substring(colonIndex + 1);
        value = unescapeVCard(value);

        if (value.isEmpty()) {
            return;
        }

        // Handle compound property names (e.g., TEL;TYPE=CELL)
        String baseProperty = property.split(";")[0];

        switch (baseProperty) {
            case "FN":
                if (contact.getName() == null || contact.getName().isEmpty()) {
                    contact.setName(value);
                }
                break;
            case "N":
                // N:LastName;FirstName;MiddleName;Prefix;Suffix
                if (contact.getName() == null || contact.getName().isEmpty()) {
                    String[] parts = value.split(";");
                    StringBuilder name = new StringBuilder();
                    for (int i = parts.length - 2; i >= 0; i--) {
                        if (!parts[i].isEmpty()) {
                            name.append(parts[i]);
                        }
                    }
                    if (name.length() == 0 && parts.length > 0) {
                        name.append(parts[parts.length - 1]); // suffix as fallback
                    }
                    if (name.length() > 0) {
                        contact.setName(name.toString());
                    }
                }
                break;
            case "NICKNAME":
                contact.setNickName(value);
                break;
            case "TEL":
                if (property.contains("CELL")) {
                    contact.setMobile(value);
                } else if (contact.getPhone() == null || contact.getPhone().isEmpty()) {
                    contact.setPhone(value);
                }
                break;
            case "EMAIL":
                contact.setEmail(value);
                break;
            case "URL":
                contact.setHomepage(value);
                break;
            case "ORG":
                contact.setCompany(value);
                break;
            case "ADR":
                // ADR:;;street;city;state;zip;country
                String[] addrParts = value.split(";");
                StringBuilder addr = new StringBuilder();
                for (String part : addrParts) {
                    if (!part.trim().isEmpty()) {
                        if (addr.length() > 0) addr.append(", ");
                        addr.append(part.trim());
                    }
                }
                if (addr.length() > 0) {
                    contact.setAddress(addr.toString());
                }
                break;
            case "BDAY":
                try {
                    String dateStr = value.replaceAll("[^0-9-]", "").trim();
                    if (dateStr.length() >= 10) {
                        dateStr = dateStr.substring(0, 10);
                    }
                    if (dateStr.matches("\\d{4}-\\d{2}-\\d{2}")) {
                        contact.setBirthday(LocalDate.parse(dateStr, DATE_FORMATTER));
                    } else if (dateStr.matches("\\d{8}")) {
                        contact.setBirthday(LocalDate.parse(
                                dateStr.substring(0, 4) + "-" + dateStr.substring(4, 6) + "-" + dateStr.substring(6, 8),
                                DATE_FORMATTER));
                    }
                } catch (DateTimeParseException ignored) {
                }
                break;
            case "NOTE":
                if (contact.getNotes() == null || contact.getNotes().isEmpty()) {
                    contact.setNotes(value);
                } else {
                    contact.setNotes(contact.getNotes() + "\n" + value);
                }
                break;
            case "CATEGORIES":
                String[] categories = value.split(",");
                for (String cat : categories) {
                    String trimmed = cat.trim();
                    if (!trimmed.isEmpty()) {
                        contact.addGroup(trimmed);
                    }
                }
                break;
            case "X-ZIPCODE":
                contact.setZipCode(value);
                break;
            case "X-IM-TOOL":
                contact.setImTool(value);
                break;
            case "X-IM-NUMBER":
                contact.setImNumber(value);
                break;
            case "PHOTO":
                contact.setPhotoPath(value);
                break;
            case "VERSION":
            case "PRODID":
            case "REV":
            case "UID":
                // Ignore meta properties
                break;
            default:
                break;
        }
    }

    private static String unescapeVCard(String value) {
        if (value == null) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (c == '\\' && i + 1 < value.length()) {
                char next = value.charAt(i + 1);
                switch (next) {
                    case 'n': case 'N': sb.append('\n'); i++; break;
                    case '\\': sb.append('\\'); i++; break;
                    case ';': sb.append(';'); i++; break;
                    case ',': sb.append(','); i++; break;
                    default: sb.append(c); break;
                }
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}