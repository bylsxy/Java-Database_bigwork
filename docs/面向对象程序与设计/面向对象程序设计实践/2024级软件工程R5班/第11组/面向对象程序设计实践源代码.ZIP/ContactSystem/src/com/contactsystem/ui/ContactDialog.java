package com.contactsystem.ui;

import com.contactsystem.model.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import javax.imageio.ImageIO;

public class ContactDialog extends JDialog {
    private ContactManager contactManager;
    private Contact contact;
    private boolean success = false;

    private JTextField nameField;
    private JTextField nickNameField;
    private JTextField phoneField;
    private JTextField mobileField;
    private JTextField emailField;
    private JTextField imToolField;
    private JTextField imNumberField;
    private JTextField homepageField;
    private JTextField birthdayField;
    private JTextField companyField;
    private JTextField addressField;
    private JTextField zipCodeField;
    private JTextArea notesArea;
    private JComboBox<String> groupCombo;
    private JLabel photoLabel;
    private String photoPath;

    public ContactDialog(JFrame parent, ContactManager contactManager, Contact contact) {
        super(parent, contact == null ? "新建联系人" : "编辑联系人", true);
        this.contactManager = contactManager;
        this.contact = contact;

        setLocationRelativeTo(parent);
        initUI();
        pack();
        setSize(Math.max(getWidth(), 550), Math.min(getHeight(), 620));
    }

    private void initUI() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // 创建选项卡面板
        JTabbedPane tabbedPane = new JTabbedPane();

        // 基本信息选项卡
        tabbedPane.addTab("基本信息", createBasicInfoPanel());

        // 详细信息选项卡
        tabbedPane.addTab("详细信息", createDetailInfoPanel());

        // 按钮面板
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton saveButton = new JButton("保存");
        JButton cancelButton = new JButton("取消");

        saveButton.addActionListener(e -> saveContact());
        cancelButton.addActionListener(e -> dispose());

        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);

        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);

        // 如果是编辑模式，填充数据
        if (contact != null) {
            fillContactData();
        }
    }

    private JPanel createBasicInfoPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // 第1行：姓名
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("姓名*:"), gbc);
        gbc.gridx = 1;
        nameField = new JTextField(20);
        panel.add(nameField, gbc);

        // 第2行：昵称
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("昵称:"), gbc);
        gbc.gridx = 1;
        nickNameField = new JTextField(20);
        panel.add(nickNameField, gbc);

        // 第3行：电话
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("电话:"), gbc);
        gbc.gridx = 1;
        phoneField = new JTextField(20);
        panel.add(phoneField, gbc);

        // 第4行：手机
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(new JLabel("手机:"), gbc);
        gbc.gridx = 1;
        mobileField = new JTextField(20);
        panel.add(mobileField, gbc);

        // 第5行：邮箱
        gbc.gridx = 0; gbc.gridy = 4;
        panel.add(new JLabel("邮箱:"), gbc);
        gbc.gridx = 1;
        emailField = new JTextField(20);
        panel.add(emailField, gbc);

        // 第6行：分组
        gbc.gridx = 0; gbc.gridy = 5;
        panel.add(new JLabel("分组:"), gbc);
        gbc.gridx = 1;
        groupCombo = new JComboBox<>();
        loadGroupsToCombo();
        panel.add(groupCombo, gbc);

        // 第7行：头像
        gbc.gridx = 0; gbc.gridy = 6;
        panel.add(new JLabel("头像:"), gbc);
        gbc.gridx = 1;
        JPanel photoPanel = new JPanel(new BorderLayout(5, 5));
        photoLabel = new JLabel("点击选择头像", SwingConstants.CENTER);
        photoLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        photoLabel.setPreferredSize(new Dimension(100, 100));
        photoLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                choosePhoto();
            }
        });
        photoPanel.add(photoLabel, BorderLayout.CENTER);
        JButton clearPhotoBtn = new JButton("清除");
        clearPhotoBtn.addActionListener(e -> {
            photoPath = null;
            photoLabel.setIcon(null);
            photoLabel.setText("点击选择头像");
        });
        photoPanel.add(clearPhotoBtn, BorderLayout.SOUTH);
        panel.add(photoPanel, gbc);

        return panel;
    }

    private JPanel createDetailInfoPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // 第1行：IM工具
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("IM工具:"), gbc);
        gbc.gridx = 1;
        imToolField = new JTextField(20);
        panel.add(imToolField, gbc);

        // 第2行：IM号码
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("IM号码:"), gbc);
        gbc.gridx = 1;
        imNumberField = new JTextField(20);
        panel.add(imNumberField, gbc);

        // 第3行：主页
        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("个人主页:"), gbc);
        gbc.gridx = 1;
        homepageField = new JTextField(20);
        panel.add(homepageField, gbc);

        // 第4行：生日
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(new JLabel("生日(YYYY-MM-DD):"), gbc);
        gbc.gridx = 1;
        birthdayField = new JTextField(20);
        panel.add(birthdayField, gbc);

        // 第5行：公司
        gbc.gridx = 0; gbc.gridy = 4;
        panel.add(new JLabel("工作单位:"), gbc);
        gbc.gridx = 1;
        companyField = new JTextField(20);
        panel.add(companyField, gbc);

        // 第6行：地址
        gbc.gridx = 0; gbc.gridy = 5;
        panel.add(new JLabel("家庭地址:"), gbc);
        gbc.gridx = 1;
        addressField = new JTextField(20);
        panel.add(addressField, gbc);

        // 第7行：邮编
        gbc.gridx = 0; gbc.gridy = 6;
        panel.add(new JLabel("邮编:"), gbc);
        gbc.gridx = 1;
        zipCodeField = new JTextField(20);
        panel.add(zipCodeField, gbc);

        // 第8行：备注
        gbc.gridx = 0; gbc.gridy = 7;
        panel.add(new JLabel("备注:"), gbc);
        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;
        notesArea = new JTextArea(3, 20);
        notesArea.setLineWrap(true);
        notesArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(notesArea);
        panel.add(scrollPane, gbc);

        return panel;
    }

    private void loadGroupsToCombo() {
        groupCombo.removeAllItems();
        groupCombo.addItem(""); // 空选项
        for (ContactGroup group : contactManager.getAllGroups()) {
            groupCombo.addItem(group.getName());
        }
    }

    private void choosePhoto() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
                "图片文件 (*.jpg, *.jpeg, *.png, *.gif)", "jpg", "jpeg", "png", "gif"));

        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            photoPath = file.getAbsolutePath();
            displayPhotoThumbnail(photoPath);
        }
    }

    private void displayPhotoThumbnail(String path) {
        try {
            BufferedImage img = ImageIO.read(new File(path));
            if (img != null) {
                int maxSize = 100;
                int w = img.getWidth();
                int h = img.getHeight();
                double ratio = Math.min((double) maxSize / w, (double) maxSize / h);
                int newW = (int) (w * ratio);
                int newH = (int) (h * ratio);
                Image scaled = img.getScaledInstance(newW, newH, Image.SCALE_SMOOTH);
                photoLabel.setIcon(new ImageIcon(scaled));
                photoLabel.setText("");  // 清除文字提示
            }
        } catch (IOException e) {
            photoLabel.setIcon(null);
            photoLabel.setText("无法加载");
        }
    }

    private void fillContactData() {
        nameField.setText(contact.getName());
        nickNameField.setText(contact.getNickName());
        phoneField.setText(contact.getPhone());
        mobileField.setText(contact.getMobile());
        emailField.setText(contact.getEmail());
        imToolField.setText(contact.getImTool());
        imNumberField.setText(contact.getImNumber());
        homepageField.setText(contact.getHomepage());
        if (contact.getBirthday() != null) {
            birthdayField.setText(contact.getBirthday().toString());
        }
        companyField.setText(contact.getCompany());
        addressField.setText(contact.getAddress());
        zipCodeField.setText(contact.getZipCode());
        notesArea.setText(contact.getNotes());

        if (contact.getGroups() != null && !contact.getGroups().isEmpty()) {
            String firstGroup = contact.getGroups().iterator().next();
            groupCombo.setSelectedItem(firstGroup);
        }

        if (contact.getPhotoPath() != null && !contact.getPhotoPath().isEmpty()) {
            photoPath = contact.getPhotoPath();
            displayPhotoThumbnail(photoPath);
        }
    }

    private void saveContact() {
        // 验证必填字段：仅姓名为必填
        if (nameField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "姓名为必填字段!", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Contact contactToSave = contact != null ? contact : new Contact();

        contactToSave.setName(nameField.getText().trim());
        contactToSave.setNickName(nickNameField.getText().trim());
        contactToSave.setPhone(phoneField.getText().trim());
        contactToSave.setMobile(mobileField.getText().trim());
        contactToSave.setEmail(emailField.getText().trim());
        contactToSave.setImTool(imToolField.getText().trim());
        contactToSave.setImNumber(imNumberField.getText().trim());
        contactToSave.setHomepage(homepageField.getText().trim());
        contactToSave.setCompany(companyField.getText().trim());
        contactToSave.setAddress(addressField.getText().trim());
        contactToSave.setZipCode(zipCodeField.getText().trim());
        contactToSave.setNotes(notesArea.getText().trim());

        // 解析生日
        String birthdayStr = birthdayField.getText().trim();
        if (!birthdayStr.isEmpty()) {
            try {
                LocalDate birthday = LocalDate.parse(birthdayStr, DateTimeFormatter.ISO_LOCAL_DATE);
                contactToSave.setBirthday(birthday);
            } catch (DateTimeParseException e) {
                JOptionPane.showMessageDialog(this,
                        "生日格式错误，请使用 YYYY-MM-DD 格式", "错误", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }

        // 设置头像
        if (photoPath != null) {
            contactToSave.setPhotoPath(photoPath);
        }

        // 设置分组：同步更新 ContactGroup 的 contactIDs
        String selectedGroupName = (String) groupCombo.getSelectedItem();
        if (selectedGroupName != null && !selectedGroupName.trim().isEmpty()) {
            String groupName = selectedGroupName.trim();

            // 如果联系人之前在其他分组中，先从那些分组移除
            if (contact != null) {
                for (String oldGroupName : contact.getGroups()) {
                    ContactGroup oldGroup = findGroupByName(oldGroupName);
                    if (oldGroup != null && !oldGroupName.equals(groupName)) {
                        oldGroup.removeContact(contactToSave.getID());
                    }
                }
            }

            contactToSave.getGroups().clear();
            contactToSave.addGroup(groupName);

            // 将联系人ID添加到对应ContactGroup中
            ContactGroup group = findGroupByName(groupName);
            if (group != null) {
                group.addContact(contactToSave.getID());
            }
        }

        // 保存联系人
        boolean result = contact == null ?
                contactManager.addContact(contactToSave) :
                contactManager.updateContact(contactToSave);

        if (result) {
            success = true;
            JOptionPane.showMessageDialog(this,
                    contact == null ? "联系人添加成功!" : "联系人修改成功!",
                    "成功", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } else {
            JOptionPane.showMessageDialog(this,
                    "保存失败，请重试!", "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private ContactGroup findGroupByName(String name) {
        for (ContactGroup g : contactManager.getAllGroups()) {
            if (g.getName().equals(name)) {
                return g;
            }
        }
        return null;
    }

    public boolean isSuccess() {
        return success;
    }
}