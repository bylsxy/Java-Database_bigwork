package com.contactsystem.model;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class ContactManager {
    private Map<String, Contact> contacts;           // ID -> Contact
    private Map<String, ContactGroup> groups;       // ID -> Group
    private Map<String, String> contactToPinyin;    // ContactID -> Pinyin
    private static final String DATA_FILE = "contacts.dat";

    public ContactManager() {
        contacts = new HashMap<>();
        groups = new HashMap<>();
        contactToPinyin = new HashMap<>();
        loadData();
    }

    // 联系人管理
    public boolean addContact(Contact contact) {
        if (contact.getID() == null) {
            contact.setID(UUID.randomUUID().toString());
        }
        contacts.put(contact.getID(), contact);
        contactToPinyin.put(contact.getID(), contact.getFullPinyin());
        saveData();
        return true;
    }

    public boolean updateContact(Contact contact) {
        if (contacts.containsKey(contact.getID())) {
            contacts.put(contact.getID(), contact);
            contactToPinyin.put(contact.getID(), contact.getFullPinyin());
            saveData();
            return true;
        }
        return false;
    }

    public boolean deleteContact(String contactId) {
        if (contacts.containsKey(contactId)) {
            // 从所有分组中移除
            for (ContactGroup group : groups.values()) {
                group.removeContact(contactId);
            }
            contacts.remove(contactId);
            contactToPinyin.remove(contactId);
            saveData();
            return true;
        }
        return false;
    }

    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }

    public List<Contact> getAllContacts() {
        return contacts.values().stream()
                .sorted()
                .collect(Collectors.toList());
    }

    // 分组管理
    public boolean addGroup(ContactGroup group) {
        if (groups.containsKey(group.getId())) {
            return false;
        }
        groups.put(group.getId(), group);
        saveData();
        return true;
    }

    public boolean deleteGroup(String groupId) {
        if (groups.containsKey(groupId)) {
            // 不删除联系人，只删除分组
            groups.remove(groupId);
            saveData();
            return true;
        }
        return false;
    }

    public ContactGroup getGroup(String groupId) {
        return groups.get(groupId);
    }

    public List<ContactGroup> getAllGroups() {
        return groups.values().stream()
                .sorted()
                .collect(Collectors.toList());
    }

    // 联系人分组管理
    public void addContactToGroup(String contactId, String groupId) {
        Contact contact = contacts.get(contactId);
        ContactGroup group = groups.get(groupId);
        if (contact != null && group != null) {
            contact.addGroup(group.getName());
            group.addContact(contactId);
            saveData();
        }
    }

    public void removeContactFromGroup(String contactId, String groupId) {
        Contact contact = contacts.get(contactId);
        ContactGroup group = groups.get(groupId);
        if (contact != null && group != null) {
            contact.removeGroup(group.getName());
            group.removeContact(contactId);
            saveData();
        }
    }

    public void addContactsToGroup(List<String> contactIds, String groupId) {
        for (String contactId : contactIds) {
            addContactToGroup(contactId, groupId);
        }
    }

    public void removeContactsFromGroup(List<String> contactIds, String groupId) {
        for (String contactId : contactIds) {
            removeContactFromGroup(contactId, groupId);
        }
    }

    public List<Contact> getContactsInGroup(String groupId) {
        ContactGroup group = groups.get(groupId);
        if (group != null) {
            return group.getContactIDs().stream()
                    .map(this::getContact)
                    .filter(Objects::nonNull)
                    .sorted()
                    .collect(Collectors.toList());
        }
        return new ArrayList<>();
    }

    // 搜索功能
    public List<Contact> searchContacts(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllContacts();
        }

        String lowerKeyword = keyword.toLowerCase();
        return contacts.values().stream()
                .filter(contact -> matchesKeyword(contact, lowerKeyword))
                .sorted()
                .collect(Collectors.toList());
    }

    private boolean matchesKeyword(Contact contact, String keyword) {
        // 按姓名搜索
        if (contact.getName() != null && contact.getName().toLowerCase().contains(keyword)) {
            return true;
        }
        // 按电话号码搜索
        if (contact.getPhone() != null && contact.getPhone().contains(keyword)) {
            return true;
        }
        // 按手机号搜索
        if (contact.getMobile() != null && contact.getMobile().contains(keyword)) {
            return true;
        }
        // 按拼音全拼搜索
        if (contact.getFullPinyin() != null && contact.getFullPinyin().toLowerCase().contains(keyword)) {
            return true;
        }
        // 按拼音首字母搜索
        if (contact.getPinyinInitial() != null && contact.getPinyinInitial().toLowerCase().contains(keyword)) {
            return true;
        }
        // 按邮箱搜索
        if (contact.getEmail() != null && contact.getEmail().toLowerCase().contains(keyword)) {
            return true;
        }
        // 按公司搜索
        if (contact.getCompany() != null && contact.getCompany().toLowerCase().contains(keyword)) {
            return true;
        }
        return false;
    }

    // 按姓名首字母分组
    public Map<Character, List<Contact>> getContactsByInitial() {
        Map<Character, List<Contact>> result = new TreeMap<>();

        for (Contact contact : contacts.values()) {
            char initial = getContactInitial(contact);
            result.computeIfAbsent(initial, k -> new ArrayList<>()).add(contact);
        }

        // 每个分组内按拼音排序
        for (List<Contact> list : result.values()) {
            list.sort(Comparator.naturalOrder());
        }

        return result;
    }

    private char getContactInitial(Contact contact) {
        if (contact.getFullPinyin() != null && !contact.getFullPinyin().isEmpty()) {
            return Character.toUpperCase(contact.getFullPinyin().charAt(0));
        } else if (contact.getName() != null && !contact.getName().isEmpty()) {
            return Character.toUpperCase(contact.getName().charAt(0));
        }
        return '#';
    }

    // 数据持久化
    @SuppressWarnings("unchecked")
    private void loadData() {
        File file = new File(DATA_FILE);
        if (file.exists()) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(DATA_FILE))) {
                Map<String, Contact> loadedContacts = (Map<String, Contact>) ois.readObject();
                Map<String, ContactGroup> loadedGroups = (Map<String, ContactGroup>) ois.readObject();

                contacts = loadedContacts;
                groups = loadedGroups;

                // 重建拼音索引
                for (Contact contact : contacts.values()) {
                    contactToPinyin.put(contact.getID(), contact.getFullPinyin());
                }

            } catch (IOException | ClassNotFoundException e) {
                System.err.println("加载数据失败: " + e.getMessage());
                contacts = new HashMap<>();
                groups = new HashMap<>();
            }
        }
    }

    public void saveData() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            oos.writeObject(contacts);
            oos.writeObject(groups);
        } catch (IOException e) {
            System.err.println("保存数据失败: " + e.getMessage());
            e.printStackTrace();
            javax.swing.JOptionPane.showMessageDialog(null,
                    "保存数据失败: " + e.getMessage(), "错误", javax.swing.JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * 备份数据到指定文件
     */
    public boolean backupData(String backupPath) {
        try {
            File src = new File(DATA_FILE);
            if (!src.exists()) {
                return false;
            }
            try (FileInputStream fis = new FileInputStream(src);
                 FileOutputStream fos = new FileOutputStream(backupPath)) {
                byte[] buffer = new byte[4096];
                int len;
                while ((len = fis.read(buffer)) > 0) {
                    fos.write(buffer, 0, len);
                }
            }
            return true;
        } catch (IOException e) {
            System.err.println("备份失败: " + e.getMessage());
            return false;
        }
    }

    /**
     * 从备份文件恢复数据
     */
    public boolean restoreData(String backupPath) {
        File backupFile = new File(backupPath);
        if (!backupFile.exists()) {
            return false;
        }
        try {
            File dest = new File(DATA_FILE);
            try (FileInputStream fis = new FileInputStream(backupFile);
                 FileOutputStream fos = new FileOutputStream(dest)) {
                byte[] buffer = new byte[4096];
                int len;
                while ((len = fis.read(buffer)) > 0) {
                    fos.write(buffer, 0, len);
                }
            }
            // 重新加载数据
            loadData();
            return true;
        } catch (IOException e) {
            System.err.println("恢复失败: " + e.getMessage());
            return false;
        }
    }

    // 导入导出功能
    public void exportToCSV(String filePath, List<Contact> contactsToExport) throws IOException {
        try (PrintWriter writer = new PrintWriter(
                new OutputStreamWriter(new FileOutputStream(filePath), "UTF-8"))) {
            // UTF-8 BOM
            writer.print('﻿');
            // 写入表头
            writer.println("姓名,昵称,电话,手机,IM工具,IM号码,邮箱,主页,生日,工作单位,地址,邮编,备注");

            // 写入数据
            for (Contact contact : contactsToExport) {
                writer.println(String.format("\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\"",
                        escapeCSV(contact.getName()),
                        escapeCSV(contact.getNickName()),
                        escapeCSV(contact.getPhone()),
                        escapeCSV(contact.getMobile()),
                        escapeCSV(contact.getImTool()),
                        escapeCSV(contact.getImNumber()),
                        escapeCSV(contact.getEmail()),
                        escapeCSV(contact.getHomepage()),
                        contact.getBirthday() != null ? contact.getBirthday().toString() : "",
                        escapeCSV(contact.getCompany()),
                        escapeCSV(contact.getAddress()),
                        escapeCSV(contact.getZipCode()),
                        escapeCSV(contact.getNotes())
                ));
            }
        }
    }

    private String escapeCSV(String value) {
        if (value == null) {
            return "";
        }
        return value.replace("\"", "\"\"")
                    .replace("\r\n", "\\n")
                    .replace("\n", "\\n")
                    .replace("\r", "\\n");
    }

    public void exportToVCard(String filePath, List<Contact> contactsToExport) throws IOException {
        try (PrintWriter writer = new PrintWriter(
                new OutputStreamWriter(new FileOutputStream(filePath), "UTF-8"))) {
            for (Contact contact : contactsToExport) {
                writer.print(contact.toVCard());
            }
        }
    }

    public List<Contact> importFromCSV(String filePath) throws IOException {
        return com.contactsystem.util.CSVHandler.parseCSV(filePath);
    }

    public List<Contact> importFromVCard(String filePath) throws IOException {
        return com.contactsystem.util.VCardParser.parseVCard(filePath);
    }
}
