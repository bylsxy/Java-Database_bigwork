package com.contactsystem.util;

import com.contactsystem.model.Contact;
import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

public class CSVHandler {

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE;

    public static List<Contact> parseCSV(String filePath) throws IOException {
        List<Contact> contacts = new ArrayList<>();

        // 读取文件原始字节用于编码检测
        byte[] rawBytes = new byte[4096];
        int bytesRead;
        try (FileInputStream fis = new FileInputStream(filePath)) {
            bytesRead = fis.read(rawBytes);
        }
        if (bytesRead <= 0) {
            return contacts;
        }

        // 检测编码：有BOM用UTF-8，否则先试UTF-8再试GBK
        String encoding;
        boolean hasBOM = bytesRead >= 3
                && (rawBytes[0] & 0xFF) == 0xEF
                && (rawBytes[1] & 0xFF) == 0xBB
                && (rawBytes[2] & 0xFF) == 0xBF;

        if (hasBOM) {
            encoding = "UTF-8";
        } else {
            // 用UTF-8解码头部行，检查是否包含预期的中文字段名
            int firstLineEnd = 0;
            for (int i = 0; i < bytesRead; i++) {
                if (rawBytes[i] == '\n' || rawBytes[i] == '\r') {
                    firstLineEnd = i;
                    break;
                }
            }
            if (firstLineEnd > 0) {
                String utf8Header = new String(rawBytes, 0, firstLineEnd, "UTF-8");
                if (containsExpectedHeaders(utf8Header)) {
                    encoding = "UTF-8";
                } else {
                    encoding = "GBK";
                }
            } else {
                encoding = "UTF-8";
            }
        }

        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(new FileInputStream(filePath), encoding))) {

            String headerLine = reader.readLine();
            if (headerLine == null) {
                return contacts;
            }

            // BOM handling for UTF-8
            if (headerLine.startsWith("﻿")) {
                headerLine = headerLine.substring(1);
            }

            List<String> headers = parseCSVLine(headerLine);
            Map<String, Integer> headerMap = buildHeaderMap(headers);

            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }
                List<String> fields = parseCSVLine(line);
                Contact contact = createContactFromFields(headerMap, fields);
                if (contact != null && contact.getName() != null && !contact.getName().isEmpty()) {
                    contacts.add(contact);
                }
            }
        }
        return contacts;
    }

    private static boolean containsExpectedHeaders(String headerLine) {
        // 检查是否包含常见的中文CSV表头字段
        String[] expected = {"姓名", "名字", "电话", "手机", "邮箱"};
        for (String keyword : expected) {
            if (headerLine.contains(keyword)) {
                return true;
            }
        }
        // 也检查英文表头
        String[] expectedEn = {"Name", "Phone", "Email", "FN", "Mobile"};
        for (String keyword : expectedEn) {
            if (headerLine.contains(keyword)) {
                return true;
            }
        }
        return false;
    }

    private static Map<String, Integer> buildHeaderMap(List<String> headers) {
        Map<String, Integer> map = new LinkedHashMap<>();
        for (int i = 0; i < headers.size(); i++) {
            String header = headers.get(i).trim();
            if (!header.isEmpty()) {
                map.put(header, i);
            }
        }
        return map;
    }

    private static Contact createContactFromFields(Map<String, Integer> headerMap, List<String> fields) {
        Contact contact = new Contact();

        for (Map.Entry<String, Integer> entry : headerMap.entrySet()) {
            String header = entry.getKey();
            int index = entry.getValue();
            String value = index < fields.size() ? fields.get(index).trim() : "";

            if (value.isEmpty()) {
                continue;
            }

            switch (header) {
                case "姓名":
                case "名字":
                case "Name":
                case "FN":
                    contact.setName(value);
                    break;
                case "昵称":
                case "Nickname":
                    contact.setNickName(value);
                    break;
                case "电话":
                case "电话号码":
                case "Phone":
                    contact.setPhone(value);
                    break;
                case "手机":
                case "手机号码":
                case "Mobile":
                case "Cell":
                    contact.setMobile(value);
                    break;
                case "IM工具":
                    contact.setImTool(value);
                    break;
                case "IM号码":
                    contact.setImNumber(value);
                    break;
                case "邮箱":
                case "Email":
                case "E-mail":
                    contact.setEmail(value);
                    break;
                case "主页":
                case "个人主页":
                case "Homepage":
                case "URL":
                    contact.setHomepage(value);
                    break;
                case "生日":
                case "Birthday":
                case "BDAY":
                    try {
                        contact.setBirthday(LocalDate.parse(value, DATE_FORMATTER));
                    } catch (DateTimeParseException ignored) {
                        // ignore invalid date
                    }
                    break;
                case "工作单位":
                case "公司":
                case "Company":
                case "ORG":
                    contact.setCompany(value);
                    break;
                case "家庭地址":
                case "地址":
                case "Address":
                case "ADR":
                    contact.setAddress(value);
                    break;
                case "邮编":
                case "邮政编码":
                case "ZipCode":
                    contact.setZipCode(value);
                    break;
                case "备注":
                case "Notes":
                case "Note":
                case "NOTE":
                    contact.setNotes(value);
                    break;
                default:
                    break;
            }
        }
        return contact;
    }

    /**
     * 解析一行CSV数据，正确处理带引号的字段
     */
    public static List<String> parseCSVLine(String line) {
        List<String> fields = new ArrayList<>();
        boolean inQuotes = false;
        StringBuilder currentField = new StringBuilder();

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);

            if (inQuotes) {
                if (c == '"') {
                    if (i + 1 < line.length() && line.charAt(i + 1) == '"') {
                        currentField.append('"');
                        i++;
                    } else {
                        inQuotes = false;
                    }
                } else {
                    currentField.append(c);
                }
            } else {
                if (c == '"') {
                    inQuotes = true;
                } else if (c == ',') {
                    fields.add(currentField.toString());
                    currentField = new StringBuilder();
                } else {
                    currentField.append(c);
                }
            }
        }
        fields.add(currentField.toString());
        return fields;
    }

    /**
     * CSV字段转义
     */
    public static String escapeCSVField(String field) {
        if (field == null) {
            return "";
        }
        if (field.contains(",") || field.contains("\"") || field.contains("\n")) {
            return "\"" + field.replace("\"", "\"\"") + "\"";
        }
        return field;
    }
}