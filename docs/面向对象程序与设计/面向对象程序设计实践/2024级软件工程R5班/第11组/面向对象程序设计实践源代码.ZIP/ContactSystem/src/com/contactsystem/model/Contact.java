package com.contactsystem.model;
import  java.util.*;
import java.time.LocalDate;
import java.io.Serializable;
import com.contactsystem.util.PinYinUtil;

public class Contact implements Comparable<Contact>, Serializable {
    private static final long serialVersionUID = 1L;
    private String id;
    private String name;          //姓名
    private String nickName;      //昵称
    private String phone;         //电话
    private String mobile;        //手机
    private String imTool;        //即时通信工具
    private String imNumber;      //IM号码
    private String homepage;      //主页
    private String address;       //地址
    private String email;         //邮箱
    private LocalDate birthday;   //生日
    private String photoPath;     //相片路径
    private String company;       //工作单位
    private String zipCode;       //邮政编码
    private Set<String> groups;   //属于的组
    private String notes;         //备注
    private String Fullpinyin;    //全拼音
    private String pinyinInitial;   //拼音首字母

    public Contact() {
       this.id = UUID.randomUUID().toString();
       this.groups = new HashSet<>();
    }

    public Contact(String name, String phone, String mobile) {
        this();
        this.name = name;
        this.phone = phone;
        this.mobile = mobile;
    }

    public void updatePinYin() {
        if (name != null && !name.isEmpty()) {
            try {
                this.Fullpinyin = PinYinUtil.getFullPinyin(name);
                this.pinyinInitial = PinYinUtil.getInitials(name);
            } catch (Throwable e) {
                this.Fullpinyin = name.toLowerCase();
                this.pinyinInitial = "";
                System.err.println("拼音更新失败: " + e.getMessage());
            }
        }
    }
    public String getID() {return id;}
    public void setID(String id) {this.id=id;}
    public String getName() {return name;}
    public void setName(String name) {
        this.name = name;
        updatePinYin();
    }
    public String getNickName() {return nickName;}
    public void setNickName(String nickName) {this.nickName=nickName;}

    public String getPhone() {return phone;}
    public void setPhone(String phone) {this.phone=phone;}

    public String getMobile() {return mobile;}
    public void setMobile(String mobile) {this.mobile=mobile;}

    public String getImTool() {return imTool;}
    public void setImTool(String imTool) {this.imTool=imTool;}

    public String getHomepage() {return homepage;}
    public void setHomepage(String homepage) {this.homepage=homepage;}

    public String getAddress() {return address;}
    public void setAddress(String address) {this.address=address;}

    public String getEmail() {return email;}
    public void setEmail(String email) {this.email=email;}

    public LocalDate getBirthday() {return birthday;}
    public void setBirthday(LocalDate birthday) {this.birthday=birthday;}

    public String getPhotoPath() {return photoPath;}
    public void setPhotoPath(String photoPath) {this.photoPath=photoPath;}

    public String getCompany() {return company;}
    public void setCompany(String company) {this.company=company;}

    public String getZipCode() {return zipCode;}
    public void setZipCode(String zipCode) {this.zipCode=zipCode;}

    public String getImNumber() {return imNumber;}
    public void setImNumber(String imNumber) {this.imNumber=imNumber;}

    public Set<String> getGroups() {return groups;}
    public void setGroups(Set<String> groups) {this.groups=groups;}
    public void addGroup(String group) {this.groups.add(group);}
    public void removeGroup(String group) {this.groups.remove(group);}
    public boolean isInGroup(String group) {return groups.contains(group);}

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public String getFullPinyin() {return Fullpinyin;}
    public String getPinyinInitial() {return pinyinInitial;}

    public String getGroupsString() {
        return String.join(",", groups);
    }
    public String getBirthdayString() {
        return birthday != null ? birthday.toString() : "";
    }
    @Override
    public int compareTo(Contact other) {
        if(this.Fullpinyin != null && other.Fullpinyin != null){
            return this.Fullpinyin.compareToIgnoreCase(other.Fullpinyin);
        }
        return this.name.compareToIgnoreCase(other.name);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Contact contact = (Contact) o;
        return Objects.equals(id, contact.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Contact{" +
                "name='" + name + '\'' +
                ", phone='" + phone + '\'' +
                ", mobile='" + mobile + '\'' +
                ", groups=" + groups +
                '}';
    }
    public String toVCard() {
        StringBuilder vcard = new StringBuilder();
        vcard.append("BEGIN:VCARD\r\n");
        vcard.append("VERSION:3.0\r\n");
        vcard.append("FN:").append(escapeVCard(name)).append("\r\n");
        vcard.append("N:").append(escapeVCard(name)).append(";;;;\r\n");
        if (nickName != null && !nickName.isEmpty()) {
            vcard.append("NICKNAME:").append(escapeVCard(nickName)).append("\r\n");
        }
        if (phone != null && !phone.isEmpty()) {
            vcard.append("TEL;TYPE=HOME,VOICE:").append(escapeVCard(phone)).append("\r\n");
        }
        if (mobile != null && !mobile.isEmpty()) {
            vcard.append("TEL;TYPE=CELL:").append(escapeVCard(mobile)).append("\r\n");
        }
        if (email != null && !email.isEmpty()) {
            vcard.append("EMAIL;TYPE=INTERNET:").append(escapeVCard(email)).append("\r\n");
        }
        if (homepage != null && !homepage.isEmpty()) {
            vcard.append("URL:").append(escapeVCard(homepage)).append("\r\n");
        }
        if (company != null && !company.isEmpty()) {
            vcard.append("ORG:").append(escapeVCard(company)).append("\r\n");
        }
        if (address != null && !address.isEmpty()) {
            vcard.append("ADR;TYPE=HOME:;;").append(escapeVCard(address)).append(";;;;\r\n");
        }
        if (zipCode != null && !zipCode.isEmpty()) {
            vcard.append("X-ZIPCODE:").append(escapeVCard(zipCode)).append("\r\n");
        }
        if (birthday != null) {
            vcard.append("BDAY:").append(birthday).append("\r\n");
        }
        if (imTool != null && !imTool.isEmpty()) {
            vcard.append("X-IM-TOOL:").append(escapeVCard(imTool)).append("\r\n");
        }
        if (imNumber != null && !imNumber.isEmpty()) {
            vcard.append("X-IM-NUMBER:").append(escapeVCard(imNumber)).append("\r\n");
        }
        if (notes != null && !notes.isEmpty()) {
            vcard.append("NOTE:").append(escapeVCard(notes)).append("\r\n");
        }
        if (photoPath != null && !photoPath.isEmpty()) {
            vcard.append("PHOTO;VALUE=URI:").append(escapeVCard(photoPath)).append("\r\n");
        }
        if (groups != null && !groups.isEmpty()) {
            StringBuilder cats = new StringBuilder();
            for (String g : groups) {
                if (cats.length() > 0) cats.append(",");
                cats.append(g);
            }
            vcard.append("CATEGORIES:").append(escapeVCard(cats.toString())).append("\r\n");
        }
        vcard.append("END:VCARD\r\n");
        return vcard.toString();
    }

    private String escapeVCard(String value) {
        if (value == null) return "";
        return value.replace("\\", "\\\\")
                    .replace(";", "\\;")
                    .replace(",", "\\,")
                    .replace("\n", "\\n")
                    .replace("\r", "");
    }
}

