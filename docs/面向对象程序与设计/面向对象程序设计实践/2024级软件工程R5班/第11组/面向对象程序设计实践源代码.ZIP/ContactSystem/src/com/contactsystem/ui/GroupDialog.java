package com.contactsystem.ui;

import com.contactsystem.model.*;
import com.contactsystem.ui.renderer.ContactListRenderer;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.*;
import java.util.List;

public class GroupDialog extends JDialog {
    private ContactManager contactManager;
    private ContactGroup group;

    private JTextField groupNameField;
    private JTextArea descriptionArea;
    private JList<Contact> allContactsList;
    private JList<Contact> groupContactsList;
    private DefaultListModel<Contact> allContactsModel;
    private DefaultListModel<Contact> groupContactsModel;

    public GroupDialog(JFrame parent, ContactManager contactManager, ContactGroup group) {
        super(parent, "管理分组: " + group.getName(), true);
        this.contactManager = contactManager;
        this.group = group;

        setSize(800, 500);
        setLocationRelativeTo(parent);
        initUI();
        loadContacts();
    }

    private void initUI() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // 顶部：分组信息
        JPanel infoPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        infoPanel.setBorder(BorderFactory.createTitledBorder("分组信息"));

        infoPanel.add(new JLabel("分组名称:"));
        groupNameField = new JTextField(group.getName());
        infoPanel.add(groupNameField);

        infoPanel.add(new JLabel("描述:"));
        descriptionArea = new JTextArea(3, 20);
        if (group.getDescription() != null) {
            descriptionArea.setText(group.getDescription());
        }
        infoPanel.add(new JScrollPane(descriptionArea));

        // 中部：联系人管理
        JPanel contactPanel = new JPanel(new GridLayout(1, 3, 10, 10));
        contactPanel.setBorder(BorderFactory.createTitledBorder("联系人管理"));

        // 左侧：所有联系人
        JPanel allContactsPanel = new JPanel(new BorderLayout(5, 5));
        allContactsPanel.setBorder(BorderFactory.createTitledBorder("所有联系人"));
        allContactsModel = new DefaultListModel<>();
        allContactsList = new JList<>(allContactsModel);
        allContactsList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        allContactsList.setCellRenderer(new ContactListRenderer());
        JScrollPane allScroll = new JScrollPane(allContactsList);
        allContactsPanel.add(allScroll, BorderLayout.CENTER);

        // 中间：操作按钮
        JPanel buttonPanel = new JPanel(new GridLayout(5, 1, 5, 5));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(50, 10, 50, 10));

        JButton addButton = new JButton(">>");
        JButton addAllButton = new JButton(">>>");
        JButton removeButton = new JButton("<<");
        JButton removeAllButton = new JButton("<<<");

        addButton.addActionListener(e -> addSelectedToGroup());
        addAllButton.addActionListener(e -> addAllToGroup());
        removeButton.addActionListener(e -> removeSelectedFromGroup());
        removeAllButton.addActionListener(e -> removeAllFromGroup());

        buttonPanel.add(addButton);
        buttonPanel.add(addAllButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        buttonPanel.add(removeButton);
        buttonPanel.add(removeAllButton);

        // 右侧：组内联系人
        JPanel groupContactsPanel = new JPanel(new BorderLayout(5, 5));
        groupContactsPanel.setBorder(BorderFactory.createTitledBorder("组内联系人 (" + group.getContactCount() + ")"));
        groupContactsModel = new DefaultListModel<>();
        groupContactsList = new JList<>(groupContactsModel);
        groupContactsList.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        groupContactsList.setCellRenderer(new ContactListRenderer());
        JScrollPane groupScroll = new JScrollPane(groupContactsList);
        groupContactsPanel.add(groupScroll, BorderLayout.CENTER);

        contactPanel.add(allContactsPanel);
        contactPanel.add(buttonPanel);
        contactPanel.add(groupContactsPanel);

        // 底部：按钮
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton saveButton = new JButton("保存");
        JButton cancelButton = new JButton("取消");

        saveButton.addActionListener(e -> saveChanges());
        cancelButton.addActionListener(e -> dispose());

        bottomPanel.add(saveButton);
        bottomPanel.add(cancelButton);

        mainPanel.add(infoPanel, BorderLayout.NORTH);
        mainPanel.add(contactPanel, BorderLayout.CENTER);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void loadContacts() {
        allContactsModel.clear();
        groupContactsModel.clear();

        // 加载所有联系人
        List<Contact> allContacts = contactManager.getAllContacts();
        for (Contact contact : allContacts) {
            allContactsModel.addElement(contact);
        }

        // 加载组内联系人
        List<Contact> groupContacts = contactManager.getContactsInGroup(group.getId());
        for (Contact contact : groupContacts) {
            groupContactsModel.addElement(contact);
        }
    }

    private void addSelectedToGroup() {
        List<Contact> selected = allContactsList.getSelectedValuesList();
        for (Contact contact : selected) {
            contactManager.addContactToGroup(contact.getID(), group.getId());
        }
        loadContacts();
    }

    private void addAllToGroup() {
        for (int i = 0; i < allContactsModel.size(); i++) {
            Contact contact = allContactsModel.getElementAt(i);
            contactManager.addContactToGroup(contact.getID(), group.getId());
        }
        loadContacts();
    }

    private void removeSelectedFromGroup() {
        List<Contact> selected = groupContactsList.getSelectedValuesList();
        for (Contact contact : selected) {
            contactManager.removeContactFromGroup(contact.getID(), group.getId());
        }
        loadContacts();
    }

    private void removeAllFromGroup() {
        for (int i = 0; i < groupContactsModel.size(); i++) {
            Contact contact = groupContactsModel.getElementAt(i);
            contactManager.removeContactFromGroup(contact.getID(), group.getId());
        }
        loadContacts();
    }

    private void saveChanges() {
        String newName = groupNameField.getText().trim();
        if (newName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "分组名称不能为空!", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String oldName = group.getName();
        group.setName(newName);
        group.setDescription(descriptionArea.getText().trim());

        // 更新所有组内联系人中存储的分组名称
        if (!newName.equals(oldName)) {
            for (String contactId : group.getContactIDs()) {
                Contact contact = contactManager.getContact(contactId);
                if (contact != null) {
                    contact.removeGroup(oldName);
                    contact.addGroup(newName);
                }
            }
        }

        contactManager.saveData();
        JOptionPane.showMessageDialog(this, "分组修改成功!", "成功", JOptionPane.INFORMATION_MESSAGE);
        dispose();
    }
}
