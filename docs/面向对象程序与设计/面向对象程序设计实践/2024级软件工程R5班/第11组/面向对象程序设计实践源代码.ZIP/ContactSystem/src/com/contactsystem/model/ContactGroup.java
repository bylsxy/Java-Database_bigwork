package com.contactsystem.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

public class ContactGroup implements Comparable<ContactGroup>, Serializable {
    private static final long serialVersionUID = 1L;
    private String id;
    private String name;
    private String description;
    private Set<String> contactIDs;

    public ContactGroup() {
        this.id=String.valueOf(System.currentTimeMillis());
        this.contactIDs = new HashSet<>();
    }

    public ContactGroup(String name) {
        this();
        this.name=name;
    }

    public ContactGroup(String name, String description) {
        this();
        this.name=name;
        this.description=description;
    }
    public String getId() {return id;}
    public void setId(String id) {this.id = id;}

    public String getName() {return name;}
    public void setName(String name) {this.name = name;}

    public String getDescription() {return description;}
    public void setDescription(String description) {this.description = description;}

    public Set<String> getContactIDs() {return contactIDs;}
    public void setContactIDs(Set<String> contactIDs) {this.contactIDs = contactIDs;}

    public void addContact(String contactID) {
        contactIDs.add(contactID);
    }

    public void removeContact(String contactID) {
        contactIDs.remove(contactID);
    }

    public boolean containsContact(String contactID) {
        return contactIDs.contains(contactID);
    }

    public int getContactCount() {
        return contactIDs.size();
    }

    @Override
    public int compareTo(ContactGroup other) {
        return this.name.compareTo(other.name);
    }

    @Override
    public boolean equals(Object o) {
        if(this == o) return true;
        if(o == null || getClass() != o.getClass()) return false;
        ContactGroup that = (ContactGroup) o;
        return id.equals(that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return name + "(" +contactIDs.size() + "人)";
    }
}