package com.contactsystem.util;

import net.sourceforge.pinyin4j.PinyinHelper;
import net.sourceforge.pinyin4j.format.HanyuPinyinCaseType;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;

public class PinYinUtil {

    private static boolean pinyinAvailable = true;

    static {
        try {
            Class.forName("net.sourceforge.pinyin4j.PinyinHelper");
        } catch (ClassNotFoundException e) {
            pinyinAvailable = false;
            System.err.println("拼音库(pinyin4j)未找到，拼音搜索功能将有限制");
        }
    }

    /**
     * 获取汉字字符串的拼音全拼，库不可用时返回原字符串的小写
     */
    public static String getFullPinyin(String chinese) {
        if (!pinyinAvailable || chinese == null || chinese.trim().isEmpty()) {
            return chinese != null ? chinese.toLowerCase().replaceAll("[^a-z]", "") : "";
        }

        HanyuPinyinOutputFormat format = new HanyuPinyinOutputFormat();
        format.setCaseType(HanyuPinyinCaseType.LOWERCASE);
        format.setToneType(HanyuPinyinToneType.WITHOUT_TONE);

        StringBuilder pinyin = new StringBuilder();
        char[] chars = chinese.toCharArray();

        for (char c : chars) {
            if (Character.toString(c).matches("[\\u4E00-\\u9FA5]")) {
                try {
                    String[] pinyinArray = PinyinHelper.toHanyuPinyinStringArray(c, format);
                    if (pinyinArray != null && pinyinArray.length > 0) {
                        pinyin.append(pinyinArray[0]);
                    }
                } catch (Exception e) {
                    // BadHanyuPinyinOutputFormatCombination or other pinyin4j errors
                    pinyin.append(c);
                }
            } else if (Character.isLetter(c)) {
                pinyin.append(Character.toLowerCase(c));
            }
        }

        return pinyin.toString();
    }

    /**
     * 获取汉字字符串的拼音首字母，库不可用时返回英文首字母
     */
    public static String getInitials(String chinese) {
        if (!pinyinAvailable || chinese == null || chinese.trim().isEmpty()) {
            if (chinese != null && chinese.length() > 0 && Character.isLetter(chinese.charAt(0))) {
                return String.valueOf(Character.toLowerCase(chinese.charAt(0)));
            }
            return "";
        }

        HanyuPinyinOutputFormat format = new HanyuPinyinOutputFormat();
        format.setCaseType(HanyuPinyinCaseType.LOWERCASE);
        format.setToneType(HanyuPinyinToneType.WITHOUT_TONE);

        StringBuilder initials = new StringBuilder();
        char[] chars = chinese.toCharArray();

        for (char c : chars) {
            if (Character.toString(c).matches("[\\u4E00-\\u9FA5]")) {
                try {
                    String[] pinyinArray = PinyinHelper.toHanyuPinyinStringArray(c, format);
                    if (pinyinArray != null && pinyinArray.length > 0) {
                        initials.append(pinyinArray[0].charAt(0));
                    }
                } catch (Exception e) {
                    // pinyin4j error, skip
                }
            } else if (Character.isLetter(c)) {
                initials.append(Character.toLowerCase(c));
            }
        }

        return initials.toString();
    }

    /**
     * 判断字符串是否包含中文
     */
    public static boolean containsChinese(String str) {
        if (str == null) return false;
        for (char c : str.toCharArray()) {
            if (Character.toString(c).matches("[\\u4E00-\\u9FA5]")) {
                return true;
            }
        }
        return false;
    }
}