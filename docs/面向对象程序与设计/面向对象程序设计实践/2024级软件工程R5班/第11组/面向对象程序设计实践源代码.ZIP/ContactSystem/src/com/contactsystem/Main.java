package com.contactsystem;

import com.contactsystem.ui.MainFrame;
import javax.swing.*;
import java.awt.Font;

public class Main {
    public static void main(String[] args) {// 设置外观
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        setChineseFont();// 设置中文字体

        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }

    private static void setChineseFont() {// 尝试设置中文字体
        String[] fontNames = {"Microsoft YaHei", "SimSun", "SimHei", "KaiTi", "NSimSun"};
        Font font = null;

        for (String fontName : fontNames) {
            font = new Font(fontName, Font.PLAIN, 12);
            if (font.getFamily().equals(fontName)) {
                break;
            }
        }

        if (font != null) {
            UIManager.put("Label.font", font);
            UIManager.put("Button.font", font);
            UIManager.put("TextField.font", font);
            UIManager.put("TextArea.font", font);
            UIManager.put("ComboBox.font", font);
            UIManager.put("List.font", font);
            UIManager.put("Table.font", font);
            UIManager.put("Tree.font", font);
            UIManager.put("Menu.font", font);
            UIManager.put("MenuItem.font", font);
        }
    }
}
