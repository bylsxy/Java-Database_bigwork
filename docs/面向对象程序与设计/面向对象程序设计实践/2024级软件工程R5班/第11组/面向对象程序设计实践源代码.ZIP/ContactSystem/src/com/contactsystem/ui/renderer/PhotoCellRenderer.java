package com.contactsystem.ui.renderer;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.imageio.ImageIO;

public class PhotoCellRenderer extends DefaultTableCellRenderer {

    private static final int THUMB_SIZE = 32;
    private static final int MAX_CACHE = 50;
    private static final Map<String, ImageIcon> cache = new LinkedHashMap<String, ImageIcon>() {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, ImageIcon> eldest) {
            return size() > MAX_CACHE;
        }
    };

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value,
                                                    boolean isSelected, boolean hasFocus,
                                                    int row, int column) {
        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        setText("");
        setHorizontalAlignment(SwingConstants.CENTER);

        if (value instanceof String && !((String) value).isEmpty()) {
            String path = (String) value;
            ImageIcon icon = cache.get(path);
            if (icon == null) {
                icon = loadThumbnail(path);
                if (icon != null) {
                    cache.put(path, icon);
                }
            }
            setIcon(icon != null ? icon : null);
        } else {
            setIcon(null);
        }
        return this;
    }

    private ImageIcon loadThumbnail(String path) {
        try {
            File file = new File(path);
            if (!file.exists()) return null;
            BufferedImage img = ImageIO.read(file);
            if (img != null) {
                int w = img.getWidth(), h = img.getHeight();
                double ratio = Math.min((double) THUMB_SIZE / w, (double) THUMB_SIZE / h);
                Image scaled = img.getScaledInstance(
                        (int) (w * ratio), (int) (h * ratio), Image.SCALE_SMOOTH);
                return new ImageIcon(scaled);
            }
        } catch (IOException e) {
            // ignore
        }
        return null;
    }
}