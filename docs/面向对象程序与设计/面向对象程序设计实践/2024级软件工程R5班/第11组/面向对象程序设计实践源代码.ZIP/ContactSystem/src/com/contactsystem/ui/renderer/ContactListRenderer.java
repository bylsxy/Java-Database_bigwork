package com.contactsystem.ui.renderer;

import com.contactsystem.model.Contact;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class ContactListRenderer extends DefaultListCellRenderer {

    private static final int AVATAR_SIZE = 24;

    @Override
    public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                   boolean isSelected, boolean cellHasFocus) {
        super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

        if (value instanceof Contact) {
            Contact contact = (Contact) value;
            String display = contact.getName();
            if (contact.getMobile() != null && !contact.getMobile().isEmpty()) {
                display += "  [" + contact.getMobile() + "]";
            }
            if (contact.getEmail() != null && !contact.getEmail().isEmpty()) {
                display += "  <" + contact.getEmail() + ">";
            }
            setText(display);

            // 显示小头像
            Icon avatar = loadAvatar(contact.getPhotoPath());
            setIcon(avatar != null ? avatar : null);
        }

        return this;
    }

    private Icon loadAvatar(String photoPath) {
        if (photoPath == null || photoPath.isEmpty()) {
            return null;
        }
        try {
            File file = new File(photoPath);
            if (!file.exists()) return null;
            BufferedImage img = ImageIO.read(file);
            if (img != null) {
                int w = img.getWidth();
                int h = img.getHeight();
                double ratio = Math.min((double) AVATAR_SIZE / w, (double) AVATAR_SIZE / h);
                Image scaled = img.getScaledInstance(
                        (int) (w * ratio), (int) (h * ratio), Image.SCALE_SMOOTH);
                return new ImageIcon(scaled);
            }
        } catch (IOException e) {
            // ignore
        }
        return null;
    }
}